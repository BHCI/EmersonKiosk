/* Image manager */
(function (){
	
	var FWDImageManager = function(data, parent){
		
		var self = this;
		var prototype = FWDImageManager.prototype;
		
		this.toolTipLeft_img = data.toolTipLeft_img;
		this.toolTipPointer_img = data.toolTipPointer_img;
		
		this.playListData_ar = data.playListData_ar;
		this.images_ar = data.images_ar;
		this.smallDos_ar = [];
		this.markers_ar = [];
		this.markersList_ar = data.markersList_ar;
		this.markersPosition_ar = data.markersPosition_ar;
		this.largeImagesPaths_ar = data.largeImagesPaths_ar;
		
		this.curMarker_do;
		this.markersToolTip_do;
		this.markersToolTipWindow_do;
		this.hider;
		this.prevSmall_sdo;
		this.largeImage_img;
		this.dumy_sdo;
		this.mainImagesHolder_do;
		this.smallImage_sdo;
		this.largeImage_sdo;
		this.left_sdo;
		this.top_sdo;
		this.right_sdo;
		this.bottom_sdo;
		this.markersPositionInfo_sdo;
		
		this.handMovePath_str =  data.handMovePath_str;
		
		this.backgroundColor_str = parent.backgroundColor_str;
		this.draggingMode_str = data.startDraggingMode_str;
		this.controllerPosition_str = data.controllerPosition_str;
		this.buttonToolTipLeft_str = data.buttonToolTipLeft_str;
		this.buttonToolTipMiddle_str = data.buttonToolTipMiddle_str;
		this.buttonToolTipRight_str = data.buttonToolTipRight_str;
		this.buttonToolTipFontColor_str = data.buttonToolTipFontColor_str;
		this.buttonToolTipBottomPointer_str = data.buttonToolTipBottomPointer_str;
		this.buttonToolTipTopPointer_str = data.buttonToolTipTopPointer_str;
		this.lastMarkerId_str;
		this.swipeDirection_str;
		
		this.curId = data.startAtImage;
		this.prevId = 1000;
		this.curLargeImageId = 1000;
		this.totalImages = data.totalImages;
		this.stageWidth;
		this.stageHeight;
		this.smallestPossibleScale;
		this.currentScale = 1;
		this.prevScale = 0;
		this.percentZoomed = 0.1;
		this.imageWidth = data.imageWidth;
		this.imageHeight = data.imageHeight;
		this.zoomFactor = data.zoomFactor;
		this.zoomSpeed = .1;
		this.finalX = 0;
		this.finalY = 0;
		this.xPositionOnPress;
		this.yPositionOnPress;
		this.lastPresedX = 0;
		this.lastPresedY = 0;
		this.lastPresedX2 = 0;
		this.lastPresedY2 = 0;
		this.mouseX = 0;
		this.mouseY = 0;
		this.controllerHeight = data.controllerHeight;
		this.rotationSpeed = Math.abs(-1.1 + data.dragRotationSpeed);
		this.startScaleForMobileZoom;
		this.totalMarkers;
		this.globalX;
		this.globalY;
		this.markerToolTipOffsetY = data.markerToolTipOffsetY;
		this.toolTipWindowMaxWidth = data.toolTipWindowMaxWidth;
		this.swipeDragDist = 0;
		this.currentDist = 0;
		this.spinDist = 10;
		this.dragAndSpinSpeed = data.dragAndSpinSpeed;
		
		this.tweenDone_to;
		this.removeSmallSDOId_to;
		this.setAlphaWithDelayId_to;
		this.hideToolTipWindowId_to;
		this.addHideToolTipWindowTestWithDelayId_to;
		this.showToolTipWindoId_to;
		this.showMarkerToolTipId_to;
		this.dragAndSpinId_int;
		
		this.allImagesAreLoaded_bl = false;
		this.allowToDragHoriz_bl = false;
		this.allowToDragVert_bl = false;
		this.isTweening_bl = false;
		this.isDragging_bl = false;
		this.isRotatingFirstTime_bl = true;
		this.addCorrectionForWebKit_bl = data.addCorrectionForWebKit_bl;
		this.disablePanOrRotate_bl = false;
		this.useEntireScreenFor3dObject_bl = data.useEntireScreenFor3dObject_bl;
		this.stopRotationAtEnds_bl = data.stopRotationAtEnds_bl;
		this.isMobile_bl = data.isMobile_bl;
		this.isLargeImageLoaded_bl = false;
		this.showNavigator_bl = data.showNavigator_bl;
		this.showMarkers_bl = data.showMarkers_bl;
		this.isNavigatorShowed_bl = false;
		this.addImageFirstTimeOnActivate_bl = true;
		this.showMarkersInfo_bl = data.showMarkersInfo_bl;
		this.addDragAndSpinSupport_bl = data.addDragAndSpinSupport_bl;
		this.isMobile_bl = data.isMobile_bl;
		this.firstInteractionOccured_bl = false;
		this.isSwiping_bl = false;
		this.showLargeImageVersionOnZoom_bl = data.showLargeImageVersionOnZoom_bl;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		
		self.init = function(){
			if(self.controllerPosition_str == FWDController.POSITION_TOP && !self.useEntireScreenFor3dObject_bl) self.setY(self.controllerHeight);
			self.setupMainContiners();
			self.setupDumy();
			
			if(self.showMarkers_bl){
				self.setupMarkers();
				if(!self.isMobile_bl || self.hasPointerEvent_bl) self.setupMarkersToolTip();
				self.setupMarkersToolTipWindow();
			}
		};
		
		//##########################################//
		//Setup hider.
		//##########################################//
		self.setupHider = function(hider){
			self.hider = hider;
		};
		
		//###########################################//
		//Setup main containers
		//###########################################//
		self.setupMainContiners = function(){
			self.setOverflow("visible");
			self.setBkColor(self.backgroundColor_str);
			self.largeImage_img = new Image();
		
			self.mainImagesHolder_do =  new FWDDisplayObject("div", "absolute", "visible");
			self.smallImage_sdo = new FWDSimpleDisplayObject("img");
			self.largeImage_sdo = new FWDSimpleDisplayObject("img");
			self.addChild(self.mainImagesHolder_do);
			
			if(self.addCorrectionForWebKit_bl) self.setupCorrectionLinesForChrome();
		};
		
		
		
		//###########################################//
		//Setup correction lines for chrome.
		//###########################################//
		self.setupCorrectionLinesForChrome = function(){
			
			self.left_sdo = new FWDSimpleDisplayObject("div");
			self.top_sdo = new FWDSimpleDisplayObject("div");
			self.right_sdo = new FWDSimpleDisplayObject("div");
			self.bottom_sdo = new FWDSimpleDisplayObject("div");
			
			self.left_sdo.setBkColor(self.backgroundColor_str);
			self.top_sdo.setBkColor(self.backgroundColor_str);
			self.right_sdo.setBkColor(self.backgroundColor_str);
			self.bottom_sdo.setBkColor(self.backgroundColor_str);
			
			self.left_sdo.setWidth(1);
			self.top_sdo.setHeight(1);
			self.right_sdo.setWidth(2);
			self.bottom_sdo.setHeight(2);
			
			self.addChild(self.left_sdo);
			self.addChild(self.top_sdo);
			self.addChild(self.right_sdo);
			self.addChild(self.bottom_sdo);
		};
		
		self.resizeAndPositionCorrectionLines = function(animate){
		
			TweenMax.killTweensOf(self.left_sdo);
			TweenMax.killTweensOf(self.top_sdo);
			TweenMax.killTweensOf(self.right_sdo);
			TweenMax.killTweensOf(self.bottom_sdo);
		
			if(animate){
				TweenMax.to(self.left_sdo, .2, {x:self.finalX, y:self.finalY, h:self.finalHeight});
				TweenMax.to(self.top_sdo, .2, {x:self.finalX, y:self.finalY, w:self.finalWidth});
				TweenMax.to(self.right_sdo, .2, {x:self.finalX + self.finalWidth - 2, y:self.finalY, h:self.finalHeight});
				TweenMax.to(self.bottom_sdo, .2, {x:self.finalX, y:self.finalY  + self.finalHeight - 2, w:self.finalWidth});
			}else{
				self.left_sdo.setX(self.finalX - 1);
				self.left_sdo.setY(self.finalY);
				self.left_sdo.setHeight(self.finalHeight);
				
				self.top_sdo.setX(self.finalX);
				self.top_sdo.setY(self.finalY - 1);
				self.top_sdo.setWidth(self.finalWidth);
				
				self.right_sdo.setX(self.finalX + self.finalWidth - 2);
				self.right_sdo.setY(self.finalY);
				self.right_sdo.setHeight(self.finalHeight);
				
				self.bottom_sdo.setX(self.finalX);
				self.bottom_sdo.setY(self.finalY  + self.finalHeight - 2);
				self.bottom_sdo.setWidth(self.finalWidth);
			}
		};
		
		//###########################################//
		// Resize and position self...
		//###########################################//
		self.resizeAndPosition = function(centerImage_bl){
			
			if(self.stageWidth == parent.stageWidth && self.stageHeight == parent.stageHeight - self.controllerHeight) return;
			
			self.stageWidth = parent.stageWidth;
			if(self.useEntireScreenFor3dObject_bl){
				self.stageHeight = parent.stageHeight;
			}else{
				self.stageHeight = parent.stageHeight - self.controllerHeight;
			}
			
			self.setWidth(self.stageWidth);
			self.setHeight(self.stageHeight);
			
			if(self.allImagesAreLoaded_bl){
				self.resizeAndPositionAfterAllLoad();
				if(centerImage_bl) self.centerImage();
				if(self.showNavigator_bl){
					self.hideOrShowNavigator();
					self.updateNavigator(false);
				}
				
				self.positionMarkers();
			}else{
				self.resiezeAndPositionIfNotAllImagesAreLoaded();
			}
		};
		
		self.resiezeAndPositionIfNotAllImagesAreLoaded = function(){
			var scX = self.stageWidth/self.imageWidth;
			var scY = self.stageHeight/self.imageHeight;
			var totalScale;
			
			if(scX < scY){
				totalScale = scX;
			}else{
				totalScale = scY;
			}

			if(totalScale > 1) totalScale = 1;
			
			self.currentScale = self.prevScale = self.smallestPossibleScale = totalScale;
			
			self.finalWidth = Math.round(self.currentScale * self.imageWidth);
			self.finalHeight = Math.round(self.currentScale * self.imageHeight);
			self.finalX =  Math.round((self.stageWidth - self.finalWidth)/2);
			self.finalY =  Math.round((self.stageHeight - self.finalHeight)/2);	
			self.resizeAndPositionSmallImage(false);
		};
		
		//#################################################//
		//Show images while they are loaded
		//#################################################//
		self.showLoadedImage = function(id){
			self.smallImage_sdo = new FWDSimpleDisplayObject("img");
			self.smallImage_sdo.setScreen(self.images_ar[id]);
			if(FWDUtils.isAndroid) self.smallImage_sdo.setBackfaceVisibility();
			self.smallDos_ar[id] = self.smallImage_sdo;
			self.mainImagesHolder_do.addChild(self.smallImage_sdo);
			
			self.removeSmallSDOId_to = setTimeout(function(){
						if(self == null) return; 
						if(id > 0) self.smallDos_ar[id - 1].setVisible(false);
					}
				, 40);
			self.resizeAndPosition();
			self.resiezeAndPositionIfNotAllImagesAreLoaded();
			
		};
		
		//##############################################################################################//
		//initlaize this after all iamges are loaded...
		//##############################################################################################//
		self.activate = function(){
			self.allImagesAreLoaded_bl = true;
			self.addSmallImage();
			self.addLargeImage();
			self.resizeAndPositionAfterAllLoad();
			self.addPannSupport();
			self.addRotationSupport();
			self.addPinchSupport();
			self.addMouseWheelSupport();
			self.showOrHideMarkers();
			self.positionMarkers(false);
			if(self.showMarkersInfo_bl) self.setupMarkersInfo();
		};
		
		//################################################//
		/* setup dumy */
		//################################################//
		self.setupDumy = function(){
			self.dumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE) self.dumy_sdo.getStyle().background = "url('dumy')";
			if(!self.showMarkersInfo_bl) self.dumy_sdo.getStyle().cursor = 'url(' + self.handMovePath_str + '), default';
			self.addChild(self.dumy_sdo);
		};
		
		//################################################//
		//add small and large image.
		//################################################//
		self.addSmallImage = function(){
			if(self.curId == self.prevId) return;
			self.prevId = self.curId;
			self.curLargeImageId = 1000;
			
			if(self.addImageFirstTimeOnActivate_bl){
				self.removeSmallSDOId_to = setTimeout(function(){
						if(self == null) return;
						self.smallImage_sdo.setVisible(false);
						self.smallImage_sdo = self.smallDos_ar[self.curId];
						self.smallImage_sdo.setVisible(true);
						self.resizeAndPositionAfterAllLoad();
					}
				, 40);
			}
			
			clearTimeout(self.setAlphaWithDelayId_to);
			
			if(self.largeImage_img){
				self.largeImage_img.onload = null;
				self.largeImage_img.onerror = null;
				if(!FWDUtils.isIEAndLessThen9) self.largeImage_img.src = null;
			}
			
			if(self.mainImagesHolder_do.contains(self.largeImage_sdo)) self.mainImagesHolder_do.removeChild(self.largeImage_sdo);
			
			if(!self.addImageFirstTimeOnActivate_bl){
				self.smallImage_sdo.setVisible(false);
				self.smallImage_sdo = self.smallDos_ar[self.curId];
				self.smallImage_sdo.setVisible(true);
			}
			self.addImageFirstTimeOnActivate_bl = false;
		};
		
		self.removeWithDelay = function(){
			while(self.mainImagesHolder_do.getNumChildren() > 1){
				self.mainImagesHolder_do.removeChildAtZero(0);
			}
		};
		
		self.addLargeImage = function(){	
			if(!self.showLargeImageVersionOnZoom_bl) return;
			if(self.currentScale <= 1) return;
			if(self.curLargeImageId ==  self.curId) return;
			self.isLargeImageLoaded_bl = false;
			self.curLargeImageId = self.curId;
			clearTimeout(self.setAlphaWithDelayId_to);
			
			if(self.mainImagesHolder_do.contains(self.largeImage_sdo)) self.mainImagesHolder_do.removeChild(self.largeImage_sdo);
			
			if(self.largeImage_img){	
				self.largeImage_img.onload = null;
				self.largeImage_img.onerror = null;
				if(!FWDUtils.isIEAndLessThen9) self.largeImage_img.src = null;
			}
			
			self.largeImage_img.src = self.largeImagesPaths_ar[self.curId];
			self.largeImage_img.onload = self.largeImageLoadHandler;
			self.largeImage_img.onerror = self.largeImageErrorHandler;
			self.largeImage_sdo.setScreen(self.largeImage_img);
			self.largeImage_sdo.setAlpha(0);
			self.mainImagesHolder_do.addChild(self.largeImage_sdo);
		};
		
		self.largeImageErrorHandler = function(){
			var error = "The large image labeled <font color='#FFFFFF'>" + self.largeImagesPaths_ar[self.curId] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			self.dispatchEvent(FWDImageManager.LARGE_IMAGE_LOAD_ERROR, {error:error});
		};
		
		self.largeImageLoadHandler = function(){
			self.isLargeImageLoaded_bl = true;
			self.setAlphaWithDelayId_to = setTimeout(function(){
				//self.smallImage_sdo.setVisible(false);
				self.largeImage_sdo.setAlpha(1);
			}, 100);
			self.largeImage_sdo.setWidth(self.finalWidth);
			self.largeImage_sdo.setHeight(self.finalHeight);
		};
		
		self.gotoImage = function(){
			if(self.stopRotationAtEnds_bl){
				if(self.curId < 0){
					self.curId = 0;
				}else if(self.curId > self.totalImages - 1){
					self.curId = self.totalImages - 1;
				}
			}else{
				if(self.curId > self.totalImages - 1){
					self.curId = 0;
				}else if(self.curId < 0){
					self.curId = self.totalImages - 1;
				}
			}
				
			
			self.addSmallImage();
			self.resizeAndPositionAfterAllLoad();
			if(!self.isSwiping_bl){
				self.showOrHideMarkers();
				self.positionMarkers();
			}
			self.dispatchEvent(FWDImageManager.ROTATE_UPDATE, {id:self.curId});
		};
		
		//###################################################//
		// resize handler after all images are loaded
		//##################################################//
		self.resizeAndPositionAfterAllLoad = function(){
			var scX = self.stageWidth/self.imageWidth;
			var scY = self.stageHeight/self.imageHeight;
			var totalScale;
			
			if(scX < scY){
				totalScale = scX;
			}else{
				totalScale = scY;
			}

			self.smallestPossibleScale = totalScale;
		
			if(totalScale >= 1) self.smallestPossibleScale  = 1;
			
			if(self.currentScale <= 1 ){
				if(scX > scY  && self.finalHeight <= self.stageHeight){
					 self.currentScale = self.smallestPossibleScale;
				}else if(scX < scY  && self.finalWidth <= self.stageWidth){
					 self.currentScale = self.smallestPossibleScale;
				}
			}
			
			self.finalWidth = Math.round(self.currentScale * self.imageWidth);
			self.finalHeight = Math.round(self.currentScale * self.imageHeight);
			
			
			self.setWidth(self.stageWidth);
			self.dumy_sdo.setWidth(self.stageWidth);
			if(self.useEntireScreenFor3dObject_bl){
				self.setHeight(self.stageHeight);
				self.dumy_sdo.setHeight(self.stageHeight);
			}else{
				self.setHeight(self.stageHeight + self.controllerHeight);
				self.dumy_sdo.setHeight(self.stageHeight + self.controllerHeight);
			}
		
			self.checkXAndYBouds();
			self.resizeAndPositionSmallImage(false);
			self.resizeAndPositionLargeImage(false);
			if(self.addCorrectionForWebKit_bl) self.resizeAndPositionCorrectionLines(false);
			self.dispatchScrollBarUpdate(false);
			//self.positionMarkers();
		};
		
		//###############################################//
		//resize and position small image and large image.
		//###############################################//
		self.resizeAndPositionSmallImage = function(animate){
			self.isTweening_bl = true;
			TweenMax.killTweensOf(self.mainImagesHolder_do);
			TweenMax.killTweensOf(self.smallImage_sdo);
			clearTimeout(self.tweenDone_to);
			if(animate){
				TweenMax.to(self.mainImagesHolder_do, .2, {x:self.finalX, y:self.finalY});
				TweenMax.to(self.smallImage_sdo, .2, {w:self.finalWidth, h:self.finalHeight});
				self.tweenDone_to = setTimeout(self.tweenDoneHandler, 200);
			}else{
				self.mainImagesHolder_do.setX(self.finalX);
				self.mainImagesHolder_do.setY(self.finalY);
				self.smallImage_sdo.setWidth(self.finalWidth);
				self.smallImage_sdo.setHeight(self.finalHeight);
				self.isTweening_bl = false;
				self.dispatchEvent(FWDImageManager.IMAGE_ZOOM_COMPLETE);
			}
		};
		
		self.resizeAndPositionLargeImage = function(animate){
			if(!self.showLargeImageVersionOnZoom_bl || !self.isLargeImageLoaded_bl) return;
			TweenMax.killTweensOf(self.largeImage_sdo);
			if(animate){
				TweenMax.to(self.largeImage_sdo, .2, {w:self.finalWidth, h:self.finalHeight});
			}else{
				self.largeImage_sdo.setWidth(self.finalWidth);
				self.largeImage_sdo.setHeight(self.finalHeight);
			}
		};
		
		self.tweenDoneHandler = function(){
			self.isTweening_bl = false;
			self.addLargeImage();
			self.resizeAndPositionLargeImage();
			self.dispatchEvent(FWDImageManager.IMAGE_ZOOM_COMPLETE);
		};
		
		//###############################################//
		/* check x and y position */
		//##############################################//
		self.checkXAndYBouds = function(){
			if(self.finalWidth <= self.stageWidth){
				self.finalX = Math.round((self.stageWidth - self.finalWidth)/2);
			}else if(self.finalWidth > self.stageWidth + 1){
				self.allowToDragHoriz_bl = true;	
				if(self.finalX > 0){
					self.finalX = 0;
				}else if(self.finalX <= self.stageWidth - self.finalWidth + 1){
					self.finalX = self.stageWidth - self.finalWidth + 1;
				}
			}else{
				self.allowToDragHoriz_bl = false;
			}
			
			if(self.finalHeight <= self.stageHeight ){
				self.finalY = Math.round((self.stageHeight - self.finalHeight)/2);
			}else if(self.finalHeight > self.stageHeight + 1){
				self.allowToDragVert_bl = true;
				if(self.finalY > 0){
					self.finalY = 0;
				}else if(self.finalY <= self.stageHeight - self.finalHeight){
					self.finalY = self.stageHeight - self.finalHeight;
				}
			}else{
				self.allowToDragVert_bl = false;
			}
		};
		
		//################################################//
		/* zoom image */
		//################################################//
		self.zoomImage = function(setPositionAndSize){
			
			if(setPositionAndSize){
				self.finalWidth = Math.round(self.currentScale * self.imageWidth);
				self.finalHeight =  Math.round(self.currentScale * self.imageHeight);
				self.finalX -= Math.round((self.mouseX - self.finalX) * (self.currentScale - self.prevScale) / self.prevScale); 
				self.finalY -= Math.round((self.mouseY - self.finalY) * (self.currentScale - self.prevScale) / self.prevScale); 	
			}
			
			self.dispatchScrollBarUpdate(true);
			self.checkXAndYBouds();
			self.resizeAndPositionSmallImage(true);
			self.resizeAndPositionLargeImage(true);
			if(self.addCorrectionForWebKit_bl) self.resizeAndPositionCorrectionLines(true);
			if(self.showNavigator_bl){
				self.hideOrShowNavigator();
				self.updateNavigator(true);
			}
			self.positionMarkers(true);
			self.prevScale = self.currentScale;
		};
			
		//###############################################//
		/* setup pinch */
		//###############################################//
		self.addPinchSupport = function(){
			if(self.screen.addEventListener){
				self.screen.addEventListener('gesturestart', this.gestureStartHandler);
				self.screen.addEventListener('gesturechange', this.gestureChangeHandler);
			}
		};
		
		self.gestureStartHandler = function(e){
			self.startScaleForMobileZoom = 1;
		};
		
		self.gestureChangeHandler = function(e){	
			e.preventDefault();	
			
			if(self.disablePanOrRotate_bl) return;
			var toAdd;
			
			if(e.scale > 1){
				toAdd = e.scale - self.startScaleForMobileZoom;
			}else{
				toAdd = - (self.startScaleForMobileZoom - e.scale);
			}
			
			self.startScaleForMobileZoom = 1;
			
			self.mouseX = Math.round(self.stageWidth/2);
			self.mouseY = Math.round(self.stageHeight/2);
			self.currentScale +=  toAdd;
			self.startScaleForMobileZoom = e.scale;
			
			if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))){
				self.currentScale = self.smallestPossibleScale;
			}else if(self.currentScale > self.zoomFactor){
				 self.currentScale = self.zoomFactor;
			}
			
			self.zoomImage(true);
		};
		
		//###############################################//
		//Add touch pann support
		//###############################################//
		self.addPannSupport = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.dumy_sdo.screen.addEventListener("MSPointerDown", self.panStartHandler);
				}else{
					self.dumy_sdo.screen.addEventListener("touchstart", self.panStartHandler);
				}
			}else if(self.screen.addEventListener){
				self.dumy_sdo.screen.addEventListener("mousedown", self.panStartHandler);
			}else if(self.screen.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousedown", self.panStartHandler);
			}
		};
		
		self.panStartHandler = function(e){
			if(self.draggingMode_str != FWDImageManager.PAN || self.isTweening_bl || self.disablePanOrRotate_bl) return;
			if(e.preventDefault) e.preventDefault();
			if(self.finalWidth < self.stageWidth && self.finalHeight < self.stageHeight) return;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.showPanDumy();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			self.isDragging_bl = true;
			self.xPositionOnPress = self.mainImagesHolder_do.getX();
			self.yPositionOnPress = self.mainImagesHolder_do.getY();
			self.lastPresedX = viewportMouseCoordinates.screenX;
			self.lastPresedY = viewportMouseCoordinates.screenY;
			
			self.dispatchEvent(FWDImageManager.PAN_START);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.panMoveHandler);
					window.addEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.addEventListener("touchmove", self.panMoveHandler);
					window.addEventListener("touchend", self.panEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.panMoveHandler);
					window.addEventListener("mouseup", self.panEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.panMoveHandler);
					document.attachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		self.panMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(e.touches && e.touches.length != 1 || self.disablePanOrRotate_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
		
			if(self.finalWidth > self.stageWidth + 1){
				self.finalX = Math.round(self.xPositionOnPress + viewportMouseCoordinates.screenX - self.lastPresedX);
				if(self.finalX > 0){
					self.finalX = 0;
				}else if(self.finalX <= self.stageWidth - self.finalWidth + 1){
					self.finalX = self.stageWidth - self.finalWidth + 1;
				}
				self.mainImagesHolder_do.setX(self.finalX);
			}
			
			if(self.finalHeight > self.stageHeight + 1){
				self.finalY = Math.round(self.yPositionOnPress + viewportMouseCoordinates.screenY - self.lastPresedY);
				if(self.finalY > 0){
					self.finalY = 0;
				}else if(self.finalY <= self.stageHeight - self.finalHeight){
					self.finalY = self.stageHeight - self.finalHeight;
				}
				self.mainImagesHolder_do.setY(self.finalY);
			}
			
			if(self.showNavigator_bl){
				self.hideOrShowNavigator();
				self.updateNavigator(false);
			}
			
			self.positionMarkers(false);
		};
		
		self.panEndHandler = function(e){
			self.isDragging_bl = false;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.hidePanDumy();
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.panMoveHandler);
					window.removeEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.removeEventListener("touchmove", self.panMoveHandler);
					window.removeEventListener("touchend", self.panEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.panMoveHandler);
					window.removeEventListener("mouseup", self.panEndHandler);	
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.panMoveHandler);
					document.detachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		//###################################################//
		//Rotate image.
		//###################################################//
		self.addRotationSupport = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.dumy_sdo.screen.addEventListener("MSPointerDown", self.rotateStartHandler);
				}else{
					self.dumy_sdo.screen.addEventListener("touchstart", self.rotateStartHandler);
				}
			}else if(self.screen.addEventListener){
				self.dumy_sdo.screen.addEventListener("mousedown", self.rotateStartHandler);
			}else if(self.screen.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousedown", self.rotateStartHandler);
			}
		};
		
		self.rotateStartHandler = function(e){
			if(self.draggingMode_str != FWDImageManager.ROTATE || self.isTweening_bl || self.disablePanOrRotate_bl) return;
			clearInterval(self.dragAndSpinId_int);
			if(e.preventDefault) e.preventDefault();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			self.isDragging_bl = true;
			self.isSwiping_bl = false;
			if(self.markersToolTipWindow_do) self.markersToolTipWindow_do.hide();
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.showRotateDumy();
			self.currentDist = self.lastPresedX = viewportMouseCoordinates.screenX;
			self.showOrHideMarkers();
			self.positionMarkers();
			self.dispatchEvent(FWDImageManager.ROTATE_START);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.rotateMoveHandler);
					window.addEventListener("MSPointerUp", self.rotateEndHandler);
				}else{
					window.addEventListener("touchmove", self.rotateMoveHandler);
					window.addEventListener("touchend", self.rotateEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.rotateMoveHandler);
					window.addEventListener("mouseup", self.rotateEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.rotateMoveHandler);
					document.attachEvent("onmouseup", self.rotateEndHandler);
				}
			}
		};
		
		self.rotateMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if((e.touches && e.touches.length != 1) || self.disablePanOrRotate_bl) return;
			
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			var dif = (viewportMouseCoordinates.screenX - self.lastPresedX)/(80 * self.rotationSpeed); 
			
			self.swipeDragDist = viewportMouseCoordinates.screenX - self.currentDist;
			self.currentDist = viewportMouseCoordinates.screenX;
			
			if(self.isRotatingFirstTime_bl){
				if(dif > 0){
					if(dif != 0) dif = -1;
				}else{
					if(dif != 0) dif = 1;
				}
				self.curId += dif;
				self.gotoImage();
				self.isRotatingFirstTime_bl = false;
				return;
			}
			
			if(Math.abs(dif) >= 1){
				if(dif > 0){
					self.lastPresedX = self.lastPresedX + (80 * self.rotationSpeed);
					if(dif != 0) dif = -1;
				}else{
					self.lastPresedX = self.lastPresedX - (80 * self.rotationSpeed);
					if(dif != 0) dif = 1;
				}
				
				self.curId += dif;
				self.gotoImage();
			}
		};
		
		self.rotateEndHandler = function(e){
			if(Math.abs(self.swipeDragDist) > self.spinDist && self.addDragAndSpinSupport_bl && self.firstInteractionOccured_bl){
				self.startToSwipe();
			}else{
				self.addLargeImage();
			}
			
			self.isDragging_bl = false;
			self.isRotatingFirstTime_bl = true;
			self.firstInteractionOccured_bl  = true;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.hideRotateDumy();
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.rotateMoveHandler);
					window.removeEventListener("MSPointerUp", self.rotateEndHandler);
				}else{
					window.removeEventListener("touchmove", self.rotateMoveHandler);
					window.removeEventListener("touchend", self.rotateEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.rotateMoveHandler);
					window.removeEventListener("mouseup", self.rotateEndHandler);	
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.rotateMoveHandler);
					document.detachEvent("onmouseup", self.rotateEndHandler);
				}
			}
		};
		
		//###############################################//
		/* Swipe */
		//###############################################//
		this.startToSwipe = function(){
			self.isSwiping_bl = true;
			

			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				marker.hide();
			}
			
			self.swipeDirection_str = self.swipeDragDist < 0 ? "left" : "right";
			self.swipeDragDist = Math.abs(self.swipeDragDist/(20 * self.dragAndSpinSpeed));
			self.dragAndSpinId_int = setInterval(self.swipeTweenUpdate, 16);
		};
		
		this.swipeTweenUpdate = function(){
			var steps = 0;
			var sgn;
	
			self.swipeDragDist += (0 - self.swipeDragDist) * 0.07;
			steps = Math.round(self.swipeDragDist);
			if(self.swipeDirection_str == "left"){
				sgn = 1;
			}else{
				sgn = -1;
			}
			self.curId  += steps * sgn;
			
			if(steps == 0){
				self.isSwiping_bl = false;
				clearInterval(self.dragAndSpinId_int);
				self.gotoImage();
				self.addLargeImage();
			}else{
				self.gotoImage();
			}
		};
		
		//###############################################//
		//Add mousewheel support.
		//###############################################//
		self.addMouseWheelSupport = function(){
			if(window.addEventListener){
				self.dumy_sdo.screen.addEventListener ("mousewheel", self.mouseWheelHandler);
				self.dumy_sdo.screen.addEventListener('DOMMouseScroll', self.mouseWheelHandler);
			}else if(document.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousewheel", self.mouseWheelHandler);
			}
		};
		
		self.mouseWheelHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isDragging_bl || self.disablePanOrRotate_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			if(self.hider) self.hider.reset();
			self.mouseX = viewportMouseCoordinates.screenX - self.getGlobalX();
			self.mouseY = viewportMouseCoordinates.screenY - self.getGlobalY();
			
			var dir = e.detail || e.wheelDelta;	
			if(e.wheelDelta) dir *= -1;
			if(FWDUtils.isOpera) dir *= -1;
			
			if(dir > 0){
				self.currentScale -= self.zoomSpeed;
				if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))) self.currentScale = self.smallestPossibleScale;
			}else if(dir < 0){
				self.currentScale += self.zoomSpeed;
				if(self.currentScale > self.zoomFactor) self.currentScale = self.zoomFactor;
			}
			
			self.zoomImage(true);
			
			if(e.preventDefault){
				e.preventDefault();
			}else{
				return false;
			}
		};
		
		//###########################################//
		/* Setup markers */
		//###########################################//
		self.setupMarkers = function(){
			var marker;
			var objData;
			var toolTipId = 0;
			self.totalMarkers = self.markersList_ar.length;
			for(var i=0; i<self.totalMarkers; i++){
				objData = self.markersList_ar[i];
				FWDMarker.setPrototype();
				marker = new FWDMarker(objData.markerId, 
						objData.normalStatePath_str, 
						objData.selectedStatePath_str, 
						objData.type, 
						objData.regPoint, 
						objData.toolTipLabel, 
						objData.markerWidth, 
						objData.markerHeight);
				marker.addListener(FWDMarker.MOUSE_OVER, self.markerOnMouseOverHandler);
				marker.addListener(FWDMarker.MOUSE_OUT, self.markerOnMouseOutHandler);
				marker.addListener(FWDMarker.MOUSE_DOWN, self.markerOnStartHandler);
				
				if(objData.type == "tooltip"){
					marker.toolTipId = toolTipId;
					marker.innerHTML_str = objData.innerHTML;
					marker.toolTipWindowMaxWidth = objData.maxWidth;
				}else if(objData.type == "infowindow"){
					marker.innerHTML_str = objData.innerHTML;
				}else if(objData.type == "link"){
					marker.link_str = objData.link;
					marker.target_str = objData.target;
				}
				self.markers_ar.push(marker);
				self.addChild(marker);
			}
		};
		
		self.markerOnMouseOverHandler = function(e){
			var marker = e.target;
			if(marker.hasToolTip_bl){
				self.showMarkerToolTip(marker, marker.toolTipLabel_str);
			};
			
			if(marker.type_str == "tooltip"){
				if(self.lastMarkerId_str != marker.markerId) self.hideToolTipWindow();
				self.lastMarkerId_str = marker.markerId;
				self.curMarker_do = marker;
				clearTimeout(self.hideToolTipWindowId_to);
				self.showToolTipWindow(marker, marker.innerHTML_str, marker.toolTipWindowMaxWidth);
			}
		};
		
		self.markerOnMouseOutHandler = function(e){
			var marker = e.target;
			if(marker.hasToolTip_bl){
				if(self.markersToolTip_do){
					if(self.contains(self.markersToolTip_do)) self.removeChild(self.markersToolTip_do);
					self.markersToolTip_do.hide();
				}
			};
			
			if(marker.type_str == "tooltip"){
				self.toolTipWindowAddEventsToSetGlobalXAndGlobalY();
				clearTimeout(self.hideToolTipWindowId_to);
				self.hideToolTipWindowId_to = setTimeout(self.hideToolTipWindowWithDelay, 300);
			}
		};
		
		self.markerOnStartHandler = function(e){
			var marker = e.target;
			if(marker.type_str == "infowindow"){
				self.dispatchEvent(FWDImageManager.SHOW_INFO, {text:marker.innerHTML_str});
			}else if(marker.type_str == "tooltip"){	
				if(self.lastMarkerId_str != marker.markerId) self.hideToolTipWindow();
				self.curMarker_do = marker;
				self.lastMarkerId_str = marker.markerId;
				self.toolTipWindowAddEventsToSetGlobalXAndGlobalY();
				self.showToolTipWindow(marker, marker.innerHTML_str, marker.toolTipWindowMaxWidth);
			}
		};
		
		self.showMarkersWithAlphaForChromeFirstTime_bl = true;
		
		//Show or hide markers.
		self.showOrHideMarkers = function(){
			var marker;
			var positionObj = self.markersPosition_ar[self.curId];
			var positonObj2;
			var totalCurMarkers;
			
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				marker.isActive_bl = false;
			}
			
			if(positionObj){
				totalCurMarkers = positionObj.length;
				for(var i=0; i<totalCurMarkers; i++){
					positonObj2 = positionObj[i];
					for(var j=0; j<self.totalMarkers; j++){
						marker = self.markers_ar[j];
						if(positonObj2.markerId == marker.markerId && !marker.isActive_bl){
							marker.originalX = positonObj2.x;
							marker.originalY = positonObj2.y;
							marker.show();
							marker.isActive_bl = true;
						}
					}
				}
			}
			
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				if(!marker.isActive_bl) marker.hide();
				if(marker.isActive_bl && self.showMarkersWithAlphaForChromeFirstTime_bl){
					marker.showOnChromeOnce();
				}
			}
			self.showMarkersWithAlphaForChromeFirstTime_bl = false;	
		};
		
		//position markers.
		self.positionMarkers = function(animate){
			var marker;
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				if(marker.isActive_bl){
					marker.finalX = self.finalX + marker.offsetX + Math.round(marker.originalX * self.currentScale);
					marker.finalY = self.finalY + marker.offsetY + Math.round(marker.originalY * self.currentScale);
					if(animate){
						TweenMax.killTweensOf(marker);
						TweenMax.to(marker, .2, {x:marker.finalX, y:marker.finalY});
					}else{
						TweenMax.killTweensOf(marker);
						marker.setX(marker.finalX);
						marker.setY(marker.finalY);
					}
				}
				
			}
		};
		
		//###########################################//
		/* Setup markers tooltip */
		//###########################################//
		self.setupMarkersToolTip = function(){
			FWDMarkerToolTip.setPrototype();
			self.markersToolTip_do = new FWDMarkerToolTip(
					self.toolTipLeft_img,
					self.toolTipPointer_img,
					self.buttonToolTipLeft_str,
					self.buttonToolTipMiddle_str,
					self.buttonToolTipRight_str,
					self.buttonToolTipFontColor_str,
					self.buttonToolTipTopPointer_str,
					self.buttonToolTipBottomPointer_str);
		};
		
		//###########################################//
		/* Setup markers tooltip window*/
		//###########################################//
		self.setupMarkersToolTipWindow = function(){
			FWDMarkerWindowToolTip.setPrototype();
			self.markersToolTipWindow_do = new FWDMarkerWindowToolTip(
					self,
					self.toolTipPointer_img,
					self.buttonToolTipTopPointer_str,
					self.buttonToolTipBottomPointer_str);
			self.addChild(self.markersToolTipWindow_do);
		};
		
		
		//######################################################//
		/* show tool tip */
		//######################################################//
		self.showMarkerToolTip = function(marker, label){
			var finalX;
			var finalY;
			var globalX = self.getX();
			var pointerOffsetX = 0;
			var pointerPostion;
			
			self.addChild(self.markersToolTip_do);
			self.markersToolTip_do.setLabel(label);
			self.markersToolTip_do.show();
			clearTimeout(self.showMarkerToolTipId_to);
			
			self.showMarkerToolTipId_to = setTimeout(function(){
				if(!self.markersToolTip_do.isShowed_bl) return;
				finalX = parseInt(marker.finalX + (marker.width - self.markersToolTip_do.totalWidth)/2);
				
				finalY = marker.finalY - self.markersToolTip_do.totalHeight - self.markerToolTipOffsetY;
				
				if(finalY < 0){
					finalY = marker.finalY + marker.height + self.markersToolTip_do.pointerHeight + self.markerToolTipOffsetY;
					self.markersToolTip_do.pointerUp_sdo.setVisible(true);
					self.markersToolTip_do.pointerDown_sdo.setVisible(false);
					pointerPostion = FWDMarkerToolTip.POINTER_UP;
				}else{
					self.markersToolTip_do.pointerUp_sdo.setVisible(false);
					self.markersToolTip_do.pointerDown_sdo.setVisible(true);
					pointerPostion = FWDMarkerToolTip.POINTER_DOWN;
				}
				
				if(finalX < 0){
					pointerOffsetX = finalX;
					finalX = 0;
				}else if(self.stageWidth - finalX - self.markersToolTip_do.totalWidth < 0){
					pointerOffsetX = -(self.stageWidth - finalX - self.markersToolTip_do.totalWidth);
					finalX = finalX + self.stageWidth - finalX - self.markersToolTip_do.totalWidth;
				}
			
				self.markersToolTip_do.setX(finalX);
				self.markersToolTip_do.setY(finalY);	
				self.markersToolTip_do.positionPointer(pointerOffsetX, pointerPostion);
			}, 80);
			
		};
			
		//######################################################//
		/* show tool tip window */
		//######################################################//
		self.showToolTipWindow = function(marker, label, maxWidth){
			if(self.markersToolTipWindow_do.toolTipWindowId == marker.toolTipWindowId) return;
			
			var finalX;
			var finalY;
			var globalX = self.getX();
			var pointerOffsetX = 0;
			var pointerPostion;
			
			self.markersToolTipWindow_do.setLabel(label, maxWidth);
			
			self.markersToolTipWindow_do.toolTipWindowId = marker.toolTipWindowId;
			
			clearTimeout(self.showToolTipWindoId_to);
			self.showToolTipWindoId_to = setTimeout(function(){
				finalX = parseInt(marker.finalX + (marker.width - self.markersToolTipWindow_do.totalWidth)/2);
				
				if(marker.finalY < self.stageHeight/2){
					finalY = marker.finalY + marker.height + self.markersToolTipWindow_do.pointerHeight + self.markerToolTipOffsetY;
					self.markersToolTipWindow_do.pointerUp_sdo.setVisible(true);
					self.markersToolTipWindow_do.pointerDown_sdo.setVisible(false);
					pointerPostion = FWDMarkerWindowToolTip.POINTER_UP;
				}else{
					finalY = marker.finalY - self.markersToolTipWindow_do.totalHeight - self.markerToolTipOffsetY;
					self.markersToolTipWindow_do.pointerUp_sdo.setVisible(false);
					self.markersToolTipWindow_do.pointerDown_sdo.setVisible(true);
					pointerPostion = FWDMarkerWindowToolTip.POINTER_DOWN;
				}
			
				if(finalX < 0){
					pointerOffsetX = finalX;
					finalX = 0;
				}else if(self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth < 0){
					pointerOffsetX = -(self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth);
					finalX = finalX + self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth;
				}
				
				self.markersToolTipWindow_do.show();
				self.markersToolTipWindow_do.setX(finalX);
				self.markersToolTipWindow_do.setY(finalY);	
				self.markersToolTipWindow_do.positionPointer(pointerOffsetX, pointerPostion);
			}, 80);
		};
		
		//######################################################//
		/* hide tool tip window */
		//######################################################//
		self.toolTipWindowAddEventsToSetGlobalXAndGlobalY = function(){
			if(self.isMobile_bl){
				self.addHideToolTipWindowTestWithDelayId_to = setTimeout(function(){
					if(self.hasPointerEvent_bl){
						window.addEventListener("MSPointerDown", self.hideToolTipWindowTest);
						window.addEventListener("MSPointerMove", self.hideToolTipWindowTest);
					}else{
						window.addEventListener("touchstart", self.hideToolTipWindowTest);
					}
				}, 50);
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.hideToolTipWindowTest);
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.hideToolTipWindowTest);
				}
			}
		};
		
		self.hideToolTipWindowTest = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.globalX = viewportMouseCoordinates.screenX;
			self.globalY = viewportMouseCoordinates.screenY;
			if(e.touches || e.pointerType != e.MSPOINTER_TYPE_MOUSE) self.hideToolTipWindowWithDelay();
		};
		
		self.hideToolTipWindowWithDelay = function(addDelay){
			if(!FWDUtils.hitTest(self.markersToolTipWindow_do.screen, self.globalX, self.globalY)
			   && !FWDUtils.hitTest(self.curMarker_do.screen, self.globalX, self.globalY)	){
				self.hideToolTipWindow();
				if(self.isMobile_bl){
					clearTimeout(self.addHideToolTipWindowTestWithDelayId_to);
					if(self.hasPointerEvent_bl){
						window.removeEventListener("MSPointerDown", self.hideToolTipWindowTest);
						window.removeEventListener("MSPointerMove", self.hideToolTipWindowTest);
					}else{
						window.removeEventListener("touchstart", self.hideToolTipWindowTest);
					}
				}else{
					if(window.removeEventListener){
						window.removeEventListener("mousemove", self.hideToolTipWindowTest);
					}else if(document.detachEvent){
						document.detachEvent("onmousemove", self.hideToolTipWindowTest);
					}
				}
			}else{
				self.hideToolTipWindowId_to = setTimeout(self.hideToolTipWindowWithDelay, 300);
			}
		};
		
		self.hideToolTipWindow = function(){
			if(!self.markersToolTipWindow_do) return;
			clearTimeout(self.hideToolTipWindowId_to);
			self.markersToolTipWindow_do.hide();
			self.markersToolTipWindow_do.toolTipWindowId = "none";
		};
		
		
		//####################################//
		/* markers info */
		//####################################//
		self.setupMarkersInfo = function(){
			if(window.addEventListener){
				window.addEventListener("mousemove", self.showMarkersInfoPosition);
				window.addEventListener ("mousewheel", self.showMarkersInfoPosition);
				window.addEventListener('DOMMouseScroll', self.showMarkersInfoPosition);
			}else if(document.attachEvent){
				document.attachEvent("onmousemove", self.showMarkersInfoPosition);
				document.attachEvent("onmousewheel", self.showMarkersInfoPosition);
			}
		
			self.markersPositionInfo_sdo = new FWDSimpleDisplayObject("div");
			self.markersPositionInfo_sdo.setDisplay("inline-block");
			self.markersPositionInfo_sdo.getStyle().fontSmoothing = "antialiased";
			self.markersPositionInfo_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.markersPositionInfo_sdo.getStyle().textRendering = "optimizeLegibility";
			self.markersPositionInfo_sdo.getStyle().padding = "6px";
			self.markersPositionInfo_sdo.getStyle().fontFamily = "Arial";
			self.markersPositionInfo_sdo.getStyle().fontSize= "12px";
			self.markersPositionInfo_sdo.getStyle().lineHeight = "20px";
			self.markersPositionInfo_sdo.getStyle().color = "#000000";
			self.markersPositionInfo_sdo.setBkColor("#FFFFFF");
			self.addChild(self.markersPositionInfo_sdo);
		};
		
		self.showMarkersInfoPosition = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			var globalX = self.getGlobalX();
			var globalY = self.getGlobalY();
			var localX = viewportMouseCoordinates.screenX - globalX;
			var localY = viewportMouseCoordinates.screenY - globalY;
			var finalX = parseInt((localX - self.finalX) * (1/self.currentScale));
			var finalY = parseInt((localY - self.finalY) * (1/self.currentScale));
			var infoFinalX = localX + 10;
			var infoFinalY = localY + 10;
			
			self.markersPositionInfo_sdo.setInnerHTML("Image nr:" + "<font color='#FF0000'>" + (self.curId + 1) + "</font>" +  "<br>x:" + "<font color='#FF0000'>" + finalX + "</font>" + " y:" + "<font color='#FF0000'>" + finalY + "</font>");
			var infoWidth = self.markersPositionInfo_sdo.getWidth();
			var infoHeight = self.markersPositionInfo_sdo.getHeight();
			
			if(infoFinalX + infoWidth > self.stageWidth){
				infoFinalX = infoFinalX - infoWidth - 10;
			}
			
			if(infoFinalY + infoHeight > self.stageHeight){
				infoFinalY = infoFinalY - infoHeight - 10;
			}
		
			self.markersPositionInfo_sdo.setX(infoFinalX );
			self.markersPositionInfo_sdo.setY(infoFinalY );
		};
		
		
		//##################################//
		//various methods.
		//##################################//
		self.setDraggingMode = function(draggingMode){
			self.draggingMode_str = draggingMode;
		};
		
		self.disableOrEnablePanOrTouch = function(bool){
			self.disablePanOrRotate_bl = bool;
		};
		
		self.zoomInOrOutWithScrollBar = function(percent){
			self.currentScale = percent * (self.zoomFactor - self.smallestPossibleScale) + self.smallestPossibleScale;
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			self.zoomImage(true);
		};
		
		self.dispatchScrollBarUpdate = function(animate, overwrite){
			if(!self.disablePanOrRotate_bl || overwrite){
				self.dispatchEvent(FWDImageManager.SCROLL_BAR_UPDATE, {percent:(self.currentScale - self.smallestPossibleScale)/(self.zoomFactor - self.smallestPossibleScale), animate:animate});
			}
		};
		
		self.zoomInOrOutWithButtons = function(dir, withPause){
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			
			if(dir > 0){
				if(withPause){
					self.currentScale += self.zoomSpeed;
				}else{
					self.currentScale += self.zoomSpeed/15;
				}
				if(self.currentScale > self.zoomFactor) self.currentScale = self.zoomFactor;
			}else if(dir < 0){
				if(withPause){
					self.currentScale -= self.zoomSpeed;
				}else{
					self.currentScale -= self.zoomSpeed/15;
				}
				if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))) self.currentScale = self.smallestPossibleScale;
			}
			self.dispatchScrollBarUpdate(true, true);
			
			self.zoomImage(true);
		};
		
		self.centerImage = function(){
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			
			self.finalX =  Math.round((self.stageWidth - self.finalWidth)/2);
			self.finalY =  Math.round((self.stageHeight - self.finalHeight)/2);	
		
			self.resizeAndPositionSmallImage(false);
			self.positionMarkers();
		};
		
		//############################################//
		/* navigator utils */
		//############################################//
		self.updateNavigator = function(animate){
			if(!self.isNavigatorShowed_bl) return;
			self.dispatchEvent(FWDImageManager.UPDATE_NAVIGATOR, {
				percentX:Math.abs(self.finalX/(self.finalWidth - self.stageWidth)),
				percentY:Math.abs(self.finalY/(self.finalHeight - self.stageHeight)),
				percentWidth:self.stageWidth/self.finalWidth,
				percentHeight:self.stageHeight/self.finalHeight,
				animate:animate
			});
		};
		
		self.hideOrShowNavigator = function(){
			if(self.stageWidth < self.finalWidth || self.stageHeight < self.finalHeight){
				self.isNavigatorShowed_bl = true;
				self.dispatchEvent(FWDImageManager.SHOW_NAVIGATOR);
			}else{
				self.isNavigatorShowed_bl = false;
				self.dispatchEvent(FWDImageManager.HIDE_NAVIGATOR);
			}
		};
		
		self.updateOnNavigatorPan = function(percentX, percentY){
			
			self.finalX = parseInt(percentX * (self.stageWidth - self.finalWidth));
			self.finalY = parseInt(percentY * (self.stageHeight - self.finalHeight));
			
			self.positionMarkers(true);
			self.resizeAndPositionSmallImage(true);
		};
		
	
		//#################################//
		//Clean main events.
		//#################################//
		self.cleanMainEvents = function(){
			if(window.addEventListener){
				
			}else if(window.attachEvent){
				
			}
			if(self.isMobile_bl){
				self.dumy_sdo.screen.removeEventListener("touchstart", self.panStartHandler);
				self.dumy_sdo.screen.removeEventListener("MSPointerDown", self.panStartHandler);
				window.removeEventListener("touchmove", self.panMoveHandler);
				window.removeEventListener("touchend", self.panEndHandler);
				window.removeEventListener("MSPointerMove", self.panMoveHandler);
				window.removeEventListener("MSPointerUp", self.panEndHandler);
				
				self.dumy_sdo.screen.removeEventListener("touchstart", self.rotateStartHandler);
				self.dumy_sdo.screen.removeEventListener("MSPointerDown", self.rotateStartHandler);
				window.removeEventListener("touchmove", self.rotateMoveHandler);
				window.removeEventListener("touchend", self.rotateEndHandler);
				window.removeEventListener("MSPointerMove", self.rotateMoveHandler);
				window.removeEventListener("MSPointerUp", self.rotateEndHandler);
				
				window.removeEventListener("touchstart", self.hideToolTipWindowTest);
				window.removeEventListener("MSPointerDown", self.hideToolTipWindowTest);
				window.removeEventListener("MSPointerMove", self.hideToolTipWindowTest);
				
				self.screen.removeEventListener('gesturestart', self.gestureStartHandler);
				self.screen.removeEventListener('gesturechange', self.gestureChangeHandler);
			}else{
				if(window.removeEventListener){
					self.dumy_sdo.screen.removeEventListener("mousedown", self.panStartHandler);
					window.removeEventListener("mousemove", self.panMoveHandler);
					window.removeEventListener("mouseup", self.panEndHandler);	
					
					self.dumy_sdo.screen.removeEventListener("mousedown", self.rotateStartHandler);
					window.removeEventListener("mousemove", self.rotateMoveHandler);
					window.removeEventListener("mouseup", self.rotateEndHandler);
					
					self.dumy_sdo.screen.removeEventListener ("mousewheel", self.mouseWheelHandler);
					self.dumy_sdo.screen.removeEventListener('DOMMouseScroll', self.mouseWheelHandler);
					
					window.removeEventListener("mousemove", self.hideToolTipWindowTest);
					
					window.removeEventListener("mousemove", self.showMarkersInfoPosition);
					window.removeEventListener ("mousewheel", self.showMarkersInfoPosition);
					window.removeEventListener('DOMMouseScroll', self.showMarkersInfoPosition);
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.panMoveHandler);
					document.detachEvent("onmouseup", self.panEndHandler);
					self.dumy_sdo.screen.detachEvent("onmousedown", self.panStartHandler);
					
					self.dumy_sdo.screen.detachEvent("onmousedown", self.rotateStartHandler);
					document.detachEvent("onmousemove", self.rotateMoveHandler);
					document.detachEvent("onmouseup", self.rotateEndHandler);
					
					self.dumy_sdo.screen.detachEvent("onmousewheel", self.mouseWheelHandler);
					
					document.detachEvent("onmousemove", self.hideToolTipWindowTest);
					
					document.detachEvent("onmousemove", self.showMarkersInfoPosition);
					document.detachEvent("onmousewheel", self.showMarkersInfoPosition);
				}
			}
			
			clearTimeout(self.tweenDone_to);
			clearTimeout(self.removeSmallSDOId_to);
			clearTimeout(self.setAlphaWithDelayId_to);
			clearTimeout(self.hideToolTipWindowId_to);
			clearTimeout(self.addHideToolTipWindowTestWithDelayId_to);
			clearTimeout(self.showToolTipWindoId_to);
			clearTimeout(self.showMarkerToolTipId_to);
			clearInterval(self.dragAndSpinId_int);
		};
		
		//#################################//
		/* destroy */
		//################################//
		self.destroy = function(){
			self.cleanMainEvents();
			
			if(self.largeImage_img){
				self.largeImage_img.onerror = null;
				self.largeImage_img.onload = null;
				self.largeImage_img.src = null;
			}
			
			if(self.mainImagesHolder_do){
				TweenMax.killTweensOf(self.mainImagesHolder_do);
				self.mainImagesHolder_do.destroy();
			}
			
			if(self.smallImage_sdo){
				TweenMax.killTweensOf(self.smallImage_sdo);
				self.smallImage_sdo.destroy();
			}
			
			if(self.showMarkers_bl){
				var marker;
				for(var i=0; i<self.totalMarkers; i++){
					marker = self.markers_ar[i];
					TweenMax.killTweensOf(marker);
					marker.destroy();
				}
				if(self.markersToolTip_do) self.markersToolTip_do.destroy();
				self.markersToolTipWindow_do.destroy();
			}
			
			if(self.addCorrectionForWebKit_bl){
				TweenMax.killTweensOf(self.left_sdo);
				TweenMax.killTweensOf(self.top_sdo);
				TweenMax.killTweensOf(self.right_sdo);
				TweenMax.killTweensOf(self.bottom_sdo);
				self.left_sdo.destroy();
				self.top_sdo.destroy();
				self.right_sdo.destroy();
				self.bottom_sdo.destroy();
			}
			
			for(var i=0; i<self.smallDos_ar.length; i++){
				var small_sdo = self.smallDos_ar[i];
				TweenMax.killTweensOf(small_sdo);
				small_sdo.destroy();
			};
			
			if(self.largeImage_sdo){
				TweenMax.killTweensOf(self.largeImage_sdo);
				self.largeImage_sdo.destroy();
			}
			
			if(self.markersPositionInfo_sdo){
				self.markersPositionInfo_sdo.setInnerHTML("");
				self.markersPositionInfo_sdo.destroy();
			}
			
			data = null;
			parent = null;
			
			self.playListData_ar = null;
			self.images_ar = null;
			self.smallDos_ar = null;
			self.markers_ar = null;
			self.markersList_ar = null;
			self.markersPosition_ar = null;
			self.largeImagesPaths_ar = null;
			
			self.hider = null;
			self.curMarker_do = null;
			self.prevSmall_sdo = null;
			self.largeImage_img = null;
			self.dumy_sdo = null;
			self.mainImagesHolder_do = null;
			self.smallImage_sdo = null;
			self.largeImage_sdo = null;
			self.left_sdo = null;
			self.top_sdo = null;
			self.right_sdo = null;
			self.bottom_sdo = null;
			self.markersPositionInfo_sdo = null;
			
			self.handMovePath_str = null;
			self.backgroundColor_str = null;
			self.draggingMode_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDImageManager.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
	FWDImageManager.setPrototype =  function(){
		FWDImageManager.prototype = new FWDDisplayObject("div");
	};
	
	FWDImageManager.LARGE_IMAGE_LOAD_ERROR = "largeImageLoadError";
	FWDImageManager.IMAGE_ZOOM_COMPLETE = "zoomComplete";
	FWDImageManager.SCROLL_BAR_UPDATE = "scrollBarUpdate";
	FWDImageManager.PAN_START = "panStart";
	FWDImageManager.ROTATE_START = "rotateStart";
	FWDImageManager.ROTATE_UPDATE = "rotateUpdate";
	FWDImageManager.ROTATE = "rotate";
	FWDImageManager.PAN = "pan";
	FWDImageManager.UPDATE_NAVIGATOR = "updateNavigator";
	FWDImageManager.SHOW_NAVIGATOR = "showNavigator";
	FWDImageManager.HIDE_NAVIGATOR = "hideNavigator";
	FWDImageManager.SHOW_INFO = "showInfo";

	FWDImageManager.prototype = null;
	window.FWDImageManager = FWDImageManager;
	
}(window));