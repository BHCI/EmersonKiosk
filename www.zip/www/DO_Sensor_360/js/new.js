/* FWDButtonToolTip */
(function (window){
var FWDButtonToolTip = function(
			leftImage_img,
			pointer_img,
			toolTipLabel_str,
			toolTipLabel2_str,
			leftImagePath_str, 
			middleImagePath_str,
			rightImagePath_str,
			buttonToolTipFontColor_str,
			pointerPosition_str,
			buttonToolTipTopPointer_str,
			buttonToolTipBottomPointer_str
		){
		
		var self = this;
		var prototype = FWDButtonToolTip.prototype;
		
		self.pointer_img;
		
		self.left_sdo = null;
		self.middle_sdo = null;
		self.right_sdo = null;
		self.text_sdo = null;
		self.pointer_sdo = null;
		
		self.leftImagePath_str = leftImagePath_str;
		self.middleImagePath_str = middleImagePath_str;
		self.rightImagePath_str = rightImagePath_str;
		self.fontColor_str = buttonToolTipFontColor_str;
		self.bottomPointer_str = buttonToolTipBottomPointer_str;
		self.topPointer_str = buttonToolTipTopPointer_str;
		self.pointerPosition_str = pointerPosition_str;
		self.toolTipLabel_str = toolTipLabel_str;
		self.toolTipLabel2_str = toolTipLabel2_str;
		
		self.marginWidth = leftImage_img.width;
		self.totalHeight = leftImage_img.height;
		self.pointerWidth = pointer_img.width;
		self.pointerHeight = pointer_img.height;
		self.totalWidth;
		
		self.hideWithDelayId_do;
	
		self.isMobile_bl = FWDUtils.isMobile;
		self.isShowed_bl = true;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setWidth(200);
			self.setupMainContainers();
			self.setLabel(self.toolTipLabel_str);
			self.hide();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){	
			var img;
		
			self.left_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.leftImagePath_str;
			self.left_sdo.setScreen(img);
			self.left_sdo.setWidth(self.marginWidth);
			self.left_sdo.setHeight(self.totalHeight);
			self.addChild(self.left_sdo);
			
			self.middle_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.middleImagePath_str;
			self.middle_sdo.setScreen(img);
			self.middle_sdo.setX(self.marginWidth);
			self.middle_sdo.setWidth(self.marginWidth);
			self.middle_sdo.setHeight(self.totalHeight);
			self.addChild(self.middle_sdo);
			
			self.right_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.rightImagePath_str;
			self.right_sdo.setScreen(img);
			self.right_sdo.setWidth(self.marginWidth);
			self.right_sdo.setHeight(self.totalHeight);
			self.addChild(self.right_sdo);	
	
			self.text_sdo = new FWDSimpleDisplayObject("div");
			self.text_sdo.setBackfaceVisibility();
			self.text_sdo.setDisplay("inline-block");
			self.text_sdo.getStyle().fontFamily = "Arial";
			self.text_sdo.getStyle().fontSize= "12px";
			self.text_sdo.setHeight(20);
			self.text_sdo.getStyle().color = self.fontColor_str;
			self.text_sdo.getStyle().fontSmoothing = "antialiased";
			self.text_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.text_sdo.getStyle().textRendering = "optimizeLegibility";	
			self.text_sdo.setX(self.marginWidth);
			
			if(FWDUtils.isIEAndLessThen9 || FWDUtils.isSafari){
				self.text_sdo.setY(parseInt((self.totalHeight - 8)/2) - 2);
			}else{
				self.text_sdo.setY(parseInt((self.totalHeight - 8)/2) - 1);
			}
			self.addChild(self.text_sdo);
			
			self.pointer_img = new Image();
			if(self.pointerPosition_str ==  FWDController.POSITION_BOTTOM){
				self.pointer_img.src = self.bottomPointer_str;
			}else{
				self.pointer_img.src = self.topPointer_str;
			}
			self.pointer_sdo = new FWDSimpleDisplayObject("img");
			self.pointer_sdo.setScreen(self.pointer_img);
			self.pointer_sdo.setWidth(self.pointerWidth);
			self.pointer_sdo.setHeight(self.pointerHeight);
			self.addChild(self.pointer_sdo);
		};
		
		//##########################################//
		/* set label */
		//##########################################//
		self.setLabel = function(label){
			if(self == null) return;
			if(!self.middle_sdo) return;
			self.text_sdo.setInnerHTML(label);
			setTimeout(function(){
				if(self == null) return;
				self.middle_sdo.setWidth(self.text_sdo.screen.offsetWidth);
				self.right_sdo.setX(self.text_sdo.screen.offsetWidth + self.marginWidth);
				self.totalWidth = (self.marginWidth * 2) + self.text_sdo.screen.offsetWidth;
				self.positionPointer(0);
				},50);
			
		};
		
		self.positionPointer = function(offsetX){
			var finalX;
			var finalY;
			
			if(!offsetX) offsetX = 0;
			
			finalX = parseInt((self.totalWidth - self.pointerWidth)/2) + offsetX;
			if(self.pointerPosition_str == FWDController.POSITION_BOTTOM){
				finalY = self.totalHeight - 1;
			}else{
				finalY = - self.pointerHeight + 1;
			}
		
			self.pointer_sdo.setX(finalX);
			self.pointer_sdo.setY(finalY);
		};
		
		//##########################################//
		/* show / hide*/
		//##########################################//
		self.show = function(){
			if(self.isShowed_bl) return;
			clearInterval(self.hideWithDelayId_do);
			self.positionPointer();
			
			TweenMax.killTweensOf(self);
			TweenMax.to(self, .4, {alpha:1, delay:.1, ease:Quart.easeOut});
			
			self.isShowed_bl = true;
		};
		
		self.hide = function(){
			if(!self.isShowed_bl) return;
			TweenMax.killTweensOf(self);
			self.setX(-5000);
			self.setAlpha(0);
			self.isShowed_bl = false;
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			TweenMax.killTweensOf(self);
			
			self.pointer_img = null;
			
			self.left_sdo.destroy();
			self.middle_sdo.destroy();
			self.right_sdo.destroy();
			self.text_sdo.destroy();
			self.pointer_sdo.destroy();
			
			self.leftImagePath_str = null;
			self.middleImagePath_str = null;
			self.rightImagePath_str = null;
			self.fontColor_str = null;
			self.bottomPointer_str = null;
			self.topPointer_str = null;
			self.pointerPosition_str = null;
			self.toolTipLabel_str = null;
			self.toolTipLabel2_str = null;
			
			self.left_sdo = null;
			self.middle_sdo = null;
			self.right_sdo = null;
			self.text_sdo = null;
			self.pointer_sdo = null;
			
			leftImage_img = null;
			pointer_img = null;
			toolTipLabel_str = null;
			toolTipLabel2_str = null;
			leftImagePath_str = null; 
			middleImagePath_str = null;
			rightImagePath_str = null;
			buttonToolTipFontColor_str = null;
			pointerPosition_str = null;
			buttonToolTipTopPointer_str = null;
			buttonToolTipBottomPointer_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDButtonToolTip.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDButtonToolTip.setPrototype = function(){
		FWDButtonToolTip.prototype = null;
		FWDButtonToolTip.prototype = new FWDDisplayObject("div");
	};
	
	FWDButtonToolTip.CLICK = "onClick";
	FWDButtonToolTip.MOUSE_DOWN = "onMouseDown";
	
	FWDButtonToolTip.prototype = null;
	window.FWDButtonToolTip = FWDButtonToolTip;
}(window));/* FWDComplexButton */
(function (){
var FWDComplexButton = function(
			n1Img, 
			s1Img, 
			n2Img, 
			s2Img, 
			disptachMainEvent_bl
		){
		
		var self = this;
		var prototype = FWDComplexButton.prototype;
		
		this.n1Img = n1Img;
		this.s1Img = s1Img;
		this.n2Img = n2Img;
		this.s2Img = s2Img;
		
		this.firstButton_do;
		this.n1_do;
		this.s1_do;
		this.secondButton_do;
		this.n2_do;
		this.s2_do;
		
		this.buttonWidth = self.n1Img.width;
		this.buttonHeight = self.n1Img.height;
		
		this.currentState = 1;
		this.isDisabled_bl = false;
		this.isMaximized_bl = false;
		this.disptachMainEvent_bl = disptachMainEvent_bl;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setButtonMode(true);
			self.setWidth(self.buttonWidth);
			self.setHeight(self.buttonHeight);
			self.setupMainContainers();
			self.secondButton_do.setVisible(false);
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			self.firstButton_do = new FWDDisplayObject("div");
			self.addChild(self.firstButton_do);
			self.n1_do = new FWDSimpleDisplayObject("img");	
			self.n1_do.setScreen(self.n1Img);
			self.s1_do = new FWDSimpleDisplayObject("img");
			self.s1_do.setScreen(self.s1Img);
			self.s1_do.setAlpha(0);
			self.firstButton_do.addChild(self.n1_do);
			self.firstButton_do.addChild(self.s1_do);
			self.firstButton_do.setWidth(self.n1Img.width);
			self.firstButton_do.setHeight(self.n1Img.height);
			
			self.secondButton_do = new FWDDisplayObject("div");
			self.addChild(self.secondButton_do);
			self.n2_do = new FWDSimpleDisplayObject("img");	
			self.n2_do.setScreen(self.n2Img);
			self.s2_do = new FWDSimpleDisplayObject("img");
			self.s2_do.setScreen(self.s2Img);
			self.s2_do.setAlpha(0);
			self.secondButton_do.addChild(self.n2_do);
			self.secondButton_do.addChild(self.s2_do);
			self.secondButton_do.setWidth(self.n2Img.width);
			self.secondButton_do.setHeight(self.n2Img.height);
			
			self.addChild(self.secondButton_do);
			self.addChild(self.firstButton_do);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.addEventListener("MSPointerDown", self.onMouseDown);
					self.screen.addEventListener("MSPointerUp", self.onClick);
					self.screen.addEventListener("MSPointerOver", self.onMouseOver);
					self.screen.addEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.addEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mousedown", self.onMouseDown);
				self.screen.addEventListener("click", self.onClick);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmousedown", self.onMouseDown);
				self.screen.attachEvent("onclick", self.onClick);
			}
		};
		
		self.onMouseOver = function(e, animate){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDComplexButton.MOUSE_OVER, {e:e});
				TweenMax.killTweensOf(self.s1_do);
				TweenMax.killTweensOf(self.s2_do);
				TweenMax.to(self.s1_do, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
				TweenMax.to(self.s2_do, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
			}
		};
			
		self.onMouseOut = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				TweenMax.killTweensOf(self.s1_do);
				TweenMax.killTweensOf(self.s2_do);
				TweenMax.to(self.s1_do, .5, {alpha:0, ease:Expo.easeOut});	
				TweenMax.to(self.s2_do, .5, {alpha:0, ease:Expo.easeOut});	
				self.dispatchEvent(FWDComplexButton.MOUSE_OUT);
			}
		};
		
		self.onClick = function(e){
			if(self.isDisabled_bl) return;
			if(e.preventDefault) e.preventDefault();
			if(self.disptachMainEvent_bl) self.dispatchEvent(FWDComplexButton.CLICK);
		};
		
		self.onMouseDown = function(e){
			if(self.isDisabled_bl) return;
			if(e.preventDefault) e.preventDefault();
			if(!self.isMobile_bl) self.onMouseOver(e, false);
			if(self.disptachMainEvent_bl) self.dispatchEvent(FWDComplexButton.MOUSE_DOWN, {e:e});
		};
		
		//##############################//
		/* toggle button */
		//#############################//
		self.toggleButton = function(){
			if(self.currentState == 1){
				self.firstButton_do.setVisible(false);
				self.secondButton_do.setVisible(true);
				self.currentState = 0;
				self.dispatchEvent(FWDComplexButton.FIRST_BUTTON_CLICK);
			}else{
				self.firstButton_do.setVisible(true);
				self.secondButton_do.setVisible(false);
				self.currentState = 1;
				self.dispatchEvent(FWDComplexButton.SECOND_BUTTON_CLICK);
			}
		};
		
		//##############################//
		/* set second buttons state */
		//##############################//
		self.setButtonState = function(state){
			if(state == 1){
				self.firstButton_do.setVisible(true);
				self.secondButton_do.setVisible(false);
				self.currentState = 1; 
			}else{
				self.firstButton_do.setVisible(false);
				self.secondButton_do.setVisible(true);
				self.currentState = 0; 
			}
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.removeEventListener("MSPointerDown", self.onMouseDown);
					self.screen.removeEventListener("MSPointerUp", self.onClick);
					self.screen.removeEventListener("MSPointerOver", self.onMouseOver);
					self.screen.removeEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.removeEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.removeEventListener){
				self.screen.removeEventListener("mouseover", self.onMouseOver);
				self.screen.removeEventListener("mouseout", self.onMouseOut);
				self.screen.removeEventListener("mousedown", self.onMouseDown);
				self.screen.removeEventListener("click", self.onClick);
			}else if(self.screen.detachEvent){
				self.screen.detachEvent("onmouseover", self.onMouseOver);
				self.screen.detachEvent("onmouseout", self.onMouseOut);
				self.screen.detachEvent("onmousedown", self.onMouseDown);
				self.screen.detachEvent("onclick", self.onClick);
			}
			
			TweenMax.killTweensOf(self.s1_do);
			TweenMax.killTweensOf(self.s2_do);
			
			self.firstButton_do.destroy();
			self.n1_do.destroy();
			self.s1_do.destroy();
			self.secondButton_do.destroy();
			self.n2_do.destroy();
			self.s2_do.destroy();
			
			self.firstButton_do = null;
			self.n1_do = null;
			self.s1_do = null;
			self.secondButton_do = null;
			self.n2_do = null;
			self.s2_do = null;
			
			self.n1Img = null;
			self.s1Img = null;
			self.n2Img = null;
			self.s2Img = null;
			
			n1Img = null; 
			s1Img = null; 
			n2Img = null; 
			s2Img = null; 
			
			self.init = null;
			self.setupMainContainers = null; 
			self.onMouseOver = null;
			self.onMouseOut = null;
			self.onClick = null;
			self.onMouseDown = null;
			self.toggleButton = null;
			self.setButtonState = null;
			self.destroy = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDComplexButton.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDComplexButton.setPrototype = function(){
		FWDComplexButton.prototype = new FWDDisplayObject("div");
	};
	
	FWDComplexButton.FIRST_BUTTON_CLICK = "onFirstClick";
	FWDComplexButton.SECOND_BUTTON_CLICK = "secondButtonOnClick";
	FWDComplexButton.MOUSE_OVER = "onMouseOver";
	FWDComplexButton.MOUSE_OUT = "onMouseOut";
	FWDComplexButton.MOUSE_DOWN = "onMouseDown";
	FWDComplexButton.CLICK = "onClick";
	
	FWDComplexButton.prototype = null;
	window.FWDComplexButton = FWDComplexButton;
}(window));/* Thumb */
(function (window){
	
	var FWDConsole = function(){
		
		var self  = this;
		var prototype = FWDConsole.prototype;
		
		this.main_do = null;
	
		this.init = function(){
			this.setupScreen();
			window.onerror = this.showError;
			this.screen.style.zIndex = 100000009;
			setTimeout(this.addConsoleToDom, 100);
			setInterval(this.position, 100);
		};
		
		this.position = function(){
			var scrollOffsets = FWDUtils.getScrollOffsets();
			self.setX(scrollOffsets.x);
			self.setY(scrollOffsets.y);
		};
		
		this.addConsoleToDom  = function(){
			if(navigator.userAgent.toLowerCase().indexOf("msie 7") != -1){
				document.getElementsByTagName("body")[0].appendChild(self.screen);
			}else{
				document.documentElement.appendChild(self.screen);
			}
		};
		
		/* setup screens */
		this.setupScreen = function(){
			this.main_do = new FWDDisplayObject("div", "absolute");
			this.main_do.setOverflow("auto");
			this.main_do.setWidth(200);
			this.main_do.setHeight(300);
			this.setWidth(200);
			this.setHeight(300);
			this.main_do.setBkColor("#FFFFFF");
			this.addChild(this.main_do);
		};
		
		this.showError = function(message, url, linenumber) {
			var currentInnerHTML = self.main_do.getInnerHTML() + "<br>" + "JavaScript error: " + message + " on line " + linenumber + " for " + url;
			self.main_do.setInnerHTML(currentInnerHTML);
			self.main_do.screen.scrollTop = self.main_do.screen.scrollHeight;
		};
		
		this.log = function(message){
			var currentInnerHTML = self.main_do.getInnerHTML() + "<br>" + message;
			self.main_do.setInnerHTML(currentInnerHTML);  
			self.main_do.getScreen().scrollTop = 10000;
		};
		
		this.init();
	};
	
	/* set prototype */
    FWDConsole.setPrototype = function(){
    	FWDConsole.prototype = new FWDDisplayObject("div", "absolute");
    };
    
    FWDConsole.prototype = null;
	window.FWDConsole = FWDConsole;
}(window));/* Context menu */
(function (){
	var FWDContextMenu = function(parent, data){
		
		var self = this;
		var prototype = FWDContextMenu.prototype;
		self.parent = parent;
		
		self.buttonsTest_ar = data.buttons_ar;
		self.itemsLabels_ar = data.contextMenuLabels_ar;
		self.items_ar = [];
		self.spacers_ar = [];
		
		self.panButton_do = null;
		self.rotateButton_do = null;
		self.nextButton_do = null;
		self.prevButton_do = null;
		self.slideShowButton_do = null;
		self.infoButton_do = null;
		self.linkButton_do = null;
		self.fullScreenButton_do = null;
		self.zoomInButton_do = null;
		self.zoomOutButton_do = null;
		self.slideShowButton_do = null;
		self.linkButton_do = null;
		self.infoButton_do = null;
		self.fullScreenButton_do = null;
	
		self.backgroundColor_str = data.contextMenuBackgroundColor_str;
		self.borderColor_str = data.contextMenuBorderColor_str;
		self.spacerColor_str = data.contextMenuSpacerColor_str;
		self.itemNormalColor_str = data.contextMenuItemNormalColor_str;
		self.itemSelectedColor_str = data.contextMenuItemSelectedColor_str;
		self.itemDisabledColor_str = data.contextMenuItemDisabledColor_str;
		self.draggingMode_str = data.startDraggingMode_str;
		self.link_str = data.link_str;
		
		self.borderRadius = 6;
		self.biggestWidth;
		self.totalWidth = 400;
		self.totalHeight = 400;
		self.sapaceBetweenButtons = 7;
		self.padding = 6;
		
		self.getMaxWidthResizeAndPositionId_to;
		
		self.inverseNextAndPrevRotation_bl = data.inverseNextAndPrevRotation_bl;
		self.showScriptDeveloper_bl = data.showScriptDeveloper_bl;
		self.show_bl = false;
		self.isActive_bl = false;
		
		self.init = function(){
			
			if(self.itemsLabels_ar || self.showScriptDeveloper_bl){
				self.show_bl = true;
				self.setWidth(self.totalWidth);
				self.setHeight(self.totalHeight);
				self.setBkColor(self.backgroundColor_str);
				self.getStyle().borderColor = self.borderColor_str;
				self.getStyle().borderStyle = "solid";
				self.getStyle().borderRadius = self.borderRadius + "px";
				self.getStyle().borderWidth = "1px";
				self.setVisible(false);
				self.setY(-2000);
				self.parent.main_do.addChild(self);
				
				self.setupLabels();	
				self.setupDeveloperButton();
				self.setupSpacers();
				self.getMaxWidthResizeAndPositionId_to = setTimeout(self.getMaxWidthResizeAndPosition, 200);
			}
			
			self.addContextEvent();
		};
		
		
		//##########################################//
		/* Setup context items. */
		//##########################################//
		self.setupLabels = function(){
			var len = self.buttonsTest_ar.length;
			var res;
			var label1_str = "";
			var label2_str = "";
			
			if(!self.itemsLabels_ar) return;
			
			for(var i=0; i<len; i++){
				res = self.buttonsTest_ar[i];	
				if(res == "pan"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.panButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.panButton_do);
					if(self.draggingMode_str == FWDController.PAN) self.panButton_do.disable();
					self.panButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.panRotateStartHandler);
					self.addChild(self.panButton_do);
				}else if(res == "rotate"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.rotateButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.rotateButton_do);
					if(self.draggingMode_str == FWDController.ROTATE) self.rotateButton_do.disable();
					self.rotateButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.panButtonStartHandler);
					self.addChild(self.rotateButton_do);
				}else if(res == "rotateright"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.nextButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.nextButton_do);
					self.nextButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.nextButtonStartHandler);
					self.addChild(self.nextButton_do);
				}else if(res == "roteteleft"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.prevButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.prevButton_do);
					self.prevButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.prevButtonStartHandler);
					self.addChild(self.prevButton_do);
				}else if(res == "scrollbar"){
					var str = self.itemsLabels_ar[i];
					if(str){
						if(str.indexOf("/") == -1){
							label1_str = "Contextmenu item is not defined!";
							label2_str = "Contextmenu item is not defined!";
						}else{
							label1_str = str.substr(0, str.indexOf("/"));
							label2_str = str.substr(str.indexOf("/") + 1);
						}
					}else{
						label1_str = "Contextmenu item is not defined!";
						label2_str = "Contextmenu item is not defined!";
					}
					
					FWDContextMenuButton.setPrototype();
					self.zoomInButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.zoomInButton_do);
					self.zoomInButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.zoomInButtonStartHandler);
					self.addChild(self.zoomInButton_do);
					
					FWDContextMenuButton.setPrototype();
					self.zoomOutButton_do = new FWDContextMenuButton(label2_str, undefined, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.zoomOutButton_do);
					self.zoomOutButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.zoomOutButtonStartHandler);
					self.addChild(self.zoomOutButton_do);
				}else if(res == "play"){
					var str = self.itemsLabels_ar[i];
					if(str){
						if(str.indexOf("/") == -1){
							label1_str = "Contextmenu item is not defined!";
							label2_str = "Contextmenu item is not defined!";
						}else{
							label1_str = str.substr(0, str.indexOf("/"));
							label2_str = str.substr(str.indexOf("/") + 1);
						}
					}else{
						label1_str = "Contextmenu item is not defined!";
						label2_str = "Contextmenu item is not defined!";
					}
					
					FWDContextMenuButton.setPrototype();
					self.slideShowButton_do = new FWDContextMenuButton(label1_str, label2_str, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.slideShowButton_do);
					self.slideShowButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.startSlideShowHandler);
					self.addChild(self.slideShowButton_do);
				}else if(res == "info"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.infoButton_do = new FWDContextMenuButton(label1_str, label2_str, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.infoButton_do);
					self.infoButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.infoButtonStart);
					self.addChild(self.infoButton_do);
				}else if(res == "link"){
					label1_str = self.itemsLabels_ar[i] || "Contextmenu item is not defined!";
					FWDContextMenuButton.setPrototype();
					self.linkButton_do = new FWDContextMenuButton(label1_str, label2_str, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
					self.items_ar.push(self.linkButton_do);
					self.linkButton_do.addListener(FWDContextMenuButton.CLICK, self.startLinkHandler);
					self.addChild(self.linkButton_do);
				}else if(res == "fullscreen"){
					if(!(parent.displayType == FWDViewer.FULL_SCREEN && !FWDUtils.hasFullScreen)){
						str =  self.itemsLabels_ar[i];
						if(str){
							if(str.indexOf("/") == -1){
								label1_str = "Contextmenu item is not defined!";
								label2_str = "Contextmenu item is not defined!";
							}else{
								label1_str = str.substr(0, str.indexOf("/"));
								label2_str = str.substr(str.indexOf("/") + 1);
							}
						}else{
							label1_str = "Contextmenu item is not defined!";
							label2_str = "Contextmenu item is not defined!";
						}
						FWDContextMenuButton.setPrototype();
						self.fullScreenButton_do = new FWDContextMenuButton(label1_str, label2_str, self.itemNormalColor_str, self.itemSelectedColor_str, self.itemDisabledColor_str);
						self.items_ar.push(self.fullScreenButton_do);
						self.fullScreenButton_do.addListener(FWDContextMenuButton.MOUSE_DOWN, self.fullScreenStartHandler);
						self.addChild(self.fullScreenButton_do);
					}
				}
			}
		};
		
		self.setupDeveloperButton = function(){
			if(self.showScriptDeveloper_bl){
				if(!self.itemsLabels_ar) self.itemsLabels_ar = [];
				self.itemsLabels_ar.push("&#0169; made by FWD");
				label1_str = "&#0169; made by FWD";
				FWDContextMenuButton.setPrototype();
				self.developerButton_do = new FWDContextMenuButton(label1_str, undefined, self.itemSelectedColor_str, self.itemNormalColor_str, self.itemDisabledColor_str);
				self.developerButton_do.isDeveleper_bl = true;
				self.items_ar.push(self.developerButton_do);
				self.addChild(self.developerButton_do);
			}
		};
		
		//pann button.
		self.panButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.ROTATE);
			self.removeFromDOM();
		};
		
		self.enablePanButton = function(){
			if(self.panButton_do) self.panButton_do.enable();
			if(self.rotateButton_do) self.rotateButton_do.disable();
			self.draggingMode_str = FWDController.ROTATE;
		};
		
		//rotate button
		self.panRotateStartHandler = function(e){
			self.dispatchEvent(FWDController.PAN);
			self.removeFromDOM();
		};
		
		self.enableRotateButton = function(){
			if(self.rotateButton_do) self.rotateButton_do.enable();
			if(self.panButton_do) self.panButton_do.disable();
			self.draggingMode_str = FWDController.PAN;
		};
		
		//next and prev buttons.
		self.nextButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.GOTO_NEXT_IMAGE, {e:e});
		};
		
		self.prevButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.GOTO_PREV_IMAGE, {e:e});
		};
		
		//zoom in/out buttons.
		self.zoomInButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.ZOOM_IN, {e:e});
		};
		
		self.zoomOutButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.ZOOM_OUT, {e:e});
		};
		
		//slideshow buttton.
		self.startSlideShowHandler = function(e){
			if(self.slideShowButton_do.currentState == 0){
				self.dispatchEvent(FWDController.START_SLIDE_SHOW, {e:e});
			}else{
				self.dispatchEvent(FWDController.STOP_SLIDE_SHOW, {e:e});
			}
		};
		
		self.updateSlideShowButton = function(currentState){
			if(!self.slideShowButton_do) return;
			if(currentState == 0){
				self.slideShowButton_do.setButtonState(0);
			}else{
				self.slideShowButton_do.setButtonState(1);
			}
		};
		
		//info
		self.infoButtonStart = function(e){
			self.removeFromDOM();
			self.dispatchEvent(FWDController.SHOW_INFO);
		};
		
		//full screen.
		self.fullScreenStartHandler = function(e){
			if(self.fullScreenButton_do.currentState == 0){
				self.dispatchEvent(FWDController.GO_FULL_SCREEN);
			}else if(self.fullScreenButton_do.currentState == 1){
				self.dispatchEvent(FWDController.GO_NORMAL_SCREEN);
			}
			self.fullScreenButton_do.onMouseOut();
		};
		
		self.updateFullScreenButton = function(currentState){
			if(!self.fullScreenButton_do) return;
			if(currentState == 0){
				self.fullScreenButton_do.setButtonState(0);
			}else{
				self.fullScreenButton_do.setButtonState(1);
			}
			self.removeFromDOM();
		};
	
		//link.
		self.startLinkHandler = function(e){
			window.open(self.link_str, "_blank");
		};
		
		
		//########################################//
		/* setup sapcers */
		//########################################//
		self.setupSpacers = function(){
			var totalSpacers = self.items_ar.length - 1;
			var spacer_sdo;
			
			for(var i=0; i<totalSpacers; i++){
				spacer_sdo = new FWDSimpleDisplayObject("div");
				self.spacers_ar[i] = spacer_sdo;
				spacer_sdo.setHeight(1);
				spacer_sdo.setBkColor(self.spacerColor_str);
				self.addChild(spacer_sdo);
			};
		};
		
		//########################################//
		/* Get max width and position */
		//#######################################//
		self.getMaxWidthResizeAndPosition = function(){
			var totalItems = self.items_ar.length;
			var item_do;
			var spacer;
			var finalX;
			var finalY;
			self.totalWidth = 0;
			self.totalHeight = 0;
			for(var i=0; i<totalItems; i++){
				item_do = self.items_ar[i];
				if(item_do.getMaxTextWidth() > self.totalWidth) self.totalWidth = item_do.getMaxTextWidth();
			};
			
			for(var i=0; i<totalItems; i++){
				spacer = self.spacers_ar[i - 1];
				item_do = self.items_ar[i];
				item_do.setX(self.padding);
				item_do.setY(10 + (i * (item_do.totalHeight + self.sapaceBetweenButtons)) - self.padding);
				
				if(spacer){
					spacer.setWidth(self.totalWidth + 2);
					spacer.setX(self.padding);
					spacer.setY(parseInt(item_do.getY() - self.sapaceBetweenButtons/2) - 1);
				};
				
				
				item_do.setWidth(self.totalWidth + 2);
				item_do.centerText();
			}
			
			self.totalHeight = item_do.getY() + item_do.totalHeight + 2;
			
			self.setWidth(self.totalWidth + self.padding * 2 + 4);
			self.setHeight(self.totalHeight);
			
			self.setVisible(true);
			self.removeFromDOM();
		};
		
		//##########################################//
		/* Add context events. */
		//##########################################//
		self.addContextEvent = function(){
			if(self.parent.main_do.screen.addEventListener){
				self.parent.main_do.screen.addEventListener("contextmenu", self.contextMenuHandler);
			}else{
				self.parent.main_do.screen.attachEvent("oncontextmenu", self.contextMenuHandler);
			}
		};
		
		self.contextMenuHandler = function(e){	
			if(!self.show_bl || !self.isActive_bl){
				if(e.preventDefault){
					e.preventDefault();
				}else{
					return false;
				}	
				return;
			}
			
			self.parent.main_do.addChild(self);
			self.positionButtons(e);
			self.setAlpha(0);
			TweenMax.to(self, .4, {alpha:1, ease:Quart.easeOut});
			
			if(window.addEventListener){
				window.addEventListener("mousedown", self.contextMenuWindowOnMouseDownHandler);
				window.addEventListener("mouseup", self.contextMenuWindowOnMouseDownHandler);
			}else{
				document.documentElement.attachEvent("onmousedown", self.contextMenuWindowOnMouseDownHandler);
				document.documentElement.attachEvent("onmouseup", self.contextMenuWindowOnMouseDownHandler);
			}
			
			if(e.preventDefault){
				e.preventDefault();
			}else{
				return false;
			}
		};
		
		self.contextMenuWindowOnMouseDownHandler = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			
			var screenX =  viewportMouseCoordinates.screenX;
			var screenY =  viewportMouseCoordinates.screenY;
			
			
			if(!FWDUtils.hitTest(self.screen, screenX, screenY)){
				if(window.removeEventListener){
					window.removeEventListener("mousedown", self.contextMenuWindowOnMouseDownHandler);
					window.removeEventListener("mouseup", self.contextMenuWindowOnMouseDownHandler);
				}else{
					document.documentElement.detachEvent("onmousedown", self.contextMenuWindowOnMouseDownHandler);
					document.documentElement.detachEvent("onmouseup", self.contextMenuWindowOnMouseDownHandler);
				}
				self.removeFromDOM();
			}
		};
	
		//####################################//
		/* position buttons */
		//####################################//
		self.positionButtons = function(e){
		
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			var parentWidth = self.parent.main_do.getWidth();
			var parentHeight = self.parent.main_do.getHeight();
		
			var localX = viewportMouseCoordinates.screenX - self.parent.main_do.getGlobalX();
			var localY = viewportMouseCoordinates.screenY - self.parent.main_do.getGlobalY();
			var finalX = localX - 2;
			var finalY = localY - 2;
			self.totalWidth = self.getWidth();
			self.totalHeight = self.getHeight();
			
			if(finalX + self.totalWidth > parentWidth - 2) finalX = localX - self.totalWidth;
			if(finalX < 0) finalX = parseInt((parentWidth - self.totalWidth)/2);
			if(finalX < 0) finalX = 0;
			
			if(finalY + self.totalHeight > parentHeight - 2) finalY = localY - self.totalHeight;
			if(finalY < 0) finalY = parseInt((parentHeight - self.totalHeight)/2);
			if(finalY < 0) finalY = 0;
	
			self.setX(finalX);
			self.setY(finalY);			
		};
		
		//########################################//
		/* disable / enable */
		//########################################//
		self.disable = function(){
			if(self.panButton_do) self.panButton_do.disable();
			if(self.rotateButton_do) self.rotateButton_do.disable();
			if(self.nextButton_do) self.nextButton_do.disable();
			if(self.prevButton_do) self.prevButton_do.disable();
			if(self.slideShowButton_do) self.slideShowButton_do.disable();
			if(self.infoButton_do) self.infoButton_do.disable();
			if(self.zoomInButton_do) self.zoomInButton_do.disable();
			if(self.zoomOutButton_do) self.zoomOutButton_do.disable();
			if(self.slideShowButton_do) self.slideShowButton_do.disable();
		};
		
		self.enable = function(){
			if(self.panButton_do && self.draggingMode_str == FWDController.ROTATE) self.panButton_do.enable();
			if(self.rotateButton_do && self.draggingMode_str == FWDController.PAN) self.rotateButton_do.enable();
			if(self.nextButton_do) self.nextButton_do.enable();
			if(self.prevButton_do) self.prevButton_do.enable();
			if(self.slideShowButton_do) self.slideShowButton_do.enable();
			if(self.infoButton_do) self.infoButton_do.enable();
			if(self.zoomInButton_do) self.zoomInButton_do.enable();
			if(self.zoomOutButton_do) self.zoomOutButton_do.enable();
			if(self.slideShowButton_do) self.slideShowButton_do.enable();
		};
		
		//######################################//
		/* remove from DOM */
		//######################################//
		self.removeFromDOM = function(){
			//if(self.parent.main_do.contains(self)) self.parent.main_do.removeChild(self);
			self.setX(-5000);
		};
		
		//######################################//
		/* destory */
		//######################################//
		self.destroy = function(){
			var length;
			
			clearTimeout(self.getMaxWidthResizeAndPositionId_to);
			
			TweenMax.killTweensOf(self);
			
			if(window.removeEventListener){
				window.removeEventListener("mousedown", self.contextMenuWindowOnMouseDownHandler);
				window.removeEventListener("mouseup", self.contextMenuWindowOnMouseDownHandler);
				self.parent.main_do.screen.removeEventListener("contextmenu", self.contextMenuHandler);
			}else{
				document.documentElement.detachEvent("onmousedown", self.contextMenuWindowOnMouseDownHandler);
				document.documentElement.detachEvent("onmouseup", self.contextMenuWindowOnMouseDownHandler);
				self.parent.main_do.screen.detachEvent("oncontextmenu", self.contextMenuHandler);
			}
			
			length = self.items_ar.length;
			for(var i=0; i<length; i++){
				self.items_ar[i].destroy();
			}
			
			length = self.spacers_ar.length;
			for(var i=0; i<length; i++){
				self.spacers_ar[i].destroy();
			}
			
			self.buttonsTest_ar = null;
			self.itemsLabels_ar = null;
			self.items_ar = null;
			self.spacers_ar = null;
			
			self.panButton_do = null;
			self.rotateButton_do = null;
			self.nextButton_do = null;
			self.prevButton_do = null;
			self.slideShowButton_do = null;
			self.infoButton_do = null;
			self.linkButton_do = null;
			self.fullScreenButton_do = null;
			self.zoomInButton_do = null;
			self.zoomOutButton_do = null;
			self.slideShowButton_do = null;
			self.linkButton_do = null;
			self.infoButton_do = null;
			self.fullScreenButton_do = null;
			
			self.backgroundColor_str = null;
			self.borderColor_str = null;
			self.spacerColor_str = null;
			self.itemNormalColor_str = null;
			self.itemSelectedColor_str = null;
			self.itemDisabledColor_str = null;
			self.draggingMode_str = null;
			self.link_str = null;
			
			self.init = null;
			self.setupLabels = null;
			self.setupDeveloperButton = null;
			self.panButtonStartHandler = null;
			self.enablePanButton = null;
			self.panRotateStartHandler = null;
			self.nextButtonStartHandler = null;
			self.prevButtonStartHandler = null;
			self.zoomInButtonStartHandler = null;
			self.zoomOutButtonStartHandler = null;
			self.startSlideShowHandler = null;
			self.updateSlideShowButton = null;
			self.fullScreenStartHandler = null;
			self.updateFullScreenButton = null;
			self.setupSpacers = null;
			self.getMaxWidthResizeAndPosition = null;
			self.addContextEvent = null;
			self.contextMenuHandler = null;
			self.contextMenuWindowOnMouseDownHandler = null;
			self.positionButtons = null;
			self.removeFromDOM = null;
			self.destroy = null;
			
			parent = null;
			data = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			prototype = null;
			self = null;
			FWDContextMenu.prototype = null;
		};
		
		self.init();
	};
	
	FWDContextMenu.setPrototype = function(){
		FWDContextMenu.prototype = new FWDDisplayObject("div");
	};
	
	
	FWDContextMenu.prototype = null;
	window.FWDContextMenu = FWDContextMenu;
	
}(window));
/* FWDContextMenuButton */
(function (){
var FWDContextMenuButton = function(
			label1, 
			label2, 
			normalColor,
			selectedColor,
			disabledColor,
			padding
		){
		
		var self = this;
		var prototype = FWDContextMenuButton.prototype;
		
		self.label1_str = label1;
		self.label2_str = label2;
		self.normalColor_str = normalColor;
		self.selectedColor_str = selectedColor;
		self.disabledColor_str = disabledColor;
		
		self.totalWidth = 400;
		self.totalHeight = 20;
		self.padding;
	
		self.text1_sdo = null;
		self.text2_sdo = null;
		self.dumy_sdo = null;
		
		self.isMobile_bl = FWDUtils.isMobile;
		self.currentState = 1;
		self.isDisabled_bl = false;
		self.isMaximized_bl = false;
		self.showSecondButton_bl = label2 != undefined;
		self.isDeveleper_bl = false;
		
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setBackfaceVisibility();
			self.setButtonMode(true);
			self.setupMainContainers();
			self.setWidth(self.totalWidth);
			self.setHeight(self.totalHeight);
			self.setButtonState(0);
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			
			self.text1_sdo = new FWDSimpleDisplayObject("div");
			self.text1_sdo.setBackfaceVisibility();
			self.text1_sdo.setDisplay("inline-block");
			self.text1_sdo.getStyle().fontFamily = "Arial";
			self.text1_sdo.getStyle().fontSize= "12px";
			self.text1_sdo.getStyle().color = self.normalColor_str;
			self.text1_sdo.getStyle().fontSmoothing = "antialiased";
			self.text1_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.text1_sdo.getStyle().textRendering = "optimizeLegibility";	
			self.text1_sdo.setInnerHTML(self.label1_str);
			self.addChild(self.text1_sdo);
			
			if(self.showSecondButton_bl){
				self.text2_sdo = new FWDSimpleDisplayObject("div");
				self.text2_sdo.setBackfaceVisibility();
				self.text2_sdo.setDisplay("inline-block");
				self.text2_sdo.getStyle().fontFamily = "Arial";
				self.text2_sdo.getStyle().fontSize= "12px";
				self.text2_sdo.getStyle().color = self.normalColor_str;
				self.text2_sdo.getStyle().fontSmoothing = "antialiased";
				self.text2_sdo.getStyle().webkitFontSmoothing = "antialiased";
				self.text2_sdo.getStyle().textRendering = "optimizeLegibility";	
				self.text2_sdo.setInnerHTML(self.label2_str);
				self.addChild(self.text2_sdo);
			}
			
			self.dumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE){
				self.dumy_sdo.setBkColor("#FF0000");
				self.dumy_sdo.setAlpha(0);
			};
			self.addChild(self.dumy_sdo);
			
			if(self.isMobile_bl){
				self.screen.addEventListener("touchstart", self.onMouseDown);
			}else if(self.screen.addEventListener){
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mousedown", self.onMouseDown);
				self.screen.addEventListener("click", self.onClick);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmousedown", self.onMouseDown);
				self.screen.attachEvent("onclick", self.onClick);
			}
		};
		
		self.onMouseOver = function(animate){
			if(self.isDisabled_bl) return;
			TweenMax.killTweensOf(self.text1_sdo);
			if(animate){
				TweenMax.to(self.text1_sdo.screen, .5, {css:{color:self.selectedColor_str}, ease:Expo.easeOut});
				if(self.showSecondButton_bl) TweenMax.to(self.text2_sdo.screen, .5, {css:{color:self.selectedColor_str}, ease:Expo.easeOut});
			}else{
				self.text1_sdo.getStyle().color = self.selectedColor_str;
				if(self.showSecondButton_bl){
					TweenMax.killTweensOf(self.text2_sdo);
					self.text2_sdo.getStyle().color = self.selectedColor_str;
				}
			}
			self.dispatchEvent(FWDContextMenuButton.MOUSE_OVER);
		};
			
		self.onMouseOut = function(e){
			if(self.isDisabled_bl) return;
			TweenMax.killTweensOf(self.text1_sdo);
			TweenMax.to(self.text1_sdo.screen, .5, {css:{color:self.normalColor_str}, ease:Expo.easeOut});
			
			if(self.showSecondButton_bl){
				TweenMax.killTweensOf(self.text2_sdo);
				TweenMax.to(self.text2_sdo.screen, .5, {css:{color:self.normalColor_str}, ease:Expo.easeOut});
			}
			self.dispatchEvent(FWDContextMenuButton.MOUSE_OUT);
		};
		
		self.onClick = function(e){
			if(self.isDeveleper_bl){
				window.open("http://www.webdesign-flash.ro", "_blank");
				return;
			}
			if(self.isDisabled_bl) return;
			if(e.preventDefault) e.preventDefault();
			self.dispatchEvent(FWDContextMenuButton.CLICK);
		};
		
		self.onMouseDown = function(e){
			if(self.isDisabled_bl) return;
			if(e.preventDefault) e.preventDefault();
			self.dispatchEvent(FWDContextMenuButton.MOUSE_DOWN, {e:e});
		};
		
		//##############################//
		/* toggle button */
		//#############################//
		self.toggleButton = function(){
			if(!self.showSecondButton_bl ) return;
			if(self.currentState == 1){
				self.text1_sdo.setVisible(true);
				self.text2_sdo.setVisible(false);
				self.currentState = 0;
				self.dispatchEvent(FWDContextMenuButton.FIRST_BUTTON_CLICK);
			}else{
				self.text1_sdo.setVisible(false);
				self.text2_sdo.setVisible(true);
				self.currentState = 1;
				self.dispatchEvent(FWDContextMenuButton.SECOND_BUTTON_CLICK);
			}
		};
		
		//##############################//
		/* set second buttons state */
		//##############################//
		self.setButtonState = function(state){
			if(state == 0){
				self.text1_sdo.setVisible(true);
				if(self.showSecondButton_bl) self.text2_sdo.setVisible(false);
				self.currentState = 0;
			}else if(state == 1){
				self.text1_sdo.setVisible(false);
				if(self.showSecondButton_bl) self.text2_sdo.setVisible(true);
				self.currentState = 1;
			}
		};		

		//##########################################//
		/* center text */
		//##########################################//
		self.centerText = function(){
			self.dumy_sdo.setWidth(self.totalWidth);
			self.dumy_sdo.setHeight(self.totalHeight);
			if(FWDUtils.isIEAndLessThen9){
				self.text1_sdo.setY(Math.round((self.totalHeight - self.text1_sdo.getHeight())/2) - 1);
				if(self.showSecondButton_bl) self.text2_sdo.setY(Math.round((self.totalHeight - self.text2_sdo.getHeight())/2) - 1);
			}else{
				self.text1_sdo.setY(Math.round((self.totalHeight - self.text1_sdo.getHeight())/2));
				if(self.showSecondButton_bl) self.text2_sdo.setY(Math.round((self.totalHeight - self.text2_sdo.getHeight())/2));
			}
			self.text1_sdo.setHeight(self.totalHeight + 2);
			if(self.showSecondButton_bl) self.text2_sdo.setHeight(self.totalHeight + 2);
		};
		
		//###############################//
		/* get max text width */
		//###############################//
		self.getMaxTextWidth = function(){
			var w1 = self.text1_sdo.getWidth();
			var w2 = 0;
			if(self.showSecondButton_bl) w2 = self.text2_sdo.getWidth();
			return Math.max(w1, w2);
		};
		
		//##############################//
		/* disable /enable button */
		//##############################//
		self.disable = function(){
			self.isDisabled_bl = true;
			TweenMax.killTweensOf(self.text1_sdo);
			TweenMax.to(self.text1_sdo.screen, .5, {css:{color:self.disabledColor_str}, ease:Expo.easeOut});
			self.setButtonMode(false);
		};
		
		self.enable = function(){
			self.isDisabled_bl = false;
			TweenMax.killTweensOf(self.text1_sdo);
			TweenMax.to(self.text1_sdo.screen, .5, {css:{color:self.normalColor_str}, ease:Expo.easeOut});
			self.setButtonMode(true);
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			
			if(self.isMobile_bl){
				self.screen.removeEventListener("touchstart", self.onMouseDown);
			}else if(self.screen.removeEventListener){
				self.screen.removeEventListener("mouseover", self.onMouseOver);
				self.screen.removeEventListener("mouseout", self.onMouseOut);
				self.screen.removeEventListener("mousedown", self.onMouseDown);
				self.screen.removeEventListener("click", self.onClick);
			}else if(self.screen.detachEvent){
				self.screen.detachEvent("onmouseover", self.onMouseOver);
				self.screen.detachEvent("onmouseout", self.onMouseOut);
				self.screen.detachEvent("onmousedown", self.onMouseDown);
				self.screen.detachEvent("onclick", self.onClick);
			}
			
			
			TweenMax.killTweensOf(self.text1_sdo);
			self.text1_sdo.destroy();
			
			if(self.text2_sdo){
				TweenMax.killTweensOf(self.text2_sdo);
				self.text2_sdo.destroy();
			}
			
			self.dumy_sdo.destroy();
			
			
			self.text1_sdo = null;
			self.text2_sdo = null;
			self.dumy_sdo = null;
			
			self.label1_str = null;
			self.label2_str = null;
			self.normalColor_str = null;
			self.selectedColor_str = null;
			self.disabledColor_str = null;
			
			label1 = null;
			label2 = null; 
			normalColor = null;
			selectedColor = null;
			disabledColor = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDContextMenuButton.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDContextMenuButton.setPrototype = function(){
		FWDContextMenuButton.prototype = new FWDDisplayObject("div");
	};
	
	FWDContextMenuButton.FIRST_BUTTON_CLICK = "onFirstClick";
	FWDContextMenuButton.SECOND_BUTTON_CLICK = "secondButtonOnClick";
	FWDContextMenuButton.MOUSE_OVER = "onMouseOver";
	FWDContextMenuButton.MOUSE_OUT = "onMouseOut";
	FWDContextMenuButton.MOUSE_DOWN = "onMouseDown";
	FWDContextMenuButton.CLICK = "onClick";
	
	FWDContextMenuButton.prototype = null;
	window.FWDContextMenuButton = FWDContextMenuButton;
}(window));/* FWDController */
(function(){
var FWDController = function(
			data,
			parent
		){
		
		var self = this;
		var prototype = FWDController.prototype;
		
		this.buttonsTest_ar = data.buttons_ar;
		this.buttonsLabels_ar = data.buttonsLabels_ar;
		this.buttons_ar = [];
	
		this.backgroundLeft_img = data.controllerBackgroundLeft_img;
		this.backgroundRight_img = data.controllerBackgroundRight_img;
		this.panN_img = data.controllerPanN_img;
		this.panS_img = data.controllerPanS_img;
		this.rotateN_img = data.controllerRotateN_img;
		this.rotateS_img = data.controllerRotateS_img;
		this.nextN_img = data.controllerNextN_img;
		this.nextS_img = data.controllerNextS_img;
		this.prevN_img = data.controllerPrevN_img;
		this.prevS_img = data.controllerPrevS_img;
		this.playN_img = data.controllerPlayN_img;
		this.playS_img = data.controllerPlayS_img;
		this.pauseN_img = data.controllerPauseN_img;
		this.pauseS_img = data.controllerPauseS_img;
		this.infoN_img = data.controllerInfoN_img;
		this.infoS_img = data.controllerInfoS_img;
		this.linkN_img = data.controllerLinkN_img;
		this.linkS_img = data.controllerLinkS_img;
		this.fullScreenNormalN_img = data.controllerFullScreenNormalN_img;
		this.fullScreenNormalS_img = data.controllerFullScreenNormalS_img;
		this.fullScreenFullN_img = data.controllerFullScreenFullN_img;
		this.fullScreenFullS_img = data.controllerFullScreenFullS_img;
		this.zoomInN_img = data.zoomInN_img;
		this.zoomInS_img = data.zoomInS_img;
		this.zoomOutN_img = data.zoomOutN_img;
		this.zoomOutS_img = data.zoomOutS_img;
		this.scrollBarHandlerN_img = data.scrollBarHandlerN_img;
		this.scrollBarHandlerS_img =  data.scrollBarHandlerS_img;
		this.scrollBarLeft_img = data.scrollBarLeft_img;
		this.scrollBarRight_img =  data.scrollBarRight_img;
		this.toolTipLeft_img = data.toolTipLeft_img;
		this.toolTipPointer_img = data.toolTipPointer_img;

		this.hider = null;
		this.mainHolder_do = null;
		this.backgroundLeft_sdo = null;
		this.backgroundMiddle_sdo = null;
		this.backgroundRight_sdo = null;
		this.panButton_do = null;
		this.rotateButton_do = null;
		this.nextButton_do = null;
		this.prevButton_do = null;
		this.slideShowButton_do = null;
		this.infoButton_do = null;
		this.linkButton_do = null;
		this.fullScreenButton_do = null;
		this.zoomIn_do = null;
		this.zoomOut_do = null;
		this.scrollBar_do = null;
		this.scrollBarLeft_sdo = null;
		this.scrollBarRight_sdo = null;
		this.scrollBarMiddle_sdo = null;
		this.scrollBarHandler_do = null;
		this.scrollBarHandlerN_sdo = null;
		this.scrollBarHandlerS_sdo = null;
		this.panButtonTooTipLabel_do = null;
		this.scrollBarHandlerToolTip_do = null;
		this.rotateButtonToolTip_do = null;
		this.nextButtonToolTip_do = null;
		this.prevButtonToolTip_do = null;
		this.slideShowToolTip_do = null;
		this.infoToolTip_do = null;
		this.linkToolTip_do = null;
		this.fullscreenToolTip_do = null;
		
		this.backgroundMiddlePath_str = data.controllerBackgroundMiddlePath_str;
		this.scrollBarMiddlePath_str = data.scrollBarMiddlePath_str;
		this.draggingMode_str = data.startDraggingMode_str;
		this.controllerPosition_str  = data.controllerPosition_str; 
		this.buttonToolTipLeft_str = data.buttonToolTipLeft_str;
		this.buttonToolTipMiddle_str = data.buttonToolTipMiddle_str;
		this.buttonToolTipRight_str = data.buttonToolTipRight_str;
		this.link_str = data.link_str;;
		this.buttonToolTipFontColor_str = data.buttonToolTipFontColor_str;
		this.buttonToolTipBottomPointer_str = data.buttonToolTipBottomPointer_str;
		this.buttonToolTipTopPointer_str = data.buttonToolTipTopPointer_str;
		
		this.scrollBarPosition = FWDUtils.indexOfArray(self.buttonsTest_ar, "scrollbar");
		this.controllerBackgroundOpacity = data.controllerBackgroundOpacity;
		this.rotationSpeed = data.buttonsRotationSpeed;
		
		this.slideShowDelay = data.slideShowDelay;
		this.stageWidth;
		this.setHeight;
		this.controllerOffsetY = data.controllerOffsetY;
		this.scrollBarOffsetX = data.scrollBarOffsetX;
		this.scrollBarRightPartWidth = self.scrollBarRight_img.width;
		this.startSpaceBetweenButtons = data.startSpaceBetweenButtons;
		this.scrollBarHeight = self.scrollBarLeft_img.height;
		this.scrollBarHandlerWidth = self.scrollBarHandlerN_img.width;
		this.scrollBarHandlerHeight = self.scrollBarHandlerN_img.height;
		this.spaceBetweenButtons = data.spaceBetweenButtons;
		this.curHeight = self.backgroundLeft_img.height;
		this.zoomButtonWidth = self.zoomOutN_img.width;
		this.zoomButtonHeight = self.zoomOutN_img.height;
		this.finalHandlerX;
		this.startSpaceForScrollBarButtons = data.startSpaceForScrollBarButtons;
		this.smallSpaceForScrollBar = data.startSpaceForScrollBar;
		this.totalLargeButtons;
		this.curWidth;
		this.maxWidth = data.controllerMaxWidth;
		this.minWidth;
		this.buttonWidth = self.panN_img.width;
		this.buttonHeight = self.panN_img.height;
		this.scrollBarTotalWidth;
		this.scrollBarHandlerXPositionOnPress;
		this.lastPresedX;
		this.scrollBarHandlerToolTipOffsetY = data.scrollBarHandlerToolTipOffsetY;
		this.zoomInAndOutToolTipOffsetY = data.zoomInAndOutToolTipOffsetY;
		this.buttonsToolTipOffsetY = data.buttonsToolTipOffsetY;
		
		this.gotoImageId_int;
		this.zoomWithButtonsId_int;
		this.slideShowId_int;
		this.gotoImageId_to;
		this.zoomWithButtonsId_to;
		
		this.showScrollBar_bl = false;
		if(FWDUtils.indexOfArray(self.buttonsTest_ar, "scrollbar") != -1) self.showScrollBar_bl = true;
		
		this.isMobile_bl = data.isMobile_bl;
		this.inverseNextAndPrevRotation_bl = data.inverseNextAndPrevRotation_bl;
		this.isScrollBarActive_bl = false;
		this.isZoomInOrOutPressed_bl = false;
		this.isKeyPressed_bl = false;
		this.addKeyboardSupport_bl = data.addKeyboardSupport_bl;
		this.showButtonsLabels_bl = Boolean(self.buttonsLabels_ar);
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;

		//##########################################//
		/* initialize this */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setSelectable(false);
			self.setupMainHolder();
			self.setupBackground();
			if(self.addKeyboardSupport_bl) self.addKeyboardSupport();
			self.setupButtons();
			self.totalLargeButtons = self.buttons_ar.lenght;
			if(self.showScrollBar_bl) self.setupScrollBar();
			if(self.buttonsTest_ar.length == 0 && !self.showScrollBar_bl) self.setVisible(false);
			self.hide();
			self.show();
			
			self.screen.onmousedown = function(){
				self.dispatchEvent(FWDController.MOUSE_DOWN);
			};
		};
		
		//###########################################//
		// Resize and position self...
		//###########################################//
		self.resizeAndPosition = function(){
			if(parent.stageWidth == self.stageWidth && parent.stageHeight == self.stageHeight) return;
					
			self.stageWidth = parent.stageWidth;
			self.stageHeight = parent.stageHeight;
			
			self.setWidth(self.stageWidth);
			self.setHeight(self.stageHeight);
			self.positionButtons();
		};
		
		//##########################################//
		//Setup main container.
		//##########################################//
		self.setupMainHolder = function(){
			self.mainHolder_do = new FWDDisplayObject("div");
			self.mainHolder_do.setOverflow("visible");
			self.addChild(self.mainHolder_do);
		};
		
		//##########################################//
		//Setup hider.
		//##########################################//
		self.setupHider = function(hider){
			self.hider = hider;
			self.hider.addListener(FWDHider.SHOW, self.onHiderShow);
			self.hider.addListener(FWDHider.HIDE, self.onHiderHide);
		};
		
		self.onHiderShow = function(){
			self.show();
		};
		
		self.onHiderHide = function(){
			if(FWDUtils.hitTest(self.mainHolder_do.screen, self.hider.globalX, self.hider.globalY)){
				self.hider.reset();
				return;
			}else{
				self.hide(true);
			}
		};
		
		//#####################################//
		/* add keyboard support */
		//####################################//
		this.addKeyboardSupport = function(){
			if(document.addEventListener){
				window.addEventListener("keydown",  self.onKeyDownHandler);	
				window.addEventListener("keyup",  self.onKeyUpHandler);
			}else if(document.attachEvent){
				document.attachEvent("onkeydown",  self.onKeyDownHandler);	
				document.attachEvent("onkeyup",  self.onKeyUpHandler);
			}
		};
		
		this.onKeyDownHandler = function(e){
			if(parent.hibernate_bl) return;
			if(self.isKeyPressed_bl) return;
			if(e.keyCode == 39){
				self.isKeyPressed_bl = true;
				if(self.slideShowButton_do) self.stopSlideShow();
				self.gotoNextImage();
				clearInterval(self.gotoImageId_int);
				clearTimeout(self.gotoImageId_to);
				self.gotoImageId_to = setTimeout(self.goToNextImageInWithDelay, 400);
				self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
				
				if(e.preventDefault){
					e.preventDefault();
				}else{
					return false;
				}
			}else if(e.keyCode == 37){
				self.isKeyPressed_bl = true;
				if(self.slideShowButton_do) self.stopSlideShow();
				self.gotoPrevImage();
				clearInterval(self.gotoImageId_int);
				clearTimeout(self.gotoImageId_to);
				self.gotoImageId_to = setTimeout(self.goToPrevImageInWithDelay, 400);
				self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
				
				if(e.preventDefault){
					e.preventDefault();
				}else{
					return false;
				}
			}
		};
		
		this.onKeyUpHandler = function(e){
			self.isKeyPressed_bl = false;
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			if(window.addEventListener){
				window.addEventListener("keydown",  self.onKeyDownHandler);	
			}else if(document.attachEvent){
				document.attachEvent("onkeydown",  self.onKeyDownHandler);	
			}
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		
		//##########################################//
		/* Setup buttons. */
		//##########################################//
		self.setupButtons = function(){
			var len = self.buttonsTest_ar.length;
			var res;
			var label1_str = "";
			var label2_str = "";
			for(var i=0; i<len; i++){
				res = self.buttonsTest_ar[i];		
				if(res == "pan"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupPanButton(label1_str);
					self.buttons_ar.push(self.panButton_do);
				}else if(res == "rotate"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupRotateButton(label1_str);
					self.buttons_ar.push(self.rotateButton_do);	
				}else if(res == "rotateright"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupNextButton(label1_str);
					self.buttons_ar.push(self.nextButton_do);
				}else if(res == "roteteleft"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupPrevButton(label1_str);
					self.buttons_ar.push(self.prevButton_do);
				}else if(res == "play"){
					if(self.showButtonsLabels_bl){
						var str =  self.buttonsLabels_ar[i];
						if(str){
							if(str.indexOf("/") == -1){
								label1_str = "tooltip is not defined!";
								label2_str = "tooltip is not defined!";
							}else{
								label1_str = str.substr(0, str.indexOf("/"));
								label2_str = str.substr(str.indexOf("/") + 1);
							}
						}else{
							label1_str = "tooltip is not defined!";
							label2_str = "tooltip is not defined!";
						}
					}
					self.setupSlideshowButton(label1_str, label2_str);
					self.buttons_ar.push(self.slideShowButton_do);
				}else if(res == "info"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupInfoButton(label1_str);
					self.buttons_ar.push(self.infoButton_do);
				}else if(res == "link"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupLinkButton(label1_str);
					self.buttons_ar.push(self.linkButton_do);
				}else if(res == "fullscreen"){
					if(!(parent.displayType == FWDViewer.FULL_SCREEN && !FWDUtils.hasFullScreen)){
						if(self.showButtonsLabels_bl){
							var str =  self.buttonsLabels_ar[i];
							if(str){
								if(str.indexOf("/") == -1){
									label1_str = "tooltip is not defined!";
									label2_str = "tooltip is not defined!";
								}else{
									label1_str = str.substr(0, str.indexOf("/"));
									label2_str = str.substr(str.indexOf("/") + 1);
								}
							}else{
								label1_str = "tooltip is not defined!";
								label2_str = "tooltip is not defined!";
							}
						}
						self.setupFullScreenButton(label1_str, label2_str);
						self.buttons_ar.push(self.fullScreenButton_do);
					}
				}
			}
		};

		//##############################//
		/* setup background */
		//##############################//
		self.positionButtons = function(){
			
			var len = self.buttons_ar.length;
			var tempSpacerBetweenButtons = self.spaceBetweenButtons;
			var lastLeftButton_do;
			var totalButtonsWidth;
			var scrollBarLength;
			var startZoomX;
			var finalX;
			var finalY;
			var button;
			var indexToAddZoomButtons;
			
			if(self.showScrollBar_bl){
				self.isScrollBarActive_bl = true;
				self.curWidth = self.stageWidth;
				
				indexToAddZoomButtons = FWDUtils.indexOfArray(self.buttons_ar, self.zoomIn_do);
				if(indexToAddZoomButtons != -1){
					self.buttons_ar.splice(indexToAddZoomButtons, 1);
					len--;
				}
				
				indexToAddZoomButtons = FWDUtils.indexOfArray(self.buttons_ar, self.zoomOut_do);
				if(indexToAddZoomButtons != -1){
					self.buttons_ar.splice(indexToAddZoomButtons, 1);
					len--;
				}
				
				if(self.scrollBarPosition > len) self.scrollBarPosition = len;
				if(self.scrollBarPosition < 0) self.scrollBarPosition = 0;
				if(self.curWidth > self.maxWidth) self.curWidth = self.maxWidth;
				
				if(len == 0){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else if(len > 1 && self.scrollBarPosition != 0 && self.scrollBarPosition != len){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (len * self.buttonWidth) + (self.spaceBetweenButtons * (len - 2)) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else if(len > 1 && (self.scrollBarPosition == 0 || self.scrollBarPosition == len)){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 3) + (len * self.buttonWidth) + (self.spaceBetweenButtons * (len - 1)) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else{
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (len * self.buttonWidth)  + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}
				
				self.scrollBarTotalWidth = self.curWidth - self.scrollBarTotalWidth;
				if(self.scrollBarTotalWidth < 100) self.isScrollBarActive_bl = false;
			}
			
			if(self.isScrollBarActive_bl){
				
				self.scrollBar_do.setVisible(true);
				
				for(var i=0; i<self.scrollBarPosition; i++){
					button = self.buttons_ar[i];
					if(button){
						button = self.buttons_ar[i];
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						button.setX(finalX);
						button.setY(finalY);
					}
				}
				
				for(var i = len + 1; i>=self.scrollBarPosition; i--){
					button = self.buttons_ar[i];
					if(button){
						button = self.buttons_ar[i];
						finalX = self.curWidth  - self.startSpaceBetweenButtons - self.buttonWidth  - (Math.abs(i - len + 1) * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						button.setX(finalX);
						button.setY(finalY);
					}
				}
				
				if(len == 0){
					startZoomX = self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}else if(len > 1 && self.scrollBarPosition != 0 && self.scrollBarPosition != len){
					startZoomX = self.buttons_ar[self.scrollBarPosition - 1].getX() + self.buttonWidth + self.startSpaceForScrollBarButtons;
				}else if(len > 1 && self.scrollBarPosition == 0){
					startZoomX = self.startSpaceBetweenButtons + self.startSpaceForScrollBarButtons;
				}else if(len > 1 && self.scrollBarPosition == len){
					startZoomX = self.buttons_ar[self.scrollBarPosition - 1].getX() + self.buttonWidth + self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}else if(len == 1 && self.scrollBarPosition > 0){
					startZoomX = self.startSpaceBetweenButtons + self.buttonWidth + self.startSpaceForScrollBarButtons;
				}else if(len == 1 && self.scrollBarPosition == 0){
					startZoomX = self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}
				
				startZoomX += self.scrollBarOffsetX;
				
				self.zoomOut_do.setX(startZoomX );
				self.zoomOut_do.setY(parseInt((self.curHeight - self.zoomButtonHeight)/2));
				
				self.zoomIn_do.setX(self.zoomOut_do.getX() + self.zoomButtonWidth + (self.smallSpaceForScrollBar * 2) + self.scrollBarTotalWidth);
				self.zoomIn_do.setY(parseInt((self.curHeight - self.zoomButtonHeight)/2));
				
				self.scrollBar_do.setX(self.zoomOut_do.getX() + self.smallSpaceForScrollBar + self.zoomButtonWidth);
				
				self.scrollBar_do.setY(parseInt((self.curHeight - self.scrollBarHeight)/2) + 1);
				self.scrollBar_do.setWidth(self.scrollBarTotalWidth);
				
				self.scrollBarMiddle_do.setX(self.scrollBarRightPartWidth - 1);
				self.scrollBarMiddle_do.setWidth(self.scrollBarTotalWidth - (self.scrollBarRightPartWidth * 2) + 2);
				self.scrollBarRight_do.setX(self.scrollBarTotalWidth - self.scrollBarRightPartWidth);
			}else{
				if(self.showScrollBar_bl){
					self.scrollBar_do.setVisible(false);
					if(FWDUtils.indexOfArray(self.buttons_ar, self.zoomIn_do) == -1){
						indexToAddZoomButtons = self.scrollBarPosition;
						self.buttons_ar.splice(indexToAddZoomButtons, 0, self.zoomIn_do);
						self.buttons_ar.splice(indexToAddZoomButtons, 0, self.zoomOut_do);
					}
					len = self.buttons_ar.length;
					//self.scrollBar_do.setWidth(self.scrollBarTotalWidth);
				}
				
				self.minWidth = (len * self.buttonWidth) + (self.startSpaceBetweenButtons * 2) + (self.spaceBetweenButtons * len) - self.spaceBetweenButtons;
				
				if(self.minWidth > self.stageWidth){
					self.minWidth = self.stageWidth;
					if(self.minWidth < 320) self.minWidth = 320;
					totalButtonsWidth = self.buttonWidth * len;
					tempSpacerBetweenButtons = ((self.minWidth - (self.startSpaceBetweenButtons * 2)) - totalButtonsWidth)/(len - 1);
				}
				
				self.curWidth = self.minWidth;
				for(var i=0; i<len + 2; i++){
					button = self.buttons_ar[i];
					if(button){
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						
						if(button == self.zoomIn_do){
							finalX = finalX + parseInt((self.buttonWidth - self.zoomButtonWidth)/2) - 2;
							finalY = parseInt((self.curHeight - self.zoomButtonHeight)/2);
						}else if(button ==  self.zoomOut_do){
							finalX = finalX + parseInt((self.buttonWidth - self.zoomButtonWidth)/2) + 2;
							finalY = parseInt((self.curHeight - self.zoomButtonHeight)/2);
						}
						
						button.setX(finalX);
						button.setY(finalY);
					}
				}
			}
		
			self.backgroundRight_sdo.setX(self.curWidth -  self.backgroundRight_sdo.getWidth());
			self.backgroundMiddle_sdo.setX(self.backgroundLeft_sdo.getWidth());
			self.backgroundMiddle_sdo.setWidth(self.curWidth - (self.backgroundLeft_sdo.getWidth() * 2));
			self.backgroundMiddle_sdo.setHeight(self.curHeight);
			
			self.mainHolder_do.setWidth(self.curWidth);
			self.mainHolder_do.setHeight(self.curHeight);
			self.setWidth(self.curWidth);
			self.setHeight(self.curHeight);
			
			if(self.controllerPosition_str == FWDController.POSITION_TOP){
				self.mainHolder_do.setX(Math.round((self.stageWidth - self.curWidth)/2));
				self.setY(self.controllerOffsetY);
			}else{
				self.mainHolder_do.setX(Math.round((self.stageWidth - self.curWidth)/2));
				self.setY(self.stageHeight - self.curHeight - self.controllerOffsetY);
			}
		};
		
		//##############################//
		/* setup background */
		//##############################//
		self.setupBackground = function(){
		
			self.backgroundLeft_sdo = new FWDSimpleDisplayObject("img");
			self.backgroundLeft_sdo.setScreen(self.backgroundLeft_img);
			if(self.controllerBackgroundOpacity != 1) self.backgroundLeft_sdo.setAlpha(self.controllerBackgroundOpacity);
			
			self.backgroundMiddle_sdo = new FWDSimpleDisplayObject("div");
			self.backgroundMiddle_sdo.getStyle().background = "url('" + self.backgroundMiddlePath_str + "')";
			self.backgroundMiddle_sdo.getStyle().backgroundRepeat = "repeat-x";
			if(self.controllerBackgroundOpacity != 1) self.backgroundMiddle_sdo.setAlpha(self.controllerBackgroundOpacity);
		
			self.backgroundRight_sdo = new FWDSimpleDisplayObject("img");
			self.backgroundRight_sdo.setScreen(self.backgroundRight_img);
			if(self.controllerBackgroundOpacity != 1) self.backgroundRight_sdo.setAlpha(self.controllerBackgroundOpacity);
			
			self.mainHolder_do.addChild(self.backgroundLeft_sdo);
			self.mainHolder_do.addChild(self.backgroundRight_sdo);
			self.mainHolder_do.addChild(self.backgroundMiddle_sdo);
		};
		
		//##############################//
		/* setup pan button */
		//##############################//
		self.setupPanButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.panButton_do = new FWDSimpleButton(self.panN_img, self.panS_img, self.isMobile_bl);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.panButtonOnMouseOverHandler);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.panButtonOnMouseOutHandler);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.panButtonOnMouseDownHandler);
			self.mainHolder_do.addChild(self.panButton_do);
			if(self.draggingMode_str == FWDController.PAN)  self.disablePanButton();
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.panButtonTooTipLabel_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str
						);
				self.mainHolder_do.addChild(self.panButtonTooTipLabel_do);
			}
			
		};
		
		self.panButtonOnMouseOverHandler = function(e){
			if(self.panButton_do.isSelectedFinal_bl) return;
			self.showToolTipButton(self.panButton_do, self.panButtonTooTipLabel_do, self.buttonsToolTipOffsetY);
		};
		
		self.panButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.panButtonTooTipLabel_do.hide();
		};
		
		self.panButtonOnMouseDownHandler = function(e){
			self.pan();
		};
		
		self.disablePanButton = function(){
			self.panButton_do.setSelctedFinal();
			if(self.rotateButton_do) self.rotateButton_do.setUnselctedFinal();
		};
		
		this.pan = function(){
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			if(self.panButton_do){
				if(self.showButtonsLabels_bl) self.panButtonTooTipLabel_do.hide();
				self.disablePanButton();
			}
			self.dispatchEvent(FWDController.CHANGE_NAVIGATION_STYLE, {draggingMode:FWDController.PAN});
		};
		
		//##############################//
		/* setup rotate button */
		//##############################//
		self.setupRotateButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.rotateButton_do = new FWDSimpleButton(self.rotateN_img, self.rotateS_img, self.isMobile_bl);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.rotateButtonOnMouseOverHandler);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.rotateButtonOnMouseOutHandler);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.rotateButtonOnMouseDownHandler);
			self.mainHolder_do.addChild(self.rotateButton_do);
			if(self.draggingMode_str == FWDController.ROTATE) self.disableRotateButton();
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.rotateButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.rotateButtonToolTip_do);
			}
			
		};			
		
		self.rotateButtonOnMouseOverHandler = function(e){
			if(self.rotateButton_do.isSelectedFinal_bl) return;
			self.showToolTipButton(self.rotateButton_do, self.rotateButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.rotateButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.rotateButtonToolTip_do.hide();
		};
		
		self.rotateButtonOnMouseDownHandler = function(e){
			self.rotate();
		};
		
		self.disableRotateButton = function(){	
			self.rotateButton_do.setSelctedFinal();
			if(self.panButton_do) self.panButton_do.setUnselctedFinal();
		};
		
		this.rotate = function(){
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			if(self.rotateButton_do){
				if(self.showButtonsLabels_bl) self.rotateButtonToolTip_do.hide();
				self.disableRotateButton();
			}
			self.dispatchEvent(FWDController.CHANGE_NAVIGATION_STYLE, {draggingMode:FWDController.ROTATE});
		}
		
		//##############################//
		/* setup next  button */
		//##############################//
		self.setupNextButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.nextButton_do = new FWDSimpleButton(self.nextN_img, self.nextS_img, self.isMobile_bl);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.nextButtonOnMouseOverHandler);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.nextButtonOnMouseOutHandler);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.nextButtonStartHandler);
			self.mainHolder_do.addChild(self.nextButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.nextButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.nextButtonToolTip_do);
			}
		};
		
		self.nextButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.nextButton_do, self.nextButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.nextButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.nextButtonToolTip_do.hide();
		};
		
		self.nextButtonStartHandler = function(e){
			if(e){
				var e = e.e;
				if(e.touches){
					if(self.scrollBarHandler_do){
						self.zoomInWithButtonsEndHandler(e);
						self.zoomOutWithButtonsEndHandler(e);
						self.handlerDragEndHandler(e);
					}
				}
			}
			
			self.gotoNextImage();
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.gotoImageId_to = setTimeout(self.goToNextImageInWithDelay, 400);
			
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.addEventListener("touchend", self.gotoImageEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
		};
		
		self.goToNextImageInWithDelay = function(){
			self.gotoImageId_int = setInterval(self.gotoNextImage, self.rotationSpeed);
		};
		
		self.gotoImageEndHandler = function(e){
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.removeEventListener("touchend", self.gotoImageEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		self.gotoNextImage = function(){
			var dir = 1;
			if(self.inverseNextAndPrevRotation_bl) dir = -1; 
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:dir});
		};
		
		//##############################//
		/* setup prev button */
		//##############################//
		self.setupPrevButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.prevButton_do = new FWDSimpleButton(self.prevN_img, self.prevS_img, self.isMobile_bl);
			self.prevButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.prevButtonOnMouseOverHandler);
			self.prevButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.prevShowButtonOnMouseOutHandler);
			self.prevButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.prevButtonStartHandler);
			self.mainHolder_do.addChild(self.prevButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.prevButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.prevButtonToolTip_do);
			}
		};
		
		self.prevButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.prevButton_do, self.prevButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.prevShowButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.prevButtonToolTip_do.hide();
		};
		
		self.prevButtonStartHandler = function(e){
			if(e){
				var e = e.e;
				if(e.touches){
					if(self.scrollBarHandler_do){
						self.zoomInWithButtonsEndHandler(e);
						self.zoomOutWithButtonsEndHandler(e);
						self.handlerDragEndHandler(e);
					}
				}
			}
			if(self.slideShowButton_do) self.stopSlideShow();
			self.gotoPrevImage();
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.gotoImageId_to = setTimeout(self.goToPrevImageInWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.addEventListener("touchend", self.gotoImageEndHandler);
				}
				window.addEventListener("mouseup", self.gotoImageEndHandler);
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
		};
		
		self.goToPrevImageInWithDelay = function(){
			self.gotoImageId_int = setInterval(self.gotoPrevImage, self.rotationSpeed);
		};
		
		self.gotoPrevImage = function(){
			var dir = -1;
			if(self.inverseNextAndPrevRotation_bl) dir = 1; 
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:dir});
		};
		
		//##############################//
		/* setup slideshow button */
		//##############################//
		self.setupSlideshowButton = function(toolTipLabel1, toolTipLabel2){
			FWDComplexButton.setPrototype();
			self.slideShowButton_do = new FWDComplexButton(self.playN_img, self.playS_img, self.pauseN_img, self.pauseS_img, true);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.slideSwhoButtonOnMouseOverHandler);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.slideShowButtonOnMouseOutHandler);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.slideShowButtonStartHandler);
			self.mainHolder_do.addChild(self.slideShowButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.slideShowToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel1,
						toolTipLabel2,
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.slideShowToolTip_do);
			}
		};
		
		self.slideSwhoButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.slideShowButton_do, self.slideShowToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.slideShowButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.slideShowToolTip_do.hide();
		};
		
		self.slideShowButtonStartHandler = function(e){
			if(self.showButtonsLabels_bl) self.slideShowToolTip_do.hide();
			if(self.slideShowButton_do.currentState == 1){
				self.startSlideshow();
				self.slideShowButton_do.setButtonState(0);
				if(self.showButtonsLabels_bl) self.slideShowToolTip_do.setLabel(self.slideShowToolTip_do.toolTipLabel2_str);
			}else{
				self.stopSlideShow();
				self.slideShowButton_do.setButtonState(1);
				if(self.showButtonsLabels_bl) self.slideShowToolTip_do.setLabel(self.slideShowToolTip_do.toolTipLabel_str);
			}
		};
		
		self.startSlideshow = function(){
			if(self.slideShowButton_do) self.slideShowButton_do.setButtonState(0);
			clearInterval(self.slideShowId_int);
			self.slideShowId_int = setInterval(self.slideShowComplete, self.slideShowDelay);
			self.dispatchEvent(FWDController.START_SLIDE_SHOW);
		};
		
		self.stopSlideShow = function(){
			if(self.slideShowButton_do) self.slideShowButton_do.setButtonState(1);
			clearInterval(self.slideShowId_int);
			self.dispatchEvent(FWDController.STOP_SLIDE_SHOW);
		};
		
		self.slideShowComplete = function(){
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:1});
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		//##############################//
		/* setup info button */
		//##############################//
		self.setupInfoButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.infoButton_do = new FWDSimpleButton(self.infoN_img, self.infoS_img, self.isMobile_bl);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.infoButtonOnMouseOverHandler);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.infoButtonOnMouseOutHandler);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.infoButtonStartHandler);
			self.mainHolder_do.addChild(self.infoButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.infoToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.infoToolTip_do);
			}
		};
		
		self.infoButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.infoButton_do, self.infoToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.infoButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.infoToolTip_do.hide();
		};
		
		self.infoButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.SHOW_INFO);
		};
		
		
		//##############################//
		/* setup link button */
		//##############################//
		self.setupLinkButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.linkButton_do = new FWDSimpleButton(self.linkN_img, self.linkS_img, self.isMobile_bl);
			self.linkButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.linkButtonOnMouseOverHandler);
			self.linkButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.linkButtonOnMouseOutHandler);
			self.linkButton_do.addListener(FWDComplexButton.CLICK, self.linkButtonOnMouseClickHandler);
			self.mainHolder_do.addChild(self.linkButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.linkToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.linkToolTip_do);
			}
		};
		
		self.linkButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.linkButton_do, self.linkToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.linkButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.linkToolTip_do.hide();
		};
		
		self.linkButtonOnMouseClickHandler = function(e){
			window.open(self.link_str, "_blank");
		};
		
		//##############################//
		/* setup link button */
		//##############################//
		self.setupFullScreenButton = function(toolTipLabel1, toolTipLabel2){
			FWDComplexButton.setPrototype();
			self.fullScreenButton_do = new FWDComplexButton(self.fullScreenFullN_img, self.fullScreenFullS_img, self.fullScreenNormalN_img, self.fullScreenNormalS_img, true);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.fullscreenButtonOnMouseOverHandler);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.fullscreenButtonOnMouseOutHandler);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.fullScreenButtonStartHandler);
			self.mainHolder_do.addChild(self.fullScreenButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.fullscreenToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel1,
						toolTipLabel2,
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.fullscreenToolTip_do);
			}
		};
		
		self.fullscreenButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.fullScreenButton_do, self.fullscreenToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.fullscreenButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.hide();
		};
		
		self.fullScreenButtonStartHandler = function(e){
			if(self.fullScreenButton_do.currentState == 1){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.fullScreenButton_do.setButtonState(0);
				self.dispatchEvent(FWDController.GO_FULL_SCREEN);
			}else if(self.fullScreenButton_do.currentState == 0){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
				self.fullScreenButton_do.setButtonState(1);
				self.dispatchEvent(FWDController.GO_NORMAL_SCREEN);
			}
			setTimeout(function(){
				if(self == null) return;
				self.fullScreenButton_do.onMouseOut(e);
				}, 50);
		};
		
		self.setFullScreenButtonState = function(state){
			if(state == 0){
				self.fullScreenButton_do.setButtonState(0);
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
			}else if(state == 1){
				self.fullScreenButton_do.setButtonState(1);
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
			}
		};
		
		this.onFullScreenChange = function(e){
			if(parent.hibernate_bl) return;
			if(document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msieFullScreen){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.fullScreenButton_do.setButtonState(0);
				self.dispatchEvent(FWDController.GO_FULL_SCREEN);
			}else{
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
				self.fullScreenButton_do.setButtonState(1);	
				self.dispatchEvent(FWDController.GO_NORMAL_SCREEN);
			}
		};
		
		//##############################//
		/* setup scrollbar */
		//##############################//
		self.setupScrollBar = function(){
			var label_str1;
			
			FWDSimpleButton.setPrototype();
			self.zoomIn_do = new FWDSimpleButton(self.zoomInN_img, self.zoomInS_img);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_OVER, self.zoomInMouseOverHandler);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_OUT, self.zoomInOrOutMouseOutHandler);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.zoomInStartHandler);
			self.mainHolder_do.addChild(self.zoomIn_do);
			
			FWDSimpleButton.setPrototype();
			self.zoomOut_do = new FWDSimpleButton(self.zoomOutN_img, self.zoomOutS_img);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_OVER, self.zoomOutMouseOverHandler);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_OUT, self.zoomInOrOutMouseOutHandler);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.zoomOutStartHandler);
			self.mainHolder_do.addChild(self.zoomOut_do);
			
			self.scrollBar_do = new FWDDisplayObject("div");
			self.scrollBar_do.setOverflow("visible");
			self.scrollBar_do.setHeight(self.scrollBarHeight);
			self.mainHolder_do.addChild(self.scrollBar_do);
			
			self.scrollBarLeft_do = new FWDSimpleDisplayObject("img");
			self.scrollBarLeft_do.setScreen(data.scrollBarLeft_img);
			self.scrollBar_do.addChild(self.scrollBarLeft_do);
			
			self.scrollBarMiddle_do = new FWDSimpleDisplayObject("div");
			self.scrollBarMiddle_do.setHeight(self.scrollBarHeight);
			self.scrollBarMiddle_do.getStyle().background = "url('" + self.scrollBarMiddlePath_str + "')";
			self.scrollBarMiddle_do.getStyle().backgroundRepeat = "repeat-x";
			
			self.scrollBar_do.addChild(self.scrollBarMiddle_do);
			
			self.scrollBarRight_do = new FWDSimpleDisplayObject("img");
			self.scrollBarRight_do.setScreen(self.scrollBarRight_img);
			self.scrollBar_do.addChild(self.scrollBarRight_do);
			
			FWDSimpleButton.setPrototype();
			self.scrollBarHandler_do = new FWDSimpleButton(self.scrollBarHandlerN_img, self.scrollBarHandlerS_img, self.isMobile_bl);
			self.scrollBarHandler_do.setY(parseInt((self.scrollBarHeight - self.scrollBarHandlerHeight)/2) - 1);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_OVER, self.handlerOnMouseOver);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_OUT, self.handlerOnMouseOut);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.handlerDragStartHandler);
			self.scrollBar_do.addChild(self.scrollBarHandler_do);
			
			if(self.showButtonsLabels_bl){
				label_str1 = self.buttonsLabels_ar[self.scrollBarPosition] || "tooltip is not defined!";
				FWDButtonToolTip.setPrototype();
				self.scrollBarHandlerToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						label_str1,
						"",
						self.buttonToolTipLeft_str,
						self.buttonToolTipMiddle_str,
						self.buttonToolTipRight_str,
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				
				self.mainHolder_do.addChild(self.scrollBarHandlerToolTip_do);
			}
		};
		
			
		//##########################################//
		// zoom in / out handler...
		//##########################################//
		self.zoomInMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl){
				self.scrollBarHandlerToolTip_do.show();
				if(self.isScrollBarActive_bl){
					self.positionAndSetLabelScrollBarHandler();
				}else{
					if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
						setTimeout(function(){
							if(self == null) return;
							var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
							self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
							self.showZoomInOrOutToolTipButton(self.zoomIn_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
						}, 50);
					}
				}
			}
		};
		
		self.zoomInOrOutMouseOutHandler  = function(e){
			if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
		};
			
		self.zoomInStartHandler = function(e){
			if(e){
				e = e.e;
				if(e.touches){
					self.handlerDragEndHandler(e);
				}
			}
			
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.zoomWithButtonsId_to = setTimeout(self.startZoomInWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			self.zoomInWithButtonsDispatchEvent(true);
			if(self.slideShowButton_do) self.stopSlideShow();
			if(self.zoomIn_do) self.zoomIn_do.isSelectedFinal_bl = true;
			self.isZoomInOrOutPressed_bl = true;
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				}else{
					window.addEventListener("touchend", self.zoomInWithButtonsEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.zoomInWithButtonsEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
				}
			}
		};
		
		self.startZoomInWithDelay = function(){
			self.zoomWithButtonsId_int = setInterval(self.zoomInWithButtonsDispatchEvent, 16);
		};
	
		self.zoomInWithButtonsDispatchEvent = function(withPause){	
			if(withPause){
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:1, withPause:true});
			}else{
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:1, withPause:false});
			}
			if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
				setTimeout(function(){
					if(self == null) return;
					var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
					if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
					if(self.showZoomInOrOutToolTipButton) self.showZoomInOrOutToolTipButton(self.zoomIn_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
				}, 50);
			}
		};
		
		self.zoomInWithButtonsEndHandler = function(e){
			var viewportMouseCoordinates;
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.isZoomInOrOutPressed_bl = false;
			
			if(self.zoomIn_do){
				self.zoomIn_do.isSelectedFinal_bl = false;
				viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
				if(!FWDUtils.hitTest(self.zoomIn_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
					self.zoomIn_do.onMouseOut(e);
				}
			}
		
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				}else{
					window.removeEventListener("touchend", self.zoomInWithButtonsEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.zoomInWithButtonsEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
				}
			}
		};
		
		//////////////////////////////////////////////////////
		/////////////////////////////////////////////////////
		self.zoomOutMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl){
				self.scrollBarHandlerToolTip_do.show();
				if(self.isScrollBarActive_bl){
					self.positionAndSetLabelScrollBarHandler();
				}else{
					if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
						setTimeout(function(){
							if(self == null) return;
							var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
							self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
							self.showZoomInOrOutToolTipButton(self.zoomOut_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
						}, 50);
					}
				}
			}
		};
	
		self.zoomOutStartHandler = function(e){
			if(e){
				e = e.e;
				if(e.touches){
					self.handlerDragEndHandler(e);
				}
			}
			
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.zoomWithButtonsId_to = setTimeout(self.startZoomOutWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			self.zoomOutWithButtonsDispatchEvent(true);
			if(self.slideShowButton_do) self.stopSlideShow();
			if(self.zoomOut_do) self.zoomOut_do.isSelectedFinal_bl = true;
			self.isZoomInOrOutPressed_bl = true;
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				}else{
					window.addEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
				}
			}
		};
		
		self.startZoomOutWithDelay = function(){
			self.zoomWithButtonsId_int = setInterval(self.zoomOutWithButtonsDispatchEvent, 16);
		};
		
		self.zoomOutWithButtonsDispatchEvent = function(withPause){	
			if(!self.isScrollBarActive_bl  && self.showButtonsLabels_bl){
				setTimeout(function(){
					if(self == null) return;
					var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
					if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
					if(self.showZoomInOrOutToolTipButton) self.showZoomInOrOutToolTipButton(self.zoomOut_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
				}, 50);
			};
			
			if(withPause){
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:-1, withPause:true});
			}else{
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:-1, withPause:false});
			}
		};

		self.zoomOutWithButtonsEndHandler = function(e){
			var viewportMouseCoordinates;
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.isZoomInOrOutPressed_bl = false;
			
			if(self.zoomOut_do){
				self.zoomOut_do.isSelectedFinal_bl = false;
				viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
				if(!FWDUtils.hitTest(self.zoomOut_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
					self.zoomOut_do.onMouseOut(e);
				}
			}
			
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				}else{
					window.removeEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				}
			}else{
				
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
				}
			}
		};
		
		//##########################################//
		// Scrollbar handler...
		//##########################################//
		self.handlerOnMouseOver = function(e){
			if(self.showButtonsLabels_bl){
				self.positionAndSetLabelScrollBarHandler();
				self.scrollBarHandlerToolTip_do.show();
			}
		};
		
		self.handlerOnMouseOut = function(e){
			if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
		};
		
		self.handlerDragStartHandler = function(e){
			e = e.e;
			if(self.isMobile_bl){
				self.handlerDragEndHandler(e);
				if(self.prevButton_do || self.prevButton_do) self.gotoImageEndHandler(e);
			}
			if(self.slideShowButton_do) self.stopSlideShow();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.lastPresedX = viewportMouseCoordinates.screenX;
			self.scrollBarHandlerXPositionOnPress = self.scrollBarHandler_do.getX();
			self.scrollBarHandler_do.isSelectedFinal_bl = true;
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.handlerDragMoveHandler);
					window.addEventListener("MSPointerUp", self.handlerDragEndHandler);
				}else{
					window.addEventListener("touchmove", self.handlerDragMoveHandler);
					window.addEventListener("touchend", self.handlerDragEndHandler);
				}
			}else{
				self.scrollBarHandler_do.isSelectedFinal_bl = true;
				if(window.addEventListener){
					window.addEventListener("mousemove", self.handlerDragMoveHandler);
					window.addEventListener("mouseup", self.handlerDragEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.handlerDragMoveHandler);
					document.attachEvent("onmouseup", self.handlerDragEndHandler);
				}
			}
		};
		
		self.handlerDragMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.finalHandlerX = Math.round(self.scrollBarHandlerXPositionOnPress + viewportMouseCoordinates.screenX - self.lastPresedX);
			
			if(self.finalHandlerX <= 0){
				self.finalHandlerX = 0;
			}else if(self.finalHandlerX >= self.scrollBarTotalWidth - self.scrollBarHandlerWidth){
				self.finalHandlerX = self.scrollBarTotalWidth - self.scrollBarHandlerWidth;
			}
			
			var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
			self.dispatchEvent(FWDController.SCROLL_BAR_UPDATE, {percent:percent});
			
			self.scrollBarHandler_do.setX(self.finalHandlerX);
			self.positionAndSetLabelScrollBarHandler();
		};
		
		self.handlerDragEndHandler = function(e){
			var viewportMouseCoordinates;
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			if(!FWDUtils.hitTest(self.scrollBarHandler_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
				self.scrollBarHandler_do.onMouseOut(e);
				if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
				self.scrollBarHandler_do.setUnselctedFinal();
			}
			
			self.scrollBarHandler_do.isSelectedFinal_bl = false;
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.handlerDragMoveHandler);
					window.removeEventListener("MSPointerUp", self.handlerDragEndHandler);
				}else{
					window.removeEventListener("touchmove", self.handlerDragMoveHandler);
					window.removeEventListener("touchend", self.handlerDragEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.handlerDragMoveHandler);
					window.removeEventListener("mouseup", self.handlerDragEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.handlerDragMoveHandler);
					document.detachEvent("onmouseup", self.handlerDragEndHandler);
				}
			}
		};
		
		self.updateScrollBar = function(percent, animate){
			if(!self.scrollBarHandler_do) return;
			self.finalHandlerX = Math.round(percent * (self.scrollBarTotalWidth - self.scrollBarHandlerWidth));
			
			if(!self.isScrollBarActive_bl) return
			if(self.finalHandlerX <= 0){
				self.finalHandlerX = 0;
			}else if(self.finalHandlerX >= self.scrollBarTotalWidth - self.scrollBarHandlerWidth){
				self.finalHandlerX = self.scrollBarTotalWidth - self.scrollBarHandlerWidth;
			}
			
			if(animate){
				TweenMax.to(self.scrollBarHandler_do, .2, {x:self.finalHandlerX, 
					onUpdate:self.positionAndSetLabelScrollBarHandler,
					onComplete:self.positionAndSetLabelScrollBarHandler});
			}else{
				TweenMax.killTweensOf(self.scrollBarHandler_do);
				self.scrollBarHandler_do.setX(self.finalHandlerX);
			}
		};
		
		//###############################//
		//Position scrollbar handler.
		//###############################//
		self.positionAndSetLabelScrollBarHandler = function(){
			
			if(!self.showButtonsLabels_bl || !self.isScrollBarActive_bl) return;
			var finalX = 0;
			var finalY = 0;
			var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
			var globalX = self.getGlobalX();
		
			self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
			
			setTimeout(function(){
				if(self == null || !self.scrollBarHandlerToolTip_do.isShowed_bl) return
				finalX = parseInt(self.scrollBarHandler_do.getX() + self.scrollBar_do.getX() + (self.scrollBarHandlerWidth - self.scrollBarHandlerToolTip_do.totalWidth)/2);
				if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
					finalY = - self.scrollBarHandlerToolTip_do.totalHeight - self.scrollBarHandlerToolTipOffsetY;
				}else{
					finalY =  self.curHeight + self.scrollBarHandlerToolTipOffsetY;
				}
				if(globalX + finalX < 0) finalX = 0;
				self.scrollBarHandlerToolTip_do.setX(finalX);
				self.scrollBarHandlerToolTip_do.setY(finalY);
			}, 51);
		};
		
		//###############################//
		//Hide / show.
		//###############################//
		self.hide = function(animate){
			if(self.controllerPosition_str == FWDController.POSITION_BOTTOM){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:self.curHeight + self.controllerOffsetY, ease:Expo.easeInOut});
				}else{
					self.mainHolder_do.setY(self.curHeight + self.controllerOffsetY);
				}
			}else if(self.controllerPosition_str == FWDController.POSITION_TOP){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:-self.curHeight - self.controllerOffsetY, ease:Expo.easeInOut});
				}else{
					self.mainHolder_do.setY(-self.curHeight - self.controllerOffsetY);
				}
				
			}
		};
		
		self.show = function(){
			TweenMax.to(self.mainHolder_do, 1, {y:0, ease:Expo.easeInOut});
		};
		
		//######################################################//
		/* show tool tip */
		//######################################################//
		self.showToolTipButton = function(button, toolTip, offsetY){
			if(self.showButtonsLabels_bl){
			
				var finalX;
				var finalY;
				var globalX = self.mainHolder_do.getX();
				var pointerOffsetX = 0;
				
				if(self.showButtonsLabels_bl) toolTip.show();
				
				setTimeout(function(){
					if(self == null || !toolTip.isShowed_bl) return
					finalX = parseInt(button.getX() + (self.buttonWidth - toolTip.totalWidth)/2);
					
					if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
						finalY = - toolTip.totalHeight - offsetY;
					}else{
						finalY =  self.curHeight + offsetY;
					}
					
					if(globalX + finalX < 0){
						pointerOffsetX = globalX + finalX;
						finalX = finalX + Math.abs((globalX + finalX));
					}else if(globalX + self.curWidth - finalX - toolTip.totalWidth < 0){
						pointerOffsetX = -(globalX + self.curWidth - finalX - toolTip.totalWidth);
						finalX = finalX + globalX + self.curWidth - finalX - toolTip.totalWidth;
					}
					
					toolTip.setX(finalX);
					toolTip.setY(finalY);	
					toolTip.positionPointer(pointerOffsetX);
				}, 51);
			}
		};
		
		self.showZoomInOrOutToolTipButton = function(button, toolTip, offsetY){
			if(self.showButtonsLabels_bl && toolTip){
				var finalX;
				var finalY;
				var globalX = self.mainHolder_do.getX();
				var pointerOffsetX = 0;
				
				setTimeout(function(){
					if(self == null || !toolTip.isShowed_bl) return
					finalX = parseInt(button.getX() + (self.zoomButtonHeight - toolTip.totalWidth)/2);
					if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
						finalY = - toolTip.totalHeight - offsetY;
					}else{
						finalY =  self.curHeight + offsetY;
					}
					
					if(globalX + finalX < 0){
						pointerOffsetX = globalX + finalX;
						finalX = finalX + Math.abs((globalX + finalX));
					}else if(globalX + self.curWidth - finalX - toolTip.totalWidth < 0){
						pointerOffsetX = -(globalX + self.curWidth - finalX - toolTip.totalWidth);
						finalX = finalX + globalX + self.curWidth - finalX - toolTip.totalWidth;
					}
					
					toolTip.setX(finalX);
					toolTip.setY(finalY);	
					toolTip.positionPointer(pointerOffsetX);
				}, 51);
			}
		};
		
		//###############################//
		//Clean main events.
		//###############################//
		self.cleanMainEvents = function(){
		
			clearInterval(self.gotoImageId_int);
			clearInterval(self.zoomWithButtonsId_int);
			clearInterval(self.slideShowId_int);
			clearTimeout(self.gotoImageId_to);
			clearTimeout(self.zoomWithButtonsId_to);	
			
			if(self.hider){
				self.hider.removeListener(FWDHider.SHOW, self.onHiderShow);
				self.hider.removeListener(FWDHider.HIDE, self.onHiderHide);
			}
			
			self.screen.onmousedown = null;
			
			if(self.isMobile_bl){
				window.removeEventListener("touchend", self.gotoImageEndHandler);
				window.removeEventListener("MSPointerUp", self.gotoImageEndHandler);
				window.removeEventListener("touchend", self.zoomInWithButtonsEndHandler);
				window.removeEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				window.removeEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				window.removeEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				window.removeEventListener("touchmove", self.handlerDragMoveHandler);
				window.removeEventListener("touchend", self.handlerDragEndHandler);
				window.removeEventListener("MSPointerMove", self.handlerDragMoveHandler);
				window.removeEventListener("MSPointerUp", self.handlerDragEndHandler);
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.gotoImageEndHandler);
					window.removeEventListener("mouseup", self.zoomInWithButtonsEndHandler);
					window.removeEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
					window.removeEventListener("mousemove", self.handlerDragMoveHandler);
					window.removeEventListener("mouseup", self.handlerDragEndHandler);
					window.removeEventListener("keydown",  self.onKeyDownHandler);	
					window.removeEventListener("keyup",  self.onKeyUpHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.gotoImageEndHandler);
					document.detachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
					document.detachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
					document.detachEvent("onmousemove", self.handlerDragMoveHandler);
					document.detachEvent("onmouseup", self.handlerDragEndHandler);
					document.detachEvent("onkeydown",  self.onKeyDownHandler);	
					document.detachEvent("onkeyup",  self.onKeyUpHandler);
				}
			}
		};
	
		//##############################//
		/* destroy */
		//##############################//
		this.destroy = function(){
			
			self.cleanMainEvents();
			
			TweenMax.killTweensOf(self.mainHolder_do);
			self.mainHolder_do.destroy();
			
			self.backgroundLeft_sdo.destroy();
			self.backgroundMiddle_sdo.destroy();
			self.backgroundRight_sdo.destroy();
			
			if(self.panButton_do) self.panButton_do.destroy();
			if(self.rotateButton_do) self.rotateButton_do.destroy();
			if(self.nextButton_do) self.nextButton_do.destroy();
			if(self.prevButton_do) self.prevButton_do.destroy();
			if(self.slideShowButton_do) self.slideShowButton_do.destroy();
			if(self.infoButton_do) self.infoButton_do.destroy();
			if(self.linkButton_do) self.linkButton_do.destroy();
			if(self.fullScreenButton_do) self.fullScreenButton_do.destroy();
			if(self.zoomIn_do) self.zoomIn_do.destroy();
			if(self.zoomOut_do) self.zoomOut_do.destroy();
			if(self.scrollBar_do) self.scrollBar_do.destroy();
			if(self.scrollBarLeft_sdo) self.scrollBarLeft_sdo.destroy();
			if(self.scrollBarRight_sdo) self.scrollBarRight_sdo.destroy();
			if(self.scrollBarMiddle_sdo) self.scrollBarMiddle_sdo.destroy();
			if(self.scrollBarHandler_do){
				TweenMax.killTweensOf(self.mainHolder_do);
				self.scrollBarHandler_do.destroy();
			}
			if(self.scrollBarHandlerN_sdo) self.scrollBarHandlerN_sdo.destroy();
			if(self.scrollBarHandlerS_sdo) self.scrollBarHandlerS_sdo.destroy();
			
			if(self.panButtonTooTipLabel_do) self.panButtonTooTipLabel_do.destroy();
			if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.destroy();
			if(self.rotateButtonToolTip_do) self.rotateButtonToolTip_do.destroy();
			if(self.nextButtonToolTip_do) self.nextButtonToolTip_do.destroy();
			if(self.prevButtonToolTip_do) self.prevButtonToolTip_do.destroy();
			if(self.slideShowToolTip_do) self.slideShowToolTip_do.destroy();
			if(self.infoToolTip_do) self.infoToolTip_do.destroy();
			if(self.linkToolTip_do) self.linkToolTip_do.destroy();
			if(self.fullscreenToolTip_do) self.fullscreenToolTip_do.destroy();
		
			self.buttonsTest_ar = null;
			self.buttons_ar = null;
			
			self.hider = null;
			self.mainHolder_do = null;
			self.backgroundLeft_sdo = null;
			self.backgroundMiddle_sdo = null;
			self.backgroundRight_sdo = null;
			self.panButton_do = null;
			self.rotateButton_do = null;
			self.nextButton_do = null;
			self.prevButton_do = null;
			self.slideShowButton_do = null;
			self.infoButton_do = null;
			self.linkButton_do = null;
			self.fullScreenButton_do = null;
			self.zoomIn_do = null;
			self.zoomOut_do = null;
			self.scrollBar_do = null;
			self.scrollBarLeft_sdo = null;
			self.scrollBarRight_sdo = null;
			self.scrollBarMiddle_sdo = null;
			self.scrollBarHandler_do = null;
			self.scrollBarHandlerN_sdo = null;
			self.scrollBarHandlerS_sdo = null;
			self.panButtonTooTipLabel_do = null;
			self.scrollBarHandlerToolTip_do = null;
			self.rotateButtonToolTip_do = null;
			self.nextButtonToolTip_do = null;
			self.prevButtonToolTip_do = null;
			self.slideShowToolTip_do = null;
			self.infoToolTip_do = null;
			self.linkToolTip_do = null;
			self.fullscreenToolTip_do = null;
		
			self.backgroundLeft_img = null;
			self.backgroundRight_img = null;
			self.panN_img = null;
			self.panS_img = null;
			self.rotateN_img = null;
			self.rotateS_img = null;
			self.nextN_img = null;
			self.nextS_img = null;
			self.prevN_img = null;
			self.prevS_img = null;
			self.playN_img = null;
			self.playS_img = null;
			self.pauseN_img = null;
			self.pauseS_img = null;
			self.infoN_img = null;
			self.infoS_img = null;
			self.linkN_img = null;
			self.linkS_img = null;
			self.fullScreenNormalN_img = null;
			self.fullScreenNormalS_img = null;
			self.fullScreenFullN_img = null;
			self.fullScreenFullS_img = null;
			self.zoomInN_img = null;
			self.zoomInS_img = null;
			self.zoomOutN_img = null;
			self.zoomOutS_img = null;
			self.scrollBarHandlerN_img = null;
			self.scrollBarHandlerS_img = null;
			self.scrollBarLeft_img = null;
			self.scrollBarRight_img = null;
			self.toolTipLeft_img = null;
			self.toolTipPointer_img = null;

			self.backgroundMiddlePath_str = null;
			self.scrollBarMiddlePath_str = null;
			self.draggingMode_str = null;
			self.controllerPosition_str = null;
			self.buttonToolTipLeft_str = null;
			self.buttonToolTipMiddle_str =  null;
			self.buttonToolTipRight_str = null;
			self.link_str = null;
			
			data = null;
			parent = null;
		
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDController.prototype = null;
		};
	
		this.init();
	};
	
	/* set prototype */
	FWDController.setPrototype = function(){
		FWDController.prototype = new FWDDisplayObject("div");
	};
	
	FWDController.SHOW_INFO = "showInfo";
	FWDController.POSITION_TOP = "top";
	FWDController.POSITION_BOTTOM = "bottom";
	FWDController.CHANGE_NAVIGATION_STYLE = "changeNavigationStyle";
	FWDController.GOTO_NEXT_IMAGE = "gotoNextImage";
	FWDController.GOTO_PREV_IMAGE = "gotoPrevImage";
	FWDController.GOTO_NEXT_OR_PREV_IMAGE = "gotoNextOrPrevImage";
	FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE = "gotoNextOrPrevImageComplete";
	FWDController.DISABLE_PAN_OR_MOVE = "disablePanOrMove";
	FWDController.ENABLE_PAN_OR_MOVE = "enablePanOrMove";
	FWDController.SCROLL_BAR_UPDATE = "scrollBarUpdate";
	FWDController.ZOOM_WITH_BUTTONS = "zoomWithButtons";
	FWDController.ZOOM_IN = "zoomIn";
	FWDController.ZOOM_OUT = "zoomOut";
	FWDController.PAN = "pan";
	FWDController.ROTATE = "rotate";
	FWDController.START_SLIDE_SHOW = "startSlideShow";
	FWDController.STOP_SLIDE_SHOW = "stopSlideShow";
	FWDController.GO_FULL_SCREEN = "goFullScreen";
	FWDController.GO_NORMAL_SCREEN = "goNormalScreen";
	FWDController.MOUSE_DOWN = "controllerOnMouseDown";
	
	FWDController.prototype = null;
	window.FWDController = FWDController;
	
}());/* Data */
(function(window){
	
	var FWDData = function(props){
		
		var self = this;
		var prototype = FWDData.prototype;
		
		this.navigatorImage_img;
		this.mainPreloader_img = null;
		this.mainLightboxCloseButtonN_img = null;
		this.mainLightboxCloseButtonS_img = null;
		this.controllerBackgroundLeft_img = null;
		this.controllerBackgroundRight_img = null;
		this.controllerPanN_img = null;
		this.controllerPanS_img = null;
		this.controllerRotateN_img = null;
		this.controllerRotateS_img = null;
		this.controllerNextN_img = null;
		this.controllerNextS_img = null;
		this.controllerPrevN_img = null;
		this.controllerPrevS_img = null;
		this.controllerPlayN_img = null;
		this.controllerPlayS_img = null;
		this.controllerPauseN_img = null;
		this.controllerPauseS_img = null;
		this.controllerInfoN_img = null;
		this.controllerInfoS_img = null;
		this.controllerLinkN_img = null;
		this.controllerLinkS_img = null;
		this.controllerFullScreenNormalN_img = null;
		this.controllerFullScreenNormalS_img = null;
		this.controllerFullScreenFullN_img = null;
		this.controllerFullScreenFullS_img = null;
		this.zoomInN_img = null;
		this.zoomInS_img = null;
		this.zoomOutN_img = null;
		this.zoomOutS_img = null;
		this.scrollBarHandlerN_img = null;
		this.scrollBarHandlerS_img = null;
		this.scrollBarLeft_img = null;
		this.scrollBarRight_img = null;
		this.toolTipLeft_img = null;
		this.toolTipPointer_img = null;
		this.infoWindowCloseNormal_img = null;
		this.infoWindowCloseSelected_img = null;
		
		this.props_obj = props;
		this.rootElement_el = null;
		this.skinPaths_ar = [];
		this.playListData_ar = [];
		this.imagesPaths_ar = [];
		this.largeImagesPaths_ar = [];
		this.navigatorImagesPaths_ar =[];
		this.images_ar = [];
		this.navigatorImages_ar = [];
		this.markersList_ar = [];
		this.markersPosition_ar = [];
		this.buttons_ar = null;
		this.buttonsLabels_ar = null;
		this.contextMenuLabels_ar = null;
	
		this.backgroundColor_str = null;
		this.handMovePath_str = null;
		this.handGrabRotatePath_str = null;
		this.handGrabPath_str = null;
		this.handGrabRotatePath_str = null;
		this.controllerBackgroundMiddlePath_str = null;
		this.scrollBarMiddlePath_str = null;
		this.startDraggingMode_str = null;
		this.controllerPosition_str = null;
		this.preloaderFontColor_str = null;
		this.preloaderBackgroundColor_str = null;
		this.preloaderText_str = null;
		this.buttonToolTipLeft_str = null;
		this.buttonToolTipMiddle_str = null;
		this.buttonToolTipRight_str = null;
		this.buttonToolTipBottomPointer_str = null;
		this.buttonToolTipTopPointer_str = null;
		this.buttonToolTipFontColor_str = null;
		this.link_str = null;
		this.contextMenuBackgroundColor_str = null;
		this.contextMenuBorderColor_str = null;
		this.contextMenuSpacerColor_str = null;
		this.contextMenuItemNormalColor_str = null;
		this.contextMenuItemSelectedColor_str = null;
		this.contextMenuItemSelectedColor_str = null;
		this.contextMenuItemDisabledColor_str = null;
		this.navigatorPosition_str = null;
		this.navigatorHandlerColor_str = null;
		this.navigatorBorderColor_str = null;
		this.infoText_str = null;
		this.infoWindowBackgroundColor_str = null;
		this.infoWindowScrollBarColor_str = null;
		
		this.dragAndSpinSpeed;
		this.dragRotationSpeed;
		this.buttonsRotationSpeed;
		this.controllerHeight;
		this.startAtImage;
		this.imageWidth;
		this.imageHeight;
		this.spaceBetweenButtons;
		this.startSpaceBetweenButtons;
		this.scrollBarOffsetX;
		this.zoomFactor;
		this.controllerOffsetY;
		this.hideControllerDelay;
		this.controllerBackgroundOpacity;
		this.controllerMaxWidth;
		this.countLoadedSkinImages = 0;
		this.countLoadedImages = 0;
		this.scrollBarHandlerToolTipOffsetY;
		this.zoomInAndOutToolTipOffsetY;
		this.buttonsToolTipOffsetY;
		this.scrollBarPosition;
		this.startSpaceForScrollBarButtons;
		this.totalGraphics;
		this.slideShowDelay;
		this.totalImages;
		this.navigatorWidth;
		this.navigatorHeight;
		this.navigatorOffsetX;
		this.navigatorOffsetY;
		this.infoWindowBackgroundOpacity;
		this.markerToolTipOffsetY;
		this.toolTipWindowMaxWidth;
		this.lightBoxBackgroundOpacity;
		
		this.parseDelayId_to;
		this.loadImageId_to;
		
		this.showContextMenu_bl;
		this.showLargeImageVersionOnZoom_bl;
		this.showNavigator_bl;
		this.addCorrectionForWebKit_bl;
		this.inverseNextAndPrevRotation_bl;
		this.useEntireScreenFor3dObject_bl;
		this.hideController_bl;
		this.showScriptDeveloper_bl;
		this.showMarkers_bl;
		this.hasNavigatorError_bl = false;
		this.showMarkersInfo_bl = false;
		this.addKeyboardSupport_bl = false;
		this.addDragAndSpinSupport_bl = false;
		this.stopRotationAtEnds_bl = false;
		this.slideShowAutoPlay_bl = false;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		this.areAllImagesLoaded_bl = false;
	
		//###################################//
		/*init*/
		//###################################//
		self.init = function(){
			self.parseDelayId_to = setTimeout(self.parseProperties, 100);
		};
		
		//#############################################//
		// parse properties.
		//#############################################//
		self.parseProperties = function(){
			
			var skinElement_el;
			var markersElement_el;
			var playListElement_el;
			
			var childKids_ar;
			var playListChildren_ar;
			var markersChildren_ar;
			var errorMessage_str;
			var mediaKid;
			var test;
			var obj;
			var obj2;
			var child;
			var hasError_bl;
			var attributeMissing;
			var positionError;
			var hasElementWithAttribute;
			var hasMarker_bl;
			
			//check for the playlist id  property.
			if(!self.props_obj.playListAndSkinId){
				errorMessage_str = "<font color='#FFFFFF'>playListAndSkinId</font> property which represents the grid playlist id is not defined in FWDGrid constructor function!";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			};
			
			//set the root element of the grid list.
			self.rootElement_el = FWDUtils.getChildById(self.props_obj.playListAndSkinId);
			if(!self.rootElement_el){
				errorMessage_str = "Make sure that the a div with the id - <font color='#FFFFFF'>" + self.props_obj.playListAndSkinId + "</font> exists, self represents the data playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			self.rootElement_el.style.display = "none";
			skinElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-skin");
			markersElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-markers");
			playListElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-paylist");
			
			
			if(!skinElement_el){
				errorMessage_str = "Make sure that the an ul tag with the data type attribute - <font color='#FFFFFF'>data-skin</font> is defined, this tag is used for creating the playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			if(!playListElement_el){
				errorMessage_str = "Make sure that the an ul tag with the data type attribute - <font color='#FFFFFF'>data-paylist</font> is defined, this tag is used for creating the playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			//markers.
			if(markersElement_el) self.showMarkers_bl = true; 
			
			if(self.showMarkers_bl){
				markersChildren_ar = FWDUtils.getChildren(markersElement_el);
				for(var i=0; i<markersChildren_ar.length; i++){
					obj = {};
					child = markersChildren_ar[i];
					hasError_bl = false;
					attributeMissing = "";
					
					//check for markers attributes.
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-type", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-type", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-id", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-id", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-normal-state-path", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-normal-state-path", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-selected-state-path", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-selected-state-path", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-width", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-width", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-height", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-height", i);
						return;
					}
					
					obj.type = FWDUtils.getAttributeValue(child, "data-marker-type");
					test = obj.type == "link" || obj.type == "tooltip" || obj.type == "infowindow";
					if(!test){
						self.showMarkerTypeError(obj.type, i);
						return;
					}
					
					obj.markerId = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-id"));
					obj.normalStatePath_str = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-normal-state-path"));
					obj.selectedStatePath_str = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-selected-state-path"));
					obj.toolTipLabel = FWDUtils.getAttributeValue(child, "data-tool-tip-label") || undefined;
					obj.markerWidth = parseInt(FWDUtils.getAttributeValue(child, "data-marker-width"));
					if(isNaN(obj.markerWidth)) obj.markerWidth = 5;
					obj.markerHeight = parseInt(FWDUtils.getAttributeValue(child, "data-marker-height"));
					if(isNaN(obj.markerHeight)) obj.markerHeight = 5;
					
					if(obj.type == "link"){
						obj.link = FWDUtils.getAttributeValue(child, "data-marker-url") || "http://www.link-is-not-defined.com";
						obj.target = FWDUtils.getAttributeValue(child, "data-marker-target") || "_blank";
					}else{
						obj.innerHTML = child.innerHTML;
					}
					
					test = FWDUtils.getAttributeValue(child, "data-reg-point");
					test = test === "center" || test === "centertop" || test === "centerbottom";
					if(!test){
						test = "center";
					}else{
						test = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-reg-point")).toLowerCase();
					}
					obj.regPoint = test;
					obj.maxWidth = parseInt(FWDUtils.getAttributeValue(child, "data-marker-window-width"));
					if(isNaN(obj.maxWidth)) obj.maxWidth = 200;
					
					self.markersList_ar.push(obj);
				}
			}
			
			//parse playlist
			if(!FWDUtils.getChildAt(playListElement_el, 0)){
				errorMessage_str = "The playlist dose not have any chidren <ul> element.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			self.showLargeImageVersionOnZoom_bl = self.props_obj.showLargeImageVersionOnZoom; 
			self.showLargeImageVersionOnZoom_bl = self.showLargeImageVersionOnZoom_bl == "yes" ? true : false;
			self.showNavigator_bl = self.props_obj.showNavigator;
			self.showNavigator_bl = self.showNavigator_bl == "yes" ? true : false;
			self.showMarkersInfo_bl =  self.props_obj.showMarkersInfo == "yes" ? true : false;
			self.addKeyboardSupport_bl = self.props_obj.addKeyboardSupport == "no" ? false : true;
			self.stopRotationAtEnds_bl = self.props_obj.stopRotationAtEnds == "yes" ? true : false;
			self.addDragAndSpinSupport_bl = self.props_obj.addDragAndSpinSupport == "yes" ? true : false;
			if(self.stopRotationAtEnds_bl) self.addDragAndSpinSupport_bl = false;
			self.slideShowAutoPlay_bl = self.props_obj.slideShowAutoPlay == "yes" ? true : false;
			if(self.isMobile_bl) self.showMarkersInfo_bl = false;
		
			var playListChildren_ar = FWDUtils.getChildren(playListElement_el);
			self.totalImages = playListChildren_ar.length;
			var markersIn_ar = undefined;
			for(var i=0; i<playListChildren_ar.length; i++){
				
				obj = {};
				child = playListChildren_ar[i];
				childKids_ar = FWDUtils.getChildren(child);
				
				hasError_bl;
				attributeMissing = "";
				positionError = i;
				
				//check for data-small-image-path attribute.
				hasElementWithAttribute = self.checkForAttribute(child, "data-small-image-path", i);
				if(!hasElementWithAttribute) return;
				
				if(self.showLargeImageVersionOnZoom_bl){
					hasElementWithAttribute = self.checkForAttribute(child, "data-large-image-path", i);
					if(!hasElementWithAttribute) return;
				}
				
				if(self.showNavigator_bl){
					hasElementWithAttribute = self.checkForAttribute(child, "data-navigator-image-path", i);
					if(!hasElementWithAttribute) return;
				}
				
				//check for data-info attribute.
				hasMarker_bl = false;
				markersIn_ar = undefined;
				obj2 = undefined;
				for(var j=0; j<childKids_ar.length; j++){
					
					if(FWDUtils.hasAttribute(childKids_ar[j], "data-small-image-path")){
						obj.smallImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-small-image-path"));
					}
					
					if(FWDUtils.hasAttribute(childKids_ar[j], "data-large-image-path")){
						obj.largeImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-large-image-path"));
					}
					
					if(self.showNavigator_bl){
						if(FWDUtils.hasAttribute(childKids_ar[j], "data-navigator-image-path")){
							obj.navigatorImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-navigator-image-path"));
						}
					}
					
					if(FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-id")){
						hasMarker_bl = true;
						if(!markersIn_ar) markersIn_ar = [];
						obj2 = {};
						obj2.markerId = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-id"));
						obj2.x = FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-x") || 0;
						obj2.y = FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-y") || 0;
						
						markersIn_ar.push(obj2);
					};
					
					if(j == childKids_ar.length - 1){
						if(hasMarker_bl){
							self.markersPosition_ar.push(markersIn_ar);
						}else{
							self.markersPosition_ar.push(undefined);
						}
						markersIn_ar = undefined;
						obj2 = undefined;
					}
				}
				
				self.playListData_ar[i] = obj;
			};
			
			//set main properties.
			test = self.props_obj.startAtImage || 0;
			if(isNaN(test)) test = 0;
			test = test - 1;
			if(test < 0){
				test = 0;
			}else if(test > self.totalImages - 1){
				test = self.totalImages - 1;
			}
			
			
			self.startAtImage = test;
			
			self.backgroundColor_str = self.props_obj.backgroundColor || "transparent";
			self.preloaderFontColor_str = self.props_obj.preloaderFontColor || "#000000";
			self.preloaderBackgroundColor_str =	self.props_obj.preloaderBackgroundColor || "transparent";
			self.preloaderText_str = self.props_obj.preloaderText || "Loading:"; 
			
			self.startDraggingMode_str = self.props_obj.startDraggingMode || "rotate";
			if(self.startDraggingMode_str != "rotate" && self.startDraggingMode_str != "pan") self.startDraggingMode_str = "rotate";
			
			self.controllerPosition_str = self.props_obj.controllerPosition || "bottom";
			if(self.controllerPosition_str != "top" && self.controllerPosition_str != "bottom") self.startDraggingMode_str = "top";
		
			if(!self.props_obj.buttons){
				errorMessage_str = "The <font color='#FFFFFF'>buttons</font> is not defined in the contructor, this is necessary to setup the main buttons.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				console.log(errorMessage_str);
				return;
			} 
			
			self.buttons_ar = FWDUtils.splitAndTrim(self.props_obj.buttons,  true);
			
			if(self.isMobile_bl && !self.hasPointerEvent_bl){
				self.buttonsLabels_ar = null;
				self.contextMenuLabels_ar = null;
			}else{
				if(self.props_obj.buttonsToolTips) self.buttonsLabels_ar =  FWDUtils.splitAndTrim(self.props_obj.buttonsToolTips, false);
				if(self.props_obj.contextMenuLabels) self.contextMenuLabels_ar =  FWDUtils.splitAndTrim(self.props_obj.contextMenuLabels, false);
			}
			
			self.showScriptDeveloper_bl = self.props_obj.showScriptDeveloper;
			self.showScriptDeveloper_bl = self.showScriptDeveloper_bl == "no" ? false : true;
			
			self.dragRotationSpeed = self.props_obj.dragRotationSpeed || .5;
			if(isNaN(self.dragRotationSpeed)) self.dragRotationSpeed = .5;
			if(self.dragRotationSpeed < 0){
				self.dragRotationSpeed = 0;
			}else if(self.dragRotationSpeed > 1){
				self.dragRotationSpeed = 1;
			}
			
			self.dragAndSpinSpeed = self.props_obj.dragAndSpinSpeed || .4;
			if(isNaN(self.dragAndSpinSpeed)) self.dragAndSpinSpeed = .4;
			if(self.dragRotationSpeed < .1){
				self.dragRotationSpeed = .1;
			}else if(self.dragRotationSpeed > 1){
				self.dragRotationSpeed = 1;
			}
			
			self.buttonsRotationSpeed = self.props_obj.buttonsRotationSpeed || 500;
			if(isNaN(self.buttonsRotationSpeed)) self.buttonsRotationSpeed = 500;
			if(self.buttonsRotationSpeed < 200){
				self.buttonsRotationSpeed = 200;
			}else if(self.buttonsRotationSpeed > 2000){
				self.buttonsRotationSpeed = 2000;
			}
			
			self.imageWidth = self.props_obj.imageWidth;
			if(!self.imageWidth){
				self.showPropertyError("imageWidth");
				return
			}
			
			self.imageHeight = self.props_obj.imageHeight;
			if(!self.imageHeight){
				self.showPropertyError("imageHeight");
				return;
			}
			
			self.zoomFactor = self.props_obj.zoomFactor;
			if(!self.zoomFactor){
				self.showPropertyError("zoomFactor");
				return;
			}
			if(self.zoomFactor < 1){
				 self.zoomFactor = 1;
			}else if(self.zoomFactor > 4){
				 self.zoomFactor = 4;
			}
		
			self.navigatorOffsetX =  self.props_obj.navigatorOffsetX || 0;
			if(isNaN(self.navigatorOffsetX)) self.navigatorOffsetX = 0;
			self.navigatorOffsetY =  self.props_obj.navigatorOffsetY || 0;
			if(isNaN(self.navigatorOffsetY)) self.navigatorOffsetY = 0;
			
			self.controllerBackgroundOpacity = self.props_obj.controllerBackgroundOpacity;
			if(!self.controllerBackgroundOpacity)  self.controllerBackgroundOpacity = 1;
			if(isNaN(self.controllerBackgroundOpacity)) self.controllerBackgroundOpacity = 1;
			if(self.controllerBackgroundOpacity < 0){
				self.controllerBackgroundOpacity = 0;
			}else if(self.controllerBackgroundOpacity > 1){
				self.controllerBackgroundOpacity = 1;
			}
			
			self.controllerMaxWidth = self.props_obj.controllerMaxWidth;
			if(!self.controllerMaxWidth)  self.controllerMaxWidth = 900;
			if(isNaN(self.controllerMaxWidth)) self.controllerMaxWidth = 900;
			if(self.controllerMaxWidth < 200) self.controllerMaxWidth = 200;
		
			self.hideControllerDelay = self.props_obj.hideControllerDelay;
			if(self.hideControllerDelay){
				self.hideController_bl = true;
				if(isNaN(self.hideControllerDelay)){
					self.hideControllerDelay = 4000;
				}else if(self.hideControllerDelay < 0){
					self.hideControllerDelay = 4000;
				}else{
					self.hideControllerDelay *= 1000;
				}
			}
		
			self.spaceBetweenButtons = self.props_obj.spaceBetweenButtons || 0;
			self.scrollBarPosition = self.props_obj.scrollBarPosition || 0;
			self.startSpaceForScrollBarButtons = self.props_obj.startSpaceForScrollBarButtons || 0;
			self.startSpaceBetweenButtons = self.props_obj.startSpaceBetweenButtons || 0;
			self.startSpaceForScrollBar = self.props_obj.startSpaceForScrollBar || 0;
			self.scrollBarOffsetX = self.props_obj.scrollBarOffsetX || 0;
			self.controllerOffsetY = self.props_obj.controllerOffsetY || 0; 
			self.scrollBarHandlerToolTipOffsetY = self.props_obj.scrollBarHandlerToolTipOffsetY || 0;
			self.zoomInAndOutToolTipOffsetY = self.props_obj.zoomInAndOutToolTipOffsetY || 0;
			self.buttonsToolTipOffsetY = self.props_obj.buttonsToolTipOffsetY || 0;
			self.infoWindowBackgroundOpacity = self.props_obj.infoWindowBackgroundOpacity || 1;
			self.markerToolTipOffsetY = self.props_obj.markerToolTipOffsetY || 1;
			self.toolTipWindowMaxWidth = self.props_obj.toolTipWindowMaxWidth || 300;
			self.buttonToolTipFontColor_str = self.props_obj.buttonToolTipFontColor || "#000000";
			self.link_str = self.props_obj.link || "http://www.link-is-not-defined.com!";
			self.contextMenuBackgroundColor_str = self.props_obj.contextMenuBackgroundColor || "#000000";
			self.contextMenuBorderColor_str = self.props_obj.contextMenuBorderColor || "#FF0000";
			self.contextMenuSpacerColor_str = self.props_obj.contextMenuSpacerColor || "#FF0000";
			self.contextMenuItemNormalColor_str = self.props_obj.contextMenuItemNormalColor || "#FF0000";
			self.contextMenuItemSelectedColor_str = self.props_obj.contextMenuItemSelectedColor || "#FF0000";
			self.contextMenuItemDisabledColor_str = self.props_obj.contextMenuItemDisabledColor || "#FF0000";
			
			self.infoWindowBackgroundColor_str = self.props_obj.infoWindowBackgroundColor || "#FF0000";
			self.infoWindowScrollBarColor_str = self.props_obj.infoWindowScrollBarColor || "#FF0000";
			
			self.navigatorPosition_str = self.props_obj.navigatorPosition || "topleft";
			self.navigatorPosition_str = String(self.navigatorPosition_str).toLowerCase();
			test = self.navigatorPosition_str == "topleft" 
					   || self.navigatorPosition_str == "topright"
					   || self.navigatorPosition_str == "bottomleft"
					   || self.navigatorPosition_str == "bottomright";
						   
			if(!test) self.navigatorPosition_str = "topleft";
			
			self.navigatorHandlerColor_str = self.props_obj.navigatorHandlerColor || "#FF0000";
			self.navigatorBorderColor_str = self.props_obj.navigatorBorderColor || "#FF0000";
			
			self.slideShowDelay =  self.props_obj.slideShowDelay || 100;
			if(self.slideShowDelay < 100) self.slideShowDelay = 100;
		
			self.showContextMenu_bl = self.props_obj.showContextMenu; 
			self.showContextMenu_bl = self.showContextMenu_bl == "no" ? false : true;
			
			self.inverseNextAndPrevRotation_bl = self.props_obj.inverseNextAndPrevRotation;
			self.inverseNextAndPrevRotation_bl = self.inverseNextAndPrevRotation_bl == "yes" ? true : false;
			
			self.addCorrectionForWebKit_bl = self.props_obj.addCorrectionForWebKit; 
			self.addCorrectionForWebKit_bl = self.addCorrectionForWebKit_bl == "yes" ? true : false;
			if(!FWDUtils.isChrome || self.hasTouch_bl) self.addCorrectionForWebKit_bl = false;
			
			self.useEntireScreenFor3dObject_bl = self.props_obj.useEntireScreenFor3dObject; 
			self.useEntireScreenFor3dObject_bl = self.useEntireScreenFor3dObject_bl == "yes" ? true : false;
			
			self.infoText_str = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-info");
			if(self.infoText_str){
				self.infoText_str = self.infoText_str.innerHTML;
			}else{
				self.infoText_str = "not defined make sure that an ul element with the attribute data-info is defined!";
			}
			
			//setup skin paths
			self.handMovePath_str = self.checkForAttribute(skinElement_el, "data-hand-move-path");
			if(!self.handMovePath_str) return;
			
			self.handGrabRotatePath_str = self.checkForAttribute(skinElement_el, "data-hand-rotate-path");
			if(!self.handGrabRotatePath_str) return;
			
			self.handGrabPath_str = self.checkForAttribute(skinElement_el, "data-hand-grab-path");
			if(!self.handGrabPath_str) return;
			
			var preloaderPath_str = self.checkForAttribute(skinElement_el, "data-preloader-path");
			if(!preloaderPath_str) return;
				
			var mainLightBoxCloseButtonNPath_str = self.checkForAttribute(skinElement_el, "data-main-lightbox-close-button-normal-path");
			if(!mainLightBoxCloseButtonNPath_str) return;
			
			var mainLightBoxCloseButtonSPath_str = self.checkForAttribute(skinElement_el, "data-main-lightbox-close-button-selected-path");
			if(!mainLightBoxCloseButtonNPath_str) return;
			
			var controllerBackgroundLeftPath_str = self.checkForAttribute(skinElement_el, "data-controller-background-left-path");
			if(!controllerBackgroundLeftPath_str) return;
			
			var controllerBackgroundRight_str = self.checkForAttribute(skinElement_el, "data-controller-background-right-path");
			if(!controllerBackgroundRight_str) return;
			
			var controllerPanN_str = self.checkForAttribute(skinElement_el, "data-controller-pan-button-normal-state-path");
			if(!controllerPanN_str) return;
			
			var controllerPanS_str = self.checkForAttribute(skinElement_el, "data-controller-pan-button-selected-state-path");
			if(!controllerPanS_str) return;
			
			var controllerRotateN_str = self.checkForAttribute(skinElement_el, "data-controller-rotate-button-normal-state-path");
			if(!controllerRotateN_str) return;
			
			var controllerRotateS_str = self.checkForAttribute(skinElement_el, "data-controller-rotate-button-selected-state-path");
			if(!controllerRotateS_str) return;
			
			var controllerNextN_str = self.checkForAttribute(skinElement_el, "data-controller-next-button-normal-state-path");
			if(!controllerNextN_str) return;
			
			var controllerNextS_str = self.checkForAttribute(skinElement_el, "data-controller-next-button-selected-state-path");
			if(!controllerNextS_str) return;
			
			var controllerPrevN_str = self.checkForAttribute(skinElement_el, "data-controller-prev-button-normal-state-path");
			if(!controllerPrevN_str) return;
			
			var controllerPrevS_str = self.checkForAttribute(skinElement_el, "data-controller-prev-button-selected-state-path");
			if(!controllerPrevS_str) return;
			
			var controllerPlayN_str = self.checkForAttribute(skinElement_el, "data-controller-play-button-normal-state-path");
			if(!controllerPlayN_str) return;
			
			var controllerPlayS_str = self.checkForAttribute(skinElement_el, "data-controller-play-button-selected-state-path");
			if(!controllerPlayS_str) return;
			
			var controllerPauseN_str = self.checkForAttribute(skinElement_el, "data-controller-pause-button-normal-state-path");
			if(!controllerPauseN_str) return;
			
			var controllerPauseS_str = self.checkForAttribute(skinElement_el, "data-controller-pause-button-selected-state-path");
			if(!controllerPauseS_str) return;
			
			var controllerInfoN_str = self.checkForAttribute(skinElement_el, "data-controller-info-button-normal-state-path");
			if(!controllerInfoN_str) return;
			
			var controllerInfoS_str = self.checkForAttribute(skinElement_el, "data-controller-info-button-selected-state-path");
			if(!controllerInfoS_str) return;
			
			var controllerLinkN_str = self.checkForAttribute(skinElement_el, "data-controller-link-button-normal-state-path");
			if(!controllerLinkN_str) return;
			
			var controllerLinkS_str = self.checkForAttribute(skinElement_el, "data-controller-link-button-selected-state-path");
			if(!controllerLinkS_str) return;
			
			var controllerFullScreemNormalN_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-normal-button-normal-state-path");
			if(!controllerFullScreemNormalN_str) return;
			
			var controllerFullScreenNormalS_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-normal-button-selected-state-path");
			if(!controllerFullScreenNormalS_str) return;
			
			var controllerFullScreemFullN_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-full-button-normal-state-path");
			if(!controllerFullScreemFullN_str) return;
			
			var controllerFullScreenFullS_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-full-button-selected-state-path");
			if(!controllerFullScreenFullS_str) return;
			
			var zoomInN_str = self.checkForAttribute(skinElement_el, "data-controller-zoomin-button-normal-state-path");
			if(!zoomInN_str) return;
			
			var zoomInS_str = self.checkForAttribute(skinElement_el, "data-controller-zoomin-button-slected-state-path");
			if(!zoomInS_str) return;
			
			var zoomOutN_str = self.checkForAttribute(skinElement_el, "data-controller-zoomout-button-normal-state-path");
			if(!zoomOutN_str) return;
			
			var zoomOutS_str = self.checkForAttribute(skinElement_el, "data-controller-zoomout-button-slected-state-path");
			if(!zoomOutS_str) return;
			
			var scrollBarHandlerN_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-handler-normal-state-path");
			if(!scrollBarHandlerN_str) return;
			
			var scrollBarHandlerS_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-handler-selected-state-path");
			if(!scrollBarHandlerS_str) return;
			
			var scrollBarLeft_str = self.checkForAttribute(skinElement_el, "data-controller-scrollba-background-left-path");
			if(!scrollBarLeft_str) return;
			
			var scrollBarRight_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-background-right-path");
			if(!scrollBarRight_str) return;
		
			self.scrollBarMiddlePath_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-background-middle-path");
			if(!self.scrollBarMiddlePath_str) return;
			
			self.controllerBackgroundMiddlePath_str = self.checkForAttribute(skinElement_el, "data-controller-background-center-path");
			if(!self.controllerBackgroundMiddlePath_str) return;
			
			self.buttonToolTipLeft_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-left-path");
			if(!self.buttonToolTipLeft_str) return;
			
			self.buttonToolTipMiddle_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-middle-path");
			if(!self.buttonToolTipMiddle_str) return;
			
			self.buttonToolTipRight_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-right-path");
			if(!self.buttonToolTipRight_str) return;
			
			self.buttonToolTipBottomPointer_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-bottom-pointer-path");
			if(!self.buttonToolTipBottomPointer_str) return;
			
			self.buttonToolTipTopPointer_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-top-pointer-path");
			if(!self.buttonToolTipTopPointer_str) return;
			
			var infoWindowCloseNormal_str = self.checkForAttribute(skinElement_el, "data-info-window-close-button-normal-state-path");
			if(!infoWindowCloseNormal_str) return;
			
			var infoWindowCloseSelected_str = self.checkForAttribute(skinElement_el, "data-info-window-close-button-selected-state-path");
			if(!infoWindowCloseSelected_str) return;
			
			
			//set skin graphics paths.
			self.skinPaths_ar.push(preloaderPath_str);
			self.skinPaths_ar.push(mainLightBoxCloseButtonNPath_str);
			self.skinPaths_ar.push(mainLightBoxCloseButtonSPath_str);
			self.skinPaths_ar.push(controllerBackgroundLeftPath_str);
			self.skinPaths_ar.push(controllerBackgroundRight_str);
			self.skinPaths_ar.push(controllerPanN_str);
			self.skinPaths_ar.push(controllerPanS_str);
			self.skinPaths_ar.push(controllerRotateN_str);
			self.skinPaths_ar.push(controllerRotateS_str);
			self.skinPaths_ar.push(controllerNextN_str);
			self.skinPaths_ar.push(controllerNextS_str);
			self.skinPaths_ar.push(controllerPrevN_str);
			self.skinPaths_ar.push(controllerPrevS_str);
			self.skinPaths_ar.push(controllerPlayN_str);
			self.skinPaths_ar.push(controllerPlayS_str);
			self.skinPaths_ar.push(controllerPauseN_str);
			self.skinPaths_ar.push(controllerPauseS_str);
			self.skinPaths_ar.push(controllerInfoN_str);
			self.skinPaths_ar.push(controllerInfoS_str);
			self.skinPaths_ar.push(controllerLinkN_str);
			self.skinPaths_ar.push(controllerLinkS_str);
			self.skinPaths_ar.push(controllerFullScreemNormalN_str);
			self.skinPaths_ar.push(controllerFullScreenNormalS_str);
			self.skinPaths_ar.push(controllerFullScreemFullN_str);
			self.skinPaths_ar.push(controllerFullScreenFullS_str);	
			self.skinPaths_ar.push(zoomInN_str);
			self.skinPaths_ar.push(zoomInS_str);
			self.skinPaths_ar.push(zoomOutN_str);
			self.skinPaths_ar.push(zoomOutS_str);
			self.skinPaths_ar.push(scrollBarHandlerN_str);
			self.skinPaths_ar.push(scrollBarHandlerS_str);
			self.skinPaths_ar.push(scrollBarLeft_str);
			self.skinPaths_ar.push(scrollBarRight_str);
			self.skinPaths_ar.push(self.buttonToolTipTopPointer_str);
			self.skinPaths_ar.push(self.buttonToolTipLeft_str);
			self.skinPaths_ar.push(infoWindowCloseNormal_str);
			self.skinPaths_ar.push(infoWindowCloseSelected_str);
			
			
			self.skinPaths_ar.push(self.buttonToolTipMiddle_str);
			self.skinPaths_ar.push(self.buttonToolTipRight_str);
			self.skinPaths_ar.push(self.controllerBackgroundMiddlePath_str);
			
			self.totalGraphics = self.skinPaths_ar.length;
			
			self.loadSkin();
			
			//set images paths.
			for(var i=0; i<self.totalImages; i++){
				self.imagesPaths_ar[i] = self.playListData_ar[i].smallImagePath;
				if(self.showLargeImageVersionOnZoom_bl) self.largeImagesPaths_ar[i] = self.playListData_ar[i].largeImagePath;
				if(self.showNavigator_bl) self.navigatorImagesPaths_ar[i] = self.playListData_ar[i].navigatorImagePath;
			}
		};
		
		//####################################//
		/* load buttons graphics */
		//###################################//
		self.loadSkin = function(){
		
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.skinPaths_ar[self.countLoadedSkinImages];
			
			self.image_img = new Image();
			self.image_img.onload = self.onSkinLoadHandler;
			self.image_img.onerror = self.onKinLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onSkinLoadHandler = function(e){
		
			if(self.countLoadedSkinImages == 0){
				self.mainPreloader_img = self.image_img;
				self.dispatchEvent(FWDData.PRELOADER_LOAD_DONE);
			}else if(self.countLoadedSkinImages == 1){
				self.mainLightboxCloseButtonN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 2){
				self.mainLightboxCloseButtonS_img = self.image_img;
				self.dispatchEvent(FWDData.LIGHBOX_CLOSE_BUTTON_LOADED);
			}else if(self.countLoadedSkinImages == 3){
				self.controllerBackgroundLeft_img = self.image_img;
				self.controllerHeight = self.controllerBackgroundLeft_img.height;
			}else if(self.countLoadedSkinImages == 4){
				self.controllerBackgroundRight_img = self.image_img;
			}else if(self.countLoadedSkinImages == 5){
				self.controllerPanN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 6){
				self.controllerPanS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 7){
				self.controllerRotateN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 8){
				self.controllerRotateS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 9){
				self.controllerNextN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 10){
				self.controllerNextS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 11){
				self.controllerPrevN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 12){
				self.controllerPrevS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 13){
				self.controllerPlayN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 14){
				self.controllerPlayS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 15){
				self.controllerPauseN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 16){
				self.controllerPauseS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 17){
				self.controllerInfoN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 18){
				self.controllerInfoS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 19){
				self.controllerLinkN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 20){
				self.controllerLinkS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 21){
				self.controllerFullScreenNormalN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 22){
				self.controllerFullScreenNormalS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 23){
				self.controllerFullScreenFullN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 24){
				self.controllerFullScreenFullS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 25){
				self.zoomInN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 26){
				self.zoomInS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 27){
				self.zoomOutN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 28){
				self.zoomOutS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 29){
				self.scrollBarHandlerN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 30){
				self.scrollBarHandlerS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 31){
				self.scrollBarLeft_img = self.image_img;
			}else if(self.countLoadedSkinImages == 32){
				self.scrollBarRight_img = self.image_img;
			}else if(self.countLoadedSkinImages == 33){
				self.toolTipPointer_img = self.image_img;
			}else if(self.countLoadedSkinImages == 34){
				self.toolTipLeft_img = self.image_img;
			}else if(self.countLoadedSkinImages == 35){
				self.infoWindowCloseNormal_img = self.image_img;
			}else if(self.countLoadedSkinImages == 36){
				self.infoWindowCloseSelected_img = self.image_img;
			}
			
			self.dispatchEvent(FWDData.SKIN_PROGRESS, {percent:self.countLoadedSkinImages/self.totalGraphics});
			
			self.countLoadedSkinImages++;
			if(self.countLoadedSkinImages < self.totalGraphics){
				self.loadImageId_to = setTimeout(self.loadSkin, 16);
			}else{
				self.dispatchEvent(FWDData.SKIN_PROGRESS, {percent:self.countLoadedSkinImages/self.totalGraphics});
				self.dispatchEvent(FWDData.LOAD_DONE);
				if(self.showNavigator_bl){
					self.loadNavigatorFirstImage();
				}else{
					self.loadImages();
				}
			}
		};
		
		self.onKinLoadErrorHandler = function(e){
			var message = "The skin graphics with the label <font color='#FFFFFF'>" + self.skinPaths_ar[self.countLoadedSkinImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			console.log(e);
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
		};
		
		self.stopToLoad = function(){
			clearTimeout(self.loadImageId_to);
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			if(self.navigatorImage_img){
				self.navigatorImage_img.onload = null;
				self.navigatorImage_img.onerror = null;
			}
		};
		
		//####################################//
		/* load navigator images */
		//###################################//
		self.loadNavigatorFirstImage = function(){
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.navigatorImagesPaths_ar[0];
			self.image_img = new Image();
			self.image_img.onload = self.onFirstNavigatorImageLoadHandler;
			self.image_img.onerror = self.onImageLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onFirstNavigatorImageLoadHandler = function(){
			self.navigatorImages_ar.push(self.image_img);
			self.navigatorWidth = self.image_img.width;
			self.navigatorHeight = self.image_img.height;
			self.loadImages();
		};
		
		//####################################//
		/* load small images */
		//###################################//
		self.loadImages = function(){
			if(self.hasNavigatorError_bl) return;
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.imagesPaths_ar[self.countLoadedImages];
			self.image_img = new Image();
			self.image_img.onload = self.onImageLoadHandler;
			self.image_img.onerror = self.onImageLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onImageLoadHandler = function(e){
			
			if(self.countLoadedImages == 0) self.dispatchEvent(FWDData.FIRST_IMAGE_LOAD_COMPLETE);
				
			self.images_ar.push(self.image_img);
			
			self.dispatchEvent(FWDData.IMAGE_LOADED, {id:self.countLoadedImages});
			self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
			
			if(self.showNavigator_bl && self.countLoadedImages !=0){
				self.navigatorImage_img = new Image();
				self.navigatorImages_ar.push(self.navigatorImage_img);
				if(self.countLoadedImages == self.totalImages - 1) self.navigatorImage_img.onload = self.onLastNavigatorImageLoadHandler;
				self.navigatorImage_img.onerror = self.onNavigatorImageLoadErrorHandler;
				self.navigatorImage_img.src = self.navigatorImagesPaths_ar[self.countLoadedImages];
			}
			
			self.countLoadedImages++;
			if(self.countLoadedImages < self.totalImages){
				self.loadImageId_to = setTimeout(self.loadImages, 40);
			}else{
				if(!self.showNavigator_bl){
					self.areAllImagesLoaded_bl = true;
					self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
					self.dispatchEvent(FWDData.IMAGES_LOAD_COMPLETE);
				}
			}
		};
		
		self.onLastNavigatorImageLoadHandler = function(e){
			if(self == null) return;
			self.areAllImagesLoaded_bl = true;
			self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
			self.dispatchEvent(FWDData.IMAGES_LOAD_COMPLETE);
		};
		
		self.onNavigatorImageLoadErrorHandler = function(e){
			var message = "The navigator image with the label <font color='#FFFFFF'>" + self.navigatorImagesPaths_ar[self.countLoadedImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			self.hasNavigatorError_bl = true;
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
			console.log(e);
		};
		
		
		self.onImageLoadErrorHandler = function(e){
			var message = "The image with the label <font color='#FFFFFF'>" + self.imagesPaths_ar[self.countLoadedImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			console.log(e);
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
		};
		
		//####################################//
		/* check if element with and attribute exists or throw error */
		//####################################//
		self.checkForAttribute = function(e, attr, position){
			var test = FWDUtils.getChildFromNodeListFromAttribute(e, attr);
			test = test ? FWDUtils.trim(FWDUtils.getAttributeValue(test, attr)) : undefined;
	
			if(!test){
				if(position != undefined){
					self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Element with attribute <font color='#FFFFFF'>" + attr + "</font> is not defined at positon <font color='#FFFFFF'>" + (position + 1) + "</font>"});
				}else{
					self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Element with attribute <font color='#FFFFFF'>" + attr + "</font> is not defined."});
				}
				return;
			}
			return test;
		};
		
		//####################################//
		/* show error if a required property is not defined */
		//####################################//
		self.showPropertyError = function(error){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"The property called <font color='#FFFFFF'>" + error + "</font> is not defined."});
		};
		
		self.showMarkerError = function(error, position){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"The marker at position <font color='#FFFFFF'>" + position + "</font> dose not have defined an attribute <font color='#FFFFFF'>" + error + "</font>."});
		};
		
		self.showMarkerTypeError = function(error, position){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Marker type is incorrect <font color='#FFFFFF'>" + error + "</font> at position <font color='#FFFFFF'>" + position + "</font>. Accepted types are <font color='#FFFFFF'>link, tooltip, infowindow</font>."});
		};
			
		//####################################//
		/*destroy */
		//####################################//
		self.destroy = function(){
			var totalImages;
			var img_img;
		
			clearTimeout(self.parseDelayId_to);
			clearTimeout(self.loadImageId_to);
			
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
				self.image_img.src = null;
			}
			
			if(self.navigatorImage_img){
				self.navigatorImage_img.onload = null;
				self.navigatorImage_img.onerror = null;
				self.navigatorImage_img.src = null;
			}
			
			totalImages = self.images_ar.length;
			for(var i=0; i<totalImages; i++){
				img_img = self.images_ar[i];
				img_img.onerror = null;
				img_img.onload = null;
				img_img.src = null;
				img_img = null;
			}
			
			totalImages = self.navigatorImages_ar.length;
			for(var i=0; i<totalImages; i++){
				img_img = self.navigatorImages_ar[i];
				img_img.onerror = null;
				img_img.onload = null;
				img_img.src = null;
				img_img = null;
			}
			
			if(self.mainPreloader_img) self.mainPreloader_img.src = null;
			if(self.mainLightboxCloseButtonN_img) self.mainLightboxCloseButtonN_img.src = null;
			if(self.mainLightboxCloseButtonS_img) self.mainLightboxCloseButtonS_img.src = null;
			if(self.controllerBackgroundLeft_img) self.controllerBackgroundLeft_img.src = null; 
			if(self.controllerBackgroundRight_img) self.controllerBackgroundRight_img.src = null; 
			if(self.controllerPanN_img) self.controllerPanN_img.src = null; 
			if(self.controllerPanS_img) self.controllerPanS_img.src = null;
			
			if(self.controllerRotateN_img) self.controllerRotateN_img.src = null;
			if(self.controllerRotateS_img) self.controllerRotateS_img.src = null;
			if(self.controllerNextN_img) self.controllerNextN_img.src = null;
			if(self.controllerNextS_img) self.controllerNextS_img.src = null;
			if(self.controllerPrevN_img) self.controllerPrevN_img.src = null;
			if(self.controllerPrevS_img) self.controllerPrevS_img.src = null;
			if(self.controllerPlayN_img) self.controllerPlayN_img.src = null;
			if(self.controllerPlayS_img) self.controllerPlayS_img.src = null;
			if(self.controllerPauseN_img) self.controllerPauseN_img.src = null;
			if(self.controllerPauseS_img) self.controllerPauseS_img.src = null;
			if(self.controllerInfoN_img) self.controllerInfoN_img.src = null;
			if(self.controllerLinkN_img) self.controllerLinkN_img.src = null;
			if(self.controllerLinkS_img) self.controllerLinkS_img.src = null;
			if(self.controllerFullScreenNormalN_img) self.controllerFullScreenNormalN_img.src = null;
			if(self.controllerFullScreenNormalS_img) self.controllerFullScreenNormalS_img.src = null;
			if(self.controllerFullScreenFullN_img) self.controllerFullScreenFullN_img.src = null;
			if(self.controllerFullScreenFullS_img) self.controllerFullScreenFullS_img.src = null;
			if(self.zoomInN_img) self.zoomInN_img.src = null;
			if(self.zoomInS_img) self.zoomInS_img.src = null;
			if(self.zoomOutN_img) self.zoomOutN_img.src = null;
			if(self.zoomOutS_img) self.zoomOutS_img.src = null;
			if(self.scrollBarHandlerN_img) self.scrollBarHandlerN_img.src = null;
			if(self.scrollBarHandlerN_img) self.scrollBarHandlerN_img.src = null;
			if(self.scrollBarHandlerS_img) self.scrollBarHandlerS_img.src = null;
			if(self.scrollBarLeft_img) self.scrollBarLeft_img.src = null;
			if(self.scrollBarLeft_img) self.scrollBarLeft_img.src = null;
			if(self.scrollBarRight_img) self.scrollBarRight_img.src = null;
			if(self.toolTipLeft_img) self.toolTipLeft_img.src = null;
			if(self.toolTipPointer_img) self.toolTipPointer_img.src = null;
			if(self.infoWindowCloseNormal_img) self.infoWindowCloseNormal_img.src = null;
			if(self.infoWindowCloseSelected_img) self.infoWindowCloseSelected_img.src = null;
	
			
			self.mainPreloader_img = null;
			self.mainLightboxCloseButtonN_img = null;
			self.mainLightboxCloseButtonS_img = null;
			self.controllerBackgroundLeft_img = null;
			self.controllerBackgroundRight_img = null;
			self.controllerPanN_img = null;
			self.controllerPanS_img = null;
			self.controllerRotateN_img = null;
			self.controllerRotateS_img = null;
			self.controllerNextN_img = null;
			self.controllerNextS_img = null;
			self.controllerPrevN_img = null;
			self.controllerPrevS_img = null;
			self.controllerPlayN_img = null;
			self.controllerPlayS_img = null;
			self.controllerPauseN_img = null;
			self.controllerPauseS_img = null;
			self.controllerInfoN_img = null;
			self.controllerInfoS_img = null;
			self.controllerLinkN_img = null;
			self.controllerLinkS_img = null;
			self.controllerFullScreenNormalN_img = null;
			self.controllerFullScreenNormalS_img = null;
			self.controllerFullScreenFullN_img = null;
			self.controllerFullScreenFullS_img = null;
			self.zoomInN_img = null;
			self.zoomInS_img = null;
			self.zoomOutN_img = null;
			self.zoomOutS_img = null;
			self.scrollBarHandlerN_img = null;
			self.scrollBarHandlerS_img = null;
			self.scrollBarLeft_img = null;
			self.scrollBarRight_img = null;
			self.toolTipLeft_img = null;
			self.toolTipPointer_img = null;
			self.infoWindowCloseNormal_img = null;
			self.infoWindowCloseSelected_img = null;
			
			this.props_obj = null;
			this.rootElement_el = null;
			this.skinPaths_ar = null;
			this.playListData_ar = null;
			this.imagesPaths_ar = null;
			this.largeImagesPaths_ar = null;
			this.navigatorImagesPaths_ar = null ;
			this.images_ar = null;
			this.navigatorImages_ar = null;
			this.markersList_ar = null;
			this.markersPosition_ar = null;
			this.buttons_ar = null;
			this.buttonsLabels_ar = null;
			this.contextMenuLabels_ar = null;
			
			this.backgroundColor_str = null;
			this.handMovePath_str = null;
			this.handGrabRotatePath_str = null;
			this.controllerBackgroundMiddlePath_str = null;
			this.scrollBarMiddlePath_str = null;
			this.startDraggingMode_str = null;
			this.controllerPosition_str = null;
			this.preloaderFontColor_str = null;
			this.preloaderBackgroundColor_str = null;
			this.preloaderText_str = null;
			this.buttonToolTipLeft_str = null;
			this.buttonToolTipMiddle_str = null;
			this.buttonToolTipRight_str = null;
			this.buttonToolTipBottomPointer_str = null;
			this.buttonToolTipTopPointer_str = null;
			this.buttonToolTipFontColor_str = null;
			this.link_str = null;
			this.contextMenuBackgroundColor_str = null;
			this.contextMenuBorderColor_str = null;
			this.contextMenuSpacerColor_str = null;
			this.contextMenuItemNormalColor_str = null;
			this.contextMenuItemSelectedColor_str = null;
			this.contextMenuItemSelectedColor_str = null;
			this.contextMenuItemDisabledColor_str = null;
			this.navigatorPosition_str = null;
			this.navigatorHandlerColor_str = null;
			this.navigatorBorderColor_str = null;
			this.infoText_str = null;
			this.infoWindowBackgroundColor_str = null;
			this.infoWindowScrollBarColor_str = null;
			
			prototype.destroy();
			self = null;
			prototype = null;
			FWDData.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
	FWDData.setPrototype = function(){
		FWDData.prototype = new FWDEventDispatcher();
	};
	
	FWDData.prototype = null;
	FWDData.PRELOADER_LOAD_DONE = "onPreloaderLoadDone";
	FWDData.LOAD_DONE = "onLoadDone";
	FWDData.LOAD_ERROR = "onLoadError";
	FWDData.LIGHBOX_CLOSE_BUTTON_LOADED = "onLightBoxCloseButtonLoadDone";
	FWDData.IMAGE_LOADED = "onImageLoaded";
	FWDData.FIRST_IMAGE_LOAD_COMPLETE = "onFirstImageLoadComplete";
	FWDData.IMAGES_LOAD_COMPLETE = "onImagesLoadComplete";
	FWDData.SKIN_PROGRESS = "onSkinProgress";
	FWDData.IMAGES_PROGRESS = "onImagesPogress";
	FWDData.hasTouch_bl = false;
	
	window.FWDData = FWDData;
}(window));/* FWDDescriptionWindow */
(function (window){
var FWDDescriptionWindow = function(parent, data){
		
		var self = this;
		var prototype = FWDDescriptionWindow.prototype;
		
		this.infoWindowCloseNormal_img = data.infoWindowCloseNormal_img;
		this.infoWindowCloseSelected_img = data.infoWindowCloseSelected_img;
		
		this.close_do = null;
		this.background_sdo = null; 
		this.mainContentHolder_do = null;
		this.dumyHolder_do = null;
		this.contentHolder_sdo = null;
		this.scrollBar_do = null;
		this.scrollBarTrack_sdo = null;
		this.scrollBarHandler_sdo = null;
	
		this.mainBackgroundColor_str = data.infoWindowBackgroundColor_str;
		this.scrollBarHandlerColor = data.infoWindowScrollBarColor_str;
		this.scrollBarTrackColor = data.infoWindowScrollBarColor_str;
		this.scrollBarTrackOpacity = .6;
		
		this.toolTipWindowId = "none";
		this.backgroundOpacity = data.infoWindowBackgroundOpacity;
		this.mainContentHolderWidth;
		this.mainContentHolderHeight;
		this.contentHolderHeight;
		this.scrollBarHandlerFinalY;
		this.mainContentFinalX = 0;
		this.mainContentFinalY = 0;
		this.contentFinalX = 0;
		this.contentFinalY = 0;
		this.headerFinalY = 0;
		this.contentHeight;
		this.maxWidth = 800;
		this.offestWidth = 20;
		this.offsetHeight = 20;
		this.stageWidth;
		this.stageHeight;
		this.scrollBarHeight = 0;
		this.scrollBarWidth = 4;
		this.scrollBarHandlerHeight;
		this.scrollBarBorderRadius = 15;
		this.yPositionOnPress;
		this.lastPresedY;
		this.closeButtonWidth = self.infoWindowCloseNormal_img.width;
		this.closeButtonHeight = self.infoWindowCloseNormal_img.height;
		this.vy = 0;
		this.vy2 = 0;
		this.friction = .9;
		
		this.hideWithDelayId_do;
		this.showOrHideWithDelayId_to;
		this.hideCompleteId_to;
		this.updateMobileScrollBarId_int;
	
		this.isShowed_bl = true;
		this.isDragging_bl = false;
		this.allowToScroll_bl = true;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setBackfaceVisibility();
			self.setupMainContainers();
			if(self.isMobile_bl){
				self.setupMobileScrollbar();
			}else{
				self.setupPCScrollBar();
				self.addMouseWheelSupport();
			}
			self.setupCloseButton();
			self.hide(false);
		};
		
		//##########################################//
		/* position and resize */
		//##########################################//
		self.resizeAndPosition = function(){
			if(self.stageWidth == parent.stageWidth && self.stageHeight == parent.stageHeight) return;
			
			self.stageWidth = parent.stageWidth;
			self.stageHeight = parent.stageHeight;
			
			self.background_sdo.setWidth(self.stageWidth);
			self.background_sdo.setHeight(self.stageHeight);
			self.updateSize();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			self.background_sdo = new FWDSimpleDisplayObject("div");
			self.background_sdo.setBkColor(self.mainBackgroundColor_str);
			self.addChild(self.background_sdo);
			
			self.mainContentHolder_do = new FWDDisplayObject("div");
			self.mainContentHolder_do.setBackfaceVisibility();
			
			self.dumyHolder_do = new FWDDisplayObject("div");
			self.dumyHolder_do.setBackfaceVisibility();
			self.addChild(self.dumyHolder_do);
			
			self.dumyHolder_do.addChild(self.mainContentHolder_do);
			
			self.contentHolder_sdo = new FWDSimpleDisplayObject("div");
			self.contentHolder_sdo.getStyle().fontSmoothing = "antialiased";
			self.contentHolder_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.contentHolder_sdo.getStyle().textRendering = "optimizeLegibility";	
			if(!FWDUtils.isMobile){
				self.contentHolder_sdo.hasTransform3d_bl = false;
				self.contentHolder_sdo.hasTransform2d_bl = false;
			};
			self.contentHolder_sdo.setBackfaceVisibility();
			self.mainContentHolder_do.addChild(self.contentHolder_sdo);
		};
		
		//########################################//
		/* Setup close button */
		//#######################################//
		self.setupCloseButton = function(){
			FWDSimpleButton.setPrototype();
			self.close_do = new FWDSimpleButton(self.infoWindowCloseNormal_img, self.infoWindowCloseSelected_img);
			self.close_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.closeButtonStartHandler);
			self.mainContentHolder_do.addChild(self.close_do);
		};
		
		self.closeButtonStartHandler = function(e){
			if(!self.isShowed_bl) return;
			self.hide(true);
		};
		
		//########################################//
		/* update content size */
		//########################################//
		self.updateSize = function(){
			self.mainContentHolderWidth = self.stageWidth - self.offestWidth;
			if(self.mainContentHolderWidth > self.maxWidth) self.mainContentHolderWidth = self.maxWidth;
			self.mainContentHolder_do.setWidth(self.mainContentHolderWidth);
			self.dumyHolder_do.setWidth(self.stageWidth);
			self.dumyHolder_do.setHeight(self.stageHeight);
		
			self.close_do.setX(self.mainContentHolderWidth - self.closeButtonWidth);
			
			if(self.isMobile_bl){	
				setTimeout(function(){
					if(self == null) return;
					TweenMax.killTweensOf(self.mainContentHolder_do);
					self.contentHolderHeight = self.contentHolder_sdo.getHeight();
					self.mainContentHolderHeight = Math.min(self.stageHeight, self.contentHolderHeight);
					self.mainContentFinalX = Math.round((self.stageWidth - self.mainContentHolderWidth)/2);
					
					if(self.stageHeight > self.contentHolderHeight){
						self.mainContentFinalY = Math.round((self.stageHeight - self.contentHolderHeight)/2);
						self.allowToScroll_bl = false;
					}else{
						self.mainContentFinalY = 0;	
						self.allowToScroll_bl = true;
					}
					
					self.updateMobileScrollBarWithoutAnimation();
					TweenMax.killTweensOf(self.mainContentHolder_do);
					self.mainContentHolder_do.setX(self.mainContentFinalX);
					self.mainContentHolder_do.setY(self.mainContentFinalY);
					self.mainContentHolder_do.setHeight(self.mainContentHolderHeight);
				}, 50);
				
			}else{
			
				setTimeout(function(){
					if(self == null) return;
					TweenMax.killTweensOf(self.mainContentHolder_do);
					self.contentHolderHeight = self.contentHolder_sdo.getHeight();
					self.mainContentHolderHeight = self.stageHeight;
					self.mainContentFinalX = Math.round((self.stageWidth - self.mainContentHolderWidth)/2);
					self.scrollBarHeight = Math.min(self.contentHolderHeight - 20 - self.closeButtonHeight, self.stageHeight - 20 - self.closeButtonHeight);
					
					if(self.stageHeight > self.contentHolderHeight){
						self.scrollBar_do.setOverflow("hidden");
						self.mainContentHolderHeight = self.contentHolderHeight;
						self.scrollBarHandler_sdo.setY(0);
						self.mainContentFinalY = Math.round((self.stageHeight - self.contentHolderHeight)/2) ;
						self.allowToScroll_bl = false;
					}else{
						self.mainContentFinalY = 0;
						self.scrollBar_do.setOverflow("visible");
						self.scrollBar_do.setY(5 + self.closeButtonHeight);
						self.allowToScroll_bl = true;
					}
					
					if(self.stageHeight < 120) self.mainContentFinalY = 0;
				
					self.scrollBarHandlerHeight = Math.min((self.scrollBarHeight - 20), (self.stageHeight/self.contentHolderHeight) * (self.scrollBarHeight - 20));
					if(self.scrollBarHandlerHeight > 500){
						self.scrollBarHandlerHeight = 500;
					}
					
					self.scrollBar_do.setX(self.mainContentHolderWidth - self.scrollBarWidth - 2);
					self.scrollBarTrack_sdo.setHeight(Math.max(self.scrollBarHeight, self.scrollBarHandlerHeight));
					self.scrollBarHandler_sdo.setHeight(self.scrollBarHandlerHeight);
					
					TweenMax.killTweensOf(self.mainContentHolder_do);
					self.mainContentHolder_do.setX(self.mainContentFinalX);
					self.mainContentHolder_do.setY(self.mainContentFinalY);
					self.mainContentHolder_do.setHeight(self.mainContentHolderHeight);
					
					self.updatePCHandler(false);
				
				}, 50);
			}
		};
		
		//##########################################//
		/* set label */
		//##########################################//
		self.setText = function(text){
			if(self == null) return;
			self.updateSize();
			self.contentHolder_sdo.setInnerHTML(text);
			setTimeout(self.updateSize, 120);
		};
	
		//#########################################//
		/* Setup PC scrollbar */
		//#########################################//
		self.setupPCScrollBar = function(){
			
			self.scrollBar_do = new FWDDisplayObject("div");
			self.scrollBar_do.setOverflow("visible");
			self.mainContentHolder_do.addChild(self.scrollBar_do);
			
			self.scrollBarTrack_sdo = new FWDSimpleDisplayObject("div");
			self.scrollBarTrack_sdo.setWidth(self.scrollBarWidth);
			self.scrollBarTrack_sdo.setBkColor(self.scrollBarTrackColor);
			self.scrollBarTrack_sdo.setAlpha(0);
			self.scrollBarTrack_sdo.getStyle().borderRadius = self.scrollBarBorderRadius + "px";
			self.scrollBar_do.addChild(self.scrollBarTrack_sdo);
			
			self.scrollBarHandler_sdo = new FWDSimpleDisplayObject("div");
			self.scrollBarHandler_sdo.setButtonMode(true);
			self.scrollBarHandler_sdo.setWidth(self.scrollBarWidth);
			self.scrollBarHandler_sdo.getStyle().borderRadius = self.scrollBarBorderRadius + "px";
			self.scrollBarHandler_sdo.setBkColor(self.scrollBarHandlerColor);
			self.scrollBarHandler_sdo.setAlpha(.5);
			
			if(self.scrollBarHandler_sdo.screen.addEventListener){
				self.scrollBarHandler_sdo.screen.addEventListener("mouseover", self.scrollBarHandlerOnMouseOver);
				self.scrollBarHandler_sdo.screen.addEventListener("mouseout", self.scrollBarHandlerOnMouseOut);
				self.scrollBarHandler_sdo.screen.addEventListener("mousedown", self.scrollBarHandlerOnMouseDown);
			}else if(self.screen.attachEvent){
				self.scrollBarHandler_sdo.screen.attachEvent("onmouseover", self.scrollBarHandlerOnMouseOver);
				self.scrollBarHandler_sdo.screen.attachEvent("onmouseout", self.scrollBarHandlerOnMouseOut);
				self.scrollBarHandler_sdo.screen.attachEvent("onmousedown", self.scrollBarHandlerOnMouseDown);
			}
			
			self.scrollBar_do.addChild(self.scrollBarHandler_sdo);
		};
		
		//descktop handler
		self.scrollBarHandlerOnMouseOver = function(){
			TweenMax.to(self.scrollBarHandler_sdo, .2, {alpha:1, w:10});
			TweenMax.to(self.scrollBarTrack_sdo, .2, {alpha:.4, w:10});
			TweenMax.to(self.scrollBar_do, .2, {x:self.mainContentHolderWidth - self.scrollBarWidth - 6});
		};
		
		self.scrollBarHandlerOnMouseOut = function(){
			if(self.isDragging_bl) return;
			TweenMax.to(self.scrollBarHandler_sdo, .3, {alpha:.5, w:self.scrollBarWidth});
			TweenMax.to(self.scrollBarTrack_sdo, .3, {alpha:0, w:self.scrollBarWidth});
			TweenMax.to(self.scrollBar_do, .3, {x:self.mainContentHolderWidth - self.scrollBarWidth - 2});
		};
		
		self.scrollBarHandlerOnMouseDown = function(e){
			//if(self.stageHeight < 120) return;
			if(!self.allowToScroll_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			self.isDragging_bl = true;
			self.yPositionOnPress = self.scrollBarHandler_sdo.getY();
			self.lastPresedY = viewportMouseCoordinates.screenY;
			
			if(window.addEventListener){
				window.addEventListener("mousemove", self.scrollBarHandlerMoveHandler);
				window.addEventListener("mouseup", self.scrollBarHandlerEndHandler);	
			}else if(document.attachEvent){
				document.attachEvent("onmousemove", self.scrollBarHandlerMoveHandler);
				document.attachEvent("onmouseup", self.scrollBarHandlerEndHandler);
			}
		};
		
		self.scrollBarHandlerMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
	
			self.scrollBarHandlerFinalY = Math.round(self.yPositionOnPress + viewportMouseCoordinates.screenY - self.lastPresedY);
			if(self.scrollBarHandlerFinalY >= self.scrollBarHeight - self.scrollBarHandlerHeight){
				self.scrollBarHandlerFinalY = self.scrollBarHeight -  self.scrollBarHandlerHeight;
			}
			
			if(self.scrollBarHandlerFinalY <= 0) self.scrollBarHandlerFinalY = 0;
			self.scrollBarHandler_sdo.setY(self.scrollBarHandlerFinalY);
			self.updatePCHandler(true);
		};
		
		self.scrollBarHandlerEndHandler = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.isDragging_bl = false;
			
			if(!FWDUtils.hitTest(self.scrollBarHandler_sdo.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
				self.scrollBarHandlerOnMouseOut();
			}
			if(window.removeEventListener){
				window.removeEventListener("mousemove", self.scrollBarHandlerMoveHandler);
				window.removeEventListener("mouseup", self.scrollBarHandlerEndHandler);	
			}else if(document.detachEvent){
				document.detachEvent("onmousemove", self.scrollBarHandlerMoveHandler);
				document.detachEvent("onmouseup", self.scrollBarHandlerEndHandler);
			}
		};
		
		self.updatePCHandler = function(animate){
			
			var percent;
			var scrollPercent;
			
			//if(self.stageHeight < 120) return;

			scrollPercent = (self.scrollBarHandlerFinalY/(self.scrollBarHeight - self.scrollBarHandlerHeight));
			
			if(scrollPercent == "Infinity") scrollPercent = 0;
			if(scrollPercent >= 1) scrollPercent = 1;
		
			if(self.isDragging_bl){
				self.contentFinalY = parseInt(scrollPercent * (self.stageHeight - self.contentHolderHeight));
			}else{
				if(self.scrollBarHandler_sdo.getY() < 0){
					self.scrollBarHandler_sdo.setY(0);
				}else if(self.scrollBarHandler_sdo.getY() > self.scrollBarHeight - self.scrollBarHandlerHeight ){
					self.scrollBarHandler_sdo.setY(self.scrollBarHeight - self.scrollBarHandlerHeight);
				}
			
				percent = self.scrollBarHandler_sdo.getY()/(self.scrollBarHeight - self.scrollBarHandlerHeight);	
				if(isNaN(percent)) percent = 0;
				
				if(self.stageHeight > self.contentHolderHeight){
					self.contentFinalY = 0;
				}else{
					self.contentFinalY = Math.round((percent * (self.scrollBarHeight  - self.scrollBarHandlerHeight)));
					self.contentFinalY = Math.round(percent * (self.stageHeight - self.contentHolderHeight));
				}
			}
			
			if(animate){
				TweenMax.to(self.contentHolder_sdo, .3, {y:Math.round(self.contentFinalY)});
			}else{
				self.contentHolder_sdo.setY(Math.round(self.contentFinalY));
			}
			
		};
		
		//######################################//
		/* add mouse wheel support */
		//######################################//
		self.addMouseWheelSupport = function(){
			if(window.addEventListener){
				self.screen.addEventListener ("mousewheel", self.mouseWheelHandler);
				self.screen.addEventListener('DOMMouseScroll', self.mouseWheelHandler);
			}else if(document.attachEvent){
				self.screen.attachEvent ("onmousewheel", self.mouseWheelHandler);
			}
		};
		
		this.mouseWheelHandler = function(e){
			if(!self.isShowed_bl) return;
			//if(self.stageHeight < 120) return;
			if(self.isDragging_bl) return;
			if(self.stageHeight > self.contentHolderHeight) return;
		
			var speedPercent = (self.stageHeight/self.contentHolderHeight);
			var dir = e.detail || e.wheelDelta;	
			if(e.wheelDelta) dir *= -1;
			if(FWDUtils.isOpera) dir *= -1;
			
			if(dir > 0){
				self.scrollBarHandler_sdo.setY(self.scrollBarHandler_sdo.getY() + (45 * speedPercent));
			}else if(dir < 0){
				self.scrollBarHandler_sdo.setY(self.scrollBarHandler_sdo.getY() - (45 * speedPercent));
			}
			
			self.updatePCHandler(true);
			
			if(e.preventDefault){
				e.preventDefault();
			}else{
				return false;
			}	
			return;
		};
		
	
		//##########################################//
		/* setup mobile scrollbar */
		//##########################################//
		self.setupMobileScrollbar = function(){
			if(self.hasPointerEvent_bl){
				self.screen.addEventListener("MSPointerDown", self.scrollBarTouchStartHandler);
			}else{
				self.screen.addEventListener("touchstart", self.scrollBarTouchStartHandler);
			}
		};
		
		self.scrollBarTouchStartHandler = function(e){
			//if(e.preventDefault) e.preventDefault();
			if(!self.allowToScroll_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			self.isDragging_bl = true;
			self.lastPresedY = viewportMouseCoordinates.screenY;
	
			if(self.hasPointerEvent_bl){
				window.addEventListener("MSPointerUp", self.scrollBarTouchEndHandler);
				window.addEventListener("MSPointerMove", self.scrollBarTouchMoveHandler);
			}else{
				window.addEventListener("touchend", self.scrollBarTouchEndHandler);
				window.addEventListener("touchmove", self.scrollBarTouchMoveHandler);
			}
		};
		
		self.scrollBarTouchMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			var toAdd = viewportMouseCoordinates.screenY - self.lastPresedY;
		
			self.contentFinalY += toAdd;
			self.contentFinalY = Math.round(self.contentFinalY);
			
			self.contentHolder_sdo.setY(self.contentFinalY);
			self.lastPresedY = viewportMouseCoordinates.screenY;
			self.vy = toAdd  * 2;
		};
		
		self.scrollBarTouchEndHandler = function(e){
			self.isDragging_bl = false;
			if(self.hasPointerEvent_bl){
				window.removeEventListener("MSPointerUp", self.scrollBarTouchEndHandler);
				window.removeEventListener("MSPointerMove", self.scrollBarTouchMoveHandler);
			}else{
				window.removeEventListener("touchend", self.scrollBarTouchEndHandler);
				window.removeEventListener("touchmove", self.scrollBarTouchMoveHandler);
			}
		};
		
		self.updateMobileScrollBar = function(animate){
			
			if(!self.isDragging_bl){
				self.vy *= self.friction;
				self.contentFinalY += self.vy;	
			
				if(self.contentFinalY > 0){
					self.vy2 = (0 - self.contentFinalY) * .3;
					self.vy *= self.friction;
					self.contentFinalY += self.vy2;
				}else if(self.contentFinalY < self.mainContentHolderHeight - self.contentHolderHeight){
					self.vy2 = (self.mainContentHolderHeight - self.contentHolderHeight - self.contentFinalY) * .3;
					self.vy *= self.friction;
					self.contentFinalY += self.vy2;
				}
				self.contentHolder_sdo.setY(Math.round(self.contentFinalY));
			}
		};
		
		self.updateMobileScrollBarWithoutAnimation = function(){
			if(self.contentFinalY > 0){
				self.contentFinalY = 0;
			}else if(self.contentFinalY < self.mainContentHolderHeight - self.contentHolderHeight){
				self.contentFinalY = self.mainContentHolderHeight - self.contentHolderHeight;
			}
			self.contentHolder_sdo.setY(Math.round(self.contentFinalY));
		};
		
		self.activateScrollBar = function(){
			if(self.isMobile_bl){
				self.updateMobileScrollBarId_int = setInterval(self.updateMobileScrollBar, 16);
			}
		};
		
		//##########################################//
		/* show / hide*/
		//##########################################//
		self.show = function(text){
			if(self.isShowed_bl) return;
			self.isShowed_bl = true;
			self.resizeAndPosition();
			self.setText(text);
			self.activateScrollBar();
			if(FWDUtils.isMobile){
				TweenMax.to(self.background_sdo, .8, {alpha:self.backgroundOpacity, delay:.2});
				self.showOrHideWithDelayId_to = setTimeout(self.showWithDelay, 1800);
			}else{
				TweenMax.to(self.background_sdo, .6, {alpha:self.backgroundOpacity});
				self.showOrHideWithDelayId_to = setTimeout(self.showWithDelay, 600);
			}
			self.dispatchEvent(FWDDescriptionWindow.SHOW_START);
		};
		
		self.showWithDelay = function(){
			self.dumyHolder_do.setX(0);
			if(self.scrollBarHandler_sdo) self.scrollBarHandler_sdo.setVisible(true);
			self.mainContentHolder_do.setY(-self.mainContentHolderHeight);
			TweenMax.to(self.mainContentHolder_do, .8, {y:self.mainContentFinalY, ease:Expo.easeInOut});
		};
		
		self.hide = function(animate, overwrite){
			if(!self.isShowed_bl && !overwrite) return;
			TweenMax.killTweensOf(self.background_sdo);	
			if(animate){
				TweenMax.to(self.mainContentHolder_do, .8, {y:self.stageHeight, ease:Expo.easeInOut});
				self.showOrHideWithDelayId_to = setTimeout(self.hideWithDelay, 800);
			}else{
				self.dumyHolder_do.setX(-3000);
				if(self.scrollBarHandler_sdo) self.scrollBarHandler_sdo.setVisible(false);
				self.background_sdo.setAlpha(0);
			}
			clearInterval(self.updateMobileScrollBarId_int);
			self.isShowed_bl = false;
		};
		
		self.hideWithDelay = function(){
			self.contentHolder_sdo.setInnerHTML("");
			TweenMax.to(self.background_sdo, .6, {alpha:0});
			self.hideCompleteId_to = setTimeout(self.hideWithDelayComplete, 600);
		};
		
		self.hideWithDelayComplete = function(){
			self.contentFinalY = 0;
			if(self.scrollBarHandler_sdo) self.scrollBarHandler_sdo.setY(0);
			self.dispatchEvent(FWDDescriptionWindow.HIDE_COMPLETE);
		};
		
		//###############################//
		/* clean main events */
		//###############################//
		self.cleanMainEvents = function(){
			
			if(self.screen.removeEventListener){
				if(self.scrollBarHandler_sdo){
					self.scrollBarHandler_sdo.screen.removeEventListener("mouseover", self.scrollBarHandlerOnMouseOver);
					self.scrollBarHandler_sdo.screen.removeEventListener("mouseout", self.scrollBarHandlerOnMouseOut);
					self.scrollBarHandler_sdo.screen.removeEventListener("mousedown", self.scrollBarHandlerOnMouseDown);
				}
				
				window.removeEventListener("mousemove", self.scrollBarHandlerMoveHandler);
				window.removeEventListener("mouseup", self.scrollBarHandlerEndHandler);	
				
				self.screen.removeEventListener ("mousewheel", self.mouseWheelHandler);
				self.screen.removeEventListener('DOMMouseScroll', self.mouseWheelHandler);
				
				self.screen.addEventListener("MSPointerDown", self.scrollBarTouchStartHandler);
				self.screen.addEventListener("touchstart", self.scrollBarTouchStartHandler);
				window.removeEventListener("MSPointerUp", self.scrollBarTouchEndHandler);
				window.removeEventListener("MSPointerMove", self.scrollBarTouchMoveHandler);
				window.removeEventListener("touchend", self.scrollBarTouchEndHandler);
				window.removeEventListener("touchmove", self.scrollBarTouchMoveHandler);
			}else if(self.screen.detachEvent){
				self.scrollBarHandler_sdo.screen.detachEvent("onmouseover", self.scrollBarHandlerOnMouseOver);
				self.scrollBarHandler_sdo.screen.detachEvent("onmouseout", self.scrollBarHandlerOnMouseOut);
				self.scrollBarHandler_sdo.screen.detachEvent("onmousedown", self.scrollBarHandlerOnMouseDown);
				
				document.detachEvent("onmousemove", self.scrollBarHandlerMoveHandler);
				document.detachEvent("onmouseup", self.scrollBarHandlerEndHandler);
				
				self.screen.detachEvent("onmousewheel", self.mouseWheelHandler);
			}
			
			clearTimeout(self.hideWithDelayId_do);
			clearTimeout(self.showOrHideWithDelayId_to);
			clearTimeout(self.hideCompleteId_to);
			clearInterval(self.updateMobileScrollBarId_int);
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			self.cleanMainEvents(); 
			
			if(self.scrollBar_do){
				TweenMax.killTweensOf(self.scrollBar_do);
				TweenMax.killTweensOf(self.scrollBarHandler_sdo);
				TweenMax.killTweensOf(self.scrollBarTrack_sdo);
				
				self.scrollBar_do.destroy();
				self.scrollBarHandler_sdo.destroy();
				self.scrollBarTrack_sdo.destroy();
			}
			
			TweenMax.killTweensOf(self.contentHolder_sdo);
			self.contentHolder_sdo.destroy();
			
			TweenMax.killTweensOf(self.background_sdo);
			self.background_sdo.destroy();
			
			TweenMax.killTweensOf(self.mainContentHolder_do);
			self.mainContentHolder_do.destroy();
			
			self.close_do.destroy();
			
			self.infoWindowCloseNormal_img = null;
			self.infoWindowCloseSelected_img = null;
			
			self.close_do = null;
			self.background_sdo = null; 
			self.mainContentHolder_do = null;
			self.contentHolder_sdo = null;
			self.scrollBar_do = null;
			self.scrollBarTrack_sdo = null;
			self.scrollBarHandler_sdo = null;
			
			self.mainBackgroundColor_str = null;
			self.scrollBarHandlerColor = null;
			self.scrollBarTrackColor = null;
			self.scrollBarTrackOpacity = null;
			
			parent = null;
			data = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDDescriptionWindow.prototype = null;
			
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDDescriptionWindow.setPrototype = function(){
		FWDDescriptionWindow.prototype = new FWDDisplayObject("div");
	};
	
	FWDDescriptionWindow.HIDE_COMPLETE = "hideComplete";
	FWDDescriptionWindow.SHOW_START = "showStart";
	
	FWDDescriptionWindow.prototype = null;
	window.FWDDescriptionWindow = FWDDescriptionWindow;
}(window));/* Display object */
(function (window){
	/*
	 * @ type values: div, img.
	 * @ positon values: relative, absolute.
	 * @ positon values: hidden.
	 * @ display values: block, inline-block, self applies only if the position is relative.
	 */
	var FWDDisplayObject = function(type, position, overflow, display){
		
		var self = this;
		self.listeners = {events_ar:[]};
		
		if(type == "div" || type == "img" || type == "canvas"){
			self.type = type;	
		}else{
			throw Error("Type is not valid! " + type);
		}
	
		this.children_ar = [];
		this.style;
		this.screen;
		this.transform;
		this.position = position || "absolute";
		this.overflow = overflow || "hidden";
		this.display = display || "inline-block";
		this.visible = true;
		this.buttonMode;
		this.x = 0;
		this.y = 0;
		this.w = 0;
		this.h = 0;
		this.rect;
		this.alpha = 1;
		this.innerHTML = "";
		this.opacityType = "";
		this.isHtml5_bl = false;
		
		this.hasTransform3d_bl =  FWDUtils.hasTransform3d;
		this.hasTransform2d_bl =  FWDUtils.hasTransform2d;
		if(FWDUtils.isIE || FWDUtils.isFirefox) self.hasTransform3d_bl = false;
		//if(FWDUtils.isIE || FWDUtils.isFirefox) self.hasTransform2d_bl = false;
		this.hasBeenSetSelectable_bl = false;
		
		
		//##############################//
		/* init */
		//#############################//
		self.init = function(){
			self.setScreen();
		};	
		
		//######################################//
		/* check if it supports transforms. */
		//######################################//
		self.getTransform = function() {
		    var properties = ['transform', 'msTransform', 'WebkitTransform', 'MozTransform', 'OTransform'];
		    var p;
		    while (p = properties.shift()) {
		       if (typeof self.screen.style[p] !== 'undefined') {
		            return p;
		       }
		    }
		    return false;
		};
		
		//######################################//
		/* set opacity type */
		//######################################//
		self.getOpacityType = function(){
			var opacityType;
			if (typeof self.screen.style.opacity != "undefined") {//ie9+ 
				opacityType = "opacity";
			}else{ //ie8
				opacityType = "filter";
			}
			return opacityType;
		};
		
		//######################################//
		/* setup main screen */
		//######################################//
		self.setScreen = function(element){
			if(self.type == "img" && element){
				self.screen = element;
				self.setMainProperties();
			}else{
				self.screen = document.createElement(self.type);
				self.setMainProperties();
			}
		};
		
		//########################################//
		/* set main properties */
		//########################################//
		self.setMainProperties = function(){
			
			self.transform = self.getTransform();
			self.setPosition(self.position);
			self.setDisplay(self.display);
			self.setOverflow(self.overflow);
			self.opacityType = self.getOpacityType();
			
			if(self.opacityType == "opacity") self.isHtml5_bl = true;
			
			if(self.opacityType == "filter") self.screen.style.filter = "inherit";
			self.screen.style.left = "0px";
			self.screen.style.top = "0px";
			self.screen.style.margin = "0px";
			self.screen.style.padding = "0px";
			self.screen.style.maxWidth = "none";
			self.screen.style.maxHeight = "none";
			self.screen.style.border = "none";
			self.screen.style.lineHeight = "1";
			self.screen.style.backgroundColor = "transparent";
			self.screen.style.backfaceVisibility = "hidden";
			self.screen.style.webkitBackfaceVisibility = "hidden";
			self.screen.style.MozBackfaceVisibility = "hidden";	
			
			if(type == "img"){
				self.setWidth(self.screen.width);
				self.setHeight(self.screen.height);
			}
		};
			
		self.setBackfaceVisibility =  function(){
			self.screen.style.backfaceVisibility = "visible";
			self.screen.style.webkitBackfaceVisibility = "visible";
			self.screen.style.MozBackfaceVisibility = "visible";		
		};
		
		//###################################################//
		/* set / get various peoperties.*/
		//###################################################//
		self.setSelectable = function(val){
			if(!val){
				self.screen.style.userSelect = "none";
				self.screen.style.MozUserSelect = "none";
				self.screen.style.webkitUserSelect = "none";
				self.screen.style.khtmlUserSelect = "none";
				self.screen.style.oUserSelect = "none";
				self.screen.style.msUserSelect = "none";
				self.screen.msUserSelect = "none";
				self.screen.ondragstart = function(e){return false;};
				self.screen.onselectstart = function(){return false;};
				self.screen.ontouchstart = function(){return false;};
				self.screen.style.webkitTouchCallout='none';
				self.hasBeenSetSelectable_bl = true;
			}
		};
		
		self.getScreen = function(){
			return self.screen;
		};
		
		self.setVisible = function(val){
			self.visible = val;
			if(self.visible == true){
				self.screen.style.visibility = "visible";
			}else{
				self.screen.style.visibility = "hidden";
			}
		};
		
		self.getVisible = function(){
			return self.visible;
		};
			
		self.setResizableSizeAfterParent = function(){
			self.screen.style.width = "100%";
			self.screen.style.height = "100%";
		};
		
		self.getStyle = function(){
			return self.screen.style;
		};
		
		self.setOverflow = function(val){
			self.overflow = val;
			self.screen.style.overflow = self.overflow;
		};
		
		self.setPosition = function(val){
			self.position = val;
			self.screen.style.position = self.position;
		};
		
		self.setDisplay = function(val){
			self.display = val;
			self.screen.style.display = self.display;
		};
		
		self.setButtonMode = function(val){
			self.buttonMode = val;
			if(self.buttonMode ==  true){
				self.screen.style.cursor = "pointer";
			}else{
				self.screen.style.cursor = "default";
			}
		};
		
		self.setBkColor = function(val){
			self.screen.style.backgroundColor = val;
		};
		
		self.setInnerHTML = function(val){
			self.innerHTML = val;
			self.screen.innerHTML = self.innerHTML;
		};
		
		self.getInnerHTML = function(){
			return self.innerHTML;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.setAlpha = function(val){
			self.alpha = val;
			if(self.opacityType == "opacity"){
				self.screen.style.opacity = self.alpha;
			}else if(self.opacityType == "filter"){
				self.screen.style.filter = "alpha(opacity=" + self.alpha * 100 + ")";
				self.screen.style.filter = "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + Math.round(self.alpha * 100) + ")";
			}
		};
		
		self.getAlpha = function(){
			return self.alpha;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.getGlobalX = function(){
			return self.getRect().left;
		};
		
		self.getGlobalY = function(){
			return self.getRect().top;
		};
		
		self.setX = function(val){
			self.x = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0)';
			}else if(self.hasTransform2d_bl){
				self.screen.style[self.transform] = 'translate(' + self.x + 'px,' + self.y + 'px)';
			}else{
				self.screen.style.left = self.x + "px";
			}
		};
		
		self.getX = function(){
			return  self.x;
		};
		
		self.setY = function(val){
			self.y = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0)';	
			}else if(self.hasTransform2d_bl){
				self.screen.style[self.transform] = 'translate(' + self.x + 'px,' + self.y + 'px)';
			}else{
				self.screen.style.top = self.y + "px";
			}
		};
		
		self.getY = function(){
			return  self.y;
		};
		
		self.setWidth = function(val){
			self.w = val;
			if(self.type == "img"){
				self.screen.width = self.w;
			}else{
				self.screen.style.width = self.w + "px";
			}
		};
		
		self.getWidth = function(){
			if(self.type == "div"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}else if(self.type == "img"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				if(self.screen.width != 0) return  self.screen.width;
				return self._w;
			}else if( self.type == "canvas"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}
		};
		
		self.setHeight = function(val){
			self.h = val;
			if(self.type == "img"){
				self.screen.height = self.h;
			}else{
				self.screen.style.height = self.h + "px";
			}
		};
		
		self.getHeight = function(){
			if(self.type == "div"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}else if(self.type == "img"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				if(self.screen.height != 0) return  self.screen.height;
				return self.h;
			}else if(self.type == "canvas"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}
		};
		
		//#####################################//
		/* DOM list */
		//#####################################//
		self.addChild = function(e){
			if(self.contains(e)){	
				self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 1);
				self.children_ar.push(e);
				self.screen.appendChild(e.screen);
			}else{
				self.children_ar.push(e);
				self.screen.appendChild(e.screen);
			}
		};
		
		self.removeChild = function(e){
			if(self.contains(e)){
				self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 1);
				self.screen.removeChild(e.screen);
			}else{
				//console.log(arguments.callee.caller.toString())
				throw Error("##removeChild()## Child dose't exist, it can't be removed!");
			};
		};
		
		self.contains = function(e){
			if(FWDUtils.indexOfArray(self.children_ar, e) == -1){
				return false;
			}else{
				return true;
			}
		};
		
		self.addChildAt = function(e, index){
			if(self.getNumChildren() == 0){
				self.children_ar.push(e);
				self.screen.appendChild(e.screen);
			}else if(index == 1){
				self.screen.insertBefore(e.screen, self.children_ar[0].screen);
				self.screen.insertBefore(self.children_ar[0].screen, e.screen);	
				if(self.contains(e)){
					self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 1, e);
				}else{
					self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 0, e);
				}
			}else{
				if(index < 0  || index > self.getNumChildren() -1) throw Error("##getChildAt()## Index out of bounds!");
				
				self.screen.insertBefore(e.screen, self.children_ar[index].screen);
				if(self.contains(e)){
					self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 1, e);
				}else{
					self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 0, e);
				}
			}
		};
		
		self.getChildAt = function(index){
			if(index < 0  || index > self.getNumChildren() -1) throw Error("##getChildAt()## Index out of bounds!");
			if(self.getNumChildren() == 0) throw Errror("##getChildAt## Child dose not exist!");
			return self.children_ar[index];
		};
		
		self.removeChildAtZero = function(){
			self.screen.removeChild(self.children_ar[0].screen);
			self.children_ar.shift();
		};
		
		self.getNumChildren = function(){
			return self.children_ar.length;
		};
		
		
		//################################//
		/* event dispatcher */
		//#################################//
		self.addListener = function (type, listener){
	    	
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	if(typeof listener != "function") throw Error("listener must be of type Function.");
	    	
	    	
	        var event = {};
	        event.type = type;
	        event.listener = listener;
	        event.target = this;
	        this.listeners.events_ar.push(event);
	    };
	    
	    self.dispatchEvent = function(type, props){
	    	if(this.listeners == null) return;
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	
	        for (var i=0, len=this.listeners.events_ar.length; i < len; i++){
	        	if(this.listeners.events_ar[i].target === this && this.listeners.events_ar[i].type === type){		
	    	        if(props){
	    	        	for(var prop in props){
	    	        		this.listeners.events_ar[i][prop] = props[prop];
	    	        	}
	    	        }
	        		this.listeners.events_ar[i].listener.call(this, this.listeners.events_ar[i]);
	        	}
	        }
	    };
	    
	    self.removeListener = function(type, listener){
	    	
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	if(typeof listener != "function") throw Error("listener must be of type Function." + type);
	    	
	        for (var i=0, len=this.listeners.events_ar.length; i < len; i++){
	        	if(this.listeners.events_ar[i].target === this 
	        			&& this.listeners.events_ar[i].type === type
	        			&& this.listeners.events_ar[i].listener ===  listener
	        	){
	        		this.listeners.events_ar.splice(i,1);
	        		break;
	        	}
	        }  
	    };
	    
	    //###########################################//
	    /* destroy methods*/
	    //###########################################//
		self.disposeImage = function(){
			if(self.type == "img") self.screen.src = null;
		};
		
		
		self.destroy = function(){
			
			//try{self.screen.parentNode.removeChild(self.screen);}catch(e){};
			
			if(self.hasBeenSetSelectable_bl){
				self.screen.ondragstart = null;
				self.screen.onselectstart = null;
				self.screen.ontouchstart = null;
			};
			
			//destroy properties
			self.listeners = [];
			self.listeners = null;
			self.children_ar = [];
			self.children_ar = null;
			self.style = null;
			self.screen = null;
			self.transform = null;
			self.position = null;
			self.overflow = null;
			self.display = null;
			self.visible = null;
			self.buttonMode = null;
			self.x = null;
			self.y = null;
			self.w = null;
			self.h = null;
			self.rect = null;
			self.alpha = null;
			self.innerHTML = null;
			self.opacityType = null;
			self.isHtml5_bl = null;
		
			self.hasTransform3d_bl = null;
			self.hasTransform2d_bl = null;
			self = null;
		};
		
	    /* init */
		self.init();
	};
	
	window.FWDDisplayObject = FWDDisplayObject;
}(window));(function (){
	
	var FWDEventDispatcher = function (){
		
	    this.listeners = {events_ar:[]};
	     
	    this.addListener = function (type, listener){
	    	
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	if(typeof listener != "function") throw Error("listener must be of type Function.");
	    	
	    	
	        var event = {};
	        event.type = type;
	        event.listener = listener;
	        event.target = this;
	        this.listeners.events_ar.push(event);
	    };
	    
	    this.dispatchEvent = function(type, props){
	    	if(this.listeners == null) return;
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	
	        for (var i=0, len=this.listeners.events_ar.length; i < len; i++){
	        	if(this.listeners.events_ar[i].target === this && this.listeners.events_ar[i].type === type){		
	    	        if(props){
	    	        	for(var prop in props){
	    	        		this.listeners.events_ar[i][prop] = props[prop];
	    	        	}
	    	        }
	        		this.listeners.events_ar[i].listener.call(this, this.listeners.events_ar[i]);
	        	}
	        }
	    };
	    
	   this.removeListener = function(type, listener){
	    	
	    	if(type == undefined) throw Error("type is required.");
	    	if(typeof type === "object") throw Error("type must be of type String.");
	    	if(typeof listener != "function") throw Error("listener must be of type Function." + type);
	    	
	        for (var i=0, len=this.listeners.events_ar.length; i < len; i++){
	        	if(this.listeners.events_ar[i].target === this 
	        			&& this.listeners.events_ar[i].type === type
	        			&& this.listeners.events_ar[i].listener ===  listener
	        	){
	        		this.listeners.events_ar.splice(i,1);
	        		break;
	        	}
	        }  
	    };
	    
	    /* destroy */
	    this.destroy = function(){
	    	this.listeners = null;
	    	
	    	this.addListener = null;
		    this.dispatchEvent = null;
		    this.removeListener = null;
	    };
	    
	};	
	
	window.FWDEventDispatcher = FWDEventDispatcher;
}(window));/* hider */
(function (window){
	
    var FWDHider = function(isMobile_bl, screenToTest, hideDelay){
    	
    	var self = this;
    	var prototype = FWDHider.prototype;
   
    	this.screenToTest = screenToTest;
    	this.hideDelay = hideDelay;
    	this.globalX = 0;
    	this.globalY = 0;
	
		this.currentTime;
    	this.checkIntervalId_int;
    	
    	this.dispatchOnceShow_bl = true;
    	this.dispatchOnceHide_bl = false;
    	this.isMobile_bl = isMobile_bl;
    	this.isStopped_bl = true;
    	this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
    	
		self.init = function(){};
	
		self.start = function(){
			self.currentTime = new Date().getTime();
			self.checkIntervalId_int = setInterval(self.update, 100);
			self.addMouseOrTouchCheck();
			self.isStopped_bl = false;
		};
		
		self.stop = function(){
			clearInterval(self.checkIntervalId_int);
			self.isStopped_bl = true;
			self.removeMouseOrTouchCheck();
		};
		
		self.addMouseOrTouchCheck = function(){	
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screenToTest.screen.addEventListener("MSPointerDown", self.onMouseOrTouchUpdate);
					self.screenToTest.screen.addEventListener("MSPointerMove", self.onMouseOrTouchUpdate);
				}else{
					self.screenToTest.screen.addEventListener("touchstart", self.onMouseOrTouchUpdate);
				}
			}else if(self.screenToTest.screen.addEventListener){
				self.screenToTest.screen.addEventListener("mousemove", self.onMouseOrTouchUpdate);
			}else if(self.screenToTest.screen.attachEvent){
				self.screenToTest.screen.attachEvent("onmousemove", self.onMouseOrTouchUpdate);
			}
		};
		
		self.removeMouseOrTouchCheck = function(){	
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screenToTest.screen.removeEventListener("MSPointerDown", self.onMouseOrTouchUpdate);
					self.screenToTest.screen.removeEventListener("MSPointerMove", self.onMouseOrTouchUpdate);
				}else{
					self.screenToTest.screen.removeEventListener("touchstart", self.onMouseOrTouchUpdate);
				}
			}else if(self.screenToTest.screen.removeEventListener){
				self.screenToTest.screen.removeEventListener("mousemove", self.onMouseOrTouchUpdate);
			}else if(self.screenToTest.screen.detachEvent){
				self.screenToTest.screen.detachEvent("onmousemove", self.onMouseOrTouchUpdate);
			}
		};
		
		self.onMouseOrTouchUpdate = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			if(self.globalX == viewportMouseCoordinates.screenX && self.globalY == viewportMouseCoordinates.screenY) return
			self.currentTime = new Date().getTime();
			self.globalX = viewportMouseCoordinates.screenX;
			self.globalY = viewportMouseCoordinates.screenY;
		};
	
		self.update = function(e){
			if(new Date().getTime() > self.currentTime + self.hideDelay){
				if(self.dispatchOnceShow_bl){	
					self.dispatchEvent(FWDHider.HIDE);
					self.dispatchOnceHide_bl = true;
					self.dispatchOnceShow_bl = false;	
				}
			}else{
				if(self.dispatchOnceHide_bl){
					self.dispatchEvent(FWDHider.SHOW);
					self.dispatchOnceHide_bl = false;
					self.dispatchOnceShow_bl = true;
				}
			}
		};

		self.reset = function(){
			self.currentTime = new Date().getTime();
			self.dispatchEvent(FWDHider.SHOW);
		};
		
		/* destroy */
		self.destroy = function(){
		
			self.removeMouseOrTouchCheck();
			clearInterval(self.checkIntervalId_int);
			
			self.screenToTest = null;
			
			screenToTest = null;
			
			self.init = null;
			self.start = null;
			self.stop = null;
			self.addMouseOrTouchCheck = null;
			self.removeMouseOrTouchCheck = null;
			self.onMouseOrTouchUpdate = null;
			self.update = null;
			self.reset = null;
			self.destroy = null;
			
			prototype.destroy();
			prototype = null;
			self = null;
			FWDHider.prototype = null;
		};
		
		self.init();
     };
     
	 FWDHider.HIDE = "hide";
	 FWDHider.SHOW = "show";
	 
	 FWDHider.setPrototype = function(){
		 FWDHider.prototype = new FWDEventDispatcher();
	 };
	 

	 window.FWDHider = FWDHider;
}(window));/* Image manager */
(function (){
	
	var FWDImageManager = function(data, parent){
		
		var self = this;
		var prototype = FWDImageManager.prototype;
		
		this.toolTipLeft_img = data.toolTipLeft_img;
		this.toolTipPointer_img = data.toolTipPointer_img;
		
		this.playListData_ar = data.playListData_ar;
		this.images_ar = data.images_ar;
		this.smallDos_ar = [];
		this.markers_ar = [];
		this.markersList_ar = data.markersList_ar;
		this.markersPosition_ar = data.markersPosition_ar;
		this.largeImagesPaths_ar = data.largeImagesPaths_ar;
		
		this.curMarker_do;
		this.markersToolTip_do;
		this.markersToolTipWindow_do;
		this.hider;
		this.prevSmall_sdo;
		this.largeImage_img;
		this.dumy_sdo;
		this.mainImagesHolder_do;
		this.smallImage_sdo;
		this.largeImage_sdo;
		this.left_sdo;
		this.top_sdo;
		this.right_sdo;
		this.bottom_sdo;
		this.markersPositionInfo_sdo;
		
		this.handMovePath_str =  data.handMovePath_str;
		
		this.backgroundColor_str = parent.backgroundColor_str;
		this.draggingMode_str = data.startDraggingMode_str;
		this.controllerPosition_str = data.controllerPosition_str;
		this.buttonToolTipLeft_str = data.buttonToolTipLeft_str;
		this.buttonToolTipMiddle_str = data.buttonToolTipMiddle_str;
		this.buttonToolTipRight_str = data.buttonToolTipRight_str;
		this.buttonToolTipFontColor_str = data.buttonToolTipFontColor_str;
		this.buttonToolTipBottomPointer_str = data.buttonToolTipBottomPointer_str;
		this.buttonToolTipTopPointer_str = data.buttonToolTipTopPointer_str;
		this.lastMarkerId_str;
		this.swipeDirection_str;
		
		this.curId = data.startAtImage;
		this.prevId = 1000;
		this.curLargeImageId = 1000;
		this.totalImages = data.totalImages;
		this.stageWidth;
		this.stageHeight;
		this.smallestPossibleScale;
		this.currentScale = 1;
		this.prevScale = 0;
		this.percentZoomed = 0.1;
		this.imageWidth = data.imageWidth;
		this.imageHeight = data.imageHeight;
		this.zoomFactor = data.zoomFactor;
		this.zoomSpeed = .1;
		this.finalX = 0;
		this.finalY = 0;
		this.xPositionOnPress;
		this.yPositionOnPress;
		this.lastPresedX = 0;
		this.lastPresedY = 0;
		this.lastPresedX2 = 0;
		this.lastPresedY2 = 0;
		this.mouseX = 0;
		this.mouseY = 0;
		this.controllerHeight = data.controllerHeight;
		this.rotationSpeed = Math.abs(-1.1 + data.dragRotationSpeed);
		this.startScaleForMobileZoom;
		this.totalMarkers;
		this.globalX;
		this.globalY;
		this.markerToolTipOffsetY = data.markerToolTipOffsetY;
		this.toolTipWindowMaxWidth = data.toolTipWindowMaxWidth;
		this.swipeDragDist = 0;
		this.currentDist = 0;
		this.spinDist = 10;
		this.dragAndSpinSpeed = data.dragAndSpinSpeed;
		
		this.tweenDone_to;
		this.removeSmallSDOId_to;
		this.setAlphaWithDelayId_to;
		this.hideToolTipWindowId_to;
		this.addHideToolTipWindowTestWithDelayId_to;
		this.showToolTipWindoId_to;
		this.showMarkerToolTipId_to;
		this.dragAndSpinId_int;
		
		this.allImagesAreLoaded_bl = false;
		this.allowToDragHoriz_bl = false;
		this.allowToDragVert_bl = false;
		this.isTweening_bl = false;
		this.isDragging_bl = false;
		this.isRotatingFirstTime_bl = true;
		this.addCorrectionForWebKit_bl = data.addCorrectionForWebKit_bl;
		this.disablePanOrRotate_bl = false;
		this.useEntireScreenFor3dObject_bl = data.useEntireScreenFor3dObject_bl;
		this.stopRotationAtEnds_bl = data.stopRotationAtEnds_bl;
		this.isMobile_bl = data.isMobile_bl;
		this.isLargeImageLoaded_bl = false;
		this.showNavigator_bl = data.showNavigator_bl;
		this.showMarkers_bl = data.showMarkers_bl;
		this.isNavigatorShowed_bl = false;
		this.addImageFirstTimeOnActivate_bl = true;
		this.showMarkersInfo_bl = data.showMarkersInfo_bl;
		this.addDragAndSpinSupport_bl = data.addDragAndSpinSupport_bl;
		this.isMobile_bl = data.isMobile_bl;
		this.firstInteractionOccured_bl = false;
		this.isSwiping_bl = false;
		this.showLargeImageVersionOnZoom_bl = data.showLargeImageVersionOnZoom_bl;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		
		self.init = function(){
			if(self.controllerPosition_str == FWDController.POSITION_TOP && !self.useEntireScreenFor3dObject_bl) self.setY(self.controllerHeight);
			self.setupMainContiners();
			self.setupDumy();
			
			if(self.showMarkers_bl){
				self.setupMarkers();
				if(!self.isMobile_bl || self.hasPointerEvent_bl) self.setupMarkersToolTip();
				self.setupMarkersToolTipWindow();
			}
		};
		
		//##########################################//
		//Setup hider.
		//##########################################//
		self.setupHider = function(hider){
			self.hider = hider;
		};
		
		//###########################################//
		//Setup main containers
		//###########################################//
		self.setupMainContiners = function(){
			self.setOverflow("visible");
			self.setBkColor(self.backgroundColor_str);
			self.largeImage_img = new Image();
		
			self.mainImagesHolder_do =  new FWDDisplayObject("div", "absolute", "visible");
			self.smallImage_sdo = new FWDSimpleDisplayObject("img");
			self.largeImage_sdo = new FWDSimpleDisplayObject("img");
			self.addChild(self.mainImagesHolder_do);
			
			if(self.addCorrectionForWebKit_bl) self.setupCorrectionLinesForChrome();
		};
		
		
		
		//###########################################//
		//Setup correction lines for chrome.
		//###########################################//
		self.setupCorrectionLinesForChrome = function(){
			
			self.left_sdo = new FWDSimpleDisplayObject("div");
			self.top_sdo = new FWDSimpleDisplayObject("div");
			self.right_sdo = new FWDSimpleDisplayObject("div");
			self.bottom_sdo = new FWDSimpleDisplayObject("div");
			
			self.left_sdo.setBkColor(self.backgroundColor_str);
			self.top_sdo.setBkColor(self.backgroundColor_str);
			self.right_sdo.setBkColor(self.backgroundColor_str);
			self.bottom_sdo.setBkColor(self.backgroundColor_str);
			
			self.left_sdo.setWidth(1);
			self.top_sdo.setHeight(1);
			self.right_sdo.setWidth(2);
			self.bottom_sdo.setHeight(2);
			
			self.addChild(self.left_sdo);
			self.addChild(self.top_sdo);
			self.addChild(self.right_sdo);
			self.addChild(self.bottom_sdo);
		};
		
		self.resizeAndPositionCorrectionLines = function(animate){
		
			TweenMax.killTweensOf(self.left_sdo);
			TweenMax.killTweensOf(self.top_sdo);
			TweenMax.killTweensOf(self.right_sdo);
			TweenMax.killTweensOf(self.bottom_sdo);
		
			if(animate){
				TweenMax.to(self.left_sdo, .2, {x:self.finalX, y:self.finalY, h:self.finalHeight});
				TweenMax.to(self.top_sdo, .2, {x:self.finalX, y:self.finalY, w:self.finalWidth});
				TweenMax.to(self.right_sdo, .2, {x:self.finalX + self.finalWidth - 2, y:self.finalY, h:self.finalHeight});
				TweenMax.to(self.bottom_sdo, .2, {x:self.finalX, y:self.finalY  + self.finalHeight - 2, w:self.finalWidth});
			}else{
				self.left_sdo.setX(self.finalX - 1);
				self.left_sdo.setY(self.finalY);
				self.left_sdo.setHeight(self.finalHeight);
				
				self.top_sdo.setX(self.finalX);
				self.top_sdo.setY(self.finalY - 1);
				self.top_sdo.setWidth(self.finalWidth);
				
				self.right_sdo.setX(self.finalX + self.finalWidth - 2);
				self.right_sdo.setY(self.finalY);
				self.right_sdo.setHeight(self.finalHeight);
				
				self.bottom_sdo.setX(self.finalX);
				self.bottom_sdo.setY(self.finalY  + self.finalHeight - 2);
				self.bottom_sdo.setWidth(self.finalWidth);
			}
		};
		
		//###########################################//
		// Resize and position self...
		//###########################################//
		self.resizeAndPosition = function(centerImage_bl){
			
			if(self.stageWidth == parent.stageWidth && self.stageHeight == parent.stageHeight - self.controllerHeight) return;
			
			self.stageWidth = parent.stageWidth;
			if(self.useEntireScreenFor3dObject_bl){
				self.stageHeight = parent.stageHeight;
			}else{
				self.stageHeight = parent.stageHeight - self.controllerHeight;
			}
			
			self.setWidth(self.stageWidth);
			self.setHeight(self.stageHeight);
			
			if(self.allImagesAreLoaded_bl){
				self.resizeAndPositionAfterAllLoad();
				if(centerImage_bl) self.centerImage();
				if(self.showNavigator_bl){
					self.hideOrShowNavigator();
					self.updateNavigator(false);
				}
				
				self.positionMarkers();
			}else{
				self.resiezeAndPositionIfNotAllImagesAreLoaded();
			}
		};
		
		self.resiezeAndPositionIfNotAllImagesAreLoaded = function(){
			var scX = self.stageWidth/self.imageWidth;
			var scY = self.stageHeight/self.imageHeight;
			var totalScale;
			
			if(scX < scY){
				totalScale = scX;
			}else{
				totalScale = scY;
			}

			if(totalScale > 1) totalScale = 1;
			
			self.currentScale = self.prevScale = self.smallestPossibleScale = totalScale;
			
			self.finalWidth = Math.round(self.currentScale * self.imageWidth);
			self.finalHeight = Math.round(self.currentScale * self.imageHeight);
			self.finalX =  Math.round((self.stageWidth - self.finalWidth)/2);
			self.finalY =  Math.round((self.stageHeight - self.finalHeight)/2);	
			self.resizeAndPositionSmallImage(false);
		};
		
		//#################################################//
		//Show images while they are loaded
		//#################################################//
		self.showLoadedImage = function(id){
			self.smallImage_sdo = new FWDSimpleDisplayObject("img");
			self.smallImage_sdo.setScreen(self.images_ar[id]);
			if(FWDUtils.isAndroid) self.smallImage_sdo.setBackfaceVisibility();
			self.smallDos_ar[id] = self.smallImage_sdo;
			self.mainImagesHolder_do.addChild(self.smallImage_sdo);
			
			self.removeSmallSDOId_to = setTimeout(function(){
						if(self == null) return; 
						if(id > 0) self.smallDos_ar[id - 1].setVisible(false);
					}
				, 40);
			self.resizeAndPosition();
			self.resiezeAndPositionIfNotAllImagesAreLoaded();
			
		};
		
		//##############################################################################################//
		//initlaize this after all iamges are loaded...
		//##############################################################################################//
		self.activate = function(){
			self.allImagesAreLoaded_bl = true;
			self.addSmallImage();
			self.addLargeImage();
			self.resizeAndPositionAfterAllLoad();
			self.addPannSupport();
			self.addRotationSupport();
			self.addPinchSupport();
			self.addMouseWheelSupport();
			self.showOrHideMarkers();
			self.positionMarkers(false);
			if(self.showMarkersInfo_bl) self.setupMarkersInfo();
		};
		
		//################################################//
		/* setup dumy */
		//################################################//
		self.setupDumy = function(){
			self.dumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE) self.dumy_sdo.getStyle().background = "url('dumy')";
			if(!self.showMarkersInfo_bl) self.dumy_sdo.getStyle().cursor = 'url(' + self.handMovePath_str + '), default';
			self.addChild(self.dumy_sdo);
		};
		
		//################################################//
		//add small and large image.
		//################################################//
		self.addSmallImage = function(){
			if(self.curId == self.prevId) return;
			self.prevId = self.curId;
			self.curLargeImageId = 1000;
			
			if(self.addImageFirstTimeOnActivate_bl){
				self.removeSmallSDOId_to = setTimeout(function(){
						if(self == null) return;
						self.smallImage_sdo.setVisible(false);
						self.smallImage_sdo = self.smallDos_ar[self.curId];
						self.smallImage_sdo.setVisible(true);
						self.resizeAndPositionAfterAllLoad();
					}
				, 40);
			}
			
			clearTimeout(self.setAlphaWithDelayId_to);
			
			if(self.largeImage_img){
				self.largeImage_img.onload = null;
				self.largeImage_img.onerror = null;
				if(!FWDUtils.isIEAndLessThen9) self.largeImage_img.src = null;
			}
			
			if(self.mainImagesHolder_do.contains(self.largeImage_sdo)) self.mainImagesHolder_do.removeChild(self.largeImage_sdo);
			
			if(!self.addImageFirstTimeOnActivate_bl){
				self.smallImage_sdo.setVisible(false);
				self.smallImage_sdo = self.smallDos_ar[self.curId];
				self.smallImage_sdo.setVisible(true);
			}
			self.addImageFirstTimeOnActivate_bl = false;
		};
		
		self.removeWithDelay = function(){
			while(self.mainImagesHolder_do.getNumChildren() > 1){
				self.mainImagesHolder_do.removeChildAtZero(0);
			}
		};
		
		self.addLargeImage = function(){	
			if(!self.showLargeImageVersionOnZoom_bl) return;
			if(self.currentScale <= 1) return;
			if(self.curLargeImageId ==  self.curId) return;
			self.isLargeImageLoaded_bl = false;
			self.curLargeImageId = self.curId;
			clearTimeout(self.setAlphaWithDelayId_to);
			
			if(self.mainImagesHolder_do.contains(self.largeImage_sdo)) self.mainImagesHolder_do.removeChild(self.largeImage_sdo);
			
			if(self.largeImage_img){	
				self.largeImage_img.onload = null;
				self.largeImage_img.onerror = null;
				if(!FWDUtils.isIEAndLessThen9) self.largeImage_img.src = null;
			}
			
			self.largeImage_img.src = self.largeImagesPaths_ar[self.curId];
			self.largeImage_img.onload = self.largeImageLoadHandler;
			self.largeImage_img.onerror = self.largeImageErrorHandler;
			self.largeImage_sdo.setScreen(self.largeImage_img);
			self.largeImage_sdo.setAlpha(0);
			self.mainImagesHolder_do.addChild(self.largeImage_sdo);
		};
		
		self.largeImageErrorHandler = function(){
			var error = "The large image labeled <font color='#FFFFFF'>" + self.largeImagesPaths_ar[self.curId] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			self.dispatchEvent(FWDImageManager.LARGE_IMAGE_LOAD_ERROR, {error:error});
		};
		
		self.largeImageLoadHandler = function(){
			self.isLargeImageLoaded_bl = true;
			self.setAlphaWithDelayId_to = setTimeout(function(){
				//self.smallImage_sdo.setVisible(false);
				self.largeImage_sdo.setAlpha(1);
			}, 100);
			self.largeImage_sdo.setWidth(self.finalWidth);
			self.largeImage_sdo.setHeight(self.finalHeight);
		};
		
		self.gotoImage = function(){
			if(self.stopRotationAtEnds_bl){
				if(self.curId < 0){
					self.curId = 0;
				}else if(self.curId > self.totalImages - 1){
					self.curId = self.totalImages - 1;
				}
			}else{
				if(self.curId > self.totalImages - 1){
					self.curId = 0;
				}else if(self.curId < 0){
					self.curId = self.totalImages - 1;
				}
			}
				
			
			self.addSmallImage();
			self.resizeAndPositionAfterAllLoad();
			if(!self.isSwiping_bl){
				self.showOrHideMarkers();
				self.positionMarkers();
			}
			self.dispatchEvent(FWDImageManager.ROTATE_UPDATE, {id:self.curId});
		};
		
		//###################################################//
		// resize handler after all images are loaded
		//##################################################//
		self.resizeAndPositionAfterAllLoad = function(){
			var scX = self.stageWidth/self.imageWidth;
			var scY = self.stageHeight/self.imageHeight;
			var totalScale;
			
			if(scX < scY){
				totalScale = scX;
			}else{
				totalScale = scY;
			}

			self.smallestPossibleScale = totalScale;
		
			if(totalScale >= 1) self.smallestPossibleScale  = 1;
			
			if(self.currentScale <= 1 ){
				if(scX > scY  && self.finalHeight <= self.stageHeight){
					 self.currentScale = self.smallestPossibleScale;
				}else if(scX < scY  && self.finalWidth <= self.stageWidth){
					 self.currentScale = self.smallestPossibleScale;
				}
			}
			
			self.finalWidth = Math.round(self.currentScale * self.imageWidth);
			self.finalHeight = Math.round(self.currentScale * self.imageHeight);
			
			
			self.setWidth(self.stageWidth);
			self.dumy_sdo.setWidth(self.stageWidth);
			if(self.useEntireScreenFor3dObject_bl){
				self.setHeight(self.stageHeight);
				self.dumy_sdo.setHeight(self.stageHeight);
			}else{
				self.setHeight(self.stageHeight + self.controllerHeight);
				self.dumy_sdo.setHeight(self.stageHeight + self.controllerHeight);
			}
		
			self.checkXAndYBouds();
			self.resizeAndPositionSmallImage(false);
			self.resizeAndPositionLargeImage(false);
			if(self.addCorrectionForWebKit_bl) self.resizeAndPositionCorrectionLines(false);
			self.dispatchScrollBarUpdate(false);
			//self.positionMarkers();
		};
		
		//###############################################//
		//resize and position small image and large image.
		//###############################################//
		self.resizeAndPositionSmallImage = function(animate){
			self.isTweening_bl = true;
			TweenMax.killTweensOf(self.mainImagesHolder_do);
			TweenMax.killTweensOf(self.smallImage_sdo);
			clearTimeout(self.tweenDone_to);
			if(animate){
				TweenMax.to(self.mainImagesHolder_do, .2, {x:self.finalX, y:self.finalY});
				TweenMax.to(self.smallImage_sdo, .2, {w:self.finalWidth, h:self.finalHeight});
				self.tweenDone_to = setTimeout(self.tweenDoneHandler, 200);
			}else{
				self.mainImagesHolder_do.setX(self.finalX);
				self.mainImagesHolder_do.setY(self.finalY);
				self.smallImage_sdo.setWidth(self.finalWidth);
				self.smallImage_sdo.setHeight(self.finalHeight);
				self.isTweening_bl = false;
				self.dispatchEvent(FWDImageManager.IMAGE_ZOOM_COMPLETE);
			}
		};
		
		self.resizeAndPositionLargeImage = function(animate){
			if(!self.showLargeImageVersionOnZoom_bl || !self.isLargeImageLoaded_bl) return;
			TweenMax.killTweensOf(self.largeImage_sdo);
			if(animate){
				TweenMax.to(self.largeImage_sdo, .2, {w:self.finalWidth, h:self.finalHeight});
			}else{
				self.largeImage_sdo.setWidth(self.finalWidth);
				self.largeImage_sdo.setHeight(self.finalHeight);
			}
		};
		
		self.tweenDoneHandler = function(){
			self.isTweening_bl = false;
			self.addLargeImage();
			self.resizeAndPositionLargeImage();
			self.dispatchEvent(FWDImageManager.IMAGE_ZOOM_COMPLETE);
		};
		
		//###############################################//
		/* check x and y position */
		//##############################################//
		self.checkXAndYBouds = function(){
			if(self.finalWidth <= self.stageWidth){
				self.finalX = Math.round((self.stageWidth - self.finalWidth)/2);
			}else if(self.finalWidth > self.stageWidth + 1){
				self.allowToDragHoriz_bl = true;	
				if(self.finalX > 0){
					self.finalX = 0;
				}else if(self.finalX <= self.stageWidth - self.finalWidth + 1){
					self.finalX = self.stageWidth - self.finalWidth + 1;
				}
			}else{
				self.allowToDragHoriz_bl = false;
			}
			
			if(self.finalHeight <= self.stageHeight ){
				self.finalY = Math.round((self.stageHeight - self.finalHeight)/2);
			}else if(self.finalHeight > self.stageHeight + 1){
				self.allowToDragVert_bl = true;
				if(self.finalY > 0){
					self.finalY = 0;
				}else if(self.finalY <= self.stageHeight - self.finalHeight){
					self.finalY = self.stageHeight - self.finalHeight;
				}
			}else{
				self.allowToDragVert_bl = false;
			}
		};
		
		//################################################//
		/* zoom image */
		//################################################//
		self.zoomImage = function(setPositionAndSize){
			
			if(setPositionAndSize){
				self.finalWidth = Math.round(self.currentScale * self.imageWidth);
				self.finalHeight =  Math.round(self.currentScale * self.imageHeight);
				self.finalX -= Math.round((self.mouseX - self.finalX) * (self.currentScale - self.prevScale) / self.prevScale); 
				self.finalY -= Math.round((self.mouseY - self.finalY) * (self.currentScale - self.prevScale) / self.prevScale); 	
			}
			
			self.dispatchScrollBarUpdate(true);
			self.checkXAndYBouds();
			self.resizeAndPositionSmallImage(true);
			self.resizeAndPositionLargeImage(true);
			if(self.addCorrectionForWebKit_bl) self.resizeAndPositionCorrectionLines(true);
			if(self.showNavigator_bl){
				self.hideOrShowNavigator();
				self.updateNavigator(true);
			}
			self.positionMarkers(true);
			self.prevScale = self.currentScale;
		};
			
		//###############################################//
		/* setup pinch */
		//###############################################//
		self.addPinchSupport = function(){
			if(self.screen.addEventListener){
				self.screen.addEventListener('gesturestart', this.gestureStartHandler);
				self.screen.addEventListener('gesturechange', this.gestureChangeHandler);
			}
		};
		
		self.gestureStartHandler = function(e){
			self.startScaleForMobileZoom = 1;
		};
		
		self.gestureChangeHandler = function(e){	
			e.preventDefault();	
			
			if(self.disablePanOrRotate_bl) return;
			var toAdd;
			
			if(e.scale > 1){
				toAdd = e.scale - self.startScaleForMobileZoom;
			}else{
				toAdd = - (self.startScaleForMobileZoom - e.scale);
			}
			
			self.startScaleForMobileZoom = 1;
			
			self.mouseX = Math.round(self.stageWidth/2);
			self.mouseY = Math.round(self.stageHeight/2);
			self.currentScale +=  toAdd;
			self.startScaleForMobileZoom = e.scale;
			
			if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))){
				self.currentScale = self.smallestPossibleScale;
			}else if(self.currentScale > self.zoomFactor){
				 self.currentScale = self.zoomFactor;
			}
			
			self.zoomImage(true);
		};
		
		//###############################################//
		//Add touch pann support
		//###############################################//
		self.addPannSupport = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.dumy_sdo.screen.addEventListener("MSPointerDown", self.panStartHandler);
				}else{
					self.dumy_sdo.screen.addEventListener("touchstart", self.panStartHandler);
				}
			}else if(self.screen.addEventListener){
				self.dumy_sdo.screen.addEventListener("mousedown", self.panStartHandler);
			}else if(self.screen.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousedown", self.panStartHandler);
			}
		};
		
		self.panStartHandler = function(e){
			if(self.draggingMode_str != FWDImageManager.PAN || self.isTweening_bl || self.disablePanOrRotate_bl) return;
			if(e.preventDefault) e.preventDefault();
			if(self.finalWidth < self.stageWidth && self.finalHeight < self.stageHeight) return;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.showPanDumy();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			self.isDragging_bl = true;
			self.xPositionOnPress = self.mainImagesHolder_do.getX();
			self.yPositionOnPress = self.mainImagesHolder_do.getY();
			self.lastPresedX = viewportMouseCoordinates.screenX;
			self.lastPresedY = viewportMouseCoordinates.screenY;
			
			self.dispatchEvent(FWDImageManager.PAN_START);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.panMoveHandler);
					window.addEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.addEventListener("touchmove", self.panMoveHandler);
					window.addEventListener("touchend", self.panEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.panMoveHandler);
					window.addEventListener("mouseup", self.panEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.panMoveHandler);
					document.attachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		self.panMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(e.touches && e.touches.length != 1 || self.disablePanOrRotate_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
		
			if(self.finalWidth > self.stageWidth + 1){
				self.finalX = Math.round(self.xPositionOnPress + viewportMouseCoordinates.screenX - self.lastPresedX);
				if(self.finalX > 0){
					self.finalX = 0;
				}else if(self.finalX <= self.stageWidth - self.finalWidth + 1){
					self.finalX = self.stageWidth - self.finalWidth + 1;
				}
				self.mainImagesHolder_do.setX(self.finalX);
			}
			
			if(self.finalHeight > self.stageHeight + 1){
				self.finalY = Math.round(self.yPositionOnPress + viewportMouseCoordinates.screenY - self.lastPresedY);
				if(self.finalY > 0){
					self.finalY = 0;
				}else if(self.finalY <= self.stageHeight - self.finalHeight){
					self.finalY = self.stageHeight - self.finalHeight;
				}
				self.mainImagesHolder_do.setY(self.finalY);
			}
			
			if(self.showNavigator_bl){
				self.hideOrShowNavigator();
				self.updateNavigator(false);
			}
			
			self.positionMarkers(false);
		};
		
		self.panEndHandler = function(e){
			self.isDragging_bl = false;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.hidePanDumy();
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.panMoveHandler);
					window.removeEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.removeEventListener("touchmove", self.panMoveHandler);
					window.removeEventListener("touchend", self.panEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.panMoveHandler);
					window.removeEventListener("mouseup", self.panEndHandler);	
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.panMoveHandler);
					document.detachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		//###################################################//
		//Rotate image.
		//###################################################//
		self.addRotationSupport = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.dumy_sdo.screen.addEventListener("MSPointerDown", self.rotateStartHandler);
				}else{
					self.dumy_sdo.screen.addEventListener("touchstart", self.rotateStartHandler);
				}
			}else if(self.screen.addEventListener){
				self.dumy_sdo.screen.addEventListener("mousedown", self.rotateStartHandler);
			}else if(self.screen.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousedown", self.rotateStartHandler);
			}
		};
		
		self.rotateStartHandler = function(e){
			if(self.draggingMode_str != FWDImageManager.ROTATE || self.isTweening_bl || self.disablePanOrRotate_bl) return;
			clearInterval(self.dragAndSpinId_int);
			if(e.preventDefault) e.preventDefault();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			self.isDragging_bl = true;
			self.isSwiping_bl = false;
			if(self.markersToolTipWindow_do) self.markersToolTipWindow_do.hide();
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.showRotateDumy();
			self.currentDist = self.lastPresedX = viewportMouseCoordinates.screenX;
			self.showOrHideMarkers();
			self.positionMarkers();
			self.dispatchEvent(FWDImageManager.ROTATE_START);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.rotateMoveHandler);
					window.addEventListener("MSPointerUp", self.rotateEndHandler);
				}else{
					window.addEventListener("touchmove", self.rotateMoveHandler);
					window.addEventListener("touchend", self.rotateEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.rotateMoveHandler);
					window.addEventListener("mouseup", self.rotateEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.rotateMoveHandler);
					document.attachEvent("onmouseup", self.rotateEndHandler);
				}
			}
		};
		
		self.rotateMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if((e.touches && e.touches.length != 1) || self.disablePanOrRotate_bl) return;
			
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			var dif = (viewportMouseCoordinates.screenX - self.lastPresedX)/(80 * self.rotationSpeed); 
			
			self.swipeDragDist = viewportMouseCoordinates.screenX - self.currentDist;
			self.currentDist = viewportMouseCoordinates.screenX;
			
			if(self.isRotatingFirstTime_bl){
				if(dif > 0){
					if(dif != 0) dif = -1;
				}else{
					if(dif != 0) dif = 1;
				}
				self.curId += dif;
				self.gotoImage();
				self.isRotatingFirstTime_bl = false;
				return;
			}
			
			if(Math.abs(dif) >= 1){
				if(dif > 0){
					self.lastPresedX = self.lastPresedX + (80 * self.rotationSpeed);
					if(dif != 0) dif = -1;
				}else{
					self.lastPresedX = self.lastPresedX - (80 * self.rotationSpeed);
					if(dif != 0) dif = 1;
				}
				
				self.curId += dif;
				self.gotoImage();
			}
		};
		
		self.rotateEndHandler = function(e){
			if(Math.abs(self.swipeDragDist) > self.spinDist && self.addDragAndSpinSupport_bl && self.firstInteractionOccured_bl){
				self.startToSwipe();
			}else{
				self.addLargeImage();
			}
			
			self.isDragging_bl = false;
			self.isRotatingFirstTime_bl = true;
			self.firstInteractionOccured_bl  = true;
			if(!self.isMobile_bl || e.pointerType == e.MSPOINTER_TYPE_MOUSE) parent.hideRotateDumy();
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.rotateMoveHandler);
					window.removeEventListener("MSPointerUp", self.rotateEndHandler);
				}else{
					window.removeEventListener("touchmove", self.rotateMoveHandler);
					window.removeEventListener("touchend", self.rotateEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.rotateMoveHandler);
					window.removeEventListener("mouseup", self.rotateEndHandler);	
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.rotateMoveHandler);
					document.detachEvent("onmouseup", self.rotateEndHandler);
				}
			}
		};
		
		//###############################################//
		/* Swipe */
		//###############################################//
		this.startToSwipe = function(){
			self.isSwiping_bl = true;
			

			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				marker.hide();
			}
			
			self.swipeDirection_str = self.swipeDragDist < 0 ? "left" : "right";
			self.swipeDragDist = Math.abs(self.swipeDragDist/(20 * self.dragAndSpinSpeed));
			self.dragAndSpinId_int = setInterval(self.swipeTweenUpdate, 16);
		};
		
		this.swipeTweenUpdate = function(){
			var steps = 0;
			var sgn;
	
			self.swipeDragDist += (0 - self.swipeDragDist) * 0.07;
			steps = Math.round(self.swipeDragDist);
			if(self.swipeDirection_str == "left"){
				sgn = 1;
			}else{
				sgn = -1;
			}
			self.curId  += steps * sgn;
			
			if(steps == 0){
				self.isSwiping_bl = false;
				clearInterval(self.dragAndSpinId_int);
				self.gotoImage();
				self.addLargeImage();
			}else{
				self.gotoImage();
			}
		};
		
		//###############################################//
		//Add mousewheel support.
		//###############################################//
		self.addMouseWheelSupport = function(){
			if(window.addEventListener){
				self.dumy_sdo.screen.addEventListener ("mousewheel", self.mouseWheelHandler);
				self.dumy_sdo.screen.addEventListener('DOMMouseScroll', self.mouseWheelHandler);
			}else if(document.attachEvent){
				self.dumy_sdo.screen.attachEvent("onmousewheel", self.mouseWheelHandler);
			}
		};
		
		self.mouseWheelHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isDragging_bl || self.disablePanOrRotate_bl) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);
			if(self.hider) self.hider.reset();
			self.mouseX = viewportMouseCoordinates.screenX - self.getGlobalX();
			self.mouseY = viewportMouseCoordinates.screenY - self.getGlobalY();
			
			var dir = e.detail || e.wheelDelta;	
			if(e.wheelDelta) dir *= -1;
			if(FWDUtils.isOpera) dir *= -1;
			
			if(dir > 0){
				self.currentScale -= self.zoomSpeed;
				if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))) self.currentScale = self.smallestPossibleScale;
			}else if(dir < 0){
				self.currentScale += self.zoomSpeed;
				if(self.currentScale > self.zoomFactor) self.currentScale = self.zoomFactor;
			}
			
			self.zoomImage(true);
			
			if(e.preventDefault){
				e.preventDefault();
			}else{
				return false;
			}
		};
		
		//###########################################//
		/* Setup markers */
		//###########################################//
		self.setupMarkers = function(){
			var marker;
			var objData;
			var toolTipId = 0;
			self.totalMarkers = self.markersList_ar.length;
			for(var i=0; i<self.totalMarkers; i++){
				objData = self.markersList_ar[i];
				FWDMarker.setPrototype();
				marker = new FWDMarker(objData.markerId, 
						objData.normalStatePath_str, 
						objData.selectedStatePath_str, 
						objData.type, 
						objData.regPoint, 
						objData.toolTipLabel, 
						objData.markerWidth, 
						objData.markerHeight);
				marker.addListener(FWDMarker.MOUSE_OVER, self.markerOnMouseOverHandler);
				marker.addListener(FWDMarker.MOUSE_OUT, self.markerOnMouseOutHandler);
				marker.addListener(FWDMarker.MOUSE_DOWN, self.markerOnStartHandler);
				
				if(objData.type == "tooltip"){
					marker.toolTipId = toolTipId;
					marker.innerHTML_str = objData.innerHTML;
					marker.toolTipWindowMaxWidth = objData.maxWidth;
				}else if(objData.type == "infowindow"){
					marker.innerHTML_str = objData.innerHTML;
				}else if(objData.type == "link"){
					marker.link_str = objData.link;
					marker.target_str = objData.target;
				}
				self.markers_ar.push(marker);
				self.addChild(marker);
			}
		};
		
		self.markerOnMouseOverHandler = function(e){
			var marker = e.target;
			if(marker.hasToolTip_bl){
				self.showMarkerToolTip(marker, marker.toolTipLabel_str);
			};
			
			if(marker.type_str == "tooltip"){
				if(self.lastMarkerId_str != marker.markerId) self.hideToolTipWindow();
				self.lastMarkerId_str = marker.markerId;
				self.curMarker_do = marker;
				clearTimeout(self.hideToolTipWindowId_to);
				self.showToolTipWindow(marker, marker.innerHTML_str, marker.toolTipWindowMaxWidth);
			}
		};
		
		self.markerOnMouseOutHandler = function(e){
			var marker = e.target;
			if(marker.hasToolTip_bl){
				if(self.markersToolTip_do){
					if(self.contains(self.markersToolTip_do)) self.removeChild(self.markersToolTip_do);
					self.markersToolTip_do.hide();
				}
			};
			
			if(marker.type_str == "tooltip"){
				self.toolTipWindowAddEventsToSetGlobalXAndGlobalY();
				clearTimeout(self.hideToolTipWindowId_to);
				self.hideToolTipWindowId_to = setTimeout(self.hideToolTipWindowWithDelay, 300);
			}
		};
		
		self.markerOnStartHandler = function(e){
			var marker = e.target;
			if(marker.type_str == "infowindow"){
				self.dispatchEvent(FWDImageManager.SHOW_INFO, {text:marker.innerHTML_str});
			}else if(marker.type_str == "tooltip"){	
				if(self.lastMarkerId_str != marker.markerId) self.hideToolTipWindow();
				self.curMarker_do = marker;
				self.lastMarkerId_str = marker.markerId;
				self.toolTipWindowAddEventsToSetGlobalXAndGlobalY();
				self.showToolTipWindow(marker, marker.innerHTML_str, marker.toolTipWindowMaxWidth);
			}
		};
		
		self.showMarkersWithAlphaForChromeFirstTime_bl = true;
		
		//Show or hide markers.
		self.showOrHideMarkers = function(){
			var marker;
			var positionObj = self.markersPosition_ar[self.curId];
			var positonObj2;
			var totalCurMarkers;
			
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				marker.isActive_bl = false;
			}
			
			if(positionObj){
				totalCurMarkers = positionObj.length;
				for(var i=0; i<totalCurMarkers; i++){
					positonObj2 = positionObj[i];
					for(var j=0; j<self.totalMarkers; j++){
						marker = self.markers_ar[j];
						if(positonObj2.markerId == marker.markerId && !marker.isActive_bl){
							marker.originalX = positonObj2.x;
							marker.originalY = positonObj2.y;
							marker.show();
							marker.isActive_bl = true;
						}
					}
				}
			}
			
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				if(!marker.isActive_bl) marker.hide();
				if(marker.isActive_bl && self.showMarkersWithAlphaForChromeFirstTime_bl){
					marker.showOnChromeOnce();
				}
			}
			self.showMarkersWithAlphaForChromeFirstTime_bl = false;	
		};
		
		//position markers.
		self.positionMarkers = function(animate){
			var marker;
			for(var i=0; i< self.totalMarkers; i++){
				marker = self.markers_ar[i];
				if(marker.isActive_bl){
					marker.finalX = self.finalX + marker.offsetX + Math.round(marker.originalX * self.currentScale);
					marker.finalY = self.finalY + marker.offsetY + Math.round(marker.originalY * self.currentScale);
					if(animate){
						TweenMax.killTweensOf(marker);
						TweenMax.to(marker, .2, {x:marker.finalX, y:marker.finalY});
					}else{
						TweenMax.killTweensOf(marker);
						marker.setX(marker.finalX);
						marker.setY(marker.finalY);
					}
				}
				
			}
		};
		
		//###########################################//
		/* Setup markers tooltip */
		//###########################################//
		self.setupMarkersToolTip = function(){
			FWDMarkerToolTip.setPrototype();
			self.markersToolTip_do = new FWDMarkerToolTip(
					self.toolTipLeft_img,
					self.toolTipPointer_img,
					self.buttonToolTipLeft_str,
					self.buttonToolTipMiddle_str,
					self.buttonToolTipRight_str,
					self.buttonToolTipFontColor_str,
					self.buttonToolTipTopPointer_str,
					self.buttonToolTipBottomPointer_str);
		};
		
		//###########################################//
		/* Setup markers tooltip window*/
		//###########################################//
		self.setupMarkersToolTipWindow = function(){
			FWDMarkerWindowToolTip.setPrototype();
			self.markersToolTipWindow_do = new FWDMarkerWindowToolTip(
					self,
					self.toolTipPointer_img,
					self.buttonToolTipTopPointer_str,
					self.buttonToolTipBottomPointer_str);
			self.addChild(self.markersToolTipWindow_do);
		};
		
		
		//######################################################//
		/* show tool tip */
		//######################################################//
		self.showMarkerToolTip = function(marker, label){
			var finalX;
			var finalY;
			var globalX = self.getX();
			var pointerOffsetX = 0;
			var pointerPostion;
			
			self.addChild(self.markersToolTip_do);
			self.markersToolTip_do.setLabel(label);
			self.markersToolTip_do.show();
			clearTimeout(self.showMarkerToolTipId_to);
			
			self.showMarkerToolTipId_to = setTimeout(function(){
				if(!self.markersToolTip_do.isShowed_bl) return;
				finalX = parseInt(marker.finalX + (marker.width - self.markersToolTip_do.totalWidth)/2);
				
				finalY = marker.finalY - self.markersToolTip_do.totalHeight - self.markerToolTipOffsetY;
				
				if(finalY < 0){
					finalY = marker.finalY + marker.height + self.markersToolTip_do.pointerHeight + self.markerToolTipOffsetY;
					self.markersToolTip_do.pointerUp_sdo.setVisible(true);
					self.markersToolTip_do.pointerDown_sdo.setVisible(false);
					pointerPostion = FWDMarkerToolTip.POINTER_UP;
				}else{
					self.markersToolTip_do.pointerUp_sdo.setVisible(false);
					self.markersToolTip_do.pointerDown_sdo.setVisible(true);
					pointerPostion = FWDMarkerToolTip.POINTER_DOWN;
				}
				
				if(finalX < 0){
					pointerOffsetX = finalX;
					finalX = 0;
				}else if(self.stageWidth - finalX - self.markersToolTip_do.totalWidth < 0){
					pointerOffsetX = -(self.stageWidth - finalX - self.markersToolTip_do.totalWidth);
					finalX = finalX + self.stageWidth - finalX - self.markersToolTip_do.totalWidth;
				}
			
				self.markersToolTip_do.setX(finalX);
				self.markersToolTip_do.setY(finalY);	
				self.markersToolTip_do.positionPointer(pointerOffsetX, pointerPostion);
			}, 80);
			
		};
			
		//######################################################//
		/* show tool tip window */
		//######################################################//
		self.showToolTipWindow = function(marker, label, maxWidth){
			if(self.markersToolTipWindow_do.toolTipWindowId == marker.toolTipWindowId) return;
			
			var finalX;
			var finalY;
			var globalX = self.getX();
			var pointerOffsetX = 0;
			var pointerPostion;
			
			self.markersToolTipWindow_do.setLabel(label, maxWidth);
			
			self.markersToolTipWindow_do.toolTipWindowId = marker.toolTipWindowId;
			
			clearTimeout(self.showToolTipWindoId_to);
			self.showToolTipWindoId_to = setTimeout(function(){
				finalX = parseInt(marker.finalX + (marker.width - self.markersToolTipWindow_do.totalWidth)/2);
				
				if(marker.finalY < self.stageHeight/2){
					finalY = marker.finalY + marker.height + self.markersToolTipWindow_do.pointerHeight + self.markerToolTipOffsetY;
					self.markersToolTipWindow_do.pointerUp_sdo.setVisible(true);
					self.markersToolTipWindow_do.pointerDown_sdo.setVisible(false);
					pointerPostion = FWDMarkerWindowToolTip.POINTER_UP;
				}else{
					finalY = marker.finalY - self.markersToolTipWindow_do.totalHeight - self.markerToolTipOffsetY;
					self.markersToolTipWindow_do.pointerUp_sdo.setVisible(false);
					self.markersToolTipWindow_do.pointerDown_sdo.setVisible(true);
					pointerPostion = FWDMarkerWindowToolTip.POINTER_DOWN;
				}
			
				if(finalX < 0){
					pointerOffsetX = finalX;
					finalX = 0;
				}else if(self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth < 0){
					pointerOffsetX = -(self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth);
					finalX = finalX + self.stageWidth - finalX - self.markersToolTipWindow_do.totalWidth;
				}
				
				self.markersToolTipWindow_do.show();
				self.markersToolTipWindow_do.setX(finalX);
				self.markersToolTipWindow_do.setY(finalY);	
				self.markersToolTipWindow_do.positionPointer(pointerOffsetX, pointerPostion);
			}, 80);
		};
		
		//######################################################//
		/* hide tool tip window */
		//######################################################//
		self.toolTipWindowAddEventsToSetGlobalXAndGlobalY = function(){
			if(self.isMobile_bl){
				self.addHideToolTipWindowTestWithDelayId_to = setTimeout(function(){
					if(self.hasPointerEvent_bl){
						window.addEventListener("MSPointerDown", self.hideToolTipWindowTest);
						window.addEventListener("MSPointerMove", self.hideToolTipWindowTest);
					}else{
						window.addEventListener("touchstart", self.hideToolTipWindowTest);
					}
				}, 50);
			}else{
				if(window.addEventListener){
					window.addEventListener("mousemove", self.hideToolTipWindowTest);
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.hideToolTipWindowTest);
				}
			}
		};
		
		self.hideToolTipWindowTest = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.globalX = viewportMouseCoordinates.screenX;
			self.globalY = viewportMouseCoordinates.screenY;
			if(e.touches || e.pointerType != e.MSPOINTER_TYPE_MOUSE) self.hideToolTipWindowWithDelay();
		};
		
		self.hideToolTipWindowWithDelay = function(addDelay){
			if(!FWDUtils.hitTest(self.markersToolTipWindow_do.screen, self.globalX, self.globalY)
			   && !FWDUtils.hitTest(self.curMarker_do.screen, self.globalX, self.globalY)	){
				self.hideToolTipWindow();
				if(self.isMobile_bl){
					clearTimeout(self.addHideToolTipWindowTestWithDelayId_to);
					if(self.hasPointerEvent_bl){
						window.removeEventListener("MSPointerDown", self.hideToolTipWindowTest);
						window.removeEventListener("MSPointerMove", self.hideToolTipWindowTest);
					}else{
						window.removeEventListener("touchstart", self.hideToolTipWindowTest);
					}
				}else{
					if(window.removeEventListener){
						window.removeEventListener("mousemove", self.hideToolTipWindowTest);
					}else if(document.detachEvent){
						document.detachEvent("onmousemove", self.hideToolTipWindowTest);
					}
				}
			}else{
				self.hideToolTipWindowId_to = setTimeout(self.hideToolTipWindowWithDelay, 300);
			}
		};
		
		self.hideToolTipWindow = function(){
			if(!self.markersToolTipWindow_do) return;
			clearTimeout(self.hideToolTipWindowId_to);
			self.markersToolTipWindow_do.hide();
			self.markersToolTipWindow_do.toolTipWindowId = "none";
		};
		
		
		//####################################//
		/* markers info */
		//####################################//
		self.setupMarkersInfo = function(){
			if(window.addEventListener){
				window.addEventListener("mousemove", self.showMarkersInfoPosition);
				window.addEventListener ("mousewheel", self.showMarkersInfoPosition);
				window.addEventListener('DOMMouseScroll', self.showMarkersInfoPosition);
			}else if(document.attachEvent){
				document.attachEvent("onmousemove", self.showMarkersInfoPosition);
				document.attachEvent("onmousewheel", self.showMarkersInfoPosition);
			}
		
			self.markersPositionInfo_sdo = new FWDSimpleDisplayObject("div");
			self.markersPositionInfo_sdo.setDisplay("inline-block");
			self.markersPositionInfo_sdo.getStyle().fontSmoothing = "antialiased";
			self.markersPositionInfo_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.markersPositionInfo_sdo.getStyle().textRendering = "optimizeLegibility";
			self.markersPositionInfo_sdo.getStyle().padding = "6px";
			self.markersPositionInfo_sdo.getStyle().fontFamily = "Arial";
			self.markersPositionInfo_sdo.getStyle().fontSize= "12px";
			self.markersPositionInfo_sdo.getStyle().lineHeight = "20px";
			self.markersPositionInfo_sdo.getStyle().color = "#000000";
			self.markersPositionInfo_sdo.setBkColor("#FFFFFF");
			self.addChild(self.markersPositionInfo_sdo);
		};
		
		self.showMarkersInfoPosition = function(e){
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			var globalX = self.getGlobalX();
			var globalY = self.getGlobalY();
			var localX = viewportMouseCoordinates.screenX - globalX;
			var localY = viewportMouseCoordinates.screenY - globalY;
			var finalX = parseInt((localX - self.finalX) * (1/self.currentScale));
			var finalY = parseInt((localY - self.finalY) * (1/self.currentScale));
			var infoFinalX = localX + 10;
			var infoFinalY = localY + 10;
			
			self.markersPositionInfo_sdo.setInnerHTML("Image nr:" + "<font color='#FF0000'>" + (self.curId + 1) + "</font>" +  "<br>x:" + "<font color='#FF0000'>" + finalX + "</font>" + " y:" + "<font color='#FF0000'>" + finalY + "</font>");
			var infoWidth = self.markersPositionInfo_sdo.getWidth();
			var infoHeight = self.markersPositionInfo_sdo.getHeight();
			
			if(infoFinalX + infoWidth > self.stageWidth){
				infoFinalX = infoFinalX - infoWidth - 10;
			}
			
			if(infoFinalY + infoHeight > self.stageHeight){
				infoFinalY = infoFinalY - infoHeight - 10;
			}
		
			self.markersPositionInfo_sdo.setX(infoFinalX );
			self.markersPositionInfo_sdo.setY(infoFinalY );
		};
		
		
		//##################################//
		//various methods.
		//##################################//
		self.setDraggingMode = function(draggingMode){
			self.draggingMode_str = draggingMode;
		};
		
		self.disableOrEnablePanOrTouch = function(bool){
			self.disablePanOrRotate_bl = bool;
		};
		
		self.zoomInOrOutWithScrollBar = function(percent){
			self.currentScale = percent * (self.zoomFactor - self.smallestPossibleScale) + self.smallestPossibleScale;
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			self.zoomImage(true);
		};
		
		self.dispatchScrollBarUpdate = function(animate, overwrite){
			if(!self.disablePanOrRotate_bl || overwrite){
				self.dispatchEvent(FWDImageManager.SCROLL_BAR_UPDATE, {percent:(self.currentScale - self.smallestPossibleScale)/(self.zoomFactor - self.smallestPossibleScale), animate:animate});
			}
		};
		
		self.zoomInOrOutWithButtons = function(dir, withPause){
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			
			if(dir > 0){
				if(withPause){
					self.currentScale += self.zoomSpeed;
				}else{
					self.currentScale += self.zoomSpeed/15;
				}
				if(self.currentScale > self.zoomFactor) self.currentScale = self.zoomFactor;
			}else if(dir < 0){
				if(withPause){
					self.currentScale -= self.zoomSpeed;
				}else{
					self.currentScale -= self.zoomSpeed/15;
				}
				if(parseFloat(self.currentScale.toFixed(5)) <= parseFloat(self.smallestPossibleScale.toFixed(5))) self.currentScale = self.smallestPossibleScale;
			}
			self.dispatchScrollBarUpdate(true, true);
			
			self.zoomImage(true);
		};
		
		self.centerImage = function(){
			self.mouseX = self.stageWidth/2;
			self.mouseY = self.stageHeight/2;
			
			self.finalX =  Math.round((self.stageWidth - self.finalWidth)/2);
			self.finalY =  Math.round((self.stageHeight - self.finalHeight)/2);	
		
			self.resizeAndPositionSmallImage(false);
			self.positionMarkers();
		};
		
		//############################################//
		/* navigator utils */
		//############################################//
		self.updateNavigator = function(animate){
			if(!self.isNavigatorShowed_bl) return;
			self.dispatchEvent(FWDImageManager.UPDATE_NAVIGATOR, {
				percentX:Math.abs(self.finalX/(self.finalWidth - self.stageWidth)),
				percentY:Math.abs(self.finalY/(self.finalHeight - self.stageHeight)),
				percentWidth:self.stageWidth/self.finalWidth,
				percentHeight:self.stageHeight/self.finalHeight,
				animate:animate
			});
		};
		
		self.hideOrShowNavigator = function(){
			if(self.stageWidth < self.finalWidth || self.stageHeight < self.finalHeight){
				self.isNavigatorShowed_bl = true;
				self.dispatchEvent(FWDImageManager.SHOW_NAVIGATOR);
			}else{
				self.isNavigatorShowed_bl = false;
				self.dispatchEvent(FWDImageManager.HIDE_NAVIGATOR);
			}
		};
		
		self.updateOnNavigatorPan = function(percentX, percentY){
			
			self.finalX = parseInt(percentX * (self.stageWidth - self.finalWidth));
			self.finalY = parseInt(percentY * (self.stageHeight - self.finalHeight));
			
			self.positionMarkers(true);
			self.resizeAndPositionSmallImage(true);
		};
		
	
		//#################################//
		//Clean main events.
		//#################################//
		self.cleanMainEvents = function(){
			if(window.addEventListener){
				
			}else if(window.attachEvent){
				
			}
			if(self.isMobile_bl){
				self.dumy_sdo.screen.removeEventListener("touchstart", self.panStartHandler);
				self.dumy_sdo.screen.removeEventListener("MSPointerDown", self.panStartHandler);
				window.removeEventListener("touchmove", self.panMoveHandler);
				window.removeEventListener("touchend", self.panEndHandler);
				window.removeEventListener("MSPointerMove", self.panMoveHandler);
				window.removeEventListener("MSPointerUp", self.panEndHandler);
				
				self.dumy_sdo.screen.removeEventListener("touchstart", self.rotateStartHandler);
				self.dumy_sdo.screen.removeEventListener("MSPointerDown", self.rotateStartHandler);
				window.removeEventListener("touchmove", self.rotateMoveHandler);
				window.removeEventListener("touchend", self.rotateEndHandler);
				window.removeEventListener("MSPointerMove", self.rotateMoveHandler);
				window.removeEventListener("MSPointerUp", self.rotateEndHandler);
				
				window.removeEventListener("touchstart", self.hideToolTipWindowTest);
				window.removeEventListener("MSPointerDown", self.hideToolTipWindowTest);
				window.removeEventListener("MSPointerMove", self.hideToolTipWindowTest);
				
				self.screen.removeEventListener('gesturestart', self.gestureStartHandler);
				self.screen.removeEventListener('gesturechange', self.gestureChangeHandler);
			}else{
				if(window.removeEventListener){
					self.dumy_sdo.screen.removeEventListener("mousedown", self.panStartHandler);
					window.removeEventListener("mousemove", self.panMoveHandler);
					window.removeEventListener("mouseup", self.panEndHandler);	
					
					self.dumy_sdo.screen.removeEventListener("mousedown", self.rotateStartHandler);
					window.removeEventListener("mousemove", self.rotateMoveHandler);
					window.removeEventListener("mouseup", self.rotateEndHandler);
					
					self.dumy_sdo.screen.removeEventListener ("mousewheel", self.mouseWheelHandler);
					self.dumy_sdo.screen.removeEventListener('DOMMouseScroll', self.mouseWheelHandler);
					
					window.removeEventListener("mousemove", self.hideToolTipWindowTest);
					
					window.removeEventListener("mousemove", self.showMarkersInfoPosition);
					window.removeEventListener ("mousewheel", self.showMarkersInfoPosition);
					window.removeEventListener('DOMMouseScroll', self.showMarkersInfoPosition);
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.panMoveHandler);
					document.detachEvent("onmouseup", self.panEndHandler);
					self.dumy_sdo.screen.detachEvent("onmousedown", self.panStartHandler);
					
					self.dumy_sdo.screen.detachEvent("onmousedown", self.rotateStartHandler);
					document.detachEvent("onmousemove", self.rotateMoveHandler);
					document.detachEvent("onmouseup", self.rotateEndHandler);
					
					self.dumy_sdo.screen.detachEvent("onmousewheel", self.mouseWheelHandler);
					
					document.detachEvent("onmousemove", self.hideToolTipWindowTest);
					
					document.detachEvent("onmousemove", self.showMarkersInfoPosition);
					document.detachEvent("onmousewheel", self.showMarkersInfoPosition);
				}
			}
			
			clearTimeout(self.tweenDone_to);
			clearTimeout(self.removeSmallSDOId_to);
			clearTimeout(self.setAlphaWithDelayId_to);
			clearTimeout(self.hideToolTipWindowId_to);
			clearTimeout(self.addHideToolTipWindowTestWithDelayId_to);
			clearTimeout(self.showToolTipWindoId_to);
			clearTimeout(self.showMarkerToolTipId_to);
			clearInterval(self.dragAndSpinId_int);
		};
		
		//#################################//
		/* destroy */
		//################################//
		self.destroy = function(){
			self.cleanMainEvents();
			
			if(self.largeImage_img){
				self.largeImage_img.onerror = null;
				self.largeImage_img.onload = null;
				self.largeImage_img.src = null;
			}
			
			if(self.mainImagesHolder_do){
				TweenMax.killTweensOf(self.mainImagesHolder_do);
				self.mainImagesHolder_do.destroy();
			}
			
			if(self.smallImage_sdo){
				TweenMax.killTweensOf(self.smallImage_sdo);
				self.smallImage_sdo.destroy();
			}
			
			if(self.showMarkers_bl){
				var marker;
				for(var i=0; i<self.totalMarkers; i++){
					marker = self.markers_ar[i];
					TweenMax.killTweensOf(marker);
					marker.destroy();
				}
				if(self.markersToolTip_do) self.markersToolTip_do.destroy();
				self.markersToolTipWindow_do.destroy();
			}
			
			if(self.addCorrectionForWebKit_bl){
				TweenMax.killTweensOf(self.left_sdo);
				TweenMax.killTweensOf(self.top_sdo);
				TweenMax.killTweensOf(self.right_sdo);
				TweenMax.killTweensOf(self.bottom_sdo);
				self.left_sdo.destroy();
				self.top_sdo.destroy();
				self.right_sdo.destroy();
				self.bottom_sdo.destroy();
			}
			
			for(var i=0; i<self.smallDos_ar.length; i++){
				var small_sdo = self.smallDos_ar[i];
				TweenMax.killTweensOf(small_sdo);
				small_sdo.destroy();
			};
			
			if(self.largeImage_sdo){
				TweenMax.killTweensOf(self.largeImage_sdo);
				self.largeImage_sdo.destroy();
			}
			
			if(self.markersPositionInfo_sdo){
				self.markersPositionInfo_sdo.setInnerHTML("");
				self.markersPositionInfo_sdo.destroy();
			}
			
			data = null;
			parent = null;
			
			self.playListData_ar = null;
			self.images_ar = null;
			self.smallDos_ar = null;
			self.markers_ar = null;
			self.markersList_ar = null;
			self.markersPosition_ar = null;
			self.largeImagesPaths_ar = null;
			
			self.hider = null;
			self.curMarker_do = null;
			self.prevSmall_sdo = null;
			self.largeImage_img = null;
			self.dumy_sdo = null;
			self.mainImagesHolder_do = null;
			self.smallImage_sdo = null;
			self.largeImage_sdo = null;
			self.left_sdo = null;
			self.top_sdo = null;
			self.right_sdo = null;
			self.bottom_sdo = null;
			self.markersPositionInfo_sdo = null;
			
			self.handMovePath_str = null;
			self.backgroundColor_str = null;
			self.draggingMode_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDImageManager.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
	FWDImageManager.setPrototype =  function(){
		FWDImageManager.prototype = new FWDDisplayObject("div");
	};
	
	FWDImageManager.LARGE_IMAGE_LOAD_ERROR = "largeImageLoadError";
	FWDImageManager.IMAGE_ZOOM_COMPLETE = "zoomComplete";
	FWDImageManager.SCROLL_BAR_UPDATE = "scrollBarUpdate";
	FWDImageManager.PAN_START = "panStart";
	FWDImageManager.ROTATE_START = "rotateStart";
	FWDImageManager.ROTATE_UPDATE = "rotateUpdate";
	FWDImageManager.ROTATE = "rotate";
	FWDImageManager.PAN = "pan";
	FWDImageManager.UPDATE_NAVIGATOR = "updateNavigator";
	FWDImageManager.SHOW_NAVIGATOR = "showNavigator";
	FWDImageManager.HIDE_NAVIGATOR = "hideNavigator";
	FWDImageManager.SHOW_INFO = "showInfo";

	FWDImageManager.prototype = null;
	window.FWDImageManager = FWDImageManager;
	
}(window));/* Info screen */
(function (window){
	
	var FWDInfo = function(){
		
		var self = this;
		var prototype = FWDInfo.prototype;
		
		/* init */
		this.init = function(){
			this.setWidth(500);
			this.setBkColor("#FF0000");
			this.getStyle().padding = "10px";
		};
		
		this.showText = function(txt){
			this.setInnerHTML(txt);
		};
		
		/* destroy */
		this.destroy = function(){
	
			this.init = null;
			this.showText = null;
			this.destroy = null;

			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			FWDInfo.prototype = null;
		};
		
		this.init();
	};
		
	/* set prototype */
	FWDInfo.setPrototype = function(){
		FWDInfo.prototype = new FWDDisplayObject("div", "relative");
	};
	
	FWDInfo.prototype = null;
	window.FWDInfo = FWDInfo;
}(window));(function (window) {

        // This library re-implements setTimeout, setInterval, clearTimeout, clearInterval for iOS6.
        // iOS6 suffers from a bug that kills timers that are created while a page is scrolling.
        // This library fixes that problem by recreating timers after scrolling finishes (with interval correction).
		// This code is free to use by anyone (MIT, blabla).
		// Author: rkorving@wizcorp.jp
		
		var platform = navigator.platform;
		var isIpadOrIphone = false;
		if(platform == 'iPad' ||  platform == 'iPhone') isIpadOrIphone = true;
		if(!isIpadOrIphone) return;
		
		var userAgent = navigator.userAgent;
		var isIosVersion6 = false;
		if(userAgent.indexOf("6") != -1) isIosVersion6 = true;
		if(!isIosVersion6) return;
		
	
        var timeouts = {};
        var intervals = {};
        var orgSetTimeout = window.setTimeout;
        var orgSetInterval = window.setInterval;
        var orgClearTimeout = window.clearTimeout;
        var orgClearInterval = window.clearInterval;


        function createTimer(set, map, args) {
                var id, cb = args[0], repeat = (set === orgSetInterval);

                function callback() {
                        if (cb) {
                                cb.apply(window, arguments);

                                if (!repeat) {
                                        delete map[id];
                                        cb = null;
                                }
                        }
                }

                args[0] = callback;

                id = set.apply(window, args);

                map[id] = { args: args, created: Date.now(), cb: cb, id: id };

                return id;
        }


        function resetTimer(set, clear, map, virtualId, correctInterval) {
                var timer = map[virtualId];

                if (!timer) {
                        return;
                }

                var repeat = (set === orgSetInterval);

                // cleanup

                clear(timer.id);

                // reduce the interval (arg 1 in the args array)

                if (!repeat) {
                        var interval = timer.args[1];

                        var reduction = Date.now() - timer.created;
                        if (reduction < 0) {
                                reduction = 0;
                        }

                        interval -= reduction;
                        if (interval < 0) {
                                interval = 0;
                        }

                        timer.args[1] = interval;
                }

                // recreate

                function callback() {
                        if (timer.cb) {
                                timer.cb.apply(window, arguments);
                                if (!repeat) {
                                        delete map[virtualId];
                                        timer.cb = null;
                                }
                        }
                }

                timer.args[0] = callback;
                timer.created = Date.now();
                timer.id = set.apply(window, timer.args);
        }


        window.setTimeout = function () {
                return createTimer(orgSetTimeout, timeouts, arguments);
        };


        window.setInterval = function () {
                return createTimer(orgSetInterval, intervals, arguments);
        };

        window.clearTimeout = function (id) {
                var timer = timeouts[id];

                if (timer) {
                        delete timeouts[id];
                        orgClearTimeout(timer.id);
                }
        };

        window.clearInterval = function (id) {
                var timer = intervals[id];

                if (timer) {
                        delete intervals[id];
                        orgClearInterval(timer.id);
                }
        };

        window.addEventListener('scroll', function () {
                // recreate the timers using adjusted intervals
                // we cannot know how long the scroll-freeze lasted, so we cannot take that into account
                var virtualId;
             
                for (virtualId in timeouts) {
                        resetTimer(orgSetTimeout, orgClearTimeout, timeouts, virtualId);
                }

                for (virtualId in intervals) {
                        resetTimer(orgSetInterval, orgClearInterval, intervals, virtualId);
                }
        });

}(window));/* FWDLightBox */
(function (window){
	
	var FWDLightBox = function(
			parent,
			mainBackgroundColor_str,
			holderBackgroundColor_str,
			lightBoxBackgroundOpacity,
			lightBoxWidth,
			lightBoxHeight
		){
		
		var self  = this;
		var prototype = FWDLightBox.prototype;

		this.mainLightBox_do = null;
		this.lightBoxBackground_sdo = null;
		this.lightBoxGridHolder_do = null;
		this.closeButton_do = null;
		
		this.mainBackgroundColor_str = mainBackgroundColor_str;
		this.holderBackgroundColor_str = holderBackgroundColor_str;
		
		this.lightBoxBackgroundOpacity = lightBoxBackgroundOpacity;
		this.lightBoxWidth = lightBoxWidth;
		this.lightBoxHeight = lightBoxHeight;
		
		this.setupButtonWithDelayId_to;
		
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		this.closeButtonIsTweening_bl = true;
	
		this.init = function(){
			self.getStyle().zIndex = 100000000;
			self.setupMainContainers();
		};
		
		//#############################################//
		/* setup main containers */
		//#############################################//
		this.setupMainContainers = function(){
			var viewportSize = FWDUtils.getViewportSize();
			var scrollOffsets = FWDUtils.getScrollOffsets();
			
			if(self.isMobile_bl && self.hasPointerEvent_bl) self.getStyle().msTouchAction = "none";
			
			self.setWidth(viewportSize.w);
			self.setHeight(viewportSize.h);
			self.setX(scrollOffsets.x);
			self.setY(scrollOffsets.y);
			
			self.lightBoxBackground_sdo = new FWDSimpleDisplayObject("div"); 
			self.lightBoxBackground_sdo.setResizableSizeAfterParent();
			self.lightBoxBackground_sdo.setBkColor(self.mainBackgroundColor_str);
			self.addChild(self.lightBoxBackground_sdo);
			
			self.mainLightBox_do = new FWDDisplayObject("div");
			//self.mainLightBox_do.getStyle().boxShadow = "0px 0px 5px #999999";
			self.mainLightBox_do.setBkColor(self.holderBackgroundColor_str);
			parent.stageContainer = self.mainLightBox_do.screen;
			self.addChild(self.mainLightBox_do);
			
			if(navigator.userAgent.toLowerCase().indexOf("msie 7") == -1){
				document.documentElement.appendChild(self.screen);
			}else{
				document.getElementsByTagName("body")[0].appendChild(self.screen);
			}
			
			self.lightBoxBackground_sdo.setAlpha(0);
			TweenMax.to(self.lightBoxBackground_sdo, .8, {alpha:self.lightBoxBackgroundOpacity});
			self.setX(scrollOffsets.x);
			self.setY(scrollOffsets.y);
			
			self.mainLightBox_do.setWidth(0);
			self.mainLightBox_do.setHeight(0);
			self.mainLightBox_do.setX(parseInt(viewportSize.w/2));
			self.mainLightBox_do.setY(parseInt(viewportSize.h/2));
			
			if(self.lightBoxWidth > viewportSize.w){
				self.finalLightBoxWidth = viewportSize.w;
				self.finalLightBoxHeight = parseInt(self.lightBoxHeight * (viewportSize.w/self.lightBoxWidth));
			}else{
				self.finalLightBoxWidth = self.lightBoxWidth;
				self.finalLightBoxHeight = self.lightBoxHeight;
			}
			
			TweenMax.to(self.mainLightBox_do, .8, {
				w:self.finalLightBoxWidth, 
				h:self.finalLightBoxHeight,
				x:parseInt((viewportSize.w - self.finalLightBoxWidth)/2),
				y:parseInt((viewportSize.h - self.finalLightBoxHeight)/2),
				delay:.4,
				ease:Expo.easeInOut});
		};
		
		//#############################################//
		/* setup lightbox close button */
		//#############################################//
		this.setupCloseButton = function(n_img, s_img){
			
			var viewportSize = FWDUtils.getViewportSize();
			FWDSimpleButton.setPrototype();
			self.closeButton_do = new FWDSimpleButton(n_img, s_img);
			self.closeButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.closeButtonOnStartHandler);
			self.addChild(self.closeButton_do);
			
			var closeButtonFinalX = parseInt((viewportSize.w + self.finalLightBoxWidth)/2 - self.closeButton_do.totalWidth/2);
			var closeButtonFinalY = parseInt((viewportSize.h - self.finalLightBoxHeight)/2 - self.closeButton_do.totalHeight/2);
		
			if(closeButtonFinalX + self.closeButton_do.totalWidth > viewportSize.w){
				closeButtonFinalX = viewportSize.w - self.closeButton_do.totalWidth;
			}
			
			if(closeButtonFinalY < 0){
				closeButtonFinalY = 0;
			}
		
			self.closeButton_do.setX(viewportSize.w);
			self.closeButton_do.setY(closeButtonFinalY);
			
			
			TweenMax.to(self.closeButton_do, .9, {x:closeButtonFinalX, onComplete:self.showCloseButtonComplete, ease:Expo.easeInOut});
			
			if(self.isMobile_bl){
				if(!self.hasPointerEvent_bl){
					window.addEventListener("touchstart", self.mouseDummyHandler);
					window.addEventListener("touchmove", self.mouseDummyHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener ("mousewheel", self.mouseDummyHandler);
					window.addEventListener('DOMMouseScroll', self.mouseDummyHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmousewheel", self.mouseDummyHandler);
				}
			}
		};
		
		this.showCloseButtonComplete = function(){
			self.closeButtonIsTweening_bl = false;
		}
		
		
		this.mouseDummyHandler = function(e){
			if(e.preventDefault){
				e.preventDefault();
			}else{
				return false;
			}
		};
			
		this.closeButtonOnStartHandler = function(e){
			var viewportSize = FWDUtils.getViewportSize();
			self.closeButton_do.isDisabled_bl = true;
			TweenMax.to(self.closeButton_do, .9, {x:viewportSize.w, ease:Expo.easeInOut});
			
			TweenMax.to(self.mainLightBox_do, .8, {
				w:0, 
				h:0,
				x:parseInt(viewportSize.w/2),
				y:parseInt(viewportSize.h/2),
				delay:.4,
				ease:Expo.easeInOut});
			
			TweenMax.to(self.lightBoxBackground_sdo, .8, {alpha:0, delay:.8});
			self.lighboxAnimDoneId_to = setTimeout(self.lighboxHideAnimationDone, 1600);
			self.dispatchEvent(FWDLightBox.CLOSE);
		};
		
		this.lighboxHideAnimationDone = function(){
			self.dispatchEvent(FWDLightBox.HIDE_COMPLETE);
		};
		
		//#####################################//
		/* destroy */
		//####################################//
		self.destroy = function(){
			
			try{
				if(navigator.userAgent.toLowerCase().indexOf("msie 7") == -1){
					document.documentElement.removeChild(self.screen);
				}else{
					document.getElementsByTagName("body")[0].removeChild(self.screen);
				}
			}catch(e){}
			
			if(self.isMobile_bl){
				if(!self.hasPointerEvent_bl){
					window.removeEventListener("touchstart", self.mouseDummyHandler);
					window.removeEventListener("touchmove", self.mouseDummyHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener ("mousewheel", self.mouseDummyHandler);
					window.removeEventListener('DOMMouseScroll', self.mouseDummyHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmousewheel", self.mouseDummyHandler);
				}
			}
			
			clearTimeout(self.lighboxAnimDoneId_to);
			
			if(self.lightBoxBackground_sdo){
				TweenMax.killTweensOf(self.lightBoxBackground_sdo);
				self.lightBoxBackground_sdo.destroy();
			}
			
			if(self.lightBoxGridHolder_do){
				TweenMax.killTweensOf(self.lightBoxGridHolder_do);
				self.lightBoxGridHolder_do.destroy();
			}
			
			if(self.closeButton_do){
				TweenMax.killTweensOf(self.closeButton_do);
				self.closeButton_do.destroy();
			}
			
			self.mainLightBox_do = null;
			self.lightBoxBackground_sdo = null;
			self.lightBoxGridHolder_do = null;
			self.closeButton_do = null;
			
			self.mainBackgroundColor_str = null;
			self.holderBackgroundColor_str = null;
			
			parent = null;
			mainBackgroundColor_str = null;
			holderBackgroundColor_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDLightBox.prototype = null;
		};
	
		this.init();
	};
	
	/* set prototype */
    FWDLightBox.setPrototype = function(){
    	FWDLightBox.prototype = new FWDDisplayObject("div");
    };
    
    FWDLightBox.CLOSE = "ligtBoxClose";
    FWDLightBox.HIDE_COMPLETE = "hideComplete";
    
    FWDLightBox.prototype = null;
	window.FWDLightBox = FWDLightBox;
}(window));/* FWDMarker */
(function (window){
var FWDMarker = function(
		markerId,
		normalImagePath, 
		selectedImagePath,
		type,
		regPoint,
		toolTipLabel,
		width,
		height){
		
		var self = this;
		var prototype = FWDMarker.prototype;
	
		this.n_do;
		this.s_do;
		
		this.markerId = markerId;
		this.normalImagePath_str = normalImagePath;
		this.selectedImagePath_str = selectedImagePath;
		this.type_str = type;
		this.toolTipLabel_str = toolTipLabel;
		this.innerHTML_str;
		this.link_str;
		this.target_str;
		this.regPoint_str = regPoint;
		
		this.toolTipWindowId;
		this.width = width;
		this.height = height;
		this.toolTipId;
		this.originalX;
		this.originalY;
		this.finalX;
		this.finalY;
		this.offsetX;
		this.offsetY;
		this.toolTipWindowMaxWidth;
		
		this.showId_to;
	
		this.isDisabled_bl = false;
		this.hasToolTip_bl = true;
		this.isShowed_bl = true;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			if(self.type_str == "tooltip" || !self.toolTipLabel_str) self.hasToolTip_bl = false;
			
			if(self.regPoint_str == "center"){
				self.offsetX = -(parseInt(self.width/2));
				self.offsetY = -(parseInt(self.height/2));
			}else if(self.regPoint_str == "centertop"){
				self.offsetX = -(parseInt(self.width/2));
				self.offsetY = 0;
			}else if(self.regPoint_str == "centerbottom"){
				self.offsetX = -(parseInt(self.width/2));
				self.offsetY = -self.height;
			}
			
			self.setupMainContainers();
			self.hide();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			
			var img;
			var img2;
			
			self.n_do = new FWDTransformDisplayObject("img");	
			img = new Image();
			img.src = self.normalImagePath_str;
			self.n_do.setScreen(img);
			self.n_do.setWidth(self.width);
			self.n_do.setHeight(self.height);
			
			self.s_do = new FWDTransformDisplayObject("img");
			img2 = new Image();
			img2.src = self.selectedImagePath_str;
			self.s_do.setScreen(img2);
			self.s_do.setWidth(self.width);
			self.s_do.setHeight(self.height);
			self.s_do.setAlpha(0);
			
			self.addChild(self.n_do);
			self.addChild(self.s_do);
			
			self.setButtonMode(true);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.addEventListener("MSPointerDown", self.onMouseDown);
					self.screen.addEventListener("MSPointerUp", self.onClick);
					self.screen.addEventListener("MSPointerOver", self.onMouseOver);
					self.screen.addEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.addEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){	
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mousedown", self.onMouseDown);
				self.screen.addEventListener("click", self.onClick);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmousedown", self.onMouseDown);
				self.screen.attachEvent("onclick", self.onClick);
			}
		};
		
		self.onMouseOver = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDMarker.MOUSE_OVER, {e:e});
				if(self.isDisabled_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
			}
		};
			
		self.onMouseOut = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDMarker.MOUSE_OUT, {e:e});
				if(self.isDisabled_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:0, ease:Expo.easeOut});	
			}
			
		};
			
		self.onClick = function(e){
			if(self.isDisabled_bl) return;
			if(self.type_str == "link"){
				window.open(self.link_str, self.target_str);
				self.dispatchEvent(FWDMarker.MOUSE_OUT, {e:e});
			}
			self.dispatchEvent(FWDMarker.CLICK, {e:e});
		};
		
		self.onMouseDown = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isDisabled_bl) return;
			if(self.isMobile_bl && !self.hasPointerEvent_bl){
				if(self.type_str == "link"){
					window.open(self.link_str, self.target_str);
					self.dispatchEvent(FWDMarker.MOUSE_OUT, {e:e});
				}
			}
			self.dispatchEvent(FWDMarker.MOUSE_DOWN, {e:e});
		};
		
		//##############################//
		// hide / show.
		//##############################//
		self.hide = function(){
			if(!self.isShowed_bl) return;
			self.isShowed_bl = false;
			clearTimeout(self.showId_to);
			//if(!FWDUtils.isMobile){
				TweenMax.killTweensOf(self.n_do);
				self.n_do.setAlpha(0);
			//}
			
			if(self.hasTransform2d_bl){
				self.n_do.setScale(0);
				self.s_do.setScale(0);
			}else{
				self.n_do.setWidth(0);
				self.n_do.setHeight(0);
				self.s_do.setWidth(0);
				self.s_do.setHeight(0);
			}
		};
		
		self.show = function(){
			if(self.isShowed_bl) return;
			self.isShowed_bl = true;
			
			clearTimeout(self.showId_to);
			self.showId_to = setTimeout(function(){
			
				//if(!FWDUtils.isMobile){
					TweenMax.to(self.n_do, .8, {alpha:1, ease:Quart.easeOut});
				//}
				
				if(self.hasTransform2d_bl){
					self.n_do.setScale(1);
					self.s_do.setScale(1);
				}else{
					self.n_do.setWidth(width);
					self.n_do.setHeight(height);
					self.s_do.setWidth(width);
					self.s_do.setHeight(height);
				}
			}, 200);
		};
		
		
		self.showOnChromeOnce = function(){
			self.n_do.setAlpha(0);
			TweenMax.to(self.n_do, .8, {alpha:1, delay:.1, ease:Quart.easeOut});
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			
			if(self.isMobile_bl){
				self.screen.removeEventListener("touchstart", self.onMouseDown);
			}else if(self.screen.addEventListener){
				self.screen.removeEventListener("mouseover", self.onMouseOver);
				self.screen.removeEventListener("mouseout", self.onMouseOut);
				self.screen.removeEventListener("mousedown", self.onMouseDown);
				self.screen.removeEventListener("click", self.onClick);
			}else if(self.screen.detachEvent){
				self.screen.detachEvent("onmouseover", self.onMouseOver);
				self.screen.detachEvent("onmouseout", self.onMouseOut);
				self.screen.detachEvent("onmousedown", self.onMouseDown);
				self.screen.detachEvent("onclick", self.onClick);
			}
		
			TweenMax.killTweensOf(self.n_do);
			TweenMax.killTweensOf(self.s_do);
			self.n_do.destroy();
			self.s_do.destroy();
		
			self.n_do = null;
			self.s_do = null;
			
			self.markerId = null;
			self.normalImagePath_str = null;
			self.selectedImagePath_str = null;
			self.type_str = null;
			self.toolTipLabel_str = null;
			self.innerHTML_str = null;
			self.link_str = null;
			self.target_str = null;
			self.regPoint_str = null;
			
			markerId = null;
			normalImagePath = null; 
			selectedImagePath = null;
			type = null;
			regPoint = null;
			toolTipLabel = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDMarker.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDMarker.setPrototype = function(){
		FWDMarker.prototype = new FWDDisplayObject("div");
	};
	
	FWDMarker.CLICK = "onClick";
	FWDMarker.MOUSE_OVER = "onMouseOver";
	FWDMarker.MOUSE_OUT = "onMouseOut";
	FWDMarker.MOUSE_DOWN = "onMouseDown";
	
	FWDMarker.prototype = null;
	window.FWDMarker = FWDMarker;
}(window));/* FWDMarkerToolTip */
(function (window){
var FWDMarkerToolTip = function(
			leftImage_img,
			pointerDown_img,
			leftImagePath_str, 
			middleImagePath_str,
			rightImagePath_str,
			buttonToolTipFontColor_str,
			buttonToolTipTopPointer_str,
			buttonToolTipBottomPointer_str
		){
		
		var self = this;
		var prototype = FWDMarkerToolTip.prototype;
		
		self.pointerUp_img;
		self.pointerDown_img;
		
		self.left_sdo = null;
		self.middle_sdo = null;
		self.right_sdo = null;
		self.text_sdo = null;
		self.pointerUp_sdo = null;
		self.pointerDown_sdo = null;
		
		self.leftImagePath_str = leftImagePath_str;
		self.middleImagePath_str = middleImagePath_str;
		self.rightImagePath_str = rightImagePath_str;
		self.fontColor_str = buttonToolTipFontColor_str;
		self.bottomPointer_str = buttonToolTipBottomPointer_str;
		self.topPointer_str = buttonToolTipTopPointer_str;
		self.pointerPosition_str;
		self.toolTipLabel_str;
		
		self.marginWidth = leftImage_img.width;
		self.totalHeight = leftImage_img.height;
		self.pointerWidth = pointerDown_img.width;
		self.pointerHeight = pointerDown_img.height;
		self.totalWidth;
		
		self.isMobile_bl = FWDUtils.isMobile;
		self.isShowed_bl = true;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setWidth(300);
			self.setupMainContainers();
			self.hide();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){	
			
			var img;
			
			self.left_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.leftImagePath_str;
			self.left_sdo.setScreen(img);
			self.left_sdo.setWidth(self.marginWidth);
			self.left_sdo.setHeight(self.totalHeight);
			self.addChild(self.left_sdo);
			
			self.middle_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.middleImagePath_str;
			self.middle_sdo.setScreen(img);
			self.middle_sdo.setX(self.marginWidth);
			self.middle_sdo.setWidth(self.marginWidth);
			self.middle_sdo.setHeight(self.totalHeight);
			self.addChild(self.middle_sdo);
			
			self.right_sdo = new FWDSimpleDisplayObject("img");
			img = new Image();
			img.src = self.rightImagePath_str;
			self.right_sdo.setScreen(img);
			self.right_sdo.setWidth(self.marginWidth);
			self.right_sdo.setHeight(self.totalHeight);
			self.addChild(self.right_sdo);	
	
			self.text_sdo = new FWDSimpleDisplayObject("div");
			self.text_sdo.setBackfaceVisibility();
			self.text_sdo.setDisplay("inline-block");
			self.text_sdo.getStyle().fontFamily = "Arial";
			self.text_sdo.getStyle().fontSize= "12px";
			self.text_sdo.setHeight(20);
			self.text_sdo.getStyle().color = self.fontColor_str;
			self.text_sdo.getStyle().fontSmoothing = "antialiased";
			self.text_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.text_sdo.getStyle().textRendering = "optimizeLegibility";	
			self.text_sdo.setX(self.marginWidth);
		
			if(FWDUtils.isIEAndLessThen9 || FWDUtils.isSafari){
				self.text_sdo.setY(parseInt((self.totalHeight - 8)/2) - 2);
			}else{
				self.text_sdo.setY(parseInt((self.totalHeight - 8)/2) - 1);
			}
			self.addChild(self.text_sdo);
			
			self.pointerUp_img = new Image();
			self.pointerUp_img.src = self.topPointer_str;
			self.pointerUp_sdo = new FWDSimpleDisplayObject("img");
			self.pointerUp_sdo.setScreen(self.pointerUp_img);
			self.pointerUp_sdo.setWidth(self.pointerWidth);
			self.pointerUp_sdo.setHeight(self.pointerHeight);
			self.pointerUp_sdo.setVisible(false);
			self.addChild(self.pointerUp_sdo);
				
			self.pointerDown_img = new Image();
			self.pointerDown_img.src = self.bottomPointer_str;
			self.pointerDown_sdo = new FWDSimpleDisplayObject("img");
			self.pointerDown_sdo.setScreen(self.pointerDown_img);
			self.pointerDown_sdo.setWidth(self.pointerWidth);
			self.pointerDown_sdo.setHeight(self.pointerHeight);
			self.pointerDown_sdo.setVisible(false);
			self.addChild(self.pointerDown_sdo);
			
			self.totalHeight += self.pointerHeight;
		};
		
		//##########################################//
		/* set label */
		//##########################################//
		self.setLabel = function(label){
			if(self == null) return;
			if(!self.middle_sdo) return;
			self.text_sdo.setInnerHTML(label);
			setTimeout(function(){
				self.middle_sdo.setWidth(self.text_sdo.screen.offsetWidth);
				self.right_sdo.setX(self.text_sdo.screen.offsetWidth + self.marginWidth);
				self.totalWidth = (self.marginWidth * 2) + self.text_sdo.screen.offsetWidth;
				},79);
			
		};
		
		self.positionPointer = function(offsetX, position){
			var finalX = 0;
			var finalY = 0;
	
			if(!offsetX) offsetX = 0;
			
			finalX = parseInt((self.totalWidth - self.pointerWidth)/2) + offsetX;
			if(finalX < 0) finalX = 0;
			if(position == FWDMarkerToolTip.POINTER_DOWN){
				finalY = self.totalHeight - self.pointerHeight - 1;
				self.pointerDown_sdo.setX(finalX);
				self.pointerDown_sdo.setY(finalY);
			}else{
				finalY = - self.pointerHeight + 1;
				self.pointerUp_sdo.setX(finalX);
				self.pointerUp_sdo.setY(finalY);
			}
		};
		
		//##########################################//
		/* show / hide*/
		//##########################################//
		self.show = function(){
			if(self.isShowed_bl) return;
			TweenMax.to(self, .4, {alpha:1, delay:.1, ease:Quart.easeOut});
			self.isShowed_bl = true;
		};
		
		self.hide = function(){
			if(!self.isShowed_bl) return;
			TweenMax.killTweensOf(self);
			self.setX(-5000);
			self.setAlpha(0);
			self.isShowed_bl = false;
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			TweenMax.killTweensOf(self);
			
			self.pointerUp_img = null;
			self.pointerDown_img = null;
			
			self.left_sdo.destroy();
			self.middle_sdo.destroy();
			self.right_sdo.destroy();
			self.text_sdo.destroy();
			self.pointerDown_sdo.destroy();
			
			self.leftImagePath_str = null;
			self.middleImagePath_str = null;
			self.rightImagePath_str = null;
			self.fontColor_str = null;
			self.bottomPointer_str = null;
			self.topPointer_str = null;
			self.pointerPosition_str = null;
			self.toolTipLabel_str = null;
			
			self.left_sdo = null;
			self.middle_sdo = null;
			self.right_sdo = null;
			self.text_sdo = null;
			self.pointerUp_sdo = null;
			self.pointerDown_sdo = null;
			
			leftImage_img = null;
			pointerDown_img = null;
			leftImagePath_str = null; 
			middleImagePath_str = null;
			rightImagePath_str = null;
			buttonToolTipFontColor_str = null;
			buttonToolTipTopPointer_str = null;
			buttonToolTipBottomPointer_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDMarkerToolTip.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDMarkerToolTip.setPrototype = function(){
		FWDMarkerToolTip.prototype = new FWDDisplayObject("div");
	};
	
	FWDMarkerToolTip.POINTER_UP = "pointerUp";
	FWDMarkerToolTip.POINTER_DOWN = "pointerDown";
	FWDMarkerToolTip.CLICK = "onClick";
	FWDMarkerToolTip.MOUSE_DOWN = "onMouseDown";
	
	FWDMarkerToolTip.prototype = null;
	window.FWDMarkerToolTip = FWDMarkerToolTip;
}(window));/* FWDMarkerWindowToolTip */
(function (window){
var FWDMarkerWindowToolTip = function(
			parent,
			pointerDown_img,
			buttonToolTipTopPointer_str,
			buttonToolTipBottomPointer_str
		){
		
		var self = this;
		var prototype = FWDMarkerWindowToolTip.prototype;
		
		self.pointerUp_img;
		self.pointerDown_img;
		
		self.text_sdo = null;
		self.pointerUp_sdo = null;
		self.pointerDown_sdo = null;
	
		self.bottomPointer_str = buttonToolTipBottomPointer_str;
		self.topPointer_str = buttonToolTipTopPointer_str;
		self.pointerPosition_str;
		self.toolTipLabel_str;
		
		self.totalHeight = 0;
		self.pointerWidth = pointerDown_img.width;
		self.pointerHeight = pointerDown_img.height;
		self.totalWidth;
		self.maxWidth;
		
		self.isMobile_bl = FWDUtils.isMobile;
		self.isShowed_bl = true;
		self.hasLabel_bl = false;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			//self.setBackfaceVisibility();
			self.setupMainContainers();
			self.hide();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){	

			self.text_sdo = new FWDSimpleDisplayObject("div");
			self.text_sdo.setBackfaceVisibility();
			self.text_sdo.getStyle().fontSmoothing = "antialiased";
			self.text_sdo.getStyle().webkitFontSmoothing = "antialiased";
			self.text_sdo.getStyle().textRendering = "optimizeLegibility";	
			self.addChild(self.text_sdo);
			
			self.pointerUp_img = new Image();
			self.pointerUp_img.src = self.topPointer_str;
			self.pointerUp_sdo = new FWDSimpleDisplayObject("img");
			self.pointerUp_sdo.setScreen(self.pointerUp_img);
			self.pointerUp_sdo.setWidth(self.pointerWidth);
			self.pointerUp_sdo.setHeight(self.pointerHeight);
			self.pointerUp_sdo.setVisible(false);
			self.addChild(self.pointerUp_sdo);
				
			self.pointerDown_img = new Image();
			self.pointerDown_img.src = self.bottomPointer_str;
			self.pointerDown_sdo = new FWDSimpleDisplayObject("img");
			self.pointerDown_sdo.setScreen(self.pointerDown_img);
			self.pointerDown_sdo.setWidth(self.pointerWidth);
			self.pointerDown_sdo.setHeight(self.pointerHeight);
			self.pointerDown_sdo.setVisible(false);
			self.addChild(self.pointerDown_sdo);
		};
		
		//##########################################//
		/* set label */
		//##########################################//
		self.setLabel = function(label, maxWidth){
			if(self == null) return;
			self.maxWidth = maxWidth;
			var curWidth = Math.min(self.maxWidth, parent.stageWidth);
			self.totalWidth = curWidth;
			self.setWidth(self.totalWidth);
			
			self.text_sdo.setInnerHTML(label);
			setTimeout(function(){
				self.totalHeight = self.text_sdo.getHeight() + self.pointerHeight;
				self.setWidth(self.totalWidth);
				self.setHeight(self.totalHeight - self.pointerHeight);
				},79);
			
		};
		
		self.positionPointer = function(offsetX, position){
			var finalX = 0;
			var finalY = 0;
	
			if(!offsetX) offsetX = 0;
			
			finalX = parseInt((self.totalWidth - self.pointerWidth)/2) + offsetX;
			if(finalX < 0) finalX = 0;
			if(position == FWDMarkerWindowToolTip.POINTER_DOWN){
				finalY = self.totalHeight - self.pointerHeight - 1;
				self.pointerDown_sdo.setX(finalX);
				self.pointerDown_sdo.setY(finalY);
			}else{
				finalY = - self.pointerHeight + 1;
				self.pointerUp_sdo.setX(finalX);
				self.pointerUp_sdo.setY(finalY);
			}
		};
		
		//##########################################//
		/* show / hide*/
		//##########################################//
		self.show = function(){
			if(self.isShowed_bl) return;
			self.positionPointer();
			if(self.isMobile_bl){
				self.setAlpha(1);
			}else{
				TweenMax.to(self, .4, {alpha:1, delay:.1, ease:Quart.easeOut});
			}
			self.isShowed_bl = true;
		};
		
		self.hide = function(){
			if(!self.isShowed_bl) return;
			if(!self.isMobile_bl) TweenMax.killTweensOf(self);
			self.setX(-5000);
			self.setAlpha(0);
			self.text_sdo.setInnerHTML("");
			self.isShowed_bl = false;
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			TweenMax.killTweensOf(self);
			
			self.text_sdo.destroy();
			self.pointerUp_sdo.destroy();
			self.pointerDown_sdo.destroy();
		
			self.text_sdo = null;
			self.pointerUp_sdo = null;
			self.pointerDown_sdo = null;
		
			self.pointerUp_img = null;
			self.pointerDown_img = null;
			self.bottomPointer_str = null;
			self.topPointer_str = null;
			self.pointerPosition_str = null;
			self.toolTipLabel_str = null;
			
			parent = null;
			pointerDown_img = null;
			buttonToolTipTopPointer_str = null;
			buttonToolTipBottomPointer_str = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDMarkerWindowToolTip.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDMarkerWindowToolTip.setPrototype = function(){
		FWDMarkerWindowToolTip.prototype = null;
		FWDMarkerWindowToolTip.prototype = new FWDDisplayObject("div");
	};
	
	FWDMarkerWindowToolTip.POINTER_UP = "pointerUp";
	FWDMarkerWindowToolTip.POINTER_DOWN = "pointerDown";
	FWDMarkerWindowToolTip.CLICK = "onClick";
	FWDMarkerWindowToolTip.MOUSE_DOWN = "onMouseDown";
	
	FWDMarkerWindowToolTip.prototype = null;
	window.FWDMarkerWindowToolTip = FWDMarkerWindowToolTip;
}(window));/**
 * VERSION: beta 1.542
 * DATE: 2012-10-01
 * JavaScript (ActionScript 3 and 2 also available)
 * UPDATES AND DOCS AT: http://www.greensock.com
 * 
 * Includes all of the following: TweenLite, TweenMax, TimelineLite, TimelineMax, easing.EasePack, plugins.CSSPlugin, plugins.RoundPropsPlugin, plugins.BezierPlugin
 *
 * Copyright (c) 2008-2012, GreenSock. All rights reserved. 
 * This work is subject to the terms in http://www.greensock.com/terms_of_use.html or for 
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 **/

(window._gsQueue || (window._gsQueue = [])).push( function() {

/*
 * ----------------------------------------------------------------
 * TweenMax
 * ----------------------------------------------------------------
 */
	_gsDefine("TweenMax", ["core.Animation","core.SimpleTimeline","TweenLite"], function(Animation, SimpleTimeline, TweenLite) {
		
		var TweenMax = function(target, duration, vars) {
				TweenLite.call(this, target, duration, vars);
				this._cycle = 0;
				this._yoyo = (this.vars.yoyo == true);
				this._repeat = this.vars.repeat || 0;
				this._repeatDelay = this.vars.repeatDelay || 0;
				this._dirty = true; //ensures that if there is any repeat, the totalDuration will get recalculated to accurately report it.
			},
			p = TweenMax.prototype = TweenLite.to({}, 0.1, {}),
			_blankArray = [];
			
		p.constructor = TweenMax;
		p.kill()._gc = false;
		TweenMax.killTweensOf = TweenMax.killDelayedCallsTo = TweenLite.killTweensOf;
		TweenMax.getTweensOf = TweenLite.getTweensOf;
		TweenMax.ticker = TweenLite.ticker;
	
		p.invalidate = function() {
			this._yoyo = (this.vars.yoyo == true);
			this._repeat = this.vars.repeat || 0;
			this._repeatDelay = this.vars.repeatDelay || 0;
			this._uncache(true);
			return TweenLite.prototype.invalidate.call(this);
		};
		
		p.updateTo = function(vars, resetDuration) {
			var curRatio = this.ratio, p;
			if (resetDuration) if (this.timeline != null) if (this._startTime < this._timeline._time) {
				this._startTime = this._timeline._time;
				this._uncache(false);
				if (this._gc) {
					this._enabled(true, false);
				} else {
					this._timeline.insert(this, this._startTime - this._delay); //ensures that any necessary re-sequencing of Animations in the timeline occurs to make sure the rendering order is correct.
				}
			}
			for (p in vars) {
				this.vars[p] = vars[p];
			}
			if (this._initted) {
				if (resetDuration) {
					this._initted = false;
				} else {
					if (this._notifyPluginsOfEnabled && this._firstPT) {
						TweenLite._onPluginEvent("_onDisable", this); //in case a plugin like MotionBlur must perform some cleanup tasks
					}
					if (this._time / this._duration > 0.998) { //if the tween has finished (or come extremely close to finishing), we just need to rewind it to 0 and then render it again at the end which forces it to re-initialize (parsing the new vars). We allow tweens that are close to finishing (but haven't quite finished) to work this way too because otherwise, the values are so small when determining where to project the starting values that binary math issues creep in and can make the tween appear to render incorrectly when run backwards. 
						var prevTime = this._time;
						this.render(0, true, false);
						this._initted = false;
						this.render(prevTime, true, false);
					} else if (this._time > 0) {
						this._initted = false;
						this._init();
						var inv = 1 / (1 - curRatio),
							pt = this._firstPT, endValue;
						while (pt) {
							endValue = pt.s + pt.c; 
							pt.c *= inv;
							pt.s = endValue - pt.c;
							pt = pt._next;
						}
					}
				}
			}
			return this;
		};
				
		p.render = function(time, suppressEvents, force) {
			var totalDur = (!this._dirty) ? this._totalDuration : this.totalDuration(), 
				prevTime = this._time,
				prevTotalTime = this._totalTime, 
				prevCycle = this._cycle, 
				isComplete, callback, pt;
			if (time >= totalDur) {
				this._totalTime = totalDur;
				this._cycle = this._repeat;
				if (this._yoyo && (this._cycle & 1) !== 0) {
					this._time = 0;
					this.ratio = this._ease._calcEnd ? this._ease.getRatio(0) : 0;
				} else {
					this._time = this._duration;
					this.ratio = this._ease._calcEnd ? this._ease.getRatio(1) : 1;
				}
				if (!this._reversed) {
					isComplete = true;
					callback = "onComplete";
				}
				if (this._duration === 0) { //zero-duration tweens are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
					if (time === 0 || this._rawPrevTime < 0) if (this._rawPrevTime !== time) {
						force = true;
					}
					this._rawPrevTime = time;
				}
				
			} else if (time <= 0) {
				this._totalTime = this._time = this._cycle = 0;
				this.ratio = this._ease._calcEnd ? this._ease.getRatio(0) : 0;
				if (prevTotalTime !== 0 || (this._duration === 0 && this._rawPrevTime > 0)) {
					callback = "onReverseComplete";
					isComplete = this._reversed;
				}
				if (time < 0) {
					this._active = false;
					if (this._duration === 0) { //zero-duration tweens are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
						if (this._rawPrevTime >= 0) {
							force = true;
						}
						this._rawPrevTime = time;
					}
				} else if (!this._initted) { //if we render the very beginning (time == 0) of a fromTo(), we must force the render (normal tweens wouldn't need to render at a time of 0 when the prevTime was also 0). This is also mandatory to make sure overwriting kicks in immediately.
					force = true;
				}
			} else {
				this._totalTime = this._time = time;
				
				if (this._repeat !== 0) {
					var cycleDuration = this._duration + this._repeatDelay;
					this._cycle = (this._totalTime / cycleDuration) >> 0; //originally _totalTime % cycleDuration but floating point errors caused problems, so I normalized it. (4 % 0.8 should be 0 but Flash reports it as 0.79999999!)
					if (this._cycle !== 0) if (this._cycle === this._totalTime / cycleDuration) {
						this._cycle--; //otherwise when rendered exactly at the end time, it will act as though it is repeating (at the beginning)
					}
					this._time = this._totalTime - (this._cycle * cycleDuration);
					if (this._yoyo) if ((this._cycle & 1) !== 0) {
						this._time = this._duration - this._time;
					}
					if (this._time > this._duration) {
						this._time = this._duration;
					} else if (this._time < 0) {
						this._time = 0;
					}
				}
				
				if (this._easeType) {
					var r = this._time / this._duration, 
						type = this._easeType, 
						pow = this._easePower;
					if (type === 1 || (type === 3 && r >= 0.5)) {
						r = 1 - r;
					}
					if (type === 3) {
						r *= 2;
					}
					if (pow === 1) {
						r *= r;
					} else if (pow === 2) {
						r *= r * r;
					} else if (pow === 3) {
						r *= r * r * r;
					} else if (pow === 4) {
						r *= r * r * r * r;
					}
					
					if (type === 1) {
						this.ratio = 1 - r;
					} else if (type === 2) {
						this.ratio = r;
					} else if (this._time / this._duration < 0.5) {
						this.ratio = r / 2;
					} else {
						this.ratio = 1 - (r / 2);
					}
					
				} else {
					this.ratio = this._ease.getRatio(this._time / this._duration);
				}
				
			}
				
			if (prevTime === this._time && !force) {
				return;
			} else if (!this._initted) {
				this._init();
				if (!isComplete && this._time) { //_ease is initially set to defaultEase, so now that init() has run, _ease is set properly and we need to recalculate the ratio. Overall this is faster than using conditional logic earlier in the method to avoid having to set ratio twice because we only init() once but renderTime() gets called VERY frequently.
					this.ratio = this._ease.getRatio(this._time / this._duration);
				}
			}
			
			
			
			if (!this._active) if (!this._paused) {
				this._active = true; //so that if the user renders a tween (as opposed to the timeline rendering it), the timeline is forced to re-render and align it with the proper time/frame on the next rendering cycle. Maybe the tween already finished but the user manually re-renders it as halfway done.
			}
			if (prevTotalTime == 0) if (this.vars.onStart) if (this._totalTime !== 0 || this._duration === 0) if (!suppressEvents) {
				this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || _blankArray);
			}
			
			pt = this._firstPT;
			
			while (pt) 
			{
				if (pt.f) 
				{
					pt.t[pt.p](pt.c * this.ratio + pt.s);
				} 
				else 
				{
					var newVal = pt.c * this.ratio + pt.s;
				
					if (pt.p == "x")
					{
						pt.t.setX(newVal);
					}
					else if (pt.p == "y")
					{
						pt.t.setY(newVal);
					}
					else if (pt.p == "w")
					{
						pt.t.setWidth(newVal);
					}
					else if (pt.p == "h")
					{
						pt.t.setHeight(newVal);
					}
					else if (pt.p == "alpha")
					{
						pt.t.setAlpha(newVal);
					}
					else
					{
						pt.t[pt.p] = newVal;
					}
				}
				
				pt = pt._next;
			}
			
			if (this._onUpdate) if (!suppressEvents) {
				this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || _blankArray);
			}
			if (this._cycle != prevCycle) if (!suppressEvents) if (!this._gc) if (this.vars.onRepeat) {
				this.vars.onRepeat.apply(this.vars.onRepeatScope || this, this.vars.onRepeatParams || _blankArray);
			}
			if (callback) if (!this._gc) { //check gc because there's a chance that kill() could be called in an onUpdate
				if (isComplete) {
					if (this._timeline.autoRemoveChildren) {
						this._enabled(false, false);
					}
					this._active = false;
				}
				if (!suppressEvents) if (this.vars[callback]) {
					this.vars[callback].apply(this.vars[callback + "Scope"] || this, this.vars[callback + "Params"] || _blankArray);
				}
			}
		};
		
//---- STATIC FUNCTIONS -----------------------------------------------------------------------------------------------------------
		
		TweenMax.to = function(target, duration, vars) {
			return new TweenMax(target, duration, vars);
		};
		
		TweenMax.from = function(target, duration, vars) {
			vars.runBackwards = true;
			if (vars.immediateRender != false) {
				vars.immediateRender = true;
			}
			return new TweenMax(target, duration, vars);
		};
		
		TweenMax.fromTo = function(target, duration, fromVars, toVars) {
			toVars.startAt = fromVars;
			if (fromVars.immediateRender) {
				toVars.immediateRender = true;
			}
			return new TweenMax(target, duration, toVars);
		};
		
		TweenMax.staggerTo = TweenMax.allTo = function(targets, duration, vars, stagger, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			stagger = stagger || 0;
			var a = [],
				l = targets.length,
				delay = vars.delay || 0,
				copy, i, p;
			for (i = 0; i < l; i++) {
				copy = {};
				for (p in vars) {
					copy[p] = vars[p];
				}
				copy.delay = delay;
				if (i === l - 1) if (onCompleteAll) {
					copy.onComplete = function() {
						if (vars.onComplete) {
							vars.onComplete.apply(vars.onCompleteScope, vars.onCompleteParams);
						}
						onCompleteAll.apply(onCompleteAllScope, onCompleteAllParams);
					}
				}
				a[i] = new TweenMax(targets[i], duration, copy);
				delay += stagger;
			}
			return a;
		};
		
		TweenMax.staggerFrom = TweenMax.allFrom = function(targets, duration, vars, stagger, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			vars.runBackwards = true;
			if (vars.immediateRender != false) {
				vars.immediateRender = true;
			}
			return TweenMax.staggerTo(targets, duration, vars, stagger, onCompleteAll, onCompleteAllParams, onCompleteAllScope);
		};
		
		TweenMax.staggerFromTo = TweenMax.allFromTo = function(targets, duration, fromVars, toVars, stagger, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			toVars.startAt = fromVars;
			if (fromVars.immediateRender) {
				toVars.immediateRender = true;
			}
			return TweenMax.staggerTo(targets, duration, toVars, stagger, onCompleteAll, onCompleteAllParams, onCompleteAllScope);
		};
				
		TweenMax.delayedCall = function(delay, callback, params, scope, useFrames) {
			return new TweenMax(callback, 0, {delay:delay, onComplete:callback, onCompleteParams:params, onCompleteScope:scope, onReverseComplete:callback, onReverseCompleteParams:params, onReverseCompleteScope:scope, immediateRender:false, useFrames:useFrames, overwrite:0});
		};
		
		TweenMax.set = function(target, vars) {
			return new TweenMax(target, 0, vars);
		};
		
		TweenMax.isTweening = function(target) {
			var a = TweenLite.getTweensOf(target),
				i = a.length,
				tween;
			while (--i > -1) {
				if (((tween = a[i])._active || (tween._startTime === tween.timeline._time && tween.timeline._active))) {
					return true;
				}
			}
			return false;
		};
		
		var _getChildrenOf = function(timeline, includeTimelines) {
				var a = [],
					cnt = 0,
					tween = timeline._first;
				while (tween) {
					if (tween instanceof TweenLite) {
						a[cnt++] = tween;
					} else {
						if (includeTimelines) {
							a[cnt++] = tween;
						}
						a = a.concat(_getChildrenOf(tween, includeTimelines));
						cnt = a.length;
					}
					tween = tween._next;
				}
				return a;
			}, 
			getAllTweens = TweenMax.getAllTweens = function(includeTimelines) {
				var a = _getChildrenOf(Animation._rootTimeline, includeTimelines);
				return a.concat( _getChildrenOf(Animation._rootFramesTimeline, includeTimelines) );
			};
		
		TweenMax.killAll = function(complete, tweens, delayedCalls, timelines) {
			if (tweens == null) {
				tweens = true;
			}
			if (delayedCalls == null) {
				delayedCalls = true;
			}
			var a = getAllTweens((timelines != false)),
				l = a.length,
				allTrue = (tweens && delayedCalls && timelines),
				isDC, tween, i;
			for (i = 0; i < l; i++) {
				tween = a[i];
				if (allTrue || (tween instanceof SimpleTimeline) || ((isDC = (tween.target === tween.vars.onComplete)) && delayedCalls) || (tweens && !isDC)) {
					if (complete) {
						tween.totalTime(tween.totalDuration());
					} else {
						tween._enabled(false, false);
					}
				}
			}
		};
		
		TweenMax.killChildTweensOf = function(parent, complete) {
			if (parent == null) {
				return;
			}
			if (parent.jquery) {
				parent.each( function(i, e) {
					TweenMax.killChildTweensOf(e, complete);
				});
				return;
			}
			var tl = TweenLite._tweenLookup,
				a = [],
				target, curParent, p, i, l;
			for (p in tl) {
				curParent = tl[p].target.parentNode;
				while (curParent) {
					if (curParent === parent) {
						a = a.concat(tl[p].tweens);
					}
					curParent = curParent.parentNode;
				}
			}
			l = a.length;
			for (i = 0; i < l; i++) {
				if (complete) {
					a[i].totalTime(a[i].totalDuration());
				}
				a[i]._enabled(false, false);
			}
		};
		
		TweenMax.pauseAll = function(tweens, delayedCalls, timelines) {
			_changePause(true, tweens, delayedCalls, timelines);
		};
		
		TweenMax.resumeAll = function(tweens, delayedCalls, timelines) {
			_changePause(false, tweens, delayedCalls, timelines);
		};
		
		var _changePause = function(pause, tweens, delayedCalls, timelines) {
			if (tweens == undefined) {
				tweens = true;
			}
			if (delayedCalls == undefined) {
				delayedCalls = true;
			}
			var a = getAllTweens(timelines),
				allTrue = (tweens && delayedCalls && timelines),
				i = a.length,
				isDC, tween;
			while (--i > -1) {
				tween = a[i];
				if (allTrue || (tween instanceof SimpleTimeline) || ((isDC = (tween.target === tween.vars.onComplete)) && delayedCalls) || (tweens && !isDC)) {
					tween.paused(pause);
				}
			}
		};
		
	
//---- GETTERS / SETTERS ----------------------------------------------------------------------------------------------------------
		
		p.progress = function(value) {
			return (!arguments.length) ? this._time / this.duration() : this.totalTime( this.duration() * value + (this._cycle * this._duration), false);
		};
		
		p.totalProgress = function(value) {
			return (!arguments.length) ? this._totalTime / this.totalDuration() : this.totalTime( this.totalDuration() * value, false);
		};
		
		p.time = function(value, suppressEvents) {
			if (!arguments.length) {
				return this._time;
			}
			if (this._dirty) {
				this.totalDuration();
			}
			if (value > this._duration) {
				value = this._duration;
			}
			if (this._yoyo && (this._cycle & 1) !== 0) {
				value = (this._duration - value) + (this._cycle * (this._duration + this._repeatDelay));
			} else if (this._repeat != 0) {
				value += this._cycle * (this._duration + this._repeatDelay);
			}
			return this.totalTime(value, suppressEvents);
		};
		
		p.totalDuration = function(value) {
			if (!arguments.length) {
				if (this._dirty) {
					//instead of Infinity, we use 999999999999 so that we can accommodate reverses
					this._totalDuration = (this._repeat === -1) ? 999999999999 : this._duration * (this._repeat + 1) + (this._repeatDelay * this._repeat);
					this._dirty = false;
				}
				return this._totalDuration;
			}
			return (this._repeat == -1) ? this : this.duration( (value - (this._repeat * this._repeatDelay)) / (this._repeat + 1) );
		};
		
		p.repeat = function(value) {
			if (!arguments.length) {
				return this._repeat;
			}
			this._repeat = value;
			return this._uncache(true);
		};
		
		p.repeatDelay = function(value) {
			if (!arguments.length) {
				return this._repeatDelay;
			}
			this._repeatDelay = value;
			return this._uncache(true);
		};
		
		p.yoyo = function(value) {
			if (!arguments.length) {
				return this._yoyo;
			}
			this._yoyo = value;
			return this;
		};
		
		
		return TweenMax;
		
	}, true);








/*
 * ----------------------------------------------------------------
 * TimelineLite 													(!TimelineLite)
 * ----------------------------------------------------------------
 */
	_gsDefine("TimelineLite", ["core.Animation","core.SimpleTimeline","TweenLite"], function(Animation, SimpleTimeline, TweenLite) {
		
		"use strict";
		
		var TimelineLite = function(vars) {
				SimpleTimeline.call(this, vars);
				this._labels = {};
				this.autoRemoveChildren = (this.vars.autoRemoveChildren == true);
				this.smoothChildTiming = (this.vars.smoothChildTiming == true);
				this._sortChildren = true;
				this._onUpdate = this.vars.onUpdate;
				var i = _paramProps.length,
					j, a;
				while (--i > -1) {
					if ((a = this.vars[_paramProps[i]])) {
						j = a.length;
						while (--j > -1) {
							if (a[j] === "{self}") {
								a = this.vars[_paramProps[i]] = a.concat(); //copy the array in case the user referenced the same array in multiple timelines/tweens (each {self} should be unique)
								a[j] = this;
							}
						}
					}
				}
				if (this.vars.tweens instanceof Array) {
					this.insertMultiple(this.vars.tweens, 0, this.vars.align || "normal", this.vars.stagger || 0);
				}
			},
			_paramProps = ["onStartParams","onUpdateParams","onCompleteParams","onReverseCompleteParams","onRepeatParams"],
			_blankArray = [],
			_copy = function(vars) {
				var copy = {}, p;
				for (p in vars) {
					copy[p] = vars[p];
				}
				return copy;
			},
			p = TimelineLite.prototype = new SimpleTimeline();
			
		p.constructor = TimelineLite;
		p.kill()._gc = false;
		
		p.to = function(target, duration, vars, offset, baseTimeOrLabel) {
			return this.insert( new TweenLite(target, duration, vars), this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0)); 
		}
		
		p.from = function(target, duration, vars, offset, baseTimeOrLabel) {
			return this.insert( TweenLite.from(target, duration, vars), this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0));
		}
		
		p.fromTo = function(target, duration, fromVars, toVars, offset, baseTimeOrLabel) {
			return this.insert( TweenLite.fromTo(target, duration, fromVars, toVars), this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0));
		}
		
		p.staggerTo = function(targets, duration, vars, stagger, offset, baseTimeOrLabel, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			var tl = new TimelineLite({onComplete:onCompleteAll, onCompleteParams:onCompleteAllParams, onCompleteScope:onCompleteAllScope});
			stagger = stagger || 0;
			for (var i = 0; i < targets.length; i++) {
				if (vars.startAt != null) {
					vars.startAt = _copy(vars.startAt);
				}
				tl.insert( new TweenLite(targets[i], duration, _copy(vars)), i * stagger);
			}
			return this.insert(tl, this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0));
		}
		
		p.staggerFrom = function(targets, duration, vars, stagger, offset, baseTimeOrLabel, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			if (vars.immediateRender == null) {
				vars.immediateRender = true;
			}
			vars.runBackwards = true;
			return this.staggerTo(targets, duration, vars, stagger, offset, baseTimeOrLabel, onCompleteAll, onCompleteAllParams, onCompleteAllScope);
		}
		
		p.staggerFromTo = function(targets, duration, fromVars, toVars, stagger, offset, baseTimeOrLabel, onCompleteAll, onCompleteAllParams, onCompleteAllScope) {
			toVars.startAt = fromVars;
			if (fromVars.immediateRender) {
				toVars.immediateRender = true;
			}
			return this.staggerTo(targets, duration, toVars, stagger, offset, baseTimeOrLabel, onCompleteAll, onCompleteAllParams, onCompleteAllScope);
		}
		
		p.call = function(callback, params, scope, offset, baseTimeOrLabel) {
			return this.insert( TweenLite.delayedCall(0, callback, params, scope), this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0));
		}
		
		p.set = function(target, vars, offset, baseTimeOrLabel) {
			vars.immediateRender = false;
			return this.insert( new TweenLite(target, 0, vars), this._parseTimeOrLabel(baseTimeOrLabel) + (offset || 0));
		}
		
		TimelineLite.exportRoot = function(vars, ignoreDelayedCalls) {
			vars = vars || {};
			if (vars.smoothChildTiming == null) {
				vars.smoothChildTiming = true;
			}
			var tl = new TimelineLite(vars),
				root = tl._timeline;
			if (ignoreDelayedCalls == null) {
				ignoreDelayedCalls = true;
			}
			root._remove(tl, true);
			tl._startTime = 0;
			tl._rawPrevTime = tl._time = tl._totalTime = root._time;
			var tween = root._first, next;
			while (tween) {
				next = tween._next;
				if (!ignoreDelayedCalls || !(tween instanceof TweenLite && tween.target == tween.vars.onComplete)) {
					tl.insert(tween, tween._startTime - tween._delay);
				}
				tween = next;
			}
			root.insert(tl, 0);
			return tl;
		}
		
		p.insert = function(value, timeOrLabel) {
			if (value instanceof Animation) {
				//continue...
			} else if (value instanceof Array) {
				return this.insertMultiple(value, timeOrLabel);
			} else if (typeof(value) === "string") {
				return this.addLabel(value, this._parseTimeOrLabel(timeOrLabel || 0, true));
			} else if (typeof(value) === "function") {
				value = TweenLite.delayedCall(0, value);
			} else {
				throw ("ERROR: Cannot insert() " + value + " into the TimelineLite/Max because it is neither a tween, timeline, function, nor a String.");
				return this;
			}
			
			SimpleTimeline.prototype.insert.call(this, value, this._parseTimeOrLabel(timeOrLabel || 0, true));
			
			//if the timeline has already ended but the inserted tween/timeline extends the duration, we should enable this timeline again so that it renders properly.  
			if (this._gc) if (!this._paused) if (this._time === this._duration) if (this._time < this.duration()) {
				//in case any of the anscestors had completed but should now be enabled...
				var tl = this;
				while (tl._gc && tl._timeline) {
					if (tl._timeline.smoothChildTiming) {
						tl.totalTime(tl._totalTime, true); //also enables them
					} else {
						tl._enabled(true, false);
					}
					tl = tl._timeline;
				}
			}
			return this;
		}
		
		p.remove = function(value) {
			if (value instanceof Animation) {
				return this._remove(value, false);
			} else if (value instanceof Array) {
				var i = value.length;
				while (--i > -1) {
					this.remove(value[i]);
				}
				return this;
			} else if (typeof(value) === "string") {
				return this.removeLabel(value);
			}
			return this.kill(null, value);
		}
		
		p.append = function(value, offset) {
			return this.insert(value, this.duration() + (offset || 0));
		}
		
		p.insertMultiple = function(tweens, timeOrLabel, align, stagger) {
			align = align || "normal";
			stagger = stagger || 0;
			var i, tween, curTime = this._parseTimeOrLabel(timeOrLabel || 0, true), l = tweens.length;
			for (i = 0; i < l; i++) {
				if ((tween = tweens[i]) instanceof Array) {
					tween = new TimelineLite({tweens:tween});
				}
				this.insert(tween, curTime);
				if (typeof(tween) === "string" || typeof(tween) === "function") {
					//do nothing
				} else if (align === "sequence") {
					curTime = tween._startTime + (tween.totalDuration() / tween._timeScale);
				} else if (align === "start") {
					tween._startTime -= tween.delay();
				}
				curTime += stagger;
			}
			return this._uncache(true);
		}
		
		p.appendMultiple = function(tweens, offset, align, stagger) {
			return this.insertMultiple(tweens, this.duration() + (offset || 0), align, stagger);
		}
		
		p.addLabel = function(label, time) {
			this._labels[label] = time;
			return this;
		}
	
		p.removeLabel = function(label) {
			delete this._labels[label];
			return this;
		}
		
		p.getLabelTime = function(label) {
			return (this._labels[label] != null) ? this._labels[label] : -1;
		}
		
		p._parseTimeOrLabel = function(timeOrLabel, appendIfAbsent) {
			if (timeOrLabel == null) {
				return this.duration();
			} else if (typeof(timeOrLabel) === "string" && isNaN(timeOrLabel)) {
				if (this._labels[timeOrLabel] == null) {
					return (appendIfAbsent) ? (this._labels[timeOrLabel] = this.duration()) : 0;
				}
				return this._labels[timeOrLabel];
			}
			return Number(timeOrLabel);
		}
		
		p.seek = function(timeOrLabel, suppressEvents) {
			return this.totalTime(this._parseTimeOrLabel(timeOrLabel, false), (suppressEvents != false));
		}
		
		p.stop = function() {
			return this.paused(true);
		}
	
		p.gotoAndPlay = function(timeOrLabel, suppressEvents) {
			return SimpleTimeline.prototype.play.call(this, timeOrLabel, suppressEvents);
		}
		
		p.gotoAndStop = function(timeOrLabel, suppressEvents) {
			return this.pause(timeOrLabel, suppressEvents);
		}
		
		p.render = function(time, suppressEvents, force) {
			if (this._gc) {
				this._enabled(true, false);
			}
			this._active = !this._paused; 
			var totalDur = (!this._dirty) ? this._totalDuration : this.totalDuration(), 
				prevTime = this._time, 
				prevStart = this._startTime, 
				prevTimeScale = this._timeScale, 
				prevPaused = this._paused,
				tween, isComplete, next, callback;
			if (time >= totalDur) {
				this._totalTime = this._time = totalDur;
				if (!this._reversed) if (!this._hasPausedChild()) {
					isComplete = true;
					callback = "onComplete";
					if (this._duration === 0) if (time === 0 || this._rawPrevTime < 0) if (this._rawPrevTime !== time) { //In order to accommodate zero-duration timelines, we must discern the momentum/direction of time in order to render values properly when the "playhead" goes past 0 in the forward direction or lands directly on it, and also when it moves past it in the backward direction (from a postitive time to a negative time).
						force = true;
					}
				}
				this._rawPrevTime = time;
				time = totalDur + 0.000001; //to avoid occassional floating point rounding errors - sometimes child tweens/timelines were not being fully completed (their progress might be 0.999999999999998 instead of 1 because when _time - tween._startTime is performed, floating point errors would return a value that was SLIGHTLY off)

			} else if (time <= 0) {
				this._totalTime = this._time = 0;
				if (prevTime !== 0 || (this._duration === 0 && this._rawPrevTime > 0)) {
					callback = "onReverseComplete";
					isComplete = this._reversed;
				}
				if (time < 0) {
					this._active = false;
					if (this._duration === 0) if (this._rawPrevTime >= 0) { //zero-duration timelines are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
						force = true;
					}
				} else if (!this._initted) {
					force = true;
				}
				this._rawPrevTime = time;
				time = -0.000001; //to avoid occassional floating point rounding errors in Flash - sometimes child tweens/timelines were not being rendered at the very beginning (their progress might be 0.000000000001 instead of 0 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
				
			} else {
				this._totalTime = this._time = this._rawPrevTime = time;
			}
			
			if (this._time === prevTime && !force) {
				return;
			} else if (!this._initted) {
				this._initted = true;
			}
			if (prevTime === 0) if (this.vars.onStart) if (this._time !== 0) if (!suppressEvents) {
				this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || _blankArray);
			}
			
			if (this._time > prevTime) {
				tween = this._first;
				while (tween) {
					next = tween._next; //record it here because the value could change after rendering...
					if (this._paused && !prevPaused) { //in case a tween pauses the timeline when rendering
						break;
					} else if (tween._active || (tween._startTime <= this._time && !tween._paused && !tween._gc)) {
						
						if (!tween._reversed) {
							tween.render((time - tween._startTime) * tween._timeScale, suppressEvents, false);
						} else {
							tween.render(((!tween._dirty) ? tween._totalDuration : tween.totalDuration()) - ((time - tween._startTime) * tween._timeScale), suppressEvents, false);
						}
						
					}
					tween = next;
				}
			} else {
				tween = this._last;
				while (tween) {
					next = tween._prev; //record it here because the value could change after rendering...
					if (this._paused && !prevPaused) { //in case a tween pauses the timeline when rendering
						break;
					} else if (tween._active || (tween._startTime <= prevTime && !tween._paused && !tween._gc)) {
						
						if (!tween._reversed) {
							tween.render((time - tween._startTime) * tween._timeScale, suppressEvents, false);
						} else {
							tween.render(((!tween._dirty) ? tween._totalDuration : tween.totalDuration()) - ((time - tween._startTime) * tween._timeScale), suppressEvents, false);
						}
						
					}
					tween = next;
				}
			}
			
			if (this._onUpdate) if (!suppressEvents) {
				this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || _blankArray);
			}
			
			if (callback) if (!this._gc) if (prevStart === this._startTime || prevTimeScale != this._timeScale) if (this._time === 0 || totalDur >= this.totalDuration()) { //if one of the tweens that was rendered altered this timeline's startTime (like if an onComplete reversed the timeline), it probably isn't complete. If it is, don't worry, because whatever call altered the startTime would complete if it was necessary at the new time. The only exception is the timeScale property. Also check _gc because there's a chance that kill() could be called in an onUpdate
				if (isComplete) {
					if (this._timeline.autoRemoveChildren) {
						this._enabled(false, false);
					}
					this._active = false;
				}
				if (!suppressEvents) if (this.vars[callback]) {
					this.vars[callback].apply(this.vars[callback + "Scope"] || this, this.vars[callback + "Params"] || _blankArray);
				}
			}
			
		}
		
		p._hasPausedChild = function() {
			var tween = this._first;
			while (tween) {
				if (tween._paused || ((tween instanceof TimelineLite) && tween._hasPausedChild())) {
					return true;
				}
				tween = tween._next;
			}
			return false;
		}
		
		p.getChildren = function(nested, tweens, timelines, ignoreBeforeTime) {
			ignoreBeforeTime = ignoreBeforeTime || -9999999999;
			var a = [], 
				tween = this._first, 
				cnt = 0;
			while (tween) {
				if (tween._startTime < ignoreBeforeTime) {
					//do nothing
				} else if (tween instanceof TweenLite) {
					if (tweens != false) {
						a[cnt++] = tween;
					}
				} else {
					if (timelines != false) {
						a[cnt++] = tween;
					}
					if (nested != false) {
						a = a.concat(tween.getChildren(true, tweens, timelines));
						cnt = a.length;
					}
				}
				tween = tween._next;
			}
			return a;
		}
		
		p.getTweensOf = function(target, nested) {
			var tweens = TweenLite.getTweensOf(target), 
				i = tweens.length, 
				a = [], 
				cnt = 0;
			while (--i > -1) {
				if (tweens[i].timeline === this || (nested && this._contains(tweens[i]))) {
					a[cnt++] = tweens[i];
				}
			}
			return a;
		}
		
		p._contains = function(tween) {
			var tl = tween.timeline;
			while (tl) {
				if (tl === this) {
					return true;
				}
				tl = tl.timeline;
			}
			return false;
		}
		
		p.shiftChildren = function(amount, adjustLabels, ignoreBeforeTime) {
			ignoreBeforeTime = ignoreBeforeTime || 0;
			var tween = this._first;
			while (tween) {
				if (tween._startTime >= ignoreBeforeTime) {
					tween._startTime += amount;
				}
				tween = tween._next;
			}
			if (adjustLabels) {
				for (var p in this._labels) {
					if (this._labels[p] >= ignoreBeforeTime) {
						this._labels[p] += amount;
					}
				}
			}
			return this._uncache(true);
		}
		
		p._kill = function(vars, target) {
			if (vars == null) if (target == null) {
				return this._enabled(false, false);
			}
			var tweens = (target == null) ? this.getChildren(true, true, false) : this.getTweensOf(target),
				i = tweens.length, 
				changed = false;
			while (--i > -1) {
				if (tweens[i]._kill(vars, target)) {
					changed = true;
				}
			}
			return changed;
		}
		
		p.clear = function(labels) {
			var tweens = this.getChildren(false, true, true),
				i = tweens.length;
			this._time = this._totalTime = 0;
			while (--i > -1) {
				tweens[i]._enabled(false, false);
			}
			if (labels != false) {
				this._labels = {};
			}
			return this._uncache(true);
		}
		
		p.invalidate = function() {
			var tween = this._first;
			while (tween) {
				tween.invalidate();
				tween = tween._next;
			}
			return this;
		}
		
		p._enabled = function(enabled, ignoreTimeline) {
			if (enabled == this._gc) {
				var tween = this._first;
				while (tween) {
					tween._enabled(enabled, true);
					tween = tween._next;
				}
			}
			return SimpleTimeline.prototype._enabled.call(this, enabled, ignoreTimeline);
		}
		
		p.progress = function(value) {
			return (!arguments.length) ? this._time / this.duration() : this.totalTime(this.duration() * value, false);
		}
		
		p.duration = function(value) {
			if (!arguments.length) {
				if (this._dirty) {
					this.totalDuration(); //just triggers recalculation
				}
				return this._duration;
			}
			if (this.duration() !== 0) if (value !== 0) {
				this.timeScale(this._duration / value);
			}
			return this;
		}
		
		p.totalDuration = function(value) {
			if (!arguments.length) {
				if (this._dirty) {
					var max = 0, 
						tween = this._first, 
						prevStart = -999999999999, 
						next, end;
					while (tween) {
						next = tween._next; //record it here in case the tween changes position in the sequence...
						
						if (tween._startTime < prevStart && this._sortChildren) { //in case one of the tweens shifted out of order, it needs to be re-inserted into the correct position in the sequence
							this.insert(tween, tween._startTime - tween._delay);
						} else {
							prevStart = tween._startTime;
						}
						if (tween._startTime < 0) {//children aren't allowed to have negative startTimes, so adjust here if one is found.
							max -= tween._startTime;
							this.shiftChildren(-tween._startTime, false, -9999999999);
						}
						end = tween._startTime + ((!tween._dirty ? tween._totalDuration : tween.totalDuration()) / tween._timeScale);
						if (end > max) {
							max = end;
						}
						
						tween = next;
					}
					this._duration = this._totalDuration = max;
					this._dirty = false;
				}
				return this._totalDuration;
			}
			if (this.totalDuration() !== 0) if (value !== 0) {
				this.timeScale(this._totalDuration / value);
			}
			return this;
		}
		
		p.usesFrames = function() {
			var tl = this._timeline;
			while (tl._timeline) {
				tl = tl._timeline;
			}
			return (tl === Animation._rootFramesTimeline);
		}
		
		p.rawTime = function() {
			return (this._paused || (this._totalTime !== 0 && this._totalTime !== this._totalDuration)) ? this._totalTime : (this._timeline.rawTime() - this._startTime) * this._timeScale;
		}
		
		return TimelineLite;
		
	}, true);
	




	
	
	
	
	
/*
 * ----------------------------------------------------------------
 * TimelineMax
 * ----------------------------------------------------------------
 */
	_gsDefine("TimelineMax", ["TimelineLite","TweenLite","easing.Ease"], function(TimelineLite, TweenLite, Ease) {
		
		var TimelineMax = function(vars) {
				TimelineLite.call(this, vars);
				this._repeat = this.vars.repeat || 0;
				this._repeatDelay = this.vars.repeatDelay || 0;
				this._cycle = 0;
				this._yoyo = (this.vars.yoyo == true);
				this._dirty = true;
			},
			_blankArray = [],
			_easeNone = new Ease(null, null, 1, 0),
			_getGlobalPaused = function(tween) {
				while (tween) {
					if (tween._paused) {
						return true;
					}
					tween = tween._timeline;
				}
				return false;
			},
			p = TimelineMax.prototype = new TimelineLite();
			
		p.constructor = TimelineMax;
		p.kill()._gc = false;
		TimelineMax.version = 12.0;
		
		p.invalidate = function() {
			this._yoyo = (this.vars.yoyo == true);
			this._repeat = this.vars.repeat || 0;
			this._repeatDelay = this.vars.repeatDelay || 0;
			this._uncache(true);
			return TimelineLite.prototype.invalidate.call(this);
		}
		
		p.addCallback = function(callback, timeOrLabel, params, scope) {
			return this.insert( TweenLite.delayedCall(0, callback, params, scope), timeOrLabel);
		}
		
		p.removeCallback = function(callback, timeOrLabel) {
			if (timeOrLabel == null) {
				this._kill(null, callback);
			} else {
				var a = this.getTweensOf(callback, false),
					i = a.length,
					time = this._parseTimeOrLabel(timeOrLabel, false);
				while (--i > -1) {
					if (a[i]._startTime === time) {
						a[i]._enabled(false, false);
					}
				}
			}
			return this;
		}
		
		p.tweenTo = function(timeOrLabel, vars) {
			vars = vars || {};
			var copy = {ease:_easeNone, overwrite:2, useFrames:this.usesFrames(), immediateRender:false}, p, t;
			for (p in vars) {
				copy[p] = vars[p];
			}
			copy.time = this._parseTimeOrLabel(timeOrLabel, false);
			t = new TweenLite(this, (Math.abs(Number(copy.time) - this._time) / this._timeScale) || 0.001, copy);
			copy.onStart = function() {
				t.target.paused(true);
				if (t.vars.time != t.target.time()) { //don't make the duration zero - if it's supposed to be zero, don't worry because it's already initting the tween and will complete immediately, effectively making the duration zero anyway. If we make duration zero, the tween won't run at all.
					t.duration( Math.abs( t.vars.time - t.target.time()) / t.target._timeScale );
				}
				if (vars.onStart) { //in case the user had an onStart in the vars - we don't want to overwrite it.
					vars.onStart.apply(vars.onStartScope || t, vars.onStartParams || _blankArray);
				}
			}
			return t;
		}
		
		p.tweenFromTo = function(fromTimeOrLabel, toTimeOrLabel, vars) {
			vars = vars || {};
			vars.startAt = {time:this._parseTimeOrLabel(fromTimeOrLabel, false)};
			var t = this.tweenTo(toTimeOrLabel, vars);
			return t.duration((Math.abs( t.vars.time - t.vars.startAt.time) / this._timeScale) || 0.001);
		}
		
		p.render = function(time, suppressEvents, force) {
			if (this._gc) {
				this._enabled(true, false);
			}
			this._active = !this._paused;
			var totalDur = (!this._dirty) ? this._totalDuration : this.totalDuration(), 
				prevTime = this._time, 
				prevTotalTime = this._totalTime, 
				prevStart = this._startTime, 
				prevTimeScale = this._timeScale, 
				prevRawPrevTime = this._rawPrevTime,
				prevPaused = this._paused, 
				prevCycle = this._cycle, 
				tween, isComplete, next, dur, callback;
			if (time >= totalDur) {
				if (!this._locked) {
					this._totalTime = totalDur;
					this._cycle = this._repeat;
				}
				if (!this._reversed) if (!this._hasPausedChild()) {
					isComplete = true;
					callback = "onComplete";
					if (this._duration === 0) if (time === 0 || this._rawPrevTime < 0) if (this._rawPrevTime !== time) { //In order to accommodate zero-duration timelines, we must discern the momentum/direction of time in order to render values properly when the "playhead" goes past 0 in the forward direction or lands directly on it, and also when it moves past it in the backward direction (from a postitive time to a negative time).
						force = true;
					}
				}
				this._rawPrevTime = time;
				if (this._yoyo && (this._cycle & 1) !== 0) {
					this._time = 0;
					time = -0.000001; //to avoid occassional floating point rounding errors - sometimes child tweens/timelines were not being rendered at the very beginning (their progress might be 0.000000000001 instead of 0 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
				} else {
					this._time = this._duration;
					time = this._duration + 0.000001; //to avoid occassional floating point rounding errors in Flash - sometimes child tweens/timelines were not being fully completed (their progress might be 0.999999999999998 instead of 1 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
				}
				
			} else if (time <= 0) {
				if (!this._locked) {
					this._totalTime = this._cycle = 0;
				}
				this._time = 0;
				if (prevTime !== 0 || (this._duration === 0 && this._rawPrevTime > 0)) {
					callback = "onReverseComplete";
					isComplete = this._reversed;
				}
				if (time < 0) {
					this._active = false;
					if (this._duration === 0) if (this._rawPrevTime >= 0) { //zero-duration timelines are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
						force = true;
					}
				} else if (!this._initted) {
					force = true;
				}
				this._rawPrevTime = time;
				time = -0.000001; //to avoid occassional floating point rounding errors in Flash - sometimes child tweens/timelines were not being rendered at the very beginning (their progress might be 0.000000000001 instead of 0 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
				
			} else {
				this._time = this._rawPrevTime = time;
				if (!this._locked) {
					this._totalTime = time;
					if (this._repeat !== 0) {
						var cycleDuration = this._duration + this._repeatDelay;
						this._cycle = (this._totalTime / cycleDuration) >> 0; //originally _totalTime % cycleDuration but floating point errors caused problems, so I normalized it. (4 % 0.8 should be 0 but Flash reports it as 0.79999999!)
						if (this._cycle !== 0) if (this._cycle === this._totalTime / cycleDuration) {
							this._cycle--; //otherwise when rendered exactly at the end time, it will act as though it is repeating (at the beginning)
						}
						this._time = this._totalTime - (this._cycle * cycleDuration);
						if (this._yoyo) if ((this._cycle & 1) != 0) {
							this._time = this._duration - this._time;
						}
						if (this._time > this._duration) {
							this._time = this._duration;
							time = this._duration + 0.000001; //to avoid occassional floating point rounding errors in Flash - sometimes child tweens/timelines were not being fully completed (their progress might be 0.999999999999998 instead of 1 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
						} else if (this._time < 0) {
							this._time = 0;
							time = -0.000001; //to avoid occassional floating point rounding errors in Flash - sometimes child tweens/timelines were not being rendered at the very beginning (their progress might be 0.000000000001 instead of 0 because when Flash performed _time - tween._startTime, floating point errors would return a value that was SLIGHTLY off)
						} else {
							time = this._time;
						}
					}
				}
			}
			
			if (this._cycle !== prevCycle) if (!this._locked) {
				/*
				make sure children at the end/beginning of the timeline are rendered properly. If, for example, 
				a 3-second long timeline rendered at 2.9 seconds previously, and now renders at 3.2 seconds (which
				would get transated to 2.8 seconds if the timeline yoyos or 0.2 seconds if it just repeats), there
				could be a callback or a short tween that's at 2.95 or 3 seconds in which wouldn't render. So 
				we need to push the timeline to the end (and/or beginning depending on its yoyo value). Also we must
				ensure that zero-duration tweens at the very beginning or end of the TimelineMax work. 
				*/
				var backwards = (this._yoyo && (prevCycle & 1) !== 0),
					wrap = (backwards === (this._yoyo && (this._cycle & 1) !== 0)),
					recTotalTime = this._totalTime,
					recCycle = this._cycle,
					recRawPrevTime = this._rawPrevTime,
					recTime = this._time;
				
				this._totalTime = prevCycle * this._duration;
				if (this._cycle < prevCycle) {
					backwards = !backwards;
				} else {
					this._totalTime += this._duration;
				}
				this._time = prevTime; //temporarily revert _time so that render() renders the children in the correct order. Without this, tweens won't rewind correctly. We could arhictect things in a "cleaner" way by splitting out the rendering queue into a separate method but for performance reasons, we kept it all inside this method.
				
				this._rawPrevTime = prevRawPrevTime;
				this._cycle = prevCycle;
				this._locked = true; //prevents changes to totalTime and skips repeat/yoyo behavior when we recursively call render()
				prevTime = (backwards) ? 0 : this._duration;	
				this.render(prevTime, suppressEvents, false);
				if (!suppressEvents) if (!this._gc) {
					if (this.vars.onRepeat) {
						this.vars.onRepeat.apply(this.vars.onRepeatScope || this, this.vars.onRepeatParams || _blankArray);
					}
				}
				if (wrap) {
					prevTime = (backwards) ? this._duration + 0.000001 : -0.000001;
					this.render(prevTime, true, false);
				}
				this._time = recTime;
				this._totalTime = recTotalTime;
				this._cycle = recCycle;
				this._rawPrevTime = recRawPrevTime;
				this._locked = false;
			}

			if (this._time === prevTime && !force) {
				return;
			} else if (!this._initted) {
				this._initted = true;
			}
			
			if (prevTotalTime === 0) if (this.vars.onStart) if (this._totalTime !== 0) if (!suppressEvents) {
				this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || _blankArray);
			}
			
			if (this._time > prevTime) {
				tween = this._first;
				while (tween) {
					next = tween._next; //record it here because the value could change after rendering...
					if (this._paused && !prevPaused) { //in case a tween pauses the timeline when rendering
						break;
					} else if (tween._active || (tween._startTime <= this._time && !tween._paused && !tween._gc)) {
						
						if (!tween._reversed) {
							tween.render((time - tween._startTime) * tween._timeScale, suppressEvents, false);
						} else {
							tween.render(((!tween._dirty) ? tween._totalDuration : tween.totalDuration()) - ((time - tween._startTime) * tween._timeScale), suppressEvents, false);
						}
						
					}
					tween = next;
				}
			} else {
				tween = this._last;
				while (tween) {
					next = tween._prev; //record it here because the value could change after rendering...
					if (this._paused && !prevPaused) { //in case a tween pauses the timeline when rendering
						break;
					} else if (tween._active || (tween._startTime <= prevTime && !tween._paused && !tween._gc)) {
						
						if (!tween._reversed) {
							tween.render((time - tween._startTime) * tween._timeScale, suppressEvents, false);
						} else {
							tween.render(((!tween._dirty) ? tween._totalDuration : tween.totalDuration()) - ((time - tween._startTime) * tween._timeScale), suppressEvents, false);
						}
						
					}
					tween = next;
				}
			}
			
			if (this._onUpdate) if (!suppressEvents) {
				this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || _blankArray);
			}
			
			if (callback) if (!this._locked) if (!this._gc) if (prevStart === this._startTime || prevTimeScale != this._timeScale) if (this._time === 0 || totalDur >= this.totalDuration()) { //if one of the tweens that was rendered altered this timeline's startTime (like if an onComplete reversed the timeline), it probably isn't complete. If it is, don't worry, because whatever call altered the startTime would complete if it was necessary at the new time. The only exception is the timeScale property. Also check _gc because there's a chance that kill() could be called in an onUpdate
				if (isComplete) {
					if (this._timeline.autoRemoveChildren) {
						this._enabled(false, false);
					}
					this._active = false;
				}
				if (!suppressEvents) if (this.vars[callback]) {
					this.vars[callback].apply(this.vars[callback + "Scope"] || this, this.vars[callback + "Params"] || _blankArray);
				}
			}
		}
		
		p.getActive = function(nested, tweens, timelines) {
			if (nested == null) {
				nested = true;
			}
			if (tweens == null) {
				tweens = true;
			}
			if (timelines == null) {
				timelines = false;
			}
			var a = [], 
				all = this.getChildren(nested, tweens, timelines), 
				cnt = 0, 
				l = all.length,
				i, tween;
			for (i = 0; i < l; i++) {
				tween = all[i];
				//note: we cannot just check tween.active because timelines that contain paused children will continue to have "active" set to true even after the playhead passes their end point (technically a timeline can only be considered complete after all of its children have completed too, but paused tweens are...well...just waiting and until they're unpaused we don't know where their end point will be).
				if (!tween._paused) if (tween._timeline._time >= tween._startTime) if (tween._timeline._time < tween._startTime + tween._totalDuration / tween._timeScale) if (!_getGlobalPaused(tween._timeline)) {
					a[cnt++] = tween;
				}
			}
			return a;
		}
		
		
		p.getLabelAfter = function(time) {
			if (!time) if (time !== 0) { //faster than isNan()
				time = this._time;
			}
			var labels = this.getLabelsArray(),
				l = labels.length,
				i;
			for (i = 0; i < l; i++) {
				if (labels[i].time > time) {
					return labels[i].name;
				}
			}
			return null;
		}
		
		p.getLabelBefore = function(time) {
			if (time == null) {
				time = this._time;
			}
			var labels = this.getLabelsArray(),
				i = labels.length;
			while (--i > -1) {
				if (labels[i].time < time) {
					return labels[i].name;
				}
			}
			return null;
		}
		
		p.getLabelsArray = function() {
			var a = [],
				cnt = 0,
				p;
			for (p in this._labels) {
				a[cnt++] = {time:this._labels[p], name:p};
			}
			a.sort(function(a,b) {
				return a.time - b.time;
			});
			return a;
		}
		
		
//---- GETTERS / SETTERS -------------------------------------------------------------------------------------------------------
		
		p.progress = function(value) {
			return (!arguments.length) ? this._time / this.duration() : this.totalTime( this.duration() * value + (this._cycle * this._duration), false);
		}
		
		p.totalProgress = function(value) {
			return (!arguments.length) ? this._totalTime / this.totalDuration() : this.totalTime( this.totalDuration() * value, false);
		}
		
		p.totalDuration = function(value) {
			if (!arguments.length) {
				if (this._dirty) {
					TimelineLite.prototype.totalDuration.call(this); //just forces refresh
					//Instead of Infinity, we use 999999999999 so that we can accommodate reverses.
					this._totalDuration = (this._repeat === -1) ? 999999999999 : this._duration * (this._repeat + 1) + (this._repeatDelay * this._repeat);
				}
				return this._totalDuration;
			}
			return (this._repeat == -1) ? this : this.duration( (value - (this._repeat * this._repeatDelay)) / (this._repeat + 1) );
		}
		
		p.time = function(value, suppressEvents) {
			if (!arguments.length) {
				return this._time;
			}
			if (this._dirty) {
				this.totalDuration();
			}
			if (value > this._duration) {
				value = this._duration;
			}
			if (this._yoyo && (this._cycle & 1) !== 0) {
				value = (this._duration - value) + (this._cycle * (this._duration + this._repeatDelay));
			} else if (this._repeat != 0) {
				value += this._cycle * (this._duration + this._repeatDelay);
			}
			return this.totalTime(value, suppressEvents);
		}
		
		p.repeat = function(value) {
			if (!arguments.length) {
				return this._repeat;
			}
			this._repeat = value;
			return this._uncache(true);
		}
		
		p.repeatDelay = function(value) {
			if (!arguments.length) {
				return this._repeatDelay;
			}
			this._repeatDelay = value;
			return this._uncache(true);
		}
		
		p.yoyo = function(value) {
			if (!arguments.length) {
				return this._yoyo;
			}
			this._yoyo = value;
			return this;
		}
		
		p.currentLabel = function(value) {
			if (!arguments.length) {
				return this.getLabelBefore(this._time + 0.00000001);
			}
			return this.seek(value, true);
		}
		
		return TimelineMax;
		
	}, true);
	




	
	
	
	
	
	
	
/*
 * ----------------------------------------------------------------
 * BezierPlugin 						(!BezierPlugin)
 * ----------------------------------------------------------------
 */	
	_gsDefine("plugins.BezierPlugin", ["plugins.TweenPlugin"], function(TweenPlugin) {
		
		var BezierPlugin = function(props, priority) {
				TweenPlugin.call(this, "bezier", -1);
				this._overwriteProps.pop();
				this._func = {};
				this._round = {};
			},
			p = BezierPlugin.prototype = new TweenPlugin("bezier", 1),
			_RAD2DEG = 180 / Math.PI,
			_r1 = [],
			_r2 = [],
			_r3 = [],
			_corProps = {}, 
			Segment = function Segment(a, b, c, d) {
				this.a = a;
				this.b = b;
				this.c = c;
				this.d = d;
				this.da = d - a;
				this.ca = c - a;
				this.ba = b - a;
			},
			_correlate = ",x,y,z,left,top,right,bottom,marginTop,marginLeft,marginRight,marginBottom,paddingLeft,paddingTop,paddingRight,paddingBottom,backgroundPosition,backgroundPosition_y,",
			bezierThrough = BezierPlugin.bezierThrough = function(values, curviness, quadratic, basic, correlate, prepend) {
				var obj = {},
					props = [],
					i, p;
				correlate = (typeof(correlate) === "string") ? ","+correlate+"," : _correlate;
				if (curviness == null) {
					curviness = 1;
				}
				for (p in values[0]) {
					props.push(p);
				}
				_r1.length = _r2.length = _r3.length = 0;
				i = props.length;
				while (--i > -1) {
					p = props[i];
					_corProps[p] = (correlate.indexOf(","+p+",") !== -1);
					obj[p] = _parseAnchors(values, p, _corProps[p], prepend);
				}
				i = _r1.length;
				while (--i > -1) {
					_r1[i] = Math.sqrt(_r1[i]);
					_r2[i] = Math.sqrt(_r2[i]);
				}
				if (!basic) {
					i = props.length;
					while (--i > -1) {
						if (_corProps[p]) {
							a = obj[props[i]];
							l = a.length - 1;
							for (j = 0; j < l; j++) {
								r = a[j+1].da / _r2[j] + a[j].da / _r1[j]; 
								_r3[j] = (_r3[j] || 0) + r * r;
							}
						}
					}
					i = _r3.length;
					while (--i > -1) {
						_r3[i] = Math.sqrt(_r3[i]);
					}
				}
				i = props.length;
				while (--i > -1) {
					p = props[i];
					_calculateControlPoints(obj[p], curviness, quadratic, basic, _corProps[p]); //this method requires that _parseAnchors() and _setSegmentRatios() ran first so that _r1, _r2, and _r3 values are populated for all properties
				}
				return obj;
			}, 
			_parseBezierData = function(values, type, prepend) {
				type = type || "soft";
				var obj = {},
					inc = (type === "cubic") ? 3 : 2,
					soft = (type === "soft"),
					props = [],
					a, b, c, d, cur, i, j, l, p, cnt, tmp;
				if (soft && prepend) {
					values = [prepend].concat(values);
				}
				if (values == null || values.length < inc + 1) { throw "invalid Bezier data"; }
				for (p in values[0]) {
					props.push(p);
				}
				i = props.length;
				while (--i > -1) {
					p = props[i];
					obj[p] = cur = [];
					cnt = 0;
					l = values.length;
					for (j = 0; j < l; j++) {
						a = (prepend == null) ? values[j][p] : (typeof( (tmp = values[j][p]) ) === "string" && tmp.charAt(1) === "=") ? prepend[p] + Number(tmp.charAt(0) + tmp.substr(2)) : Number(tmp);
						if (soft) if (j > 1) if (j < l - 1) {
							cur[cnt++] = (a + cur[cnt-2]) / 2;
						}
						cur[cnt++] = a;
					}
					l = cnt - inc + 1;
					cnt = 0;
					for (j = 0; j < l; j += inc) {
						a = cur[j];
						b = cur[j+1];
						c = cur[j+2];
						d = (inc === 2) ? 0 : cur[j+3];
						cur[cnt++] = tmp = (inc === 3) ? new Segment(a, b, c, d) : new Segment(a, (2 * b + a) / 3, (2 * b + c) / 3, c);
					}
					cur.length = cnt;
				}
				return obj;
			},
			_parseAnchors = function(values, p, correlate, prepend) {
				var a = [],
					l, i, obj, p1, p2, p3, r1, tmp;
				if (prepend) {
					values = [prepend].concat(values);
					i = values.length;
					while (--i > -1) {
						if (typeof( (tmp = values[i][p]) ) === "string") if (tmp.charAt(1) === "=") {
							values[i][p] = prepend[p] + Number(tmp.charAt(0) + tmp.substr(2)); //accommodate relative values. Do it inline instead of breaking it out into a function for speed reasons
						}
					}
				}
				l = values.length - 2;
				if (l < 0) {
					a[0] = new Segment(values[0][p], 0, 0, values[(l < -1) ? 0 : 1][p]);
					return a;
				}
				for (i = 0; i < l; i++) {
					p1 = values[i][p];
					p2 = values[i+1][p];
					a[i] = new Segment(p1, 0, 0, p2);
					if (correlate) {
						p3 = values[i+2][p];
						_r1[i] = (_r1[i] || 0) + (p2 - p1) * (p2 - p1);
						_r2[i] = (_r2[i] || 0) + (p3 - p2) * (p3 - p2); 
					}
				}
				a[i] = new Segment(values[i][p], 0, 0, values[i+1][p]);
				return a;
			},
			_calculateControlPoints = function(a, curviness, quad, basic, correlate) {
				var l = a.length - 1,
					ii = 0,
					cp1 = a[0].a,
					i, p1, p2, p3, seg, m1, m2, mm, cp2, qb, r1, r2, tl;
				for (i = 0; i < l; i++) {
					seg = a[ii];
					p1 = seg.a;
					p2 = seg.d;
					p3 = a[ii+1].d;
					
					if (correlate) {
						r1 = _r1[i];
						r2 = _r2[i];
						tl = ((r2 + r1) * curviness * 0.25) / (basic ? 0.5 : _r3[i] || 0.5);
						m1 = p2 - (p2 - p1) * (basic ? curviness * 0.5 : tl / r1);
						m2 = p2 + (p3 - p2) * (basic ? curviness * 0.5 : tl / r2);
						mm = p2 - (m1 + (m2 - m1) * ((r1 * 3 / (r1 + r2)) + 0.5) / 4);
					} else {
						m1 = p2 - (p2 - p1) * curviness * 0.5;
						m2 = p2 + (p3 - p2) * curviness * 0.5;
						mm = p2 - (m1 + m2) / 2;
					}
					m1 += mm;
					m2 += mm;
					
					seg.c = cp2 = m1; 
					if (i != 0) {
						seg.b = cp1;
					} else {
						seg.b = cp1 = seg.a + (seg.c - seg.a) * 0.6; //instead of placing b on a exactly, we move it inline with c so that if the user specifies an ease like Back.easeIn or Elastic.easeIn which goes BEYOND the beginning, it will do so smoothly.
					}
					
					seg.da = p2 - p1;
					seg.ca = cp2 - p1;
					seg.ba = cp1 - p1;
					
					if (quad) {
						qb = cubicToQuadratic(p1, cp1, cp2, p2);
						a.splice(ii, 1, qb[0], qb[1], qb[2], qb[3]);
						ii += 4;
					} else {
						ii++;
					}
					
					cp1 = m2;
				}
				seg = a[ii];
				seg.b = cp1;
				seg.c = cp1 + (seg.d - cp1) * 0.4; //instead of placing c on d exactly, we move it inline with b so that if the user specifies an ease like Back.easeOut or Elastic.easeOut which goes BEYOND the end, it will do so smoothly.
				seg.da = seg.d - seg.a;
				seg.ca = seg.c - seg.a;
				seg.ba = cp1 - seg.a;
				if (quad) {
					qb = cubicToQuadratic(seg.a, cp1, seg.c, seg.d);
					a.splice(ii, 1, qb[0], qb[1], qb[2], qb[3]);
				}
			},
			cubicToQuadratic = BezierPlugin.cubicToQuadratic = function(a, b, c, d) {
				var q1 = {a:a},
					q2 = {},
					q3 = {},
					q4 = {c:d},
					mab = (a + b) / 2, 
					mbc = (b + c) / 2, 
					mcd = (c + d) / 2, 
					mabc = (mab + mbc) / 2,
					mbcd = (mbc + mcd) / 2,
					m8 = (mbcd - mabc) / 8;
				q1.b = mab + (a - mab) / 4;	
				q2.b = mabc + m8;
				q1.c = q2.a = (q1.b + q2.b) / 2;
				q2.c = q3.a = (mabc + mbcd) / 2;
				q3.b = mbcd - m8;
				q4.b = mcd + (d - mcd) / 4;
				q3.c = q4.a = (q3.b + q4.b) / 2;
				return [q1, q2, q3, q4];
			},
			quadraticToCubic = BezierPlugin.quadraticToCubic = function(a, b, c) {
				return new Segment(a, (2 * b + a) / 3, (2 * b + c) / 3, c);
			},
			_parseLengthData = function(obj, resolution) {
				resolution = resolution >> 0 || 6;
				var a = [],
					lengths = [],
					d = 0,
					total = 0,
					threshold = resolution - 1,
					segments = [],
					curLS = [], //current length segments array
					p, i, l, index;
				for (p in obj) {
					_addCubicLengths(obj[p], a, resolution);
				}
				l = a.length;
				for (i = 0; i < l; i++) {
					d += Math.sqrt(a[i]);
					index = i % resolution;
					curLS[index] = d;
					if (index === threshold) {
						total += d;
						index = (i / resolution) >> 0;
						segments[index] = curLS;
						lengths[index] = total;
						d = 0;
						curLS = [];
					}
				}
				return {length:total, lengths:lengths, segments:segments};
			},
			_addCubicLengths = function(a, steps, resolution) {
				var inc = 1 / resolution,
					j = a.length,
					d, d1, s, da, ca, ba, p, i, inv, bez, index;
				while (--j > -1) {
					bez = a[j];
					s = bez.a;
					da = bez.d - s;
					ca = bez.c - s;
					ba = bez.b - s;
					d = d1 = 0;
					for (i = 1; i <= resolution; i++) {
						p = inc * i;
						inv = 1 - p;
						d = d1 - (d1 = (p * p * da + 3 * inv * (p * ca + inv * ba)) * p);
						index = j * resolution + i - 1;
						steps[index] = (steps[index] || 0) + d * d;
					}
				}
			}; 
			
		
		p.constructor = BezierPlugin;
		BezierPlugin.API = 2;
		
		
		p._onInitTween = function(target, vars, tween) {
			this._target = target;
			if (vars instanceof Array) {
				vars = {values:vars};
			}
			this._props = [];
			this._timeRes = (vars.timeResolution == null) ? 6 : parseInt(vars.timeResolution);
			var values = vars.values || [],
				first = {},
				second = values[0],
				autoRotate = vars.autoRotate || tween.vars.orientToBezier,
				p, isFunc, i, j, prepend;
			
			this._autoRotate = autoRotate ? (autoRotate instanceof Array) ? autoRotate : [["x","y","rotation",((autoRotate === true) ? 0 : Number(autoRotate) || 0)]] : null;
			for (p in second) {
				this._props.push(p);
			}
			
			i = this._props.length;
			while (--i > -1) {
				p = this._props[i];
				this._overwriteProps.push(p);
				isFunc = this._func[p] = (typeof(target[p]) === "function");
				first[p] = (!isFunc) ? parseFloat(target[p]) : target[ ((p.indexOf("set") || typeof(target["get" + p.substr(3)]) !== "function") ? p : "get" + p.substr(3)) ]();
				if (!prepend) if (first[p] !== values[0][p]) {
					prepend = first;
				}
			}
			this._beziers = (vars.type !== "cubic" && vars.type !== "quadratic" && vars.type !== "soft") ? bezierThrough(values, isNaN(vars.curviness) ? 1 : vars.curviness, false, (vars.type === "thruBasic"), vars.correlate, prepend) : _parseBezierData(values, vars.type, first);
			this._segCount = this._beziers[p].length;
			
			if (this._timeRes) {
				var ld = _parseLengthData(this._beziers, this._timeRes);
				this._length = ld.length;
				this._lengths = ld.lengths;
				this._segments = ld.segments;
				this._l1 = this._li = this._s1 = this._si = 0;
				this._l2 = this._lengths[0];
				this._curSeg = this._segments[0];
				this._s2 = this._curSeg[0];
				this._prec = 1 / this._curSeg.length;
			}
			
			if ((autoRotate = this._autoRotate)) {
				if (!(autoRotate[0] instanceof Array)) {
					this._autoRotate = autoRotate = [autoRotate];
				}
				i = autoRotate.length;
				while (--i > -1) {
					for (j = 0; j < 3; j++) {
						p = autoRotate[i][j];
						this._func[p] = (typeof(target[p]) === "function") ? target[ ((p.indexOf("set") || typeof(target["get" + p.substr(3)]) !== "function") ? p : "get" + p.substr(3)) ] : false;
					}
				}
			}
			return true;
		}
		
		//gets called every time the tween updates, passing the new ratio (typically a value between 0 and 1, but not always (for example, if an Elastic.easeOut is used, the value can jump above 1 mid-tween). It will always start and 0 and end at 1.
		p.setRatio = function(v) {
			var segments = this._segCount,
				func = this._func,
				target = this._target,
				curIndex, inv, i, p, b, t, val, l, lengths, curSeg;
			if (!this._timeRes) {
				curIndex = (v < 0) ? 0 : (v >= 1) ? segments - 1 : (segments * v) >> 0;
				t = (v - (curIndex * (1 / segments))) * segments;
			} else {
				lengths = this._lengths;
				curSeg = this._curSeg;
				v *= this._length;
				i = this._li;
				//find the appropriate segment (if the currently cached one isn't correct)
				if (v > this._l2 && i < segments - 1) {
					l = segments - 1;
					while (i < l && (this._l2 = lengths[++i]) <= v) {	}
					this._l1 = lengths[i-1];
					this._li = i;
					this._curSeg = curSeg = this._segments[i];
					this._s2 = curSeg[(this._s1 = this._si = 0)];
				} else if (v < this._l1 && i > 0) {
					while (i > 0 && (this._l1 = lengths[--i]) >= v) { 	}
					if (i === 0 && v < this._l1) {
						this._l1 = 0;
					} else {
						i++;
					}
					this._l2 = lengths[i];
					this._li = i;
					this._curSeg = curSeg = this._segments[i];
					this._s1 = curSeg[(this._si = curSeg.length - 1) - 1] || 0;
					this._s2 = curSeg[this._si];
				}
				curIndex = i;
				//now find the appropriate sub-segment (we split it into the number of pieces that was defined by "precision" and measured each one)
				v -= this._l1;
				i = this._si;
				if (v > this._s2 && i < curSeg.length - 1) {
					l = curSeg.length - 1;
					while (i < l && (this._s2 = curSeg[++i]) <= v) {	}
					this._s1 = curSeg[i-1];
					this._si = i;
				} else if (v < this._s1 && i > 0) {
					while (i > 0 && (this._s1 = curSeg[--i]) >= v) {	}
					if (i === 0 && v < this._s1) {
						this._s1 = 0;
					} else {
						i++;
					}
					this._s2 = curSeg[i];
					this._si = i;
				}
				t = (i + (v - this._s1) / (this._s2 - this._s1)) * this._prec;
			}
			inv = 1 - t;
			
			i = this._props.length;
			while (--i > -1) {
				p = this._props[i];
				b = this._beziers[p][curIndex];
				val = (t * t * b.da + 3 * inv * (t * b.ca + inv * b.ba)) * t + b.a;
				if (this._round[p]) {
					val = (val + ((val > 0) ? 0.5 : -0.5)) >> 0;
				}
				if (func[p]) {
					target[p](val);
				} else {
					target[p] = val;
				}
			}
			
			if (this._autoRotate) {
				var ar = this._autoRotate,
					b2, x1, y1, x2, y2, add, conv;
				i = ar.length;
				while (--i > -1) {
					p = ar[i][2];
					add = ar[i][3] || 0;
					conv = (ar[i][4] == true) ? 1 : _RAD2DEG;
					b = this._beziers[ar[i][0]][curIndex];
					b2 = this._beziers[ar[i][1]][curIndex];
					
					x1 = b.a + (b.b - b.a) * t;
					x2 = b.b + (b.c - b.b) * t;
					x1 += (x2 - x1) * t;
					x2 += ((b.c + (b.d - b.c) * t) - x2) * t;
					
					y1 = b2.a + (b2.b - b2.a) * t;
					y2 = b2.b + (b2.c - b2.b) * t;
					y1 += (y2 - y1) * t;
					y2 += ((b2.c + (b2.d - b2.c) * t) - y2) * t;
					
					val = Math.atan2(y2 - y1, x2 - x1) * conv + add;
					
					if (func[p]) {
						func[p].call(target, val);
					} else {
						target[p] = val;
					}
				}
			}
		}
		
		p._roundProps = function(lookup, value) {
			var op = this._overwriteProps,
				i = op.length;
			while (--i > -1) {
				if (lookup[op[i]] || lookup.bezier || lookup.bezierThrough) {
					this._round[op[i]] = value;
				}
			}
		}
		
		p._kill = function(lookup) {
			var a = this._props, 
				p, i;
			for (p in _beziers) {
				if (p in lookup) {
					delete this._beziers[p];
					delete this._func[p];
					i = a.length;
					while (--i > -1) {
						if (a[i] === p) {
							a.splice(i, 1);
						}
					}
				}
			}
			return TweenPlugin.prototype._kill.call(this, lookup);
		}
		
		TweenPlugin.activate([BezierPlugin]);
		return BezierPlugin;
		
	}, true);






	
	
	
	
	
	
	
	
/*
 * ----------------------------------------------------------------
 * CSSPlugin 						(!CSSPlugin)
 * ----------------------------------------------------------------
 */
	_gsDefine("plugins.CSSPlugin", ["plugins.TweenPlugin","TweenLite"], function(TweenPlugin, TweenLite) {
		
		"use strict";
		
		var CSSPlugin = function() {
				TweenPlugin.call(this, "css");
				this._overwriteProps.pop();
			},
			p = CSSPlugin.prototype = new TweenPlugin("css");
		
		p.constructor = CSSPlugin;
		CSSPlugin.API = 2;
		CSSPlugin.suffixMap = {top:"px", right:"px", bottom:"px", left:"px", width:"px", height:"px", fontSize:"px", padding:"px", margin:"px"};
			
		//set up some local variables and functions that we can reuse for all tweens - we do this only once and cache things to improve performance
		var _NaNExp = /[^\d\-\.]/g,
			_suffixExp = /(\d|\-|\+|=|#|\.)*/g,
			_numExp = /(\d|\.)+/g,
			_opacityExp = /opacity *= *([^)]*)/,
			_opacityValExp = /opacity:([^;]*)/,
			_capsExp = /([A-Z])/g,
			_camelExp = /-([a-z])/gi,
			_camelFunc = function(s, g) { return g.toUpperCase(); },
			_horizExp = /(Left|Right|Width)/i,
			_ieGetMatrixExp = /(M11|M12|M21|M22)=[\d\-\.e]+/gi,
			_ieSetMatrixExp = /progid\:DXImageTransform\.Microsoft\.Matrix\(.+?\)/i,
			_DEG2RAD = Math.PI / 180,
			_RAD2DEG = 180 / Math.PI,
			_forcePT = {},
			_doc = document,
			_tempDiv = _doc.createElement("div"),
			_agent = navigator.userAgent,
			_autoRound, 
			_reqSafariFix, //we won't apply the Safari transform fix until we actually come across a tween that affects a transform property (to maintain best performance).
			
			_isSafari, //Safari (and Android 4 which uses a flavor of Safari) has a bug that prevents changes to "top" and "left" properties from rendering properly if changed on the same frame as a transform UNLESS we set the element's WebkitBackfaceVisibility to hidden (weird, I know). Doing this for Android 3 and earlier seems to actually cause other problems, though (fun!)
			_ieVers, 
			_supportsOpacity = (function() { //we set _isSafari, _ieVers, and _supportsOpacity all in one function here to reduce file size slightly, especially in the minified version.
				var i = _agent.indexOf("Android"),
					d = _doc.createElement("div"), a;
				
				_isSafari = (_agent.indexOf("Safari") !== -1 && _agent.indexOf("Chrome") === -1 && (i === -1 || Number(_agent.substr(i+8, 1)) > 3));
				
				(/MSIE ([0-9]{1,}[\.0-9]{0,})/).exec(_agent);
				_ieVers = parseFloat( RegExp.$1 );
				
				d.innerHTML = "<a style='top:1px;opacity:.55;'>a</a>";
				a = d.getElementsByTagName("a")[0];
				return a ? /^0.55/.test(a.style.opacity) : false;
			})(),
			
			//parses a color (like #9F0, #FF9900, or rgb(255,51,153)) into an array with 3 elements for red, green, and blue. Also handles rgba() values (splits into array of 4 elements of course) 
			_parseColor = function(v) {
				if (!v || v === "") {
					return _colorLookup.black;
				} else if (_colorLookup[v]) {
					return _colorLookup[v];
				} else if (typeof(v) === "number") {
					return [v >> 16, (v >> 8) & 255, v & 255];
				} else if (v.charAt(0) === "#") {
					if (v.length === 4) { //for shorthand like #9F0
						var c1 = v.charAt(1),
							c2 = v.charAt(2),
							c3 = v.charAt(3);
						v = "#" + c1 + c1 + c2 + c2 + c3 + c3;
					}
					v = parseInt(v.substr(1), 16);
					return [v >> 16, (v >> 8) & 255, v & 255];
				} else {
					return v.match(_numExp) || _colorLookup.transparent;
				}
			},
			_getIEOpacity = function(obj) {
				return (_opacityExp.test( ((typeof(obj) === "string") ? obj : (obj.currentStyle ? obj.currentStyle.filter : obj.style.filter) || "") ) ? ( parseFloat( RegExp.$1 ) / 100 ) : 1);
			},
			_getComputedStyle = (_doc.defaultView) ? _doc.defaultView.getComputedStyle : function(o,s) {},
			
			//gets an individual style property. cs is for computedStyle (a speed optimization - we don't want to run it more than once if we don't have to). calc forces the returned value to be based on the computedStyle, ignoring anything that's in the element's "style" property (computing normalizes certain things for us)
			_getStyle = function(t, p, cs, calc) { 
				if (!_supportsOpacity && p === "opacity") { //several versions of IE don't use the standard "opacity" property - they use things like filter:alpha(opacity=50), so we parse that here.
					return _getIEOpacity(t);
				} else if (!calc && t.style[p]) {
					return t.style[p];
				} else if ((cs = cs || _getComputedStyle(t, null))) {
					t = cs.getPropertyValue(p.replace(_capsExp, "-$1").toLowerCase());
					return (t || cs.length) ? t : cs[p]; //Opera behaves VERY strangely - length is usually 0 and cs[p] is the only way to get accurate results EXCEPT when checking for -o-transform which only works with cs.getPropertyValue()!
				} else if (t.currentStyle) {
					cs = t.currentStyle,
					calc = cs[p]; //reuse "calc" variable to reduce minification size and improve speed slightly compared to creating a new variable.
					if (!calc && p === "backgroundPosition") { //IE doesn't report backgroundPosition accurately (before version 9) - instead, it only reports backgroundPositionX and backgroundPositionY, so we need to combine them manually.
						return cs[p + "X"] + " " + cs[p + "Y"];
					}
					return calc;
				}
				return null;
			},
			
			//returns at object containing ALL of the style properties in camel-case and their associated values.
			_getStyles = function(t, cs) {  
				var s = {}, i;
				if ((cs = cs || _getComputedStyle(t, null))) {
					if ((i = cs.length)) {
						while (--i > -1) {
							s[cs[i].replace(_camelExp, _camelFunc)] = cs.getPropertyValue(cs[i]);
						}
					} else { //Opera behaves differently - cs.length is always 0, so we must do a for...in loop.
						for (i in cs) {
							s[i] = cs[i];
						}
					}
				} else if ((cs = t.currentStyle || t.style)) {
					for (i in cs) {
						s[i.replace(_camelExp, _camelFunc)] = cs[i];
					}
				}
				if (!_supportsOpacity) {
					s.opacity = _getIEOpacity(t);
				}
				var tr = _getTransform(t, cs, false);
				s.rotation = tr.rotation * _RAD2DEG;
				s.skewX = tr.skewX * _RAD2DEG;
				s.scaleX = tr.scaleX;
				s.scaleY = tr.scaleY;
				s.x = tr.x;
				s.y = tr.y;
				if (s.filters != null) {
					delete s.filters;
				}
				return s;
			},
			
			//analyzes two style objects (as returned by _getStyles()) and only looks for differences between them that contain tweenable values (like a number or color). It returns an object containing only those isolated properties and values for tweening, and optionally populates an array of those property names too (so that we can loop through them at the end of the tween and remove them for css tweens that apply a className - we don't want the cascading to get messed up)
			_cssDif = function(s1, s2, v, d) { 
				var s = {}, val, p;
				for (p in s2) {
					if (p !== "cssText") if (p !== "length") if (isNaN(p)) if (s1[p] != (val = s2[p])) if (val !== _transformProp) if (typeof(val) === "number" || typeof(val) === "string") {
						s[p] = ((val === "" || val === "auto") && typeof(s1[p]) === "string" && s1[p].replace(_NaNExp, "") !== "") ? 0 : val; //if the ending value is defaulting ("" or "auto"), we check the starting value and if it can be parsed into a number (a string which could have a suffix too, like 700px), then we swap in 0 for "" or "auto" so that things actually tween.
						if (d) {
							d.props.push(p);
						}
					}
				}
				if (v) {
					for (p in v) { //copy properties (except className)
						if (p !== "className") {
							s[p] = v[p];
						}
					}
				}
				return s;
			},
			_transformMap = {scaleX:1, scaleY:1, x:1, y:1, rotation:1, shortRotation:1, skewX:1, skewY:1, scale:1},
			_prefixCSS = "", //the non-camelCase vendor prefix like "-o-", "-moz-", "-ms-", or "-webkit-"
			_prefix = "", //camelCase vendor prefix like "O", "ms", "Webkit", or "Moz".
			//feed in a camelCase property name like "transform" and it will check to see if it is valid as-is or if it needs a vendor prefix. It returns the corrected camelCase property name (i.e. "WebkitTransform" or "MozTransform" or "transform" or null if no such property is found, like if the browser is IE8 or before, "transform" won't be found at all)
			_checkPropPrefix = function(p, e) {
				e = e || _tempDiv;
				var s = e.style,
					a, i;
				if (s[p] !== undefined) {
					return p;
				}
				p = p.substr(0,1).toUpperCase() + p.substr(1);
				a = ["O","Moz","ms","Ms","Webkit"];
				i = 5;
				while (--i > -1 && s[a[i]+p] === undefined) { }
				if (i >= 0) {
					_prefix = (i === 3) ? "ms" : a[i];
					_prefixCSS = "-" + _prefix.toLowerCase() + "-";
					return _prefix + p;
				}
				return null;
			},
			_transformProp = _checkPropPrefix("transform"), //the Javascript (camelCase) transform property, like msTransform, WebkitTransform, MozTransform, or OTransform.
			_transformPropCSS = _prefixCSS + "transform",
						
			//parses the transform values for an element, returning an object with x, y, scaleX, scaleY, rotation, skewX, and skewY properties. Note: by default (for performance reasons), all skewing is combined into skewX and rotation but skewY still has a place in the transform object so that we can record how much of the skew is attributed to skewX vs skewY. Remember, a skewY of 10 looks the same as a rotation of 10 and skewX of -10.
			_getTransform = function(t, cs, rec) {
				var tm = t._gsTransform, s;
				if (_transformProp) {
					s = _getStyle(t, _transformPropCSS, cs, true);
				} else if (t.currentStyle) {
					//for older versions of IE, we need to interpret the filter portion that is in the format: progid:DXImageTransform.Microsoft.Matrix(M11=6.123233995736766e-17, M12=-1, M21=1, M22=6.123233995736766e-17, sizingMethod='auto expand') Notice that we need to swap b and c compared to a normal matrix.
					s = t.currentStyle.filter.match(_ieGetMatrixExp);
					s = (s && s.length === 4) ? s[0].substr(4) + "," + Number(s[2].substr(4)) + "," + Number(s[1].substr(4)) + "," + s[3].substr(4) + "," + (tm ? tm.x : 0) + "," + (tm ? tm.y : 0) : null;
				}
				var v = (s || "").replace(/[^\d\-\.e,]/g, "").split(","), 
					k = (v.length >= 6),
					a = k ? Number(v[0]) : 1,
					b = k ? Number(v[1]) : 0,
					c = k ? Number(v[2]) : 0,
					d = k ? Number(v[3]) : 1,
					min = 0.000001,
					m = rec ? tm || {skewY:0} : {skewY:0},
					invX = (m.scaleX < 0); //in order to interpret things properly, we need to know if the user applied a negative scaleX previously so that we can adjust the rotation and skewX accordingly. Otherwise, if we always interpret a flipped matrix as affecting scaleY and the user only wants to tween the scaleX on multiple sequential tweens, it would keep the negative scaleY without that being the user's intent.
				
				m.x = (k ? Number(v[4]) : 0);
				m.y = (k ? Number(v[5]) : 0);
				m.scaleX = Math.sqrt(a * a + b * b);
				m.scaleY = Math.sqrt(d * d + c * c);
				m.rotation = (a || b) ? Math.atan2(b, a) : m.rotation || 0; //note: if scaleX is 0, we cannot accurately measure rotation. Same for skewX with a scaleY of 0. Therefore, we default to the previously recorded value (or zero if that doesn't exist).
				m.skewX = (c || d) ? Math.atan2(c, d) + m.rotation : m.skewX || 0;
				if (Math.abs(m.skewX) > Math.PI / 2) {
					if (invX) {
						m.scaleX *= -1;
						m.skewX += (m.rotation <= 0) ? Math.PI : -Math.PI;
						m.rotation += (m.rotation <= 0) ? Math.PI : -Math.PI;
					} else {
						m.scaleY *= -1;
						m.skewX += (m.skewX <= 0) ? Math.PI : -Math.PI;
					}
				}
				//some browsers have a hard time with very small values like 2.4492935982947064e-16 (notice the "e-" towards the end) and would render the object slightly off. So we round to 0 in these cases. The conditional logic here is faster than calling Math.abs().
				if (m.rotation < min) if (m.rotation > -min) if (a || b) {
					m.rotation = 0;
				}
				if (m.skewX < min) if (m.skewX > -min) if (b || c) {
					m.skewX = 0;
				}
				if (rec) {
					t._gsTransform = m; //record to the object's _gsTransform which we use so that tweens can control individual properties independently (we need all the properties to accurately recompose the matrix in the setRatio() method)
				}
				return m;
			},
			
			_dimensions = {width:["Left","Right"], height:["Top","Bottom"]},
			_margins = ["marginLeft","marginRight","marginTop","marginBottom"], 
			_getDimension = function(n, t, cs) {
				var v = parseFloat((n === "width") ? t.offsetWidth : t.offsetHeight),
					a = _dimensions[n],
					i = a.length, 
					cs = cs || _getComputedStyle(t, null);
				while (--i > -1) {
					v -= parseFloat( _getStyle(t, "padding" + a[i], cs, true) ) || 0;
					v -= parseFloat( _getStyle(t, "border" + a[i] + "Width", cs, true) ) || 0;
				}
				return v;
			},
			
			//pass the target element, the property name, the numeric value, and the suffix (like "%", "em", "px", etc.) and it will spit back the equivalent pixel number
			_convertToPixels = function(t, p, v, sfx, recurse) {
				if (sfx === "px" || !sfx) { return v; }
				if (sfx === "auto" || !v) { return 0; }
				var horiz = _horizExp.test(p),
					node = t,
					style = _tempDiv.style,
					neg = (v < 0);
				if (neg) {
					v = -v;
				}
				style.cssText = "border-style:solid; border-width:0; position:absolute; line-height:0;";
				if (sfx === "%" || sfx === "em" || !node.appendChild) {
					node = t.parentNode || _doc.body;
					style[(horiz ? "width" : "height")] = v + sfx;
				} else {
					style[(horiz ? "borderLeftWidth" : "borderTopWidth")] = v + sfx;
				}
				node.appendChild(_tempDiv);
				var pix = parseFloat(_tempDiv[(horiz ? "offsetWidth" : "offsetHeight")]);
				node.removeChild(_tempDiv);
				if (pix === 0 && !recurse) { //in some browsers (like IE7/8), occasionally the value isn't accurately reported initially, but if we run the function again it will take effect. 
					pix = _convertToPixels(t, p, v, sfx, true);
				}
				return neg ? -pix : pix;
			},
			
			//for parsing things like transformOrigin or backgroundPosition which must recognize keywords like top/left/right/bottom/center as well as percentages and pixel values. Decorates the supplied object with the following properties: "ox" (offsetX), "oy" (offsetY), "oxp" (if true, "ox" is a percentage not a pixel value), and "oxy" (if true, "oy" is a percentage not a pixel value)
			_parsePosition = function(v, o) {
				if (v == null || v === "" || v === "auto" || v === "auto auto") { //note: Firefox uses "auto auto" as default whereas Chrome uses "auto".
					v = "0 0";
				}
				o = o || {};
				var x = (v.indexOf("left") !== -1) ? "0%" : (v.indexOf("right") !== -1) ? "100%" : v.split(" ")[0],
					y = (v.indexOf("top") !== -1) ? "0%" : (v.indexOf("bottom") !== -1) ? "100%" : v.split(" ")[1];
				if (y == null) {
					y = "0";
				} else if (y === "center") {
					y = "50%";
				}
				if (x === "center") {
					x = "50%";
				}
				o.oxp = (x.indexOf("%") !== -1);
				o.oyp = (y.indexOf("%") !== -1);
				o.oxr = (x.charAt(1) === "=");
				o.oyr = (y.charAt(1) === "=");
				o.ox = parseFloat(x.replace(_NaNExp, ""));
				o.oy = parseFloat(y.replace(_NaNExp, ""));
				return o;
			},
			
			//takes a value and a default number, checks if the value is relative, null, or numeric and spits back a normalized number accordingly. Primarily used in the _parseTransform() function.
			_parseVal = function(v, d) {
				return (v == null) ? d : (typeof(v) === "string" && v.indexOf("=") === 1) ? Number(v.split("=").join("")) + d : Number(v);
			},
			
			//translates strings like "40deg" or "40" or 40rad" or "+=40deg" to a numeric radian angle, optionally relative to a default value (if "+=" or "-=" prefix is found)
			_parseAngle = function(v, d) { 
				var m = (v.indexOf("rad") === -1) ? _DEG2RAD : 1, 
					r = (v.indexOf("=") === 1);
				v = Number(v.replace(_NaNExp, "")) * m;
				return r ? v + d : v;
			},
			_colorLookup = {aqua:[0,255,255],
							lime:[0,255,0],
							silver:[192,192,192],
							black:[0,0,0],
							maroon:[128,0,0],
							teal:[0,128,128],
							blue:[0,0,255],
							navy:[0,0,128],
							white:[255,255,255],
							fuchsia:[255,0,255],
							olive:[128,128,0],
							yellow:[255,255,0],
							orange:[255,165,0],
							gray:[128,128,128],
							purple:[128,0,128],
							green:[0,128,0],
							red:[255,0,0],
							pink:[255,192,203],
							cyan:[0,255,255],
							transparent:[255,255,255,0]};


		
		
		//gets called when the tween renders for the first time. This kicks everything off, recording start/end values, etc. 
		p._onInitTween = function(target, value, tween) {
			if (!target.nodeType) { //css is only for dom elements
				return false;
			}
			this._target = target;
			this._tween = tween;
			this._classData = this._transform = null; //_transform is only used for scaleX/scaleY/x/y/rotation/skewX/skewY tweens and _classData is only used if className is defined - this will be an array of properties that we're tweening related to the class which should be removed from the target.style at the END of the tween when the className is populated so that cascading happens properly.
			_autoRound = value.autoRound;
			var s = this._style = target.style, 
				cs = _getComputedStyle(target, ""),
				copy, start, v;
			
			if (_reqSafariFix) if (s.zIndex === "") {
				v = _getStyle(target, "zIndex", cs);
				if (v === "auto" || v === "") {
					//corrects a bug in [non-Android] Safari that prevents it from repainting elements in their new positions if they don't have a zIndex set. We also can't just apply this inside _parseTransform() because anything that's moved in any way (like using "left" or "top" instead of transforms like "x" and "y") can be affected, so it is best to ensure that anything that's tweening has a z-index. Setting "WebkitPerspective" to a non-zero value worked too except that on iOS Safari things would flicker randomly. Plus zIndex is less memory-intensive.
					 s.zIndex = 0;
				}
			}
			
			if (typeof(value) === "string") { 
				copy = s.cssText;
				start = _getStyles(target, cs);
				s.cssText = copy + ";" + value;
				v = _cssDif(start, _getStyles(target));
				if (!_supportsOpacity && _opacityValExp.test(value)) {
					v.opacity = parseFloat( RegExp.$1 );
				}
				value = v;
				s.cssText = copy;
			} else if (value.className) {
				copy = target.className;
				this._classData = {b:copy, e:(value.className.charAt(1) !== "=") ? value.className : (value.className.charAt(0) === "+") ? target.className + " " + value.className.substr(2) : target.className.split(value.className.substr(2)).join(""), props:[]}
				if (tween._duration) { //if it's a zero-duration tween, there's no need to tween anything or parse the data. In fact, if we switch classes temporarily (which we must do for proper parsing) and the class has a transition applied, it could cause a quick flash to the end state and back again initially in some browsers.
					start = _getStyles(target, cs);
					target.className = this._classData.e;
					value = _cssDif(start, _getStyles(target), value, this._classData);
					target.className = copy;
				} else {
					value = {};
				}
			}
			this._parseVars(value, target, cs, value.suffixMap || CSSPlugin.suffixMap);
			return true;
		}
		
		//feed a vars object to this function and it will parse through its properties and add PropTweens as necessary. This is split out from the _onInitTween() so that we can recurse if necessary, like "margin" should affect "marginLeft", "marginRight", "marginTop", and "marginBottom".
		p._parseVars = function(vars, t, cs, map) {
			var s = this._style, 
				p, v, pt, beg, clr1, clr2, bsfx, esfx, rel, start, copy, isStr;
			
			for (p in vars) {
				
				v = vars[p];
				
				if (p === "transform" || p === _transformProp) {
					this._parseTransform(t, v, cs, map);
					continue;
				} else if (_transformMap[p] || p === "transformOrigin") {
					this._parseTransform(t, vars, cs, map);
					continue;
				} else if (p === "alpha" || p === "autoAlpha") { //alpha tweens are opacity tweens			
					p = "opacity";
				} else if (p === "margin" || p === "padding") {
					copy = (v + "").split(" ");
					rel = copy.length;
					pt = {};
					pt[p + "Top"] = copy[0];
					pt[p + "Right"] = (rel > 1) ? copy[1] : copy[0];
					pt[p + "Bottom"] = (rel === 4) ? copy[2] : copy[0];
					pt[p + "Left"] = (rel === 4) ? copy[3] : (rel === 2) ? copy[1] : copy[0];
					this._parseVars(pt, t, cs, map);
					continue;
				} else if (p === "backgroundPosition" || p === "backgroundSize") {
					pt = _parsePosition(v); //end values 
					start = _parsePosition( (beg = _getStyle(t, p, cs)) ); //starting values
					this._firstPT = pt = {_next:this._firstPT, t:s, p:p, b:beg, f:false, n:"css_" + p, type:3,
							s:start.ox, //x start
							c:pt.oxr ? pt.ox : pt.ox - start.ox, //change in x
							ys:start.oy, //y start
							yc:pt.oyr ? pt.oy : pt.oy - start.oy, //change in y
							sfx:pt.oxp ? "%" : "px", //x suffix
							ysfx:pt.oyp ? "%" : "px", //y suffix
							r:(!pt.oxp && vars.autoRound !== false)};
					pt.e = (pt.s + pt.c) + pt.sfx + " " + (pt.ys + pt.yc) + pt.ysfx; //we can't just use v because it could contain relative values, like +=50px which is an illegal final value.
					continue;
				} else if (p === "border") {
					copy = (v + "").split(" ");
					this._parseVars({borderWidth:copy[0], borderStyle:copy[1] || "none", borderColor:copy[2] || "#000000"}, t, cs, map);
					continue;
				} else if (p === "bezier") {
					this._parseBezier(v, t, cs, map);
					continue;
				} else if (p === "autoRound") {
					continue;
				}
				
				beg = _getStyle(t, p, cs); 
				beg = (beg != null) ? beg + "" : ""; //make sure beginning value is a string. Don't do beg = _getStyle(...) || "" because if _getStyle() returns 0, it will make it "" since 0 is a "falsey" value.
				
				//Some of these properties are in place in order to conform with the standard PropTweens in TweenPlugins so that overwriting and roundProps occur properly. For example, f and r may seem unnecessary here, but they enable other functionality.
				//_next:*	next linked list node		[object]
				//t: 	*	target 						[object]
				//p:	*	property (camelCase)		[string]
				//s: 	*	starting value				[number]
				//c:	*	change value				[number]
				//f:	* 	is function					[boolean]
				//n:	*	name (for overwriting)		[string]
				//sfx:		suffix						[string]
				//b:		beginning value				[string]
				//i:		intermediate value			[string]
				//e: 		ending value				[string]
				//r:	*	round						[boolean]
				//type:		0=normal, 1=color, 2=rgba, 3=positional offset (like backgroundPosition or backgroundSize), 4=unsupported opacity (ie), -1=non-tweening prop	[number]
				this._firstPT = pt = {_next:this._firstPT, 
					  t:s, 
					  p:p, 
					  b:beg,	 
					  f:false,
					  n:"css_" + p,
					  sfx:"",
					  r:false,
					  type:0};
					  
				//if it's an autoAlpha, add a new PropTween for "visibility". We must make sure the "visibility" PropTween comes BEFORE the "opacity" one in order to work around a bug in old versions of IE tht would ignore "visibility" changes if made right after an alpha change. Remember, we add PropTweens in reverse order - that's why we do this here, after creating the original PropTween.
				if (p === "opacity") if (vars.autoAlpha != null) {
					if (beg === "1") if (_getStyle(t, "visibility", cs) === "hidden") { //if visibility is initially set to "hidden", we should interpret that as intent to make opacity 0.
						beg = pt.b = "0";
					}
					this._firstPT = pt._prev = {_next:pt, t:s, p:"visibility", f:false, n:"css_visibility", r:false, type:-1, b:(Number(beg) !== 0) ? "visible" : "hidden", i:"visible", e:(Number(v) === 0) ? "hidden" : "visible"};
					this._overwriteProps.push("css_visibility");
				}
				
				isStr = (typeof(v) === "string");
									
				//color values must be split apart into their R, G, B (and sometimes alpha) values and tweened independently.
				if (p === "color" || p === "fill" || p === "stroke" || p.indexOf("Color") !== -1 || (isStr && !v.indexOf("rgb("))) { //Opera uses background: to define color sometimes in addition to backgroundColor:
					clr1 = _parseColor(beg);
					clr2 = _parseColor(v);
					pt.e = pt.i = ((clr2.length > 3) ? "rgba(" : "rgb(") + clr2.join(",") + ")"; //don't just do pt.e = v because that won't work if the destination color is numeric, like 0xFF0000. We need to parse it.
					pt.b = ((clr1.length > 3) ? "rgba(" : "rgb(") + clr1.join(",") + ")"; //normalize to rgb in case the beginning value was passed in as numeric, like 0xFF0000
					pt.s = Number(clr1[0]);				//red starting value
					pt.c = Number(clr2[0]) - pt.s;		//red change
					pt.gs = Number(clr1[1]);			//green starting value
					pt.gc = Number(clr2[1]) - pt.gs;	//green change
					pt.bs = Number(clr1[2]);			//blue starting value
					pt.bc = Number(clr2[2]) - pt.bs;	//blue change
					pt.type = 1;
					if (clr1.length > 3 || clr2.length > 3) { //detect an rgba() value
						if (_supportsOpacity) {
							pt.as = (clr1.length < 4) ? 1 : Number(clr1[3]);
							pt.ac = ((clr2.length < 4) ? 1 : Number(clr2[3])) - pt.as;
							pt.type = 2;
						} else { //older versions of IE don't support rgba(), so if the destination alpha is 0, just use "transparent" for the color and make it a non-tweening property
							if (clr2[3] == 0) {
								pt.e = pt.i = "transparent";
								pt.type = -1;
							}
							if (clr1[3] == 0) {
								pt.b = "transparent";
							}
						}
					}
					
				} else {
					
					bsfx = beg.replace(_suffixExp, ""); //beginning suffix
					
					if (beg === "" || beg === "auto") {
						if (p === "width" || p === "height") {
							start = _getDimension(p, t, cs);
							bsfx = "px";
						} else {
							start = (p !== "opacity") ? 0 : 1;
							bsfx = "";
						}
					} else {
						start = (beg.indexOf(" ") === -1) ? parseFloat(beg.replace(_NaNExp, "")) : NaN;
					}
					
					if (isStr) {
						rel = (v.charAt(1) === "=");
						esfx = v.replace(_suffixExp, "");
						v = (v.indexOf(" ") === -1) ? parseFloat(v.replace(_NaNExp, "")) : NaN;
					} else {
						rel = false;
						esfx = "";
					}
					
					if (esfx === "") {
						esfx = map[p] || bsfx; //populate the end suffix, prioritizing the map, then if none is found, use the beginning suffix.
					}
					
					pt.e = (v || v === 0) ? (rel ? v + start : v) + esfx : vars[p]; //ensures that any += or -= prefixes are taken care of. Record the end value before normalizing the suffix because we always want to end the tween on exactly what they intended even if it doesn't match the beginning value's suffix.
					
					//if the beginning/ending suffixes don't match, normalize them...
					if (bsfx !== esfx) if (esfx !== "") if (v || v === 0) if (start || start === 0) { 
						start = _convertToPixels(t, p, start, bsfx);
						if (esfx === "%") {
							start /= _convertToPixels(t, p, 100, "%") / 100;
							if (start > 100) { //extremely rare
								start = 100;
							}
							
						} else if (esfx === "em") {
							start /= _convertToPixels(t, p, 1, "em");
							
						//otherwise convert to pixels.
						} else {
							v = _convertToPixels(t, p, v, esfx);
							esfx = "px"; //we don't use bsfx after this, so we don't need to set it to px too.
						}
						if (rel) if (v || v === 0) {
							pt.e = (v + start) + esfx; //the changes we made affect relative calculations, so adjust the end value here.
						}
					}
					
					if ((start || start === 0) && (v || v === 0) && (pt.c = (rel ? v : v - start))) { //faster than isNaN(). Also, we set pt.c (change) here because if it's 0, we'll just treat it like a non-tweening value. can't do (v !== start) because if it's a relative value and the CHANGE is identical to the START, the condition will fail unnecessarily.
						pt.s = start;
						pt.sfx = esfx;
						if (p === "opacity") {
							if (!_supportsOpacity) {
								pt.type = 4;
								pt.p = "filter";
								pt.b = "alpha(opacity=" + (pt.s * 100) + ")";
								pt.e = "alpha(opacity=" + ((pt.s + pt.c) * 100) + ")";
								pt.dup = (vars.autoAlpha != null); //dup = duplicate the setting of the alpha in order to work around a bug in IE7 and IE8 that prevents changes to "visibility" from taking effect if the filter is changed to a different alpha(opacity) at the same time. Setting it to the SAME value first, then the new value works around the IE7/8 bug.
								this._style.zoom = 1; //helps correct an IE issue.
							}
						} else if (_autoRound !== false && (esfx === "px" || p === "zIndex")) { //always round zIndex, and as long as autoRound isn't false, round pixel values (that improves performance in browsers typically)
							pt.r = true;
						}
					} else {
						pt.type = -1;
						pt.i = (p === "display" && pt.e === "none") ? pt.b : pt.e; //intermediate value is typically the same as the end value except for "display"
						pt.s = pt.c = 0;
					}
					
				}
				
				this._overwriteProps.push("css_" + p);
				if (pt._next) {
					pt._next._prev = pt;
				}
			}
			
		}
		
		
		//compares the beginning x, y, scaleX, scaleY, rotation, and skewX properties with the ending ones and adds PropTweens accordingly wherever necessary. We must tween them individually (rather than just tweening the matrix values) so that elgant overwriting can occur, like if one tween is controlling scaleX, scaleY, and rotation and then another one starts mid-tween that is trying to control the scaleX only - this tween should continue tweening scaleY and rotation.
		p._parseTransform = function(t, v, cs, map) {
			if (this._transform) { return; } //only need to parse the transform once, and only if the browser supports it.
			
			var m1 = this._transform = _getTransform(t, cs, true), 
				s = this._style,
				min = 0.000001,
				m2, skewY, p, pt, copy, orig;
			
			if (typeof(v) === "object") { //for values like scaleX, scaleY, rotation, x, y, skewX, and skewY or transform:{...} (object)

				m2 = {scaleX:_parseVal((v.scaleX != null) ? v.scaleX : v.scale, m1.scaleX),
					  scaleY:_parseVal((v.scaleY != null) ? v.scaleY : v.scale, m1.scaleY),
					  x:_parseVal(v.x, m1.x),
					  y:_parseVal(v.y, m1.y)};
					  
				if (v.shortRotation != null) {
					m2.rotation = (typeof(v.shortRotation) === "number") ? v.shortRotation * _DEG2RAD : _parseAngle(v.shortRotation, m1.rotation);
					var dif = (m2.rotation - m1.rotation) % (Math.PI * 2);
					if (dif !== dif % Math.PI) {
						dif += Math.PI * ((dif < 0) ? 2 : -2);
					}
					m2.rotation = m1.rotation + dif;
					
				} else {
					m2.rotation = (v.rotation == null) ? m1.rotation : (typeof(v.rotation) === "number") ? v.rotation * _DEG2RAD : _parseAngle(v.rotation, m1.rotation);
				}
				m2.skewX = (v.skewX == null) ? m1.skewX : (typeof(v.skewX) === "number") ? v.skewX * _DEG2RAD : _parseAngle(v.skewX, m1.skewX);
				
				//note: for performance reasons, we combine all skewing into the skewX and rotation values, ignoring skewY but we must still record it so that we can discern how much of the overall skew is attributed to skewX vs. skewY. Otherwise, if the skewY would always act relative (tween skewY to 10deg, for example, multiple times and if we always combine things into skewX, we can't remember that skewY was 10 from last time). Remember, a skewY of 10 degrees looks the same as a rotation of 10 degrees plus a skewX of -10 degrees.
				m2.skewY = (v.skewY == null) ? m1.skewY : (typeof(v.skewY) === "number") ? v.skewY * _DEG2RAD : _parseAngle(v.skewY, m1.skewY);
				if ((skewY = m2.skewY - m1.skewY)) {
					m2.skewX += skewY
					m2.rotation += skewY;
				}
				//don't allow rotation/skew values to be a SUPER small decimal because when they're translated back to strings for setting the css property, the browser reports them in a funky way, like 1-e7. Of course we could use toFixed() to resolve that issue but that hurts performance quite a bit with all those function calls on every frame, plus it is virtually impossible to discern values that small visually (nobody will notice changing a rotation of 0.0000001 to 0, so the performance improvement is well worth it).
				if (m2.skewY < min) if (m2.skewY > -min) {
					m2.skewY = 0;
				}
				if (m2.skewX < min) if (m2.skewX > -min) {
					m2.skewX = 0;
				}
				if (m2.rotation < min) if (m2.rotation > -min) {
					m2.rotation = 0;
				}
				
				//if a transformOrigin is defined, handle it here...
				if ((orig = v.transformOrigin) != null) {
					if (_transformProp) {
						p = _transformProp + "Origin";
						this._firstPT = pt = {_next:this._firstPT, t:s, p:p, s:0, c:0, n:p, f:false, r:false, b:s[p], e:orig, i:orig, type:-1, sfx:""};
						if (pt._next) {
							pt._next._prev = pt;
						}
					
					//for older versions of IE (6-8), we need to manually calculate things inside the setRatio() function. We record origin x and y (ox and oy) and whether or not the values are percentages (oxp and oyp). 
					} else {
						_parsePosition(orig, m1);
					}
				}
				
			} else if (typeof(v) === "string" && _transformProp) { //for values like transform:"rotate(60deg) scale(0.5, 0.8)"
				copy = s[_transformProp];
				s[_transformProp] = v;
				m2 = _getTransform(t, null, false);
				s[_transformProp] = copy;
			} else {
				return;
			}
			
			if (!_transformProp) {
				s.zoom = 1; //helps correct an IE issue.
			} else if (_isSafari) {
				_reqSafariFix = true;
				//corrects a bug in [non-Android] Safari that causes it to skip rendering changes to "top" and "left" that are made on the same frame/render as a transform update. It also helps work around bugs in iOS Safari that can prevent it from repainting elements in their new positions. We cannot just check for a Webkit browser because some Android devices like the Atrix don't like this "fix". Setting "WebkitPerspective" to a non-zero value worked too except that on iOS Safari things would flicker randomly.
				if (s.WebkitBackfaceVisibility === "") {
					s.WebkitBackfaceVisibility = "hidden";
				}
				//if zIndex isn't set, iOS Safari doesn't repaint things correctly sometimes (seemingly at random).
				if (s.zIndex === "") {
					copy = _getStyle(t, "zIndex", cs);
					if (copy === "auto" || copy === "") {
						s.zIndex = 0;
					}
				}
			}
			
			for (p in _transformMap) {
				if (m1[p] !== m2[p] || _forcePT[p] != null) if (p !== "shortRotation") if (p !== "scale") {
					this._firstPT = pt = {_next:this._firstPT, t:m1, p:p, s:m1[p], c:m2[p] - m1[p], n:p, f:false, r:false, b:m1[p], e:m2[p], type:0, sfx:0};
					if (pt._next) {
						pt._next._prev = pt;
					}
					this._overwriteProps.push("css_" + p);
				}
			}
		};
		
		p._parseBezier = function(v, t, cs, map) {
			if (!window.com.greensock.plugins.BezierPlugin) {
				console.log("Error: BezierPlugin not loaded.");
				return;
			}
			if (v instanceof Array) {
				v = {values:v};
			}
			var values = v.values || [],
				l = values.length,
				points = [],
				b = this._bezier = {_pt:[]},
				bp = b._proxy = {},
				cnt = 0,
				pcnt = 0,
				lookup = {},
				l2 = l - 1,
				oldForce = _forcePT,
				plugin = b._plugin = new window.com.greensock.plugins.BezierPlugin(),
				p, i, pt, bpt, curPoint, tfm;
			for (i = 0; i < l; i++) {
				curPoint = {};
				this._transform = null; //null each time through, otherwise _parseTransform() will abort
				bpt = this._firstPT;
				this._parseVars((_forcePT = values[i]), t, cs, map);
				
				pt = this._firstPT;
				if (i === 0) {
					tfm = this._transform;
					while (pt !== bpt) {
						bp[pt.p] = pt.s;
						b._pt[pcnt++] = lookup[pt.p] = pt; //don't rely on the linked list because it's possible that one would get removed (like overwritten), and if that was the one that was attached (like via _lastPT property), it would leave them all stranded, so the array would be more reliable here.
						if (pt.type === 1 || pt.type === 2) {
							bp[pt.p+"_g"] = pt.gs;
							bp[pt.p+"_b"] = pt.bs;
							if (pt.type === 2) {
								bp[pt.p+"_a"] = pt.as;
							}
						} else if (pt.type === 3) {
							bp[pt.p+"_y"] = pt.ys;
						}
						pt = pt._next;	
					}
					pt = this._firstPT;
				} else {
					this._firstPT = bpt;
					if (bpt._prev) {
						bpt._prev._next = null;
					}
					bpt._prev = null;
					bpt = null;
				}
				
				while (pt !== bpt) {
					if (lookup[pt.p]) {
						curPoint[pt.p] = pt.s + pt.c;
						if (i === l2) {
							lookup[pt.p].e = pt.e; //record the end value
						}
						if (pt.type === 1 || pt.type === 2) {
							curPoint[pt.p+"_g"] = pt.gs + pt.gc;
							curPoint[pt.p+"_b"] = pt.bs + pt.bc;
							if (pt.type === 2) {
								curPoint[pt.p+"_a"] = pt.as + pt.ac;
							}
						} else if (pt.type === 3) {
							curPoint[pt.p+"_y"] = pt.ys + pt.yc;
						}
						if (i === 0) {
							pt.c = pt.ac = pt.gc = pt.bc = pt.yc = 0; //no change - the BezierPlugin instance will handle that, and we'll set the "s" (start) property of the PropTween in the setRatio() method, just copying it from the _bezierProxy object.
						}
					}
					pt = pt._next;	
				}
				points[cnt++] = curPoint;
			}
			this._transform = tfm;
			_forcePT = oldForce;
			v.values = points;
			if (v.autoRotate === 0) {
				v.autoRotate = true;
			}
			if (v.autoRotate) if (!(v.autoRotate instanceof Array)) {
				i = (v.autoRotate == true) ? 0 : Number(v.autoRotate) * Math.PI / 180;
				v.autoRotate = (points[0].left != null) ? [["left","top","rotation",i,true]] : (points[0].x != null) ? [["x","y","rotation",i,true]] : false;
			}
			if ((b._autoRotate = v.autoRotate)) if (!tfm) {
				this._transform = _getTransform(t, cs, true);
			}
			plugin._onInitTween(bp, v, this._tween);
			v.values = values;
		};
		
		
		
		//gets called every time the tween updates, passing the new ratio (typically a value between 0 and 1, but not always (for example, if an Elastic.easeOut is used, the value can jump above 1 mid-tween). It will always start and 0 and end at 1.
		p.setRatio = function(v) {
			var pt = this._firstPT, 
				bz = this._bezier,
				min = 0.000001, val, i, y;
				
			if (bz) {
				bz._plugin.setRatio(v);
				var bpt = bz._pt,
					bp = bz._proxy;
				i = bpt.length;
				while (--i > -1) {
					pt = bpt[i];
					pt.s = bp[pt.p];
					if (pt.type === 1 || pt.type === 2) {
						pt.gs = bp[pt.p+"_g"];
						pt.bs = bp[pt.p+"_b"];
						if (pt.type === 2) {
							pt.as = bp[pt.p+"_a"];
						}
					} else if (pt.type === 3) {
						pt.ys = bp[pt.p+"_y"];
					}
				}
				if (bz._autoRotate) {
					this._transform.rotation = bp.rotation;
				}
			}
			
			//at the end of the tween, we set the values to exactly what we received in order to make sure non-tweening values (like "position" or "float" or whatever) are set and so that if the beginning/ending suffixes (units) didn't match and we normalized to px, the value that the user passed in is used here. We check to see if the tween is at its beginning in case it's a from() tween in which case the ratio will actually go from 1 to 0 over the course of the tween (backwards). 
			if (v === 1 && (this._tween._time === this._tween._duration || this._tween._time === 0)) {
				while (pt) {
					pt.t[pt.p] = pt.e;
					if (pt.type === 4) if (pt.s + pt.c === 1) { //for older versions of IE that need to use a filter to apply opacity, we should remove the filter if opacity hits 1 in order to improve performance.
						this._style.removeAttribute("filter");
						if (_getStyle(this._target, "filter")) { //if a class is applied that has an alpha filter, it will take effect (we don't want that), so re-apply our alpha filter in that case. We must first remove it and then check.
							pt.t[pt.p] = pt.e;
						}
					}
					pt = pt._next;
				}
			
			} else if (v || !(this._tween._time === this._tween._duration || this._tween._time === 0)) {
				
				while (pt) {
					val = pt.c * v + pt.s;
					if (pt.r) {
						val = (val > 0) ? (val + 0.5) >> 0 : (val - 0.5) >> 0; 
					} else if (val < min) if (val > -min) {
						val = 0;
					}
					if (!pt.type) {
						pt.t[pt.p] = val + pt.sfx;						
					} else if (pt.type === 1) { //rgb()
						pt.t[pt.p] = "rgb(" + (val >> 0) + ", " + ((pt.gs + (v * pt.gc)) >> 0) + ", " + ((pt.bs + (v * pt.bc)) >> 0) + ")";
					} else if (pt.type === 2) { //rgba()
						pt.t[pt.p] = "rgba(" + (val >> 0) + ", " + ((pt.gs + (v * pt.gc)) >> 0) + ", " + ((pt.bs + (v * pt.bc)) >> 0) + ", " + (pt.as + (v * pt.ac)) + ")";
					} else if (pt.type === -1) { //non-tweening
						pt.t[pt.p] = pt.i;
					} else if (pt.type === 3) { //positional property with an x and y, like backgroundPosition or backgroundSize
						y = pt.ys + v * pt.yc;
						if (pt.r) {
							y = (y > 0) ? (y + 0.5) >> 0 : (y - 0.5) >> 0; 
						}
						pt.t[pt.p] = val + pt.sfx + " " + y + pt.ysfx;						
					} else {
						if (pt.dup) {
							pt.t.filter = pt.t.filter || "alpha(opacity=100)"; //works around bug in IE7/8 that prevents changes to "visibility" from being applied propertly if the filter is changed to a different alpha on the same frame.
						}
						if (pt.t.filter.indexOf("opacity") === -1) { //only used if browser doesn't support the standard opacity style property (IE 7 and 8)
							pt.t.filter += " alpha(opacity=" + ((val * 100) >> 0) + ")"; //we round the value because otherwise, bugs in IE7/8 can prevent "visibility" changes from being applied properly.
						} else {
							pt.t.filter = pt.t.filter.replace(_opacityExp, "opacity=" + ((val * 100) >> 0)); //we round the value because otherwise, bugs in IE7/8 can prevent "visibility" changes from being applied properly.
						}
					}
					pt = pt._next;
				}
				
			//if the tween is reversed all the way back to the beginning, we need to restore the original values which may have different units (like % instead of px or em or whatever).
			} else {
				while (pt) {
					pt.t[pt.p] = pt.b;
					if (pt.type === 4) if (pt.s === 1) { //for older versions of IE that need to use a filter to apply opacity, we should remove the filter if opacity hits 1 in order to improve performance. 
						this._style.removeAttribute("filter");
						if (_getStyle(this._target, "filter")) { //if a class is applied that has an alpha filter, it will take effect (we don't want that), so re-apply our alpha filter in that case. We must first remove it and then check.
							pt.t[pt.p] = pt.b;
						}
					}
					pt = pt._next;
				}
			}
			
			//apply transform values like x, y, scaleX, scaleY, rotation, skewX, or skewY. We do these after looping through all the PropTweens because those are where the changes are made to scaleX/scaleY/rotation/skewX/skewY/x/y.
			if (this._transform) {
				pt = this._transform; //to improve speed and reduce size, reuse the pt variable as an alias to the _transform property
				//if there is no rotation or skew, browsers render the transform faster if we just feed it the list of transforms like translate() skewX() scale(), otherwise defining the matrix() values directly is fastest.
				if (_transformProp && !pt.rotation && !pt.skewX) {
					this._style[_transformProp] = ((pt.x || pt.y) ? "translate(" + pt.x + "px," + pt.y + "px) " : "") + ((pt.scaleX !== 1 || pt.scaleY !== 1) ? "scale(" + pt.scaleX + "," + pt.scaleY + ")" : "") || "translate(0px,0px)"; //we need to default to translate(0px,0px) to work around a Chrome bug that rears its ugly head when the transform is set to "".
				} else {
					var ang = _transformProp ? pt.rotation : -pt.rotation, 
						skew = _transformProp ? ang - pt.skewX : ang + pt.skewX,
						a = Math.cos(ang) * pt.scaleX,
						b = Math.sin(ang) * pt.scaleX,
						c = Math.sin(skew) * -pt.scaleY,
						d = Math.cos(skew) * pt.scaleY,
						cs;
					//some browsers have a hard time with very small values like 2.4492935982947064e-16 (notice the "e-" towards the end) and would render the object slightly off. So we round to 0 in these cases. The conditional logic here is faster than calling Math.abs().
					if (a < min) if (a > -min) {
						a = 0;
					}
					if (b < min) if (b > -min) {
						b = 0;
					}
					if (c < min) if (c > -min) {
						c = 0;
					}
					if (d < min) if (d > -min) {
						d = 0;
					}
					if (_transformProp) {
						this._style[_transformProp] = "matrix(" + a + "," + b + "," + c + "," + d + "," + pt.x + "," + pt.y + ")";
						
					//only for older versions of IE (6-8), we use a filter and marginLeft/marginTop to simulate the transform.
					} else if ((cs = this._target.currentStyle)) {
						min = b; //just for swapping the variables an inverting them (reused "min" to avoid creating another variable in memory). IE's filter matrix uses a non-standard matrix configuration (angle goes the opposite way, and b and c are reversed and inverted)
						b = -c;
						c = -min;
						var filters = cs.filter;
						this._style.filter = ""; //remove filters so that we can accurately measure offsetWidth/offsetHeight
						var w = this._target.offsetWidth,
							h = this._target.offsetHeight,
							clip = (cs.position !== "absolute"),
							m = "progid:DXImageTransform.Microsoft.Matrix(M11=" + a + ", M12=" + b + ", M21=" + c + ", M22=" + d,
							ox = pt.x,
							oy = pt.y,
							dx, dy;
						
						//if transformOrigin is being used, adjust the offset x and y
						if (pt.ox != null) {
							dx = ((pt.oxp) ? w * pt.ox * 0.01 : pt.ox) - w / 2;
							dy = ((pt.oyp) ? h * pt.oy * 0.01 : pt.oy) - h / 2;
							ox = dx - (dx * a + dy * b) + pt.x;
							oy = dy - (dx * c + dy * d) + pt.y;
						}
						
						if (!clip) {
							var mult = (_ieVers < 8) ? 1 : -1, //in Internet Explorer 7 and before, the box model is broken, causing the browser to treat the width/height of the actual rotated filtered image as the width/height of the box itself, but Microsoft corrected that in IE8. We must use a negative offset in IE8 on the right/bottom
								marg, prop, dif;
							dx = pt.ieOffsetX || 0;
							dy = pt.ieOffsetY || 0;
							pt.ieOffsetX = Math.round((w - ((a < 0 ? -a : a) * w + (b < 0 ? -b : b) * h)) / 2 + ox);
							pt.ieOffsetY = Math.round((h - ((d < 0 ? -d : d) * h + (c < 0 ? -c : c) * w)) / 2 + oy);
							for (i = 0; i < 4; i++) {
								prop = _margins[i];
								marg = cs[prop];			
								//we need to get the current margin in case it is being tweened separately (we want to respect that tween's changes)
								val = (marg.indexOf("px") !== -1) ? parseFloat(marg) : _convertToPixels(this._target, prop, parseFloat(marg), marg.replace(_suffixExp, "")) || 0;
								if (val !== pt[prop]) {
									dif = (i < 2) ? -pt.ieOffsetX : -pt.ieOffsetY; //if another tween is controlling a margin, we cannot only apply the difference in the ieOffsets, so we essentially zero-out the dx and dy here in that case. We record the margin(s) later so that we can keep comparing them, making this code very flexible.
								} else {
									dif = (i < 2) ? dx - pt.ieOffsetX : dy - pt.ieOffsetY;
								}
								this._style[prop] = (pt[prop] = Math.round( val - dif * ((i === 0 || i === 2) ? 1 : mult) )) + "px";
							}
							m += ", sizingMethod='auto expand')";
						} else {
							dx = (w / 2),
							dy = (h / 2);
							//translate to ensure that transformations occur around the correct origin (default is center).
							m += ", Dx=" + (dx - (dx * a + dy * b) + ox) + ", Dy=" + (dy - (dx * c + dy * d) + oy) + ")";
						}
						
						if (filters.indexOf("DXImageTransform.Microsoft.Matrix(") !== -1) {
							this._style.filter = filters.replace(_ieSetMatrixExp, m);
						} else {
							this._style.filter = m + " " + filters; //we must always put the transform/matrix FIRST (before alpha(opacity=xx)) to avoid an IE bug that slices part of the object when rotation is applied with alpha.
						}
	
						//at the end or beginning of the tween, if the matrix is normal (1, 0, 0, 1) and opacity is 100 (or doesn't exist), remove the filter to improve browser performance.
						if (v === 0 || v === 1) if (a === 1) if (b === 0) if (c === 0) if (d === 1) if (!clip || m.indexOf("Dx=0, Dy=0") !== -1) if (!_opacityExp.test(filters) || parseFloat(RegExp.$1) === 100) {
							this._style.removeAttribute("filter");
						}
					}
				}
			}
			
			//if we're adding/changing a class, we should do so at the END of the tween, and drop any of the associated properties that are in the target.style object in order to preserve proper cascading.
			if (this._classData) {
				pt = this._classData; //speeds things up slightly and helps minification
				if (v === 1 && (this._tween._time === this._tween._duration || this._tween._time === 0)) {
					var i = pt.props.length;
					while (--i > -1) {
						this._style[pt.props[i]] = "";
					}
					this._target.className = pt.e;
				} else if (this._target.className !== pt.b) {
					this._target.className = pt.b;
				}
			}
		}
		
		//we need to make sure that if alpha or autoAlpha is killed, opacity is too. And autoAlpha affects the "visibility" property.
		p._kill = function(lookup) {
			var copy = lookup, p;
			if (lookup.autoAlpha || lookup.alpha) {
				copy = {};
				for (p in lookup) { //copy the lookup so that we're not changing the original which may be passed elsewhere.
					copy[p] = lookup[p];
				}
				copy.opacity = 1;
				if (copy.autoAlpha) {
					copy.visibility = 1;
				}
			}
			return TweenPlugin.prototype._kill.call(this, copy);
		}
		
		
		TweenPlugin.activate([CSSPlugin]);
		return CSSPlugin;
		
	}, true);


	
	
	
	
	
	
	
	
	
	
	
	
	
/*
 * ----------------------------------------------------------------
 * RoundPropsPlugin
 * ----------------------------------------------------------------
 */
	_gsDefine("plugins.RoundPropsPlugin", ["plugins.TweenPlugin"], function(TweenPlugin) {
		
		var RoundPropsPlugin = function(props, priority) {
				TweenPlugin.call(this, "roundProps", -1);
				this._overwriteProps.length = 0;
			},
			p = RoundPropsPlugin.prototype = new TweenPlugin("roundProps", -1);
		
		p.constructor = RoundPropsPlugin;
		RoundPropsPlugin.API = 2;
		
		p._onInitTween = function(target, value, tween) {
			this._tween = tween;
			return true;
		}
		
		p._onInitAllProps = function() {
			var tween = this._tween,
				rp = (tween.vars.roundProps instanceof Array) ? tween.vars.roundProps : tween.vars.roundProps.split(","), 
				i = rp.length,
				lookup = {},
				rpt = tween._propLookup.roundProps,
				prop, pt, next;
			while (--i > -1) {
				lookup[rp[i]] = 1;
			}
			i = rp.length;
			while (--i > -1) {
				prop = rp[i];
				pt = tween._firstPT;
				while (pt) {
					next = pt._next; //record here, because it may get removed
					if (pt.pg) {
						pt.t._roundProps(lookup, true);
					} else if (pt.n === prop) {
						this._add(pt.t, prop, pt.s, pt.c);
						//remove from linked list
						if (next) {
							next._prev = pt._prev;
						}
						if (pt._prev) {
							pt._prev._next = next;
						} else if (_tween._firstPT === pt) {
							tween._firstPT = next;
						}
						pt._next = pt._prev = null;
						tween._propLookup[prop] = rpt;
					}
					pt = next;
				}
			}
			return false;
		}
				
		p._add = function(target, p, s, c) {
			this._addTween(target, p, s, s + c, p, true);
			this._overwriteProps.push(p);
		}
		
		TweenPlugin.activate([RoundPropsPlugin]);
		
		return RoundPropsPlugin;
		
	}, true);



	
	
	
	
	
	
	
/*
 * ----------------------------------------------------------------
 * EasePack
 * ----------------------------------------------------------------
 */
	_gsDefine("easing.Back", ["easing.Ease"], function(Ease) {
		
		var gs = window.com.greensock, 
			_class = gs._class, 
			_create = function(n, f) {
				var c = _class("easing." + n, function(){}, true), 
					p = c.prototype = new Ease();
				p.constructor = c;
				p.getRatio = f;
				return c;
			},
			
			//BACK
			_createBack = function(n, f) {
				var c = _class("easing." + n, function(overshoot) {
						this._p1 = (overshoot || overshoot === 0) ? overshoot : 1.70158;
						this._p2 = this._p1 * 1.525;
					}, true), 
					p = c.prototype = new Ease();
				p.constructor = c;
				p.getRatio = f;
				p.config = function(overshoot) {
					return new c(overshoot);
				};
				return c;
			}, 
			BackOut = _createBack("BackOut", function(p) {
				return ((p = p - 1) * p * ((this._p1 + 1) * p + this._p1) + 1);
			}), 
			BackIn = _createBack("BackIn", function(p) {
				return p * p * ((this._p1 + 1) * p - this._p1);
			}), 
			BackInOut = _createBack("BackInOut", function(p) {
				return ((p *= 2) < 1) ? 0.5 * p * p * ((this._p2 + 1) * p - this._p2) : 0.5 * ((p -= 2) * p * ((this._p2 + 1) * p + this._p2) + 2);
			}),  
			
			//BOUNCE
			BounceOut = _create("BounceOut", function(p) {
				if (p < 1 / 2.75) {
					return 7.5625 * p * p;
				} else if (p < 2 / 2.75) {
					return 7.5625 * (p -= 1.5 / 2.75) * p + .75;
				} else if (p < 2.5 / 2.75) {
					return 7.5625 * (p -= 2.25 / 2.75) * p + .9375;
				} else {
					return 7.5625 * (p -= 2.625 / 2.75) * p + .984375;
				}
			}), 
			BounceIn = _create("BounceIn", function(p) {
				if ((p = 1 - p) < 1 / 2.75) {
					return 1 - (7.5625 * p * p);
				} else if (p < 2 / 2.75) {
					return 1 - (7.5625 * (p -= 1.5 / 2.75) * p + .75);
				} else if (p < 2.5 / 2.75) {
					return 1 - (7.5625 * (p -= 2.25 / 2.75) * p + .9375);
				} else {
					return 1 - (7.5625 * (p -= 2.625 / 2.75) * p + .984375);
				}
			}), 
			BounceInOut = _create("BounceInOut", function(p) {
				var invert = (p < 0.5);
				if (invert) {
					p = 1 - (p * 2);
				} else {
					p = (p * 2) - 1;
				}
				if (p < 1 / 2.75) {
					p = 7.5625 * p * p;
				} else if (p < 2 / 2.75) {
					p = 7.5625 * (p -= 1.5 / 2.75) * p + .75;
				} else if (p < 2.5 / 2.75) {
					p = 7.5625 * (p -= 2.25 / 2.75) * p + .9375;
				} else {
					p = 7.5625 * (p -= 2.625 / 2.75) * p + .984375;
				}
				return invert ? (1 - p) * 0.5 : p * 0.5 + 0.5;
			}),
			
			//CIRC
			CircOut = _create("CircOut", function(p) {
				return Math.sqrt(1 - (p = p - 1) * p);
			}),
			CircIn = _create("CircIn", function(p) {
				return -(Math.sqrt(1 - (p * p)) - 1);
			}),
			CircInOut = _create("CircInOut", function(p) {
				return ((p*=2) < 1) ? -0.5 * (Math.sqrt(1 - p * p) - 1) : 0.5 * (Math.sqrt(1 - (p -= 2) * p) + 1);
			}),
			
			//ELASTIC
			_2PI = Math.PI * 2,
			_createElastic = function(n, f, def) {
				var c = _class("easing." + n, function(amplitude, period) {
						this._p1 = amplitude || 1;
						this._p2 = period || def;
						this._p3 = this._p2 / _2PI * (Math.asin(1 / this._p1) || 0);
					}, true), 
					p = c.prototype = new Ease();
				p.constructor = c;
				p.getRatio = f;
				p.config = function(amplitude, period) {
					return new c(amplitude, period);
				};
				return c;
			}, 
			ElasticOut = _createElastic("ElasticOut", function(p) {
				return this._p1 * Math.pow(2, -10 * p) * Math.sin( (p - this._p3) * _2PI / this._p2 ) + 1;
			}, 0.3), 
			ElasticIn = _createElastic("ElasticIn", function(p) {
				return -(this._p1 * Math.pow(2, 10 * (p -= 1)) * Math.sin( (p - this._p3) * _2PI / this._p2 ));
			}, 0.3), 
			ElasticInOut = _createElastic("ElasticInOut", function(p) {
				return ((p *= 2) < 1) ? -.5 * (this._p1 * Math.pow(2, 10 * (p -= 1)) * Math.sin( (p - this._p3) * _2PI / this._p2)) : this._p1 * Math.pow(2, -10 *(p -= 1)) * Math.sin( (p - this._p3) * _2PI / this._p2 ) *.5 + 1;
			}, 0.45),
			
			//Expo
			ExpoOut = _create("ExpoOut", function(p) {
				return 1 - Math.pow(2, -10 * p);
			}),
			ExpoIn = _create("ExpoIn", function(p) {
				return Math.pow(2, 10 * (p - 1)) - 0.001;
			}),
			ExpoInOut = _create("ExpoInOut", function(p) {
				return ((p *= 2) < 1) ? 0.5 * Math.pow(2, 10 * (p - 1)) : 0.5 * (2 - Math.pow(2, -10 * (p - 1)));
			}), 
			
			//Sine
			_HALF_PI = Math.PI / 2,
			SineOut = _create("SineOut", function(p) {
				return Math.sin(p * _HALF_PI);
			}),
			SineIn = _create("SineIn", function(p) {
				return -Math.cos(p * _HALF_PI) + 1;
			}),
			SineInOut = _create("SineInOut", function(p) {
				return -0.5 * (Math.cos(Math.PI * p) - 1);
			}),
			
			//SlowMo
			SlowMo = _class("easing.SlowMo", function(linearRatio, power, yoyoMode) {
				power = (power || power === 0) ? power : 0.7;
				if (linearRatio == null) {
					linearRatio = 0.7;
				} else if (linearRatio > 1) {
					linearRatio = 1;
				}
				this._p = (linearRatio != 1) ? power : 0;
				this._p1 = (1 - linearRatio) / 2;
				this._p2 = linearRatio;
				this._p3 = this._p1 + this._p2;
				this._calcEnd = (yoyoMode === true);
			}, true),
			p = SlowMo.prototype = new Ease();
			
		p.constructor = SlowMo;
		p.getRatio = function(p) {
			var r = p + (0.5 - p) * this._p;
			if (p < this._p1) {
				return this._calcEnd ? 1 - ((p = 1 - (p / this._p1)) * p) : r - ((p = 1 - (p / this._p1)) * p * p * p * r);
			} else if (p > this._p3) {
				return this._calcEnd ? 1 - (p = (p - this._p3) / this._p1) * p : r + ((p - r) * (p = (p - this._p3) / this._p1) * p * p * p);
			}
			return this._calcEnd ? 1 : r;
		};
		SlowMo.ease = new SlowMo(0.7, 0.7);
		
		p.config = SlowMo.config = function(linearRatio, power, yoyoMode) {
			return new SlowMo(linearRatio, power, yoyoMode);
		};
		
		
		//SteppedEase
		var SteppedEase = _class("easing.SteppedEase", function(steps) {
				steps = steps || 1;
				this._p1 = 1 / steps;
				this._p2 = steps + 1;
			}, true);
		p = SteppedEase.prototype = new Ease();	
		p.constructor = SteppedEase;
		p.getRatio = function(p) {
			if (p < 0) {
				p = 0;
			} else if (p >= 1) {
				p = 0.999999999;
			}
			return ((this._p2 * p) >> 0) * this._p1;
		};
		p.config = SteppedEase.config = function(steps) {
			return new SteppedEase(steps);
		};
		
		
		_class("easing.Bounce", {
				easeOut:new BounceOut(),
				easeIn:new BounceIn(),
				easeInOut:new BounceInOut()
			}, true);
		
		_class("easing.Circ", {
				easeOut:new CircOut(),
				easeIn:new CircIn(),
				easeInOut:new CircInOut()
			}, true);
		
		_class("easing.Elastic", {
				easeOut:new ElasticOut(),
				easeIn:new ElasticIn(),
				easeInOut:new ElasticInOut()
			}, true);
			
		_class("easing.Expo", {
				easeOut:new ExpoOut(),
				easeIn:new ExpoIn(),
				easeInOut:new ExpoInOut()
			}, true);
			
		_class("easing.Sine", {
				easeOut:new SineOut(),
				easeIn:new SineIn(),
				easeInOut:new SineInOut()
			}, true);
		
		
		return {
			easeOut:new BackOut(),
			easeIn:new BackIn(),
			easeInOut:new BackInOut()
		};
		
	}, true);


}); 







/*
 * ----------------------------------------------------------------
 * Base classes like TweenLite, SimpleTimeline, Ease, Ticker, etc. (!TweenLite)
 * ----------------------------------------------------------------
 */
(function(window) {
	
		"use strict";
		var _namespace = function(ns) {
				var a = ns.split("."), 
					p = window, i;
				for (i = 0; i < a.length; i++) {
					p[a[i]] = p = p[a[i]] || {};
				}
				return p;
			},
			gs = _namespace("com.greensock"),
			a, i, e, e2, p, _gsInit,
			_classLookup = {},
			
			//_DepClass is for defining a dependent class. ns = namespace (leaving off "com.greensock." as that's assumed), dep = an array of namespaces that are required, def = the function that will return the class definition (this function will be passed each dependency in order as soon as they arrive), global = if true, the class is added to the global scope (window) or if requirejs is being used, it will tap into that instead.
			_DepClass = function(ns, dep, def, global) {
				this.sc = (_classLookup[ns]) ? _classLookup[ns].sc : []; //subclasses
				_classLookup[ns] = this;
				this.gsClass = null;
				this.def = def;
				var _dep = dep || [],
					_classes = [];
				this.check = function(init) {
					var i = _dep.length, cnt = 0, cur;
					while (--i > -1) {
						if ((cur = _classLookup[_dep[i]] || new _DepClass(_dep[i])).gsClass) {
							_classes[i] = cur.gsClass;
						} else {
							cnt++;
							if (init) {
								cur.sc.push(this);
							}
						}
					}
					if (cnt === 0 && def) {
						var a = ("com.greensock." + ns).split("."),
							n = a.pop(),
							cl = _namespace(a.join("."))[n] = this.gsClass = def.apply(def, _classes);
						
						//exports to multiple environments
						if (global) {
							(window.GreenSockGlobals || window)[n] = cl; //provides a way to avoid global namespace pollution. By default, the main classes like TweenLite, Power1, Strong, etc. are added to window unless a GreenSockGlobals is defined. So if you want to have things added to a custom object instead, just do something like window.GreenSockGlobals = {} before loading any GreenSock files. You can even set up an alias like window.GreenSockGlobals = windows.gs = {} so that you can access everything like gs.TweenLite. Also remember that ALL classes are added to the window.com.greensock object (in their respective packages, like com.greensock.easing.Power1, com.greensock.TweenLite, etc.)
							if (typeof(define) === "function" && define.amd){ //AMD
								define((window.GreenSockAMDPath ? window.GreenSockAMDPath + "/" : "") + ns.split(".").join("/"), [], function() { return cl; });
							} else if (typeof(module) !== "undefined" && module.exports){ //node
								module.exports = cl;
							}
						}
						
						for (i = 0; i < this.sc.length; i++) {
							this.sc[i].check(false);
						}
						
					}
				};
				this.check(true);
			},
			//a quick way to create a class that doesn't have any dependencies. Returns the class, but first registers it in the GreenSock namespace so that other classes can grab it (other classes might be dependent on the class).
			_class = gs._class = function(ns, f, g) {
				new _DepClass(ns, [], function(){ return f; }, g);
				return f;
			};
		
		//used to create _DepClass instances (which basically registers a class that has dependencies). ns = namespace, dep = dependencies (array), f = initialization function which should return the class, g = global (whether or not the class should be added to the global namespace (or if RequireJS is used, it will be defined as a named module instead)
		window._gsDefine = function(ns, dep, f, g) {
			return new _DepClass(ns, dep, f, g);
		};
		
	

/*
 * ----------------------------------------------------------------
 * Ease
 * ----------------------------------------------------------------
 */
		var _baseParams = [0, 0, 1, 1],
			_blankArray = [],
			Ease = _class("easing.Ease", function(func, extraParams, type, power) {
				this._func = func;
				this._type = type || 0;
				this._power = power || 0;
				this._params = extraParams ? _baseParams.concat(extraParams) : _baseParams;
			}, true);
		
		p = Ease.prototype;
		p._calcEnd = false;
		p.getRatio = function(p) {
			if (this._func) {
				this._params[0] = p;
				return this._func.apply(null, this._params);
			} else {
				var t = this._type, 
					pw = this._power, 
					r = (t === 1) ? 1 - p : (t === 2) ? p : (p < 0.5) ? p * 2 : (1 - p) * 2;
				if (pw === 1) {
					r *= r;
				} else if (pw === 2) {
					r *= r * r;
				} else if (pw === 3) {
					r *= r * r * r;
				} else if (pw === 4) {
					r *= r * r * r * r;
				}
				return (t === 1) ? 1 - r : (t === 2) ? r : (p < 0.5) ? r / 2 : 1 - (r / 2);
			}
		};
		
		//create all the standard eases like Linear, Quad, Cubic, Quart, Quint, Strong, Power0, Power1, Power2, Power3, and Power4 (each with easeIn, easeOut, and easeInOut)
		a = ["Linear","Quad","Cubic","Quart","Quint"];
		i = a.length;
		while(--i > -1) {
			e = _class("easing." + a[i], function(){}, true);
			e2 = _class("easing.Power" + i, function(){}, true);
			e.easeOut = e2.easeOut = new Ease(null, null, 1, i);
			e.easeIn = e2.easeIn = new Ease(null, null, 2, i);
			e.easeInOut = e2.easeInOut = new Ease(null, null, 3, i);
		}
		_class("easing.Strong", gs.easing.Power4, true);
		gs.easing.Linear.easeNone = gs.easing.Linear.easeIn;
	

/*
 * ----------------------------------------------------------------
 * EventDispatcher
 * ----------------------------------------------------------------
 */
		p = _class("events.EventDispatcher", function(target) {
			this._listeners = {};
			this._eventTarget = target || this;
		}).prototype;
		
		p.addEventListener = function(type, callback, scope, useParam, priority) {
			priority = priority || 0;
			var list = this._listeners[type],
				index = 0,
				listener, i;
			if (list == null) {
				this._listeners[type] = list = [];
			}
			i = list.length;
			while (--i > -1) {
				listener = list[i];
				if (listener.c === callback) {
					list.splice(i, 1);
				} else if (index === 0 && listener.pr < priority) {
					index = i + 1;
				}
			}
			list.splice(index, 0, {c:callback, s:scope, up:useParam, pr:priority});
		};
		
		p.removeEventListener = function(type, callback) {
			var list = this._listeners[type];
			if (list) {
				var i = list.length;
				while (--i > -1) {
					if (list[i].c === callback) {
						list.splice(i, 1);
						return;
					}
				}
			}
		};
		
		p.dispatchEvent = function(type) {
			var list = this._listeners[type];
			if (list) {
				var i = list.length, listener,
					t = this._eventTarget;
				while (--i > -1) {
					listener = list[i];
					if (listener.up) {
						listener.c.call(listener.s || t, {type:type, target:t});
					} else {
						listener.c.call(listener.s || t);
					}
				}
			}
		};


/*
 * ----------------------------------------------------------------
 * Ticker
 * ----------------------------------------------------------------
 */
 		var _reqAnimFrame = window.requestAnimationFrame, 
			_cancelAnimFrame = window.cancelAnimationFrame, 
			_getTime = Date.now || function() {return new Date().getTime();};
		
		//now try to determine the requestAnimationFrame and cancelAnimationFrame functions and if none are found, we'll use a setTimeout()/clearTimeout() polyfill.
		a = ["ms","moz","webkit","o"];
		i = a.length;
		while (--i > -1 && !_reqAnimFrame) {
			_reqAnimFrame = window[a[i] + "RequestAnimationFrame"];
			_cancelAnimFrame = window[a[i] + "CancelAnimationFrame"] || window[a[i] + "CancelRequestAnimationFrame"];
		}
		if (!_cancelAnimFrame) {
			_cancelAnimFrame = function(id) {
				window.clearTimeout(id);
			}
		}
		
		_class("Ticker", function(fps, useRAF) {
			this.time = 0;
			this.frame = 0;
			var _self = this,
				_startTime = _getTime(),
				_useRAF = (useRAF !== false),
				_fps, _req, _id, _gap, _nextTime;
			
			this.tick = function() {
				_self.time = (_getTime() - _startTime) / 1000;
				if (!_fps || _self.time >= _nextTime) {
					_self.frame++;
					_nextTime = _self.time + _gap - (_self.time - _nextTime) - 0.0005;
					if (_nextTime <= _self.time) {
						_nextTime = _self.time + 0.001;
					}
					_self.dispatchEvent("tick");
				}
				_id = _req( _self.tick );
			};
			
			this.fps = function(value) {
				if (!arguments.length) {
					return _fps;
				}
				_fps = value;
				_gap = 1 / (_fps || 60);
				_nextTime = this.time + _gap;
				_req = (_fps === 0) ? function(f){} : (!_useRAF || !_reqAnimFrame) ? function(f) { return window.setTimeout( f, (((_nextTime - _self.time) * 1000 + 1) >> 0) || 1);	} : _reqAnimFrame;
				_cancelAnimFrame(_id);
				_id = _req( _self.tick );
			};
			
			this.useRAF = function(value) {
				if (!arguments.length) {
					return _useRAF
				}
				_useRAF = value;
				this.fps(_fps);
			};
			
			this.fps(fps);
		});
		
		p = gs.Ticker.prototype = new gs.events.EventDispatcher();
		p.constructor = gs.Ticker;


/*
 * ----------------------------------------------------------------
 * Animation
 * ----------------------------------------------------------------
 */
		var Animation = _class("core.Animation", function(duration, vars) {
				this.vars = vars || {};
				this._duration = this._totalDuration = duration || 0;
				this._delay = Number(this.vars.delay) || 0;
				this._timeScale = 1;
				this._active = (this.vars.immediateRender == true);
				this.data = this.vars.data;
				this._reversed = (this.vars.reversed == true);
				
				if (!_rootTimeline) {
					return;
				}
				if (!_gsInit) {
					_ticker.tick(); //the first time an animation (tween or timeline) is created, we should refresh the time in order to avoid a gap. The Ticker's initial time that it records might be very early in the load process and the user may have loaded several other large scripts in the mean time, but we want tweens to act as though they started when the page's onload was fired. Also remember that the requestAnimationFrame likely won't be called until the first screen redraw.
					_gsInit = true;
				}
				
				var tl = this.vars.useFrames ? _rootFramesTimeline : _rootTimeline;
				tl.insert(this, tl._time);
				
				if (this.vars.paused) {
					this.paused(true);
				}
			}),
			_ticker = Animation.ticker = new gs.Ticker();
		
		p = Animation.prototype;
		p._dirty = p._gc = p._initted = p._paused = false;
		p._totalTime = p._time = 0;
		p._rawPrevTime = -1;
		p._next = p._last = p._onUpdate = p._timeline = p.timeline = null;
		p._paused = false;
		
		p.play = function(from, suppressEvents) {
			if (arguments.length) {
				this.seek(from, suppressEvents);
			}
			this.reversed(false);
			return this.paused(false);
		};
		
		p.pause = function(atTime, suppressEvents) {
			if (arguments.length) {
				this.seek(atTime, suppressEvents);
			}
			return this.paused(true);
		};
		
		p.resume = function(from, suppressEvents) {
			if (arguments.length) {
				this.seek(from, suppressEvents);
			}
			return this.paused(false);
		};
		
		p.seek = function(time, suppressEvents) {
			return this.totalTime(Number(time), (suppressEvents != false));
		};
		
		p.restart = function(includeDelay, suppressEvents) {
			this.reversed(false);
			this.paused(false);
			return this.totalTime((includeDelay) ? -this._delay : 0, (suppressEvents != false));
		};
		
		p.reverse = function(from, suppressEvents) {
			if (arguments.length) {
				this.seek((from || this.totalDuration()), suppressEvents);
			}
			this.reversed(true);
			return this.paused(false);
		};
		
		p.render = function() {
			
		};
		
		p.invalidate = function() {
			return this;
		};
		
		p._enabled = function (enabled, ignoreTimeline) {
			this._gc = !enabled; 
			this._active = (enabled && !this._paused && this._totalTime > 0 && this._totalTime < this._totalDuration);
			if (ignoreTimeline != true) {
				if (enabled && this.timeline == null) {
					this._timeline.insert(this, this._startTime - this._delay);
				} else if (!enabled && this.timeline != null) {
					this._timeline._remove(this, true);
				}
			}
			return false;
		};
	
		
		p._kill = function(vars, target) {
			return this._enabled(false, false);
		};
		
		p.kill = function(vars, target) {
			this._kill(vars, target);
			return this;
		};
		
		p._uncache = function(includeSelf) {
			var tween = includeSelf ? this : this.timeline;
			while (tween) {
				tween._dirty = true;
				tween = tween.timeline;
			}
			return this;
		};
	
//----Animation getters/setters --------------------------------------------------------
		
		p.eventCallback = function(type, callback, params, scope) {
			if (type == null) {
				return null;
			} else if (type.substr(0,2) === "on") {
				if (arguments.length === 1) {
					return this.vars[type];
				}
				if (callback == null) {
					delete this.vars[type];
				} else {
					this.vars[type] = callback;
					this.vars[type + "Params"] = params;
					this.vars[type + "Scope"] = scope;
					if (params) {
						var i = params.length;
						while (--i > -1) {
							if (params[i] === "{self}") {
								params = this.vars[type + "Params"] = params.concat(); //copying the array avoids situations where the same array is passed to multiple tweens/timelines and {self} doesn't correctly point to each individual instance.
								params[i] = this;
							}
						}
					}
				}
				if (type === "onUpdate") {
					this._onUpdate = callback;
				}
			}
			return this;
		}
		
		p.delay = function(value) {
			if (!arguments.length) {
				return this._delay;
			}
			if (this._timeline.smoothChildTiming) {
				this.startTime( this._startTime + value - this._delay );
			}
			this._delay = value;
			return this;
		};
		
		p.duration = function(value) {
			if (!arguments.length) {
				this._dirty = false;
				return this._duration;
			}
			this._duration = this._totalDuration = value;
			this._uncache(true); //true in case it's a TweenMax or TimelineMax that has a repeat - we'll need to refresh the totalDuration. 
			if (this._timeline.smoothChildTiming) if (this._active) if (value != 0) {
				this.totalTime(this._totalTime * (value / this._duration), true);
			}
			return this;
		};
		
		p.totalDuration = function(value) {
			this._dirty = false;
			return (!arguments.length) ? this._totalDuration : this.duration(value);
		};
		
		p.time = function(value, suppressEvents) {
			if (!arguments.length) {
				return this._time;
			}
			if (this._dirty) {
				this.totalDuration();
			}
			if (value > this._duration) {
				value = this._duration;
			}
			return this.totalTime(value, suppressEvents);
		};
		
		p.totalTime = function(time, suppressEvents) {
			if (!arguments.length) {
				return this._totalTime;
			}
			if (this._timeline) {
				if (time < 0) {
					time += this.totalDuration();
				}
				if (this._timeline.smoothChildTiming) {
					if (this._dirty) {
						this.totalDuration();
					}
					if (time > this._totalDuration) {
						time = this._totalDuration;
					}
					this._startTime = (this._paused ? this._pauseTime : this._timeline._time) - ((!this._reversed ? time : this._totalDuration - time) / this._timeScale);
					if (!this._timeline._dirty) { //for performance improvement. If the parent's cache is already dirty, it already took care of marking the anscestors as dirty too, so skip the function call here.
						this._uncache(false);
					}
					if (!this._timeline._active) {
						//in case any of the anscestors had completed but should now be enabled...
						var tl = this._timeline;
						while (tl._timeline) {
							tl.totalTime(tl._totalTime, true);
							tl = tl._timeline;
						}
					}
				}
				if (this._gc) {
					this._enabled(true, false);
				}
				if (this._totalTime != time) {
					this.render(time, suppressEvents, false);
				}
			}
			return this;
		};
		
		p.startTime = function(value) {
			if (!arguments.length) {
				return this._startTime;
			}
			if (value != this._startTime) {
				this._startTime = value;
				if (this.timeline) if (this.timeline._sortChildren) {
					this.timeline.insert(this, value - this._delay); //ensures that any necessary re-sequencing of Animations in the timeline occurs to make sure the rendering order is correct.
				}
			}
			return this;
		};
		
		p.timeScale = function(value) {
			if (!arguments.length) {
				return this._timeScale;
			}
			value = value || 0.000001; //can't allow zero because it'll throw the math off
			if (this._timeline && this._timeline.smoothChildTiming) {
				var t = (this._pauseTime || this._pauseTime == 0) ? this._pauseTime : this._timeline._totalTime;
				this._startTime = t - ((t - this._startTime) * this._timeScale / value);
			}
			this._timeScale = value;
			return this._uncache(false);
		};
		
		p.reversed = function(value) {
			if (!arguments.length) {
				return this._reversed;
			}
			if (value != this._reversed) {
				this._reversed = value;
				this.totalTime(this._totalTime, true);
			}
			return this;
		};
		
		p.paused = function(value) {
			if (!arguments.length) {
				return this._paused;
			}
			if (value != this._paused) if (this._timeline) {
				if (!value && this._timeline.smoothChildTiming) {
					this._startTime += this._timeline.rawTime() - this._pauseTime;
					this._uncache(false);
				}
				this._pauseTime = (value) ? this._timeline.rawTime() : null;
				this._paused = value;
				this._active = (!this._paused && this._totalTime > 0 && this._totalTime < this._totalDuration);
			}
			if (this._gc) if (!value) {
				this._enabled(true, false);
			}
			return this;
		};
	

/*
 * ----------------------------------------------------------------
 * SimpleTimeline
 * ----------------------------------------------------------------
 */
		var SimpleTimeline = _class("core.SimpleTimeline", function(vars) {
			Animation.call(this, 0, vars);
			this.autoRemoveChildren = this.smoothChildTiming = true;
		});
		
		p = SimpleTimeline.prototype = new Animation();
		p.constructor = SimpleTimeline;
		p.kill()._gc = false;
		p._first = p._last = null;
		p._sortChildren = false;
		
		p.insert = function(tween, time) {
			tween._startTime = Number(time || 0) + tween._delay;
			if (tween._paused) if (this !== tween._timeline) { //we only adjust the _pauseTime if it wasn't in this timeline already. Remember, sometimes a tween will be inserted again into the same timeline when its startTime is changed so that the tweens in the TimelineLite/Max are re-ordered properly in the linked list (so everything renders in the proper order). 
				tween._pauseTime = tween._startTime + ((this.rawTime() - tween._startTime) / tween._timeScale);
			}
			if (tween.timeline) {
				tween.timeline._remove(tween, true); //removes from existing timeline so that it can be properly added to this one.
			}
			tween.timeline = tween._timeline = this;
			if (tween._gc) {
				tween._enabled(true, true);
			}
			
			var prevTween = this._last;
			if (this._sortChildren) {
				var st = tween._startTime;
				while (prevTween && prevTween._startTime > st) {
					prevTween = prevTween._prev;
				}
			}
			if (prevTween) {
				tween._next = prevTween._next;
				prevTween._next = tween;
			} else {
				tween._next = this._first;
				this._first = tween;
			}
			if (tween._next) {
				tween._next._prev = tween;
			} else {
				this._last = tween;
			}
			tween._prev = prevTween;
			
			if (this._timeline) {
				this._uncache(true);
			}
			return this;
		};
		
		p._remove = function(tween, skipDisable) {
			if (tween.timeline === this) {
				if (!skipDisable) {
					tween._enabled(false, true);
				}
				tween.timeline = null;
				
				if (tween._prev) {
					tween._prev._next = tween._next;
				} else if (this._first === tween) {
					this._first = tween._next;
				}
				if (tween._next) {
					tween._next._prev = tween._prev;
				} else if (this._last === tween) {
					this._last = tween._prev;
				}
				
				if (this._timeline) {
					this._uncache(true);
				}
			}
			return this;
		};
		
		p.render = function(time, suppressEvents, force) {
			var tween = this._first, 
				next;
			this._totalTime = this._time = this._rawPrevTime = time;
			while (tween) {
				next = tween._next; //record it here because the value could change after rendering...
				if (tween._active || (time >= tween._startTime && !tween._paused)) {
					if (!tween._reversed) {
						tween.render((time - tween._startTime) * tween._timeScale, suppressEvents, false);
					} else {
						tween.render(((!tween._dirty) ? tween._totalDuration : tween.totalDuration()) - ((time - tween._startTime) * tween._timeScale), suppressEvents, false);
					}
				}
				tween = next;
			}
		};
				
		p.rawTime = function() {
			return this._totalTime;			
		};
	
	
/*
 * ----------------------------------------------------------------
 * TweenLite
 * ----------------------------------------------------------------
 */
		var TweenLite = _class("TweenLite", function(target, duration, vars) {
				Animation.call(this, duration, vars);
				
				if (target == null) {
					throw "Cannot tween an undefined reference.";
				}
				this.target = target;		
				
				this._overwrite = (this.vars.overwrite == null) ? _overwriteLookup[TweenLite.defaultOverwrite] : (typeof(this.vars.overwrite) === "number") ? this.vars.overwrite >> 0 : _overwriteLookup[this.vars.overwrite];
				
				var jq, i, targ;
				if ((target instanceof Array || target.jquery) && typeof(target[0]) === "object") { 
					this._targets = target.slice(0); //works for both jQuery and Array instances
					this._propLookup = [];
					this._siblings = [];
					for (i = 0; i < this._targets.length; i++) {
						targ = this._targets[i];
						//in case the user is passing in an array of jQuery objects, for example, we need to check one more level and pull things out if necessary...
						if (targ.jquery) { 
							this._targets.splice(i--, 1);
							this._targets = this._targets.concat(targ.constructor.makeArray(targ));
							continue;
						}
						this._siblings[i] = _register(targ, this, false);
						if (this._overwrite === 1) if (this._siblings[i].length > 1) {
							_applyOverwrite(targ, this, null, 1, this._siblings[i]);
						}
					}
					
				} else {
					this._propLookup = {};
					this._siblings = _register(target, this, false);
					if (this._overwrite === 1) if (this._siblings.length > 1) {
						_applyOverwrite(target, this, null, 1, this._siblings);
					}
				}
				
				if (this.vars.immediateRender || (duration === 0 && this._delay === 0 && this.vars.immediateRender != false)) {
					this.render(-this._delay, false, true);
				}
			}, true);
	
		p = TweenLite.prototype = new Animation();
		p.constructor = TweenLite;
		p.kill()._gc = false;
	
//----TweenLite defaults, overwrite management, and root updates ----------------------------------------------------
	
		p.ratio = 0;
		p._firstPT = p._targets = p._overwrittenProps = null;
		p._notifyPluginsOfEnabled = false;
		
		TweenLite.version = 12;
		TweenLite.defaultEase = p._ease = new Ease(null, null, 1, 1);
		TweenLite.defaultOverwrite = "auto";
		TweenLite.ticker = _ticker;
		
		var _plugins = TweenLite._plugins = {},
			_tweenLookup = TweenLite._tweenLookup = {}, 
			_tweenLookupNum = 0,
			_reservedProps = {ease:1, delay:1, overwrite:1, onComplete:1, onCompleteParams:1, onCompleteScope:1, useFrames:1, runBackwards:1, startAt:1, onUpdate:1, onUpdateParams:1, onUpdateScope:1, onStart:1, onStartParams:1, onStartScope:1, onReverseComplete:1, onReverseCompleteParams:1, onReverseCompleteScope:1, onRepeat:1, onRepeatParams:1, onRepeatScope:1, easeParams:1, yoyo:1, orientToBezier:1, immediateRender:1, repeat:1, repeatDelay:1, data:1, paused:1, reversed:1},
			_overwriteLookup = {none:0, all:1, auto:2, concurrent:3, allOnStart:4, preexisting:5, "true":1, "false":0},
			_rootFramesTimeline = Animation._rootFramesTimeline = new SimpleTimeline(), 
			_rootTimeline = Animation._rootTimeline = new SimpleTimeline();
			
		_rootTimeline._startTime = _ticker.time;
		_rootFramesTimeline._startTime = _ticker.frame;
		_rootTimeline._active = _rootFramesTimeline._active = true;
		
		Animation._updateRoot = function() {
				_rootTimeline.render((_ticker.time - _rootTimeline._startTime) * _rootTimeline._timeScale, false, false);
				_rootFramesTimeline.render((_ticker.frame - _rootFramesTimeline._startTime) * _rootFramesTimeline._timeScale, false, false);
				if (!(_ticker.frame % 120)) { //dump garbage every 120 frames...
					var i, a, p;
					for (p in _tweenLookup) {
						a = _tweenLookup[p].tweens;
						i = a.length;
						while (--i > -1) {
							if (a[i]._gc) {
								a.splice(i, 1);
							}
						}
						if (a.length === 0) {
							delete _tweenLookup[p];
						}
					}
				}
			};
		
		_ticker.addEventListener("tick", Animation._updateRoot);
		
		var _register = function(target, tween, scrub) {
				var id = target._gsTweenID, a, i;
				if (!_tweenLookup[id || (target._gsTweenID = id = "t" + (_tweenLookupNum++))]) {
					_tweenLookup[id] = {target:target, tweens:[]};
				}
				if (tween) {
					a = _tweenLookup[id].tweens;
					a[(i = a.length)] = tween;
					if (scrub) {
						while (--i > -1) {
							if (a[i] === tween) {
								a.splice(i, 1);
							}
						}
					}
				}
				return _tweenLookup[id].tweens;
			},
			
			_applyOverwrite = function(target, tween, props, mode, siblings) {
				var i, changed, curTween;
				if (mode === 1 || mode >= 4) {
					var l = siblings.length;
					for (i = 0; i < l; i++) {
						if ((curTween = siblings[i]) !== tween) {
							if (!curTween._gc) if (curTween._enabled(false, false)) {
								changed = true;
							}
						} else if (mode === 5) {
							break;
						}
					}
					return changed;
				}
				//NOTE: Add 0.0000000001 to overcome floating point errors that can cause the startTime to be VERY slightly off (when a tween's time() is set for example)
				var startTime = tween._startTime + 0.0000000001, 
					overlaps = [], 
					oCount = 0, 
					globalStart;
				i = siblings.length;
				while (--i > -1) {
					if ((curTween = siblings[i]) === tween || curTween._gc || curTween._paused) {
						//ignore
					} else if (curTween._timeline !== tween._timeline) {
						globalStart = globalStart || _checkOverlap(tween, 0);
						if (_checkOverlap(curTween, globalStart) === 0) {
							overlaps[oCount++] = curTween;
						}
					} else if (curTween._startTime <= startTime) if (curTween._startTime + curTween.totalDuration() / curTween._timeScale + 0.0000000001 > startTime) if (!((tween._duration === 0 || !curTween._initted) && startTime - curTween._startTime <= 0.0000000002)) {
						overlaps[oCount++] = curTween;
					}
				}
				
				i = oCount;
				while (--i > -1) {
					curTween = overlaps[i];
					if (mode === 2) if (curTween._kill(props, target)) {
						changed = true;
					}
					if (mode !== 2 || (!curTween._firstPT && curTween._initted)) { 
						if (curTween._enabled(false, false)) { //if all property tweens have been overwritten, kill the tween.
							changed = true;
						}
					}
				}
				return changed;
			},
			
			_checkOverlap = function(tween, reference) {
				var tl = tween._timeline, 
					ts = tl._timeScale, 
					t = tween._startTime;
				while (tl._timeline) {
					t += tl._startTime;
					ts *= tl._timeScale;
					if (tl._paused) {
						return -100;
					}
					tl = tl._timeline;
				}
				t /= ts;
				return (t > reference) ? t - reference : (!tween._initted && t - reference < 0.0000000002) ? 0.0000000001 : ((t = t + tween.totalDuration() / tween._timeScale / ts) > reference) ? 0 : t - reference - 0.0000000001;
			};

	
//---- TweenLite instance methods -----------------------------------------------------------------------------

		p._init = function() {
			if (this.vars.startAt) {
				this.vars.startAt.overwrite = 0;
				this.vars.startAt.immediateRender = true;
				TweenLite.to(this.target, 0, this.vars.startAt);
			}
			var i, initPlugins, pt;
			if (this.vars.ease instanceof Ease) {
				this._ease = (this.vars.easeParams instanceof Array) ? this.vars.ease.config.apply(this.vars.ease, this.vars.easeParams) : this.vars.ease;
			} else if (typeof(this.vars.ease) === "function") {

				this._ease = new Ease(this.vars.ease, this.vars.easeParams);
			} else {
				this._ease = TweenLite.defaultEase;
			}
			this._easeType = this._ease._type;
			this._easePower = this._ease._power;
			this._firstPT = null;
			
			if (this._targets) {
				i = this._targets.length;
				while (--i > -1) {
					if ( this._initProps( this._targets[i], (this._propLookup[i] = {}), this._siblings[i], (this._overwrittenProps ? this._overwrittenProps[i] : null)) ) {
						initPlugins = true;
					}
				}
			} else {
				initPlugins = this._initProps(this.target, this._propLookup, this._siblings, this._overwrittenProps);
			}
			
			if (initPlugins) {
				TweenLite._onPluginEvent("_onInitAllProps", this); //reorders the array in order of priority. Uses a static TweenPlugin method in order to minimize file size in TweenLite
			}
			if (this._overwrittenProps) if (this._firstPT == null) if (typeof(this.target) !== "function") { //if all tweening properties have been overwritten, kill the tween. If the target is a function, it's probably a delayedCall so let it live.
				this._enabled(false, false);
			}
			if (this.vars.runBackwards) {
				pt = this._firstPT;
				while (pt) {
					pt.s += pt.c;
					pt.c = -pt.c;
					pt = pt._next;
				}
			}
			this._onUpdate = this.vars.onUpdate;
			this._initted = true;
		};
		
		p._initProps = function(target, propLookup, siblings, overwrittenProps) {
			var p, i, initPlugins, plugin, a, pt;
			if (target == null) {
				return false;
			}
			for (p in this.vars) {
				if (_reservedProps[p]) { 
					if (p === "onStartParams" || p === "onUpdateParams" || p === "onCompleteParams" || p === "onReverseCompleteParams" || p === "onRepeatParams") if ((a = this.vars[p])) {
						i = a.length;
						while (--i > -1) {
							if (a[i] === "{self}") {
								a = this.vars[p] = a.concat(); //copy the array in case the user referenced the same array in multiple tweens/timelines (each {self} should be unique)
								a[i] = this;
							}
						}
					}
					
				} else if (_plugins[p] && (plugin = new _plugins[p]())._onInitTween(target, this.vars[p], this)) {
					
					//t - target 		[object]
					//p - property 		[string]
					//s - start			[number]
					//c - change		[number]
					//f - isFunction	[boolean]
					//n - name			[string]
					//pg - isPlugin 	[boolean]
					//pr - priority		[number]
					this._firstPT = pt = {_next:this._firstPT, t:plugin, p:"setRatio", s:0, c:1, f:true, n:p, pg:true, pr:plugin._priority};
					i = plugin._overwriteProps.length;
					while (--i > -1) {
						propLookup[plugin._overwriteProps[i]] = this._firstPT;
					}
					if (plugin._priority || plugin._onInitAllProps) {
						initPlugins = true;
					}
					if (plugin._onDisable || plugin._onEnable) {
						this._notifyPluginsOfEnabled = true;
					}
					
				} else {
					this._firstPT = propLookup[p] = pt = {_next:this._firstPT, t:target, p:p, f:(typeof(target[p]) === "function"), n:p, pg:false, pr:0};
					pt.s = (!pt.f) ? parseFloat(target[p]) : target[ ((p.indexOf("set") || typeof(target["get" + p.substr(3)]) !== "function") ? p : "get" + p.substr(3)) ]();
					pt.c = (typeof(this.vars[p]) === "number") ? this.vars[p] - pt.s : (typeof(this.vars[p]) === "string") ? parseFloat(this.vars[p].split("=").join("")) : 0;
				}
				if (pt) if (pt._next) {
					pt._next._prev = pt;
				}
			}
			
			if (overwrittenProps) if (this._kill(overwrittenProps, target)) { //another tween may have tried to overwrite properties of this tween before init() was called (like if two tweens start at the same time, the one created second will run first)
				return this._initProps(target, propLookup, siblings, overwrittenProps);
			}
			if (this._overwrite > 1) if (this._firstPT) if (siblings.length > 1) if (_applyOverwrite(target, this, propLookup, this._overwrite, siblings)) {
				this._kill(propLookup, target);
				return this._initProps(target, propLookup, siblings, overwrittenProps);
			}
			return initPlugins;
		};
		
		p.render = function(time, suppressEvents, force) {
			var prevTime = this._time,
				isComplete, callback, pt;
			if (time >= this._duration) {
				this._totalTime = this._time = this._duration;
				this.ratio = this._ease._calcEnd ? this._ease.getRatio(1) : 1;
				if (!this._reversed) {
					isComplete = true;
					callback = "onComplete";
				}
				if (this._duration === 0) { //zero-duration tweens are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
					if (time === 0 || this._rawPrevTime < 0) if (this._rawPrevTime !== time) {
						force = true;
					}
					this._rawPrevTime = time;
				}
				
			} else if (time <= 0) {
				this._totalTime = this._time = 0;
				this.ratio = this._ease._calcEnd ? this._ease.getRatio(0) : 0;
				if (prevTime !== 0 || (this._duration === 0 && this._rawPrevTime > 0)) {
					callback = "onReverseComplete";
					isComplete = this._reversed;
				}
				if (time < 0) {
					this._active = false;
					if (this._duration === 0) { //zero-duration tweens are tricky because we must discern the momentum/direction of time in order to determine whether the starting values should be rendered or the ending values. If the "playhead" of its timeline goes past the zero-duration tween in the forward direction or lands directly on it, the end values should be rendered, but if the timeline's "playhead" moves past it in the backward direction (from a postitive time to a negative time), the starting values must be rendered.
						if (this._rawPrevTime >= 0) {
							force = true;
						}
						this._rawPrevTime = time;
					}
				} else if (!this._initted) { //if we render the very beginning (time == 0) of a fromTo(), we must force the render (normal tweens wouldn't need to render at a time of 0 when the prevTime was also 0). This is also mandatory to make sure overwriting kicks in immediately.
					force = true;
				}
				
			} else {
				this._totalTime = this._time = time;
				
				if (this._easeType) {
					var r = time / this._duration, type = this._easeType, pow = this._easePower;
					if (type === 1 || (type === 3 && r >= 0.5)) {
						r = 1 - r;
					}
					if (type === 3) {
						r *= 2;
					}
					if (pow === 1) {
						r *= r;
					} else if (pow === 2) {
						r *= r * r;
					} else if (pow === 3) {
						r *= r * r * r;
					} else if (pow === 4) {
						r *= r * r * r * r;
					}
					
					if (type === 1) {
						this.ratio = 1 - r;
					} else if (type === 2) {
						this.ratio = r;
					} else if (time / this._duration < 0.5) {
						this.ratio = r / 2;
					} else {
						this.ratio = 1 - (r / 2);
					}
					
				} else {
					this.ratio = this._ease.getRatio(time / this._duration);
				}
				
			}
			
			if (this._time === prevTime && !force) {
				return;
			} else if (!this._initted) {
				this._init();
				if (!isComplete && this._time) { //_ease is initially set to defaultEase, so now that init() has run, _ease is set properly and we need to recalculate the ratio. Overall this is faster than using conditional logic earlier in the method to avoid having to set ratio twice because we only init() once but renderTime() gets called VERY frequently.
					this.ratio = this._ease.getRatio(this._time / this._duration);
				}
			}
			
			if (!this._active) if (!this._paused) {
				this._active = true;  //so that if the user renders a tween (as opposed to the timeline rendering it), the timeline is forced to re-render and align it with the proper time/frame on the next rendering cycle. Maybe the tween already finished but the user manually re-renders it as halfway done.
			}
			if (prevTime === 0) if (this.vars.onStart) if (this._time !== 0 || this._duration === 0) if (!suppressEvents) {
				this.vars.onStart.apply(this.vars.onStartScope || this, this.vars.onStartParams || _blankArray);
			}
			
			pt = this._firstPT;
			while (pt) {
				if (pt.f) {
					pt.t[pt.p](pt.c * this.ratio + pt.s);
				} else {
					pt.t[pt.p] = pt.c * this.ratio + pt.s;
				}
				pt = pt._next;
			}
			
			
			if (this._onUpdate) if (!suppressEvents) {
				this._onUpdate.apply(this.vars.onUpdateScope || this, this.vars.onUpdateParams || _blankArray);
			}
			
			if (callback) if (!this._gc) { //check _gc because there's a chance that kill() could be called in an onUpdate
				if (isComplete) {
					if (this._timeline.autoRemoveChildren) {
						this._enabled(false, false);
					}
					this._active = false;
				}
				if (!suppressEvents) if (this.vars[callback]) {
					this.vars[callback].apply(this.vars[callback + "Scope"] || this, this.vars[callback + "Params"] || _blankArray);
				}
			}
			
		};
		
		p._kill = function(vars, target) {
			if (vars === "all") {
				vars = null;
			}
			if (vars == null) if (target == null || target == this.target) {
				return this._enabled(false, false);
			}
			target = target || this._targets || this.target;
			var i, overwrittenProps, p, pt, propLookup, changed, killProps, record;
			if ((target instanceof Array || target.jquery) && typeof(target[0]) === "object") { 
				i = target.length;
				while (--i > -1) {
					if (this._kill(vars, target[i])) {
						changed = true;
					}
				}
			} else {
				if (this._targets) {
					i = this._targets.length;
					while (--i > -1) {
						if (target === this._targets[i]) {
							propLookup = this._propLookup[i] || {};
							this._overwrittenProps = this._overwrittenProps || [];
							overwrittenProps = this._overwrittenProps[i] = vars ? this._overwrittenProps[i] || {} : "all";
							break;
						}
					}
				} else if (target !== this.target) {
					return false;
				} else {
					propLookup = this._propLookup;
					overwrittenProps = this._overwrittenProps = vars ? this._overwrittenProps || {} : "all";
				}

				if (propLookup) {
					killProps = vars || propLookup;
					record = (vars != overwrittenProps && overwrittenProps != "all" && vars != propLookup && (vars == null || vars._tempKill != true)); //_tempKill is a super-secret way to delete a particular tweening property but NOT have it remembered as an official overwritten property (like in BezierPlugin)
					for (p in killProps) {
						if ((pt = propLookup[p])) {
							if (pt.pg && pt.t._kill(killProps)) {
								changed = true; //some plugins need to be notified so they can perform cleanup tasks first
							}
							if (!pt.pg || pt.t._overwriteProps.length === 0) {
								if (pt._prev) {
									pt._prev._next = pt._next;
								} else if (pt === this._firstPT) {
									this._firstPT = pt._next;
								}
								if (pt._next) {
									pt._next._prev = pt._prev;
								}
								pt._next = pt._prev = null;
							}
							delete propLookup[p];
						}
						if (record) { 
							overwrittenProps[p] = 1;
						}
					}
				}
			}
			return changed;
		};
	
		p.invalidate = function() {
			if (this._notifyPluginsOfEnabled) {
				TweenLite._onPluginEvent("_onDisable", this);
			}
			this._firstPT = null;
			this._overwrittenProps = null;
			this._onUpdate = null;
			this._initted = this._active = this._notifyPluginsOfEnabled = false;
			this._propLookup = (this._targets) ? {} : [];
			return this;
		};
		
		p._enabled = function(enabled, ignoreTimeline) {
			if (enabled && this._gc) {
				if (this._targets) {
					var i = this._targets.length;
					while (--i > -1) {
						this._siblings[i] = _register(this._targets[i], this, true);
					}
				} else {
					this._siblings = _register(this.target, this, true);
				}
			}
			Animation.prototype._enabled.call(this, enabled, ignoreTimeline);
			if (this._notifyPluginsOfEnabled) if (this._firstPT) {
				return TweenLite._onPluginEvent(((enabled) ? "_onEnable" : "_onDisable"), this);
			}
			return false;
		};
	
	
//----TweenLite static methods -----------------------------------------------------
		
		TweenLite.to = function(target, duration, vars) {
			return new TweenLite(target, duration, vars);
		};
		
		TweenLite.from = function(target, duration, vars) {
			vars.runBackwards = true;
			if (vars.immediateRender != false) {
				vars.immediateRender = true;
			}
			return new TweenLite(target, duration, vars);
		};
		
		TweenLite.fromTo = function(target, duration, fromVars, toVars) {
			toVars.startAt = fromVars;
			if (fromVars.immediateRender) {
				toVars.immediateRender = true;
			}
			return new TweenLite(target, duration, toVars);
		};
		
		TweenLite.delayedCall = function(delay, callback, params, scope, useFrames) {
			return new TweenLite(callback, 0, {delay:delay, onComplete:callback, onCompleteParams:params, onCompleteScope:scope, onReverseComplete:callback, onReverseCompleteParams:params, onReverseCompleteScope:scope, immediateRender:false, useFrames:useFrames, overwrite:0});
		};
		
		TweenLite.set = function(target, vars) {
			return new TweenLite(target, 0, vars);
		};
		
		TweenLite.killTweensOf = TweenLite.killDelayedCallsTo = function(target, vars) {
			var a = TweenLite.getTweensOf(target), 
				i = a.length;
			while (--i > -1) {
				a[i]._kill(vars, target);
			}
		};
		
		TweenLite.getTweensOf = function(target) {
			if (target == null) { return; }
			var i, a, j, t;
			if ((target instanceof Array || target.jquery) && typeof(target[0]) === "object") { 
				i = target.length;
				a = [];
				while (--i > -1) {
					a = a.concat(TweenLite.getTweensOf(target[i]));
				}
				i = a.length;
				//now get rid of any duplicates (tweens of arrays of objects could cause duplicates)
				while (--i > -1) {
					t = a[i];
					j = i;
					while (--j > -1) {
						if (t === a[j]) {
							a.splice(i, 1);
						}
					}
				}
			} else {
				a = _register(target).concat();
				i = a.length;
				while (--i > -1) {
					if (a[i]._gc) {
						a.splice(i, 1);
					}
				}
			}
			return a;
		};
		
		
		
/*
 * ----------------------------------------------------------------
 * TweenPlugin   (could easily be split out as a separate file/class, but included for ease of use (so that people don't need to include another <script> call before loading plugins which is easy to forget)
 * ----------------------------------------------------------------
 */
		var TweenPlugin = _class("plugins.TweenPlugin", function(props, priority) {
					this._overwriteProps = (props || "").split(",");
					this._propName = this._overwriteProps[0];
					this._priority = priority || 0;
				}, true);
		
		p = TweenPlugin.prototype;
		TweenPlugin.version = 12;
		TweenPlugin.API = 2;
		p._firstPT = null;		
			
		p._addTween = function(target, prop, start, end, overwriteProp, round) {
			var c;
			if (end != null && (c = (typeof(end) === "number" || end.charAt(1) !== "=") ? Number(end) - start : Number(end.split("=").join("")))) {
				this._firstPT = {_next:this._firstPT, t:target, p:prop, s:start, c:c, f:(typeof(target[prop]) === "function"), n:overwriteProp || prop, r:round};
				if (this._firstPT._next) {
					this._firstPT._next._prev = this._firstPT;
				}
			}
		}
			
		p.setRatio = function(v) {
			var pt = this._firstPT, 
				val;
			while (pt) {
				val = pt.c * v + pt.s;
				if (pt.r) {
					val = (val + ((val > 0) ? 0.5 : -0.5)) >> 0; //about 4x faster than Math.round()
				}
				if (pt.f) {
					pt.t[pt.p](val);
				} else {
					pt.t[pt.p] = val;
				}
				pt = pt._next;
			}
		}
			
		p._kill = function(lookup) {
			if (lookup[this._propName] != null) {
				this._overwriteProps = [];
			} else {
				var i = this._overwriteProps.length;
				while (--i > -1) {
					if (lookup[this._overwriteProps[i]] != null) {
						this._overwriteProps.splice(i, 1);
					}
				}
			}
			var pt = this._firstPT;
			while (pt) {
				if (lookup[pt.n] != null) {
					if (pt._next) {
						pt._next._prev = pt._prev;
					}
					if (pt._prev) {
						pt._prev._next = pt._next;
						pt._prev = null;
					} else if (this._firstPT === pt) {
						this._firstPT = pt._next;
					}
				}
				pt = pt._next;
			}
			return false;
		}
			
		p._roundProps = function(lookup, value) {
			var pt = this._firstPT;
			while (pt) {
				if (lookup[this._propName] || (pt.n != null && lookup[ pt.n.split(this._propName + "_").join("") ])) { //some properties that are very plugin-specific add a prefix named after the _propName plus an underscore, so we need to ignore that extra stuff here.
					pt.r = value;
				}
				pt = pt._next;
			}
		}
		
		TweenLite._onPluginEvent = function(type, tween) {
			var pt = tween._firstPT, 
				changed;
			if (type === "_onInitAllProps") {
				//sorts the PropTween linked list in order of priority because some plugins need to render earlier/later than others, like MotionBlurPlugin applies its effects after all x/y/alpha tweens have rendered on each frame.
				var pt2, first, last, next;
				while (pt) {
					next = pt._next;
					pt2 = first;
					while (pt2 && pt2.pr > pt.pr) {
						pt2 = pt2._next;
					}
					if ((pt._prev = pt2 ? pt2._prev : last)) {
						pt._prev._next = pt;
					} else {
						first = pt;
					}
					if ((pt._next = pt2)) {
						pt2._prev = pt;
					} else {
						last = pt;
					}
					pt = next;
				}
				pt = tween._firstPT = first;
			}
			while (pt) {
				if (pt.pg) if (typeof(pt.t[type]) === "function") if (pt.t[type]()) {
					changed = true;
				}
				pt = pt._next;
			}
			return changed;
		}
		
		TweenPlugin.activate = function(plugins) {
			var i = plugins.length;
			while (--i > -1) {
				if (plugins[i].API === TweenPlugin.API) {
					TweenLite._plugins[(new plugins[i]())._propName] = plugins[i];
				}
			}
			return true;
		}
		
		
		
		//now run through all the dependencies discovered and if any are missing, log that to the console as a warning. This is why it's best to have TweenLite load last - it can check all the dependencies for you. 
		if ((a = window._gsQueue)) {
			for (i = 0; i < a.length; i++) {
				a[i]();
			}
			for (p in _classLookup) {
				if (!_classLookup[p].def) {
					console.log("Warning: TweenLite encountered missing dependency: com.greensock."+p);
				}
			}
		}
		
	
})(window);/* FWDNavigator */
(function (window){
var FWDNavigator = function(parent, data){
		
		var self = this;
		var prototype = FWDNavigator.prototype;
		
		this.hider = null;
		this.mainHolder_do = null;
		this.mainImagesHolder_do = null;
		this.smallImage_sdo = null;
		this.border_sdo = null;
		this.handler_sdo = null;
		
		this.images_ar = data.navigatorImages_ar;
		this.iamgesSdo_ar = [];
		
		this.borderColor_str = data.navigatorBorderColor_str;
		this.handlerColor_str = data.navigatorHandlerColor_str;
		this.handMovePath_str =  data.handMovePath_str;
		this.handGrabPath_str =  data.handGrabPath_str;
		this.navigatorPosition_str = data.navigatorPosition_str;
	
		this.totalImages = self.images_ar.length;
		this.stageWidth;
		this.stageHeight;
		this.totalWidth = data.navigatorWidth;
		this.totalHeight = data.navigatorHeight;
		this.offsetX = data.navigatorOffsetX;
		this.offsetY = data.navigatorOffsetY;
		this.finalWidth;
		this.finalHeight;
		this.finalX; 
		this.finalY;
		this.xPositionOnPress;
		this.yPositionOnPress;
		this.lastPresedX;
		this.lastPresedY;
		
		this.tweenCompleteId_to;
	
		this.isShowed_bl = true;
		this.isTweening_bl = false;
		this.isDragging_bl = false;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setSelectable(false);
			self.setupMainContiners();
			self.setupImagesSdos(0);
			self.hide();
			self.resizeAndPosition();
		};
		
		self.activate = function(){
			self.images_ar = data.navigatorImages_ar;
			self.totalImages = self.images_ar.length;
			self.setupImagesSdos(1);
			self.updateImage(0);
			self.addPannSupport();
			self.screen.onmousedown = function(){self.dispatchEvent(FWDNavigator.MOUSE_DOWN);};
			if(FWDUtils.isIEAndLessThen9) self.handler_sdo.screen.onmousedown = function(){self.dispatchEvent(FWDNavigator.MOUSE_DOWN);};
		};
		
		//##########################################//
		/* resize and position */
		//##########################################//
		self.resizeAndPosition = function(){
			
			if(parent.stageWidth == self.stageWidth && parent.stageHeight == self.stageHeight) return;
			
			self.stageWidth = parent.stageWidth;
			self.stageHeight = parent.stageHeight;
			
			
			if(self.navigatorPosition_str == FWDNavigator.TOP_LEFT){
				self.setX(self.offsetX);
				self.setY(self.offsetY);
			}else if(self.navigatorPosition_str == FWDNavigator.TOP_RIGHT){
				self.setX(self.stageWidth - self.totalWidth - self.offsetX);
				self.setY(self.offsetY);
			}else if(self.navigatorPosition_str == FWDNavigator.BOTTOM_LEFT){
				self.setX(self.offsetX);
				self.setY(self.stageHeight - self.totalHeight - self.offsetY);
			}else if(self.navigatorPosition_str == FWDNavigator.BOTTOM_RIGHT){
				self.setX(self.stageWidth - self.totalWidth - self.offsetX);
				self.setY(self.stageHeight - self.totalHeight - self.offsetY);
			}
		};
		
		self.setupHider = function(hider){
			self.hider = hider;
			self.hider.addListener(FWDHider.HIDE, self.onHiderHide);
		};
		
		self.onHiderHide = function(){
			if(FWDUtils.hitTest(self.mainHolder_do.screen, self.hider.globalX, self.hider.globalY)) self.hider.reset();
		};
		
		//###########################################//
		//Setup main containers
		//###########################################//
		self.setupMainContiners = function(){
			self.mainHolder_do = new FWDDisplayObject("div", "absolute", "visible");
			self.mainHolder_do.setWidth(self.totalWidth);
			self.mainHolder_do.setHeight(self.totalHeight);
			self.addChild(self.mainHolder_do);
			
			self.mainImagesHolder_do =  new FWDDisplayObject("div", "absolute", "visible");
			self.smallImage_sdo = new FWDSimpleDisplayObject("img");
			self.mainHolder_do.addChild(self.mainImagesHolder_do);
			
			self.border_sdo = new FWDSimpleDisplayObject("div");
			self.border_sdo.setWidth(self.totalWidth - 2);
			self.border_sdo.setHeight(self.totalHeight - 2);
			self.border_sdo.getStyle().borderStyle = "solid";
			self.border_sdo.getStyle().borderWidth = "1px";
			self.border_sdo.getStyle().borderColor = self.borderColor_str;
			self.mainHolder_do.addChild(self.border_sdo);

			
			self.handler_sdo = new FWDSimpleDisplayObject("div");
			self.handler_sdo.setWidth(self.totalWidth - 2);
			self.handler_sdo.setHeight(self.totalHeight - 2);
			self.handler_sdo.getStyle().borderStyle = "solid";
			self.handler_sdo.getStyle().borderWidth = "1px";
			if(FWDUtils.isIE) self.handler_sdo.getStyle().background = "url('dumy')";
			self.handler_sdo.getStyle().borderColor = self.handlerColor_str;
			self.mainHolder_do.addChild(self.handler_sdo);
		};
		
		//##########################################//
		/* Setup images sdo */
		//##########################################//
		self.setupImagesSdos = function(start){
			var image_sdo;
		
			for(var i=start; i<self.totalImages; i++){
				image_sdo = new FWDSimpleDisplayObject("img");
				image_sdo.setScreen(self.images_ar[i]);
				image_sdo.setVisible(false);
				self.iamgesSdo_ar.push(image_sdo);
				self.mainImagesHolder_do.addChild(image_sdo);
			}
			if(start == 0) self.smallImage_sdo = self.iamgesSdo_ar[0];
		};
		
		//##########################################//
		/* add image */
		//##########################################//
		self.updateImage = function(id){
			if(self.smallImage_sdo) self.smallImage_sdo.setVisible(false);	
			self.smallImage_sdo = self.iamgesSdo_ar[id];
			self.smallImage_sdo.setVisible(true);
		};
		
		//########################################//
		/* update navigator dragger */
		//########################################//
		self.update = function(percentX, percentY, percentWidth, percentHeight, animate){
			
			if(percentWidth > 1) percentWidth = 1;
			if(percentHeight > 1) percentHeight = 1;
			if(percentX > 1) percentX = 1;
			if(percentY > 1) percentY = 1;
			
			if(isNaN(percentX)) percentX = 0;
			if(isNaN(percentY)) percentY = 0;
			
			self.finalWidth = Math.round(percentWidth * (self.totalWidth -4));
			self.finalHeight = Math.round(percentHeight * (self.totalHeight-4));
			self.finalX = Math.round((percentX * ((self.totalWidth - 2) - self.finalWidth))); 
			self.finalY = Math.round((percentY * ((self.totalHeight - 2) - self.finalHeight)));
			
			clearTimeout(self.tweenCompleteId_to);
			
			if(animate){
				self.isTweening_bl = true;
				self.tweenCompleteId_to = setTimeout(function(){if(self == null) return; self.isTweening_bl = false;}, 200);
				TweenMax.killTweensOf(self.handler_sdo);
				TweenMax.to(self.handler_sdo, .2, {x:self.finalX, y:self.finalY, w:self.finalWidth, h:self.finalHeight});
			}else{
				self.isTweening_bl = false;
				TweenMax.killTweensOf(self.handler_sdo);
				self.handler_sdo.setX(self.finalX);
				self.handler_sdo.setY(self.finalY);
				self.handler_sdo.setWidth(self.finalWidth);
				self.handler_sdo.setHeight(self.finalHeight);
			}
		};
		
		//###############################################//
		//Add touch pann support
		//###############################################//
		self.addPannSupport = function(){
			self.handler_sdo.screen.style.cursor = 'url(' + self.handMovePath_str + '), default';
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.handler_sdo.screen.addEventListener("MSPointerDown", self.panStartHandler);
				}else{
					self.handler_sdo.screen.addEventListener("touchstart", self.panStartHandler);
				}	
			}else if(self.handler_sdo.screen.addEventListener){
				self.handler_sdo.screen.addEventListener("mousedown", self.panStartHandler);
			}else if(self.handler_sdo.screen.attachEvent){
				self.handler_sdo.screen.attachEvent("onmousedown", self.panStartHandler);
			}
		};
		
		self.panStartHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isTweening_bl) return;
			if(!self.isMobile_bl) parent.showPanDumy(); 
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);		
			self.isDragging_bl = true;
			self.xPositionOnPress = self.handler_sdo.getX();
			self.yPositionOnPress = self.handler_sdo.getY();
			self.lastPresedX = viewportMouseCoordinates.screenX;
			self.lastPresedY = viewportMouseCoordinates.screenY;
	
			self.dispatchEvent(FWDNavigator.PAN_START);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.panMoveHandler);
					window.addEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.addEventListener("touchmove", self.panMoveHandler);
					window.addEventListener("touchend", self.panEndHandler);
				}
			}else{
				self.handler_sdo.screen.style.cursor = 'url(' + self.handGrabPath_str + '), default';
				self.screen.style.cursor = 'url(' + self.handGrabPath_str + '), default';
				if(window.addEventListener){
					window.addEventListener("mousemove", self.panMoveHandler);
					window.addEventListener("mouseup", self.panEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.panMoveHandler);
					document.attachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		self.panMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			if(e.touches && e.touches.length != 1) return;
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
	
			self.finalX = Math.round(self.xPositionOnPress + viewportMouseCoordinates.screenX - self.lastPresedX);
			if(self.finalX < 1){
				self.finalX = 1;
			}else if(self.finalX >= self.totalWidth - 3 - self.finalWidth){
				self.finalX = self.totalWidth - 3 - self.finalWidth;
			}
			self.handler_sdo.setX(self.finalX);
		
	
			self.finalY = Math.round(self.yPositionOnPress + viewportMouseCoordinates.screenY - self.lastPresedY);
			if(self.finalY < 1){
				self.finalY = 1;
			}else if(self.finalY >= self.totalHeight - 3 - self.finalHeight){
				self.finalY = self.totalHeight - 3 - self.finalHeight;
			}
			self.handler_sdo.setY(self.finalY);
			
			self.dispatchEvent(FWDNavigator.PAN,
					{percentX:self.finalX/(self.totalWidth - 2 - self.finalWidth),
					percentY:self.finalY/(self.totalHeight - 2 - self.finalHeight)
				});
		};
		
		self.panEndHandler = function(e){
			self.isDragging_bl = false;
			if(!self.isMobile_bl) parent.hidePanDumy();
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.panMoveHandler);
					window.removeEventListener("MSPointerUp", self.panEndHandler);
				}else{
					window.removeEventListener("touchmove", self.panMoveHandler);
					window.removeEventListener("touchend", self.panEndHandler);
				}
			}else{
				self.handler_sdo.screen.style.cursor = 'url(' + self.handMovePath_str + '), default';
				self.screen.style.cursor = 'default';
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.panMoveHandler);
					window.removeEventListener("mouseup", self.panEndHandler);	
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.panMoveHandler);
					document.detachEvent("onmouseup", self.panEndHandler);
				}
			}
		};
		
		//##########################################//
		/* show / hide*/
		//##########################################//
		self.show = function(animate){
			if(self.isShowed_bl) return;
			self.resizeAndPosition();
			
			if(animate){
				TweenMax.to(self.mainHolder_do, 1, {y:0, ease:Expo.easeInOut});
			}else{
				TweenMax.killTweensOf(self.mainHolder_do);
				self.mainHolder_do.setY(0);
			}
			
			self.isShowed_bl = true;
		};
		
		self.hide = function(animate){
			if(!self.isShowed_bl) return;
			if(self.navigatorPosition_str == FWDNavigator.TOP_LEFT || self.navigatorPosition_str == FWDNavigator.TOP_RIGHT){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:-self.totalHeight - self.offsetY, ease:Expo.easeInOut});
					self.update(1,1,1,1,true);
				}else{
					TweenMax.killTweensOf(self.mainHolder_do);
					self.mainHolder_do.setY(-self.totalHeight - self.offsetY);
				}
			}else if(self.navigatorPosition_str == FWDNavigator.BOTTOM_LEFT || self.navigatorPosition_str == FWDNavigator.BOTTOM_RIGHT){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:self.totalHeight + self.offsetY, ease:Expo.easeInOut});
					self.update(1,1,1,1,true);
				}else{
					TweenMax.killTweensOf(self.mainHolder_do);
					self.mainHolder_do.setY(self.totalHeight + self.offsetY);
				}
			}
			self.isShowed_bl = false;
		};
		
		//#####################################//
		/* clean main events */
		//#####################################//
		self.cleanMainEvents = function(){
			
			if(self.isMobile_bl){
				self.handler_sdo.screen.removeEventListener("touchstart", self.panStartHandler);
				self.handler_sdo.screen.addEventListener("MSPointerDown", self.panStartHandler);
				window.removeEventListener("touchmove", self.panMoveHandler);
				window.removeEventListener("touchend", self.panEndHandler);
				window.removeEventListener("MSPointerMove", self.panMoveHandler);
				window.removeEventListener("MSPointerUp", self.panEndHandler);
			}else if(self.handler_sdo.screen.removeEventListener){
				self.handler_sdo.screen.removeEventListener("mousedown", self.panStartHandler);
				window.removeEventListener("mousemove", self.panMoveHandler);
				window.removeEventListener("mouseup", self.panEndHandler);	
			}else if(self.handler_sdo.screen.detachEvent){
				self.handler_sdo.screen.detachEvent("onmousedown", self.panStartHandler);
				document.detachEvent("onmousemove", self.panMoveHandler);
				document.detachEvent("onmouseup", self.panEndHandler);
			}
			self.screen.onmousedown = null;
			self.handler_sdo.screen.onmousedown = null;
			
			clearTimeout(self.tweenCompleteId_to);
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			self.cleanMainEvents();
			
			if(self.hider){
				self.hider.removeListener(FWDHider.HIDE, self.onHiderHide);
			};
			
			var totalImages = self.iamgesSdo_ar.length;
			for(var i=0; i<totalImages; i++){
				self.iamgesSdo_ar[i].destroy();	
			};
			
			TweenMax.killTweensOf(self.mainHolder_do);
			self.mainHolder_do.destroy();
			
			TweenMax.killTweensOf(self.handler_sdo);
			self.handler_sdo.destroy();
			
			self.mainImagesHolder_do.destroy();
		
			self.hider = null;
			self.mainHolder_do = null;
			self.mainImagesHolder_do = null;
			self.smallImage_sdo = null;
			self.handler_sdo = null;			
			
			self.images_ar = data.navigatorImages_ar;
			self.iamgesSdo_ar = [];
			
			self.borderColor_str = null;
			self.handlerColor_str = null;
			self.handMovePath_str = null;
			self.handGrabPath_str = null;
			self.navigatorPosition_str = null;
			
			data = null;
			parent = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDNavigator.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDNavigator.setPrototype = function(){
		FWDNavigator.prototype = new FWDDisplayObject("div");
	};
	
	FWDNavigator.TOP_LEFT = "topleft";
	FWDNavigator.TOP_RIGHT = "topright";
	FWDNavigator.BOTTOM_LEFT = "bottomleft";
	FWDNavigator.BOTTOM_RIGHT = "bottomright";
	FWDNavigator.PAN_START = "panStart";
	FWDNavigator.PAN = "pan";
	FWDNavigator.MOUSE_DOWN = "navigatorOnMouseDown";
	
	FWDNavigator.prototype = null;
	window.FWDNavigator = FWDNavigator;
}(window));/* Thumb */
(function (window){
	
	var FWDPreloader = function(
			parent,
			imageSource_img,
			segmentWidth,
			segmentHeight,
			totalSegments,
			fontColor,
			backgroundColor
		){
		
		var self = this;
		var prototype = FWDPreloader.prototype;
		
		self.imageSource_img = imageSource_img;
		self.bk_do = null;
		self.mainAnimHolder_do = null;
		self.animHolder_do = null;
		self.imageAnimHolder_do = null;
		self.images_do = null;
		self.text_do = null;
		
		self.backgroundColor_str = backgroundColor;
		self.fontColor_str = fontColor;
		
		self.stageWidth;
		self.stageHeight;
		self.segmentWidth = segmentWidth;
		self.segmentHeight = segmentHeight;
		self.totalSegments = totalSegments;

		self.isShowed_bl = false;
		self.allowResize_bl = true;
		
		//###################################//
		/* init */
		//###################################//
		self.init = function(){
			self.setupMainContainers();
			if(FWDUtils.isMobile){
				self.screen.addEventListener("touchstart", self.windowTouchStartHandler);
			};
		};
		
		self.windowTouchStartHandler = function(e){
			if(e.preventDefault) e.preventDefault();
		};
		
		//###################################//
		/* setup main containers. */
		//###################################//
		self.setupMainContainers = function(){
			
			self.bk_do = new FWDSimpleDisplayObject("div");
			self.bk_do.setBkColor(self.backgroundColor_str);
			self.bk_do.setAlpha(0);
			self.bk_do.setResizableSizeAfterParent();
			self.addChild(self.bk_do);
			
			self.mainAnimHolder_do = new FWDDisplayObject("div");
			self.mainAnimHolder_do.setOverflow("visible");
			self.mainAnimHolder_do.setWidth(300);
			self.mainAnimHolder_do.setHeight(300);
			self.addChild(self.mainAnimHolder_do);
			
			self.animHolder_do = new FWDDisplayObject("div");
			self.animHolder_do.setOverflow("visible");
			self.animHolder_do.setWidth(300);
			self.animHolder_do.setHeight(300);
			self.mainAnimHolder_do.addChild(self.animHolder_do);
			
			self.imageAnimHolder_do = new FWDDisplayObject("div");	
			self.imageAnimHolder_do.setWidth(self.segmentWidth);
			self.imageAnimHolder_do.setHeight(self.segmentHeight);
			self.animHolder_do.addChild(self.imageAnimHolder_do);
			
			self.images_do = new FWDSimpleDisplayObject("img");
			self.images_do.setScreen(self.imageSource_img);
			self.imageAnimHolder_do.addChild(self.images_do);
			
			self.text_do = new FWDSimpleDisplayObject("div");
			self.text_do.setDisplay("inline-block");
			self.text_do.getStyle().fontFamily = "Arial";
			self.text_do.getStyle().fontSize= "12px";
			self.text_do.getStyle().color = self.fontColor_str;
			self.text_do.getStyle().fontSmoothing = "antialiased";
			self.text_do.getStyle().webkitFontSmoothing = "antialiased";
			self.text_do.getStyle().textRendering = "optimizeLegibility";
			self.text_do.setY(self.segmentHeight + 2);
			self.animHolder_do.addChild(self.text_do);
		};
		
		//###################################//
		/* position and resize. */
		//###################################//
		self.positionAndResize = function(){
			if(parent.stageWidth == self.stageWidth && parent.stageHeight == self.stageHeight) return;
			if(!self.allowResize_bl) return;
			self.stageWidth = parent.stageWidth;
			self.stageHeight = parent.stageHeight;
			
			self.mainAnimHolder_do.setX(Math.round(self.stageWidth - self.segmentWidth)/2);
			self.mainAnimHolder_do.setY(Math.round((self.stageHeight - self.segmentHeight)/2) - 10);
			
			self.setWidth(self.stageWidth);
			self.setHeight(self.stageHeight);
		};
	
		//###################################//
		/* start / stop preloader animation */
		//###################################//
		self.update = function(percent, text){
			var posX = Math.round(percent * (self.totalSegments - 1)) * self.segmentWidth;
			self.images_do.setX(-posX);
			self.text_do.setInnerHTML(text);
			self.text_do.setX(Math.round((self.segmentWidth - self.text_do.getWidth())/2));
		};
		
		//###################################//
		/* show / hide preloader animation */
		//###################################//
		self.show = function(){
			TweenMax.killTweensOf(self.bk_do);
			TweenMax.to(self.bk_do, 1, {alpha:.6});
			TweenMax.to(self.animHolder_do, .8, {y:0, ease:Expo.easeInOut});
			self.isShowed_bl = true;
		};
		
		self.hide = function(animate){
			if(self == null) return;
			TweenMax.killTweensOf(self);
			TweenMax.killTweensOf(self.animHolder_do);
			if(animate){
				self.allowResize_bl = false;
				TweenMax.to(self.bk_do, .8, {alpha:0, delay:.6, onComplete:self.onHideComplete});
				TweenMax.to(self.animHolder_do, .8, {y:self.stageHeight/2 +  self.segmentHeight, ease:Expo.easeInOut});
			}else{
				self.bk_do.setAlpha(0);
				self.animHolder_do.setY((-self.stageHeight/2) - self.segmentHeight);
			}
			self.isShowed_bl = false;
		};
		
		self.onHideComplete = function(){
			self.dispatchEvent(FWDPreloader.HIDE_COMPLETE);
		};
		
		//###################################//
		/* destroy */
		//##################################//
		self.destroy = function(){
			if(FWDUtils.isMobile){
				self.screen.removeEventListener("touchstart", self.windowTouchStartHandler);
			};
	
			TweenMax.killTweensOf(self);
			TweenMax.killTweensOf(self.bk_do);
			TweenMax.killTweensOf(self.animHolder_do);
			
			self.bk_do.destroy();
			self.mainAnimHolder_do.destroy();
			self.animHolder_do.destroy();
			self.imageAnimHolder_do.destroy();
			self.images_do.destroy();
			self.text_do.destroy();
			
			self.imageSource_img = null;
			self.bk_do = null;
			self.mainAnimHolder_do = null;
			self.animHolder_do = null;
			self.imageAnimHolder_do = null;
			self.images_do = null;
			self.text_do = null;
			
			self.backgroundColor_str = null;
			self.fontColor_str = null;
			
			self.init = null;
			self.setupMainContainers = null;
			self.positionAndResize = null;
			self.update = null;
			self.show = null;
			self.hide = null;
			self.onHideComplete = null;
			
			parent = null;
			imageSource_img = null;
			backgroundColor = null;
			fontColor = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			FWDPreloader.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
    FWDPreloader.setPrototype = function(){
    	FWDPreloader.prototype = new FWDDisplayObject("div");
    };
    
    FWDPreloader.HIDE_COMPLETE = "hideComplete";
    
    FWDPreloader.prototype = null;
	window.FWDPreloader = FWDPreloader;
}(window));/* FWDSimpleButton */
(function (window){
var FWDSimpleButton = function(nImg, sImg){
		
		var self = this;
		var prototype = FWDSimpleButton.prototype;
		
		self.nImg = nImg;
		self.sImg = sImg;
		
		this.n_do;
		this.s_do;
		
		this.toolTipLabel_str;
		
		this.totalWidth = this.nImg.width;
		this.totalHeight = this.nImg.height;
	
		this.isDisabled_bl = false;
		this.isSelectedFinal_bl = false;
		this.isActive_bl = false;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setupMainContainers();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			self.n_do = new FWDSimpleDisplayObject("img");	
			self.n_do.setScreen(self.nImg);
			self.s_do = new FWDSimpleDisplayObject("img");
			self.s_do.setScreen(self.sImg);
			self.s_do.setAlpha(0);
			self.addChild(self.n_do);
			self.addChild(self.s_do);
			
			self.setWidth(self.nImg.width);
			self.setHeight(self.nImg.height);
			self.setButtonMode(true);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.addEventListener("MSPointerDown", self.onMouseDown);
					self.screen.addEventListener("MSPointerUp", self.onClick);
					self.screen.addEventListener("MSPointerOver", self.onMouseOver);
					self.screen.addEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.addEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){	
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mousedown", self.onMouseDown);
				self.screen.addEventListener("click", self.onClick);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmousedown", self.onMouseDown);
				self.screen.attachEvent("onclick", self.onClick);
			}
		};
		
		self.onMouseOver = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDSimpleButton.MOUSE_OVER, {e:e});
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
			}
		};
			
		self.onMouseOut = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDSimpleButton.MOUSE_OUT, {e:e});
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:0, ease:Expo.easeOut});	
			}
		};
			
		self.onClick = function(e){
			if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
			self.dispatchEvent(FWDSimpleButton.CLICK, {e:e});
		};
		
		self.onMouseDown = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
			self.dispatchEvent(FWDSimpleButton.MOUSE_DOWN, {e:e});
		};
		
		//##############################//
		// set select / deselect final.
		//##############################//
		self.setSelctedFinal = function(){
			self.isSelectedFinal_bl = true;
			TweenMax.killTweensOf(self.s_do);
			TweenMax.to(self.s_do, .8, {alpha:1, ease:Expo.easeOut});
			self.setButtonMode(false);
		};
		
		self.setUnselctedFinal = function(){
			self.isSelectedFinal_bl = false;
			TweenMax.to(self.s_do, .8, {alpha:0, delay:.1, ease:Expo.easeOut});
			self.setButtonMode(true);
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.removeEventListener("MSPointerDown", self.onMouseDown);
					self.screen.removeEventListener("MSPointerUp", self.onClick);
					self.screen.removeEventListener("MSPointerOver", self.onMouseOver);
					self.screen.removeEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.removeEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){
				self.screen.removeEventListener("mouseover", self.onMouseOver);
				self.screen.removeEventListener("mouseout", self.onMouseOut);
				self.screen.removeEventListener("mousedown", self.onMouseDown);
				self.screen.removeEventListener("click", self.onClick);
			}else if(self.screen.detachEvent){
				self.screen.detachEvent("onmouseover", self.onMouseOver);
				self.screen.detachEvent("onmouseout", self.onMouseOut);
				self.screen.detachEvent("onmousedown", self.onMouseDown);
				self.screen.detachEvent("onclick", self.onClick);
			}
		
			TweenMax.killTweensOf(self.s_do);
			self.n_do.destroy();
			self.s_do.destroy();
			
			self.nImg = null;
			self.sImg = null;
			self.n_do = null;
			self.s_do = null;
			
			nImg = null;
			sImg = null;
			
			self.toolTipLabel_str = null;
			
			self.init = null;
			self.setupMainContainers = null;
			self.onMouseOver = null;
			self.onMouseOut = null;
			self.onClick = null;
			self.onMouseDown = null;  
			self.setSelctedFinal = null;
			self.setUnselctedFinal = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDSimpleButton.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDSimpleButton.setPrototype = function(){
		FWDSimpleButton.prototype = null;
		FWDSimpleButton.prototype = new FWDDisplayObject("div");
	};
	
	FWDSimpleButton.CLICK = "onClick";
	FWDSimpleButton.MOUSE_OVER = "onMouseOver";
	FWDSimpleButton.MOUSE_OUT = "onMouseOut";
	FWDSimpleButton.MOUSE_DOWN = "onMouseDown";
	
	FWDSimpleButton.prototype = null;
	window.FWDSimpleButton = FWDSimpleButton;
}(window));/* Simple Display object */
(function (window){
	/*
	 * @ type values: div, img.
	 * @ positon values: relative, absolute.
	 * @ positon values: hidden.
	 * @ display values: block, inline-block, self applies only if the position is relative.
	 */
	var FWDSimpleDisplayObject = function(type, position, overflow, display){
		
		var self = this;
		
		if(type == "div" || type == "img" || type == "canvas"){
			self.type = type;	
		}else{
			throw Error("Type is not valid! " + type);
		}
	
		this.style;
		this.screen;
		this.transform;
		this.position = position || "absolute";
		this.overflow = overflow || "hidden";
		this.display = display || "block";
		this.visible = true;
		this.buttonMode;
		this.x = 0;
		this.y = 0;
		this.w = 0;
		this.h = 0;
		this.rect;
		this.alpha = 1;
		this.innerHTML = "";
		this.opacityType = "";
		this.isHtml5_bl = false;
		
		this.hasTransform3d_bl =  FWDUtils.hasTransform3d;
		this.hasTransform2d_bl =  FWDUtils.hasTransform2d;
		if(FWDUtils.isIE || FWDUtils.isFirefox) self.hasTransform3d_bl = false;
		//if(FWDUtils.isIE || FWDUtils.isFirefox) self.hasTransform2d_bl = false;
		this.hasBeenSetSelectable_bl = false;
		
		
		//##############################//
		/* init */
		//#############################//
		self.init = function(){
			self.setScreen();
		};	
		
		//######################################//
		/* check if it supports transforms. */
		//######################################//
		self.getTransform = function() {
		    var properties = ['transform', 'msTransform', 'WebkitTransform', 'MozTransform', 'OTransform'];
		    var p;
		    while (p = properties.shift()) {
		       if (typeof self.screen.style[p] !== 'undefined') {
		            return p;
		       }
		    }
		    return false;
		};
		
		//######################################//
		/* set opacity type */
		//######################################//
		self.getOpacityType = function(){
			var opacityType;
			if (typeof self.screen.style.opacity != "undefined") {//ie9+ 
				opacityType = "opacity";
			}else{ //ie8
				opacityType = "filter";
			}
			return opacityType;
		};
		
		//######################################//
		/* setup main screen */
		//######################################//
		self.setScreen = function(element){
			if(self.type == "img" && element){
				self.screen = element;
				self.setMainProperties();
			}else{
				self.screen = document.createElement(self.type);
				self.setMainProperties();
			}
		};
		
		//########################################//
		/* set main properties */
		//########################################//
		self.setMainProperties = function(){
			
			self.transform = self.getTransform();
			self.setPosition(self.position);
			self.setDisplay(self.display);
			self.setOverflow(self.overflow);
			self.opacityType = self.getOpacityType();
			
			if(self.opacityType == "opacity") self.isHtml5_bl = true;
			
			if(self.opacityType == "filter") self.screen.style.filter = "inherit";
			self.screen.style.left = "0px";
			self.screen.style.top = "0px";
			self.screen.style.margin = "0px";
			self.screen.style.padding = "0px";
			self.screen.style.maxWidth = "none";
			self.screen.style.maxHeight = "none";
			self.screen.style.border = "none";
			self.screen.style.lineHeight = "1";
			self.screen.style.backgroundColor = "transparent";
			self.screen.style.backfaceVisibility = "hidden";
			self.screen.style.webkitBackfaceVisibility = "hidden";
			self.screen.style.MozBackfaceVisibility = "hidden";	
			
			
			if(type == "img"){
				self.setWidth(self.screen.width);
				self.setHeight(self.screen.height);
				self.setSelectable(false);
			}
		};
		
		//###################################################//
		/* set / get various peoperties.*/
		//###################################################//
		self.setSelectable = function(val){
			if(!val){
				self.screen.style.userSelect = "none";
				self.screen.style.MozUserSelect = "none";
				self.screen.style.webkitUserSelect = "none";
				self.screen.style.khtmlUserSelect = "none";
				self.screen.style.oUserSelect = "none";
				self.screen.style.msUserSelect = "none";
				self.screen.msUserSelect = "none";
				self.screen.ondragstart = function(e){return false;};
				self.screen.onselectstart = function(){return false;};
				self.screen.ontouchstart = function(e){return false;};
				self.screen.style.webkitTouchCallout='none';
				self.hasBeenSetSelectable_bl = true;
			}
		};
			
		self.setBackfaceVisibility =  function(){
			self.screen.style.backfaceVisibility = "visible";
			self.screen.style.webkitBackfaceVisibility = "visible";
			self.screen.style.MozBackfaceVisibility = "visible";		
		};
		
		self.removeBackfaceVisibility =  function(){
			self.screen.style.backfaceVisibility = "hidden";
			self.screen.style.webkitBackfaceVisibility = "hidden";
			self.screen.style.MozBackfaceVisibility = "hidden";		
		};
		
		self.getScreen = function(){
			return self.screen;
		};
		
		self.setVisible = function(val){
			self.visible = val;
			if(self.visible == true){
				self.screen.style.visibility = "visible";
			}else{
				self.screen.style.visibility = "hidden";
			}
		};
		
		self.getVisible = function(){
			return self.visible;
		};
			
		self.setResizableSizeAfterParent = function(){
			self.screen.style.width = "100%";
			self.screen.style.height = "100%";
		};
		
		self.getStyle = function(){
			return self.screen.style;
		};
		
		self.setOverflow = function(val){
			self.overflow = val;
			self.screen.style.overflow = self.overflow;
		};
		
		self.setPosition = function(val){
			self.position = val;
			self.screen.style.position = self.position;
		};
		
		self.setDisplay = function(val){
			self.display = val;
			self.screen.style.display = self.display;
		};
		
		self.setButtonMode = function(val){
			self.buttonMode = val;
			if(self.buttonMode ==  true){
				self.screen.style.cursor = "pointer";
			}else{
				self.screen.style.cursor = "default";
			}
		};
		
		self.setBkColor = function(val){
			self.screen.style.backgroundColor = val;
		};
		
		self.setInnerHTML = function(val){
			self.innerHTML = val;
			self.screen.innerHTML = self.innerHTML;
		};
		
		self.getInnerHTML = function(){
			return self.innerHTML;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.setAlpha = function(val){
			self.alpha = val;
			if(self.opacityType == "opacity"){
				self.screen.style.opacity = self.alpha;
			}else if(self.opacityType == "filter"){
				self.screen.style.filter = "alpha(opacity=" + self.alpha * 100 + ")";
				self.screen.style.filter = "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + Math.round(self.alpha * 100) + ")";
			}
		};
		
		self.getAlpha = function(){
			return self.alpha;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.getGlobalX = function(){
			return self.getRect().left;
		};
		
		self.getGlobalY = function(){
			return self.getRect().top;
		};
		
		self.setX = function(val){
			self.x = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0)';
			}else if(self.hasTransform2d_bl){
				self.screen.style[self.transform] = 'translate(' + self.x + 'px,' + self.y + 'px)';
			}else{
				self.screen.style.left = self.x + "px";
			}
		};
		
		self.getX = function(){
			return  self.x;
		};
		
		self.setY = function(val){
			self.y = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0)';	
			}else if(self.hasTransform2d_bl){
				self.screen.style[self.transform] = 'translate(' + self.x + 'px,' + self.y + 'px)';
			}else{
				self.screen.style.top = self.y + "px";
			}
		};
		
		self.getY = function(){
			return  self.y;
		};
		
		self.setWidth = function(val){
			self.w = val;
			if(self.type == "img"){
				self.screen.width = self.w;
			}else{
				self.screen.style.width = self.w + "px";
			}
		};
		
		self.getWidth = function(){
			if(self.type == "div"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}else if(self.type == "img"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				if(self.screen.width != 0) return  self.screen.width;
				return self._w;
			}else if( self.type == "canvas"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}
		};
		
		self.setHeight = function(val){
			self.h = val;
			if(self.type == "img"){
				self.screen.height = self.h;
			}else{
				self.screen.style.height = self.h + "px";
			}
		};
		
		self.getHeight = function(){
			if(self.type == "div"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}else if(self.type == "img"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				if(self.screen.height != 0) return  self.screen.height;
				return self.h;
			}else if(self.type == "canvas"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}
		};
		
	    //###########################################//
	    /* destroy methods*/
	    //###########################################//
		self.disposeImage = function(){
			if(self.type == "img") self.screen.src = null;
		};
		
		self.destroy = function(){
			if(self == null) return;
			
			//try{self.screen.parentNode.removeChild(self.screen);}catch(e){};
			if(self.hasBeenSetSelectable_bl){
				self.screen.ondragstart = null;
				self.screen.onselectstart = null;
				self.screen.ontouchstart = null;
			};
		
			//destroy properties
			self.style = null;
			self.screen = null;
			self.transform = null;
			self.position = null;
			self.overflow = null;
			self.display = null;
			self.visible = null;
			self.buttonMode = null;
			self.x = null;
			self.y = null;
			self.w = null;
			self.h = null;
			self.rect = null;
			self.alpha = null;
			self.innerHTML = null;
			self.opacityType = null;
			self.isHtml5_bl = null;
			
			type = null;
			position = null;
			overflow = null;
			display = null;
			
			self.hasTransform3d_bl = null;
			self.hasTransform2d_bl = null;
			self = null;
		};
		
	    /* init */
		self.init();
	};
	
	window.FWDSimpleDisplayObject = FWDSimpleDisplayObject;
}(window));/* Simple Display object */
(function (window){
	/*
	 * @ type values: div, img.
	 * @ positon values: relative, absolute.
	 * @ positon values: hidden.
	 * @ display values: block, inline-block, self applies only if the position is relative.
	 */
	var FWDTransformDisplayObject = function(type, position, overflow){
		
		var self = this;
		
		if(type == "div" || type == "img" || type == "canvas"){
			self.type = type;	
		}else{
			throw Error("Type is not valid! " + type);
		}
	
		this.style;
		this.screen;
		this.transform;
		this.transformOrigin;
		this.position = position || "absolute";
		this.overflow = overflow || "hidden";
		this.visible = true;
		this.buttonMode;
		this.x = 0;
		this.y = 0;
		this.w = 0;
		this.h = 0;
		this.scale = 1;
		this.rect;
		this.alpha = 1;
		this.innerHTML = "";
		this.opacityType = "";
		this.isHtml5_bl = false;
		
		this.hasTransform3d_bl =  FWDUtils.hasTransform3d;
		this.hasTransform2d_bl =  FWDUtils.hasTransform2d;
		if(FWDUtils.isIE || FWDUtils.isFirefox) self.hasTransform3d_bl = false;
		this.hasBeenSetSelectable_bl = false;
		
		
		//##############################//
		/* init */
		//#############################//
		self.init = function(){
			self.setScreen();
		};	
		
		//######################################//
		/* check if it supports transforms. */
		//######################################//
		self.getTransform = function() {
		    var properties = ['transform', 'msTransform', 'WebkitTransform', 'MozTransform', 'OTransform'];
		    var p;
		    while (p = properties.shift()) {
		       if (typeof self.screen.style[p] !== 'undefined') {
		            return p;
		       }
		    }
		    return undefined;
		};
		
		//######################################//
		/* get transof. */
		//######################################//
		self.getTransformOrigin = function() {
		    var properties = ['transformOrigin', 'msTransformOrigin', 'WebkitTransformOrigin', 'MozTransformOrigin', 'OTransformOrigin'];
		    var p;
		    while (p = properties.shift()) {
		       if (typeof self.screen.style[p] !== 'undefined') {
		            return p;
		       }
		    }
		    return undefined;
		};
		
		//######################################//
		/* set opacity type */
		//######################################//
		self.getOpacityType = function(){
			var opacityType;
			if (typeof self.screen.style.opacity != "undefined") {//ie9+ 
				opacityType = "opacity";
			}else{ //ie8
				opacityType = "filter";
			}
			return opacityType;
		};
		
		//######################################//
		/* setup main screen */
		//######################################//
		self.setScreen = function(element){
			if(self.type == "img" && element){
				self.screen = element;
				self.setMainProperties();
			}else{
				self.screen = document.createElement(self.type);
				self.setMainProperties();
			}
		};
		
		//########################################//
		/* set main properties */
		//########################################//
		self.setMainProperties = function(){
			
			self.transform = self.getTransform();
			self.transformOrigin = self.getTransformOrigin();
			self.setPosition(self.position);
			self.setOverflow(self.overflow);
			self.opacityType = self.getOpacityType();
			
			if(self.opacityType == "opacity") self.isHtml5_bl = true;
			
			if(self.opacityType == "filter") self.screen.style.filter = "inherit";
			self.screen.style.left = "0px";
			self.screen.style.top = "0px";
			self.screen.style.margin = "0px";
			self.screen.style.padding = "0px";
			self.screen.style.maxWidth = "none";
			self.screen.style.maxHeight = "none";
			self.screen.style.border = "none";
			self.screen.style.lineHeight = "1";
			self.screen.style.backgroundColor = "transparent";
			self.screen.style.backfaceVisibility = "hidden";
			self.screen.style.webkitBackfaceVisibility = "hidden";
			self.screen.style.MozBackfaceVisibility = "hidden";	
			
			
			if(type == "img"){
				self.setWidth(self.screen.width);
				self.setHeight(self.screen.height);
				self.setSelectable(false);
			}
		};
		
		//###################################################//
		/* set / get various peoperties.*/
		//###################################################//
		self.setSelectable = function(val){
			if(!val){
				self.screen.style.userSelect = "none";
				self.screen.style.MozUserSelect = "none";
				self.screen.style.webkitUserSelect = "none";
				self.screen.style.khtmlUserSelect = "none";
				self.screen.style.oUserSelect = "none";
				self.screen.style.msUserSelect = "none";
				self.screen.msUserSelect = "none";
				self.screen.ondragstart = function(e){return false;};
				self.screen.onselectstart = function(){return false;};
				self.screen.ontouchstart = function(e){return false;};
				self.screen.style.webkitTouchCallout='none';
				self.hasBeenSetSelectable_bl = true;
			}
		};
			
		self.setBackfaceVisibility =  function(){
			self.screen.style.backfaceVisibility = "visible";
			self.screen.style.webkitBackfaceVisibility = "visible";
			self.screen.style.MozBackfaceVisibility = "visible";		
		};
		
		self.removeBackfaceVisibility =  function(){
			self.screen.style.backfaceVisibility = "hidden";
			self.screen.style.webkitBackfaceVisibility = "hidden";
			self.screen.style.MozBackfaceVisibility = "hidden";		
		};
		
		self.getScreen = function(){
			return self.screen;
		};
		
		self.setVisible = function(val){
			self.visible = val;
			if(self.visible == true){
				self.screen.style.visibility = "visible";
			}else{
				self.screen.style.visibility = "hidden";
			}
		};
		
		self.getVisible = function(){
			return self.visible;
		};
			
		self.setResizableSizeAfterParent = function(){
			self.screen.style.width = "100%";
			self.screen.style.height = "100%";
		};
		
		self.getStyle = function(){
			return self.screen.style;
		};
		
		self.setOverflow = function(val){
			self.overflow = val;
			self.screen.style.overflow = self.overflow;
		};
		
		self.setPosition = function(val){
			self.position = val;
			self.screen.style.position = self.position;
		};
		
		self.setDisplay = function(val){
			self.display = val;
			self.screen.style.display = self.display;
		};
		
		self.setButtonMode = function(val){
			self.buttonMode = val;
			if(self.buttonMode ==  true){
				self.screen.style.cursor = "pointer";
			}else{
				self.screen.style.cursor = "default";
			}
		};
		
		self.setBkColor = function(val){
			self.screen.style.backgroundColor = val;
		};
		
		self.setInnerHTML = function(val){
			self.innerHTML = val;
			self.screen.innerHTML = self.innerHTML;
		};
		
		self.getInnerHTML = function(){
			return self.innerHTML;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.setAlpha = function(val){
			self.alpha = val;
			if(self.opacityType == "opacity"){
				self.screen.style.opacity = self.alpha;
			}else if(self.opacityType == "filter"){
				self.screen.style.filter = "alpha(opacity=" + self.alpha * 100 + ")";
				self.screen.style.filter = "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + Math.round(self.alpha * 100) + ")";
			}
		};
		
		self.getAlpha = function(){
			return self.alpha;
		};
		
		self.getRect = function(){
			return self.screen.getBoundingClientRect();
		};
		
		self.getGlobalX = function(){
			return self.getRect().left;
		};
		
		self.getGlobalY = function(){
			return self.getRect().top;
		};
		
		self.setX = function(val){
			self.x = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0) scale(' + self.scale + ',' + self.scale + ')';
			}else{
				self.screen.style.left = self.x + "px";
			}
		};
		
		self.getX = function(){
			return  self.x;
		};
		
		self.setY = function(val){
			self.y = val;
			if(self.hasTransform3d_bl){
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0) scale(' + self.scale + ',' + self.scale + ')';
			}else{
				self.screen.style.top = self.y + "px";
			}
		};
		
		self.getY = function(){
			return  self.y;
		};
		
		self.setWidth = function(val){
			self.w = val;
			if(self.type == "img"){
				self.screen.width = self.w;
			}else{
				self.screen.style.width = self.w + "px";
			}
		};
		
		self.getWidth = function(){
			if(self.type == "div"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}else if(self.type == "img"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				if(self.screen.width != 0) return  self.screen.width;
				return self._w;
			}else if( self.type == "canvas"){
				if(self.screen.offsetWidth != 0) return  self.screen.offsetWidth;
				return self.w;
			}
		};
		
		self.setHeight = function(val){
			self.h = val;
			if(self.type == "img"){
				self.screen.height = self.h;
			}else{
				self.screen.style.height = self.h + "px";
			}
		};
		
		self.getHeight = function(){
			if(self.type == "div"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}else if(self.type == "img"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				if(self.screen.height != 0) return  self.screen.height;
				return self.h;
			}else if(self.type == "canvas"){
				if(self.screen.offsetHeight != 0) return  self.screen.offsetHeight;
				return self.h;
			}
		};
		
		this.setScale = function(scale){
			self.scale = scale;
			if(self.hasTransform2d_bl){
				self.screen.style[self.transform] = 'scale(' + self.scale + ',' + self.scale + ')';
			}else{
				self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0) scale(' + self.scale + ',' + self.scale + ')';
			}
		};
		
		this.setTransformOrigin = function(x, y){
			self.screen.style[self.transformOrigin] = x + "%" + " " +  y + "%";	
		};
		
		self.setPositionAndScale = function(x, y, scale){
			self.x = x;
			self.y = y;
			self.scale = scale;
			self.screen.style[self.transform] = 'translate3d(' + self.x + 'px,' + self.y + 'px,0) scale(' + self.scale + ',' + self.scale + ')';
		};
		
	    //###########################################//
	    /* destroy methods*/
	    //###########################################//
		self.disposeImage = function(){
			if(self.type == "img") self.screen.src = null;
		};
		
		//#####################################//
		/* DOM list */
		//#####################################//
		self.addChild = function(e){
			if(self.contains(e)){	
				self.children_ar.splice(FWDUtils.indexOfArray(self.children_ar, e), 1);
				self.children_ar.push(e);
				self.screen.appendChild(e.screen);
			}else{
				self.children_ar.push(e);
				self.screen.appendChild(e.screen);
			}
		};
		
		
		self.destroy = function(){
			
			//try{self.screen.parentNode.removeChild(self.screen);}catch(e){};
			if(self.hasBeenSetSelectable_bl){
				self.screen.ondragstart = null;
				self.screen.onselectstart = null;
				self.screen.ontouchstart = null;
			};
			
			//destroy properties
			self.style = null;
			self.screen = null;
			self.transform = null;
			self.position = null;
			self.overflow = null;
			self.display = null;
			self.visible = null;
			self.buttonMode = null;
			self.x = null;
			self.y = null;
			self.w = null;
			self.h = null;
			self.rect = null;
			self.alpha = null;
			self.innerHTML = null;
			self.opacityType = null;
			self.isHtml5_bl = null;
			
			type = null;
			position = null;
			overflow = null;
			display = null;
		
			self.hasTransform3d_bl = null;
			self.hasTransform2d_bl = null;
			self = null;
		};
		
	    /* init */
		self.init();
	};
	
	window.FWDTransformDisplayObject = FWDTransformDisplayObject;
}(window));//FWDUtils
(function (window){
	
	var FWDUtils = function(){};
	
	FWDUtils.dumy = document.createElement("div");
	
	//###################################//
	/* String */
	//###################################//
	FWDUtils.trim = function(str){
		return str.replace(/\s/gi, "");
	};
			
	FWDUtils.trimAndFormatUrl = function(str){
		str = str.toLocaleLowerCase();
		str = str.replace(/ /g, "-");
		str = str.replace(/ä/g, "a");
		str = str.replace(/â/g, "a");
		str = str.replace(/â/g, "a");
		str = str.replace(/à/g, "a");
		str = str.replace(/è/g, "e");
		str = str.replace(/é/g, "e");
		str = str.replace(/ë/g, "e");
		str = str.replace(/ï/g, "i");
		str = str.replace(/î/g, "i");
		str = str.replace(/ù/g, "u");
		str = str.replace(/ô/g, "o");
		str = str.replace(/ù/g, "u");
		str = str.replace(/û/g, "u");
		str = str.replace(/ÿ/g, "y");
		str = str.replace(/ç/g, "c");
		str = str.replace(/œ/g, "ce");
		return str;
	};
	
	FWDUtils.splitAndTrim = function(str, trim_bl, toLowerCase_bl){
		var array = str.split(",");
		var length = array.length;
		for(var i=0; i<length; i++){
			if(trim_bl) array[i] = FWDUtils.trim(array[i]);
			if(toLowerCase_bl) array[i] = array[i].toLowerCase();
		};
		return array;
	};
	
	//#############################################//
	//Array //
	//#############################################//
	FWDUtils.indexOfArray = function(array, prop){
		var length = array.length;
		for(var i=0; i<length; i++){
			if(array[i] === prop) return i;
		};
		return -1;
	};
	
	FWDUtils.randomizeArray = function(aArray) {
		var randomizedArray = [];
		var copyArray = aArray.concat();
			
		var length = copyArray.length;
		for(var i=0; i< length; i++) {
				var index = Math.floor(Math.random() * copyArray.length);
				randomizedArray.push(copyArray[index]);
				copyArray.splice(index,1);
			}
		return randomizedArray;
	};
	

	//#############################################//
	/*DOM manipulation */
	//#############################################//
	FWDUtils.parent = function (e, n){
		if(n === undefined) n = 1;
		while(n-- && e) e = e.parentNode;
		if(!e || e.nodeType !== 1) return null;
		return e;
	};
	
	FWDUtils.sibling = function(e, n){
		while (e && n !== 0){
			if(n > 0){
				if(e.nextElementSibling){
					 e = e.nextElementSibling;	 
				}else{
					for(var e = e.nextSibling; e && e.nodeType !== 1; e = e.nextSibling);
				}
				n--;
			}else{
				if(e.previousElementSibling){
					 e = e.previousElementSibling;	 
				}else{
					for(var e = e.previousSibling; e && e.nodeType !== 1; e = e.previousSibling);
				}
				n++;
			}
		}
		return e;
	};
	
	FWDUtils.getChildAt = function (e, n){
		var kids = FWDUtils.getChildren(e);
		if(n < 0) n += kids.length;
		if(n < 0) return null;
		return kids[n];
	};
	
	FWDUtils.getChildById = function(id){
		return document.getElementById(id) || undefined;
	};
	
	FWDUtils.getChildren = function(e, allNodesTypes){
		var kids = [];
		for(var c = e.firstChild; c != null; c = c.nextSibling){
			if(allNodesTypes){
				kids.push(c);
			}else if(c.nodeType === 1){
				kids.push(c);
			}
		}
		return kids;
	};
	
	FWDUtils.getChildrenFromAttribute = function(e, attr, allNodesTypes){
		var kids = [];
		for(var c = e.firstChild; c != null; c = c.nextSibling){
			if(allNodesTypes && FWDUtils.hasAttribute(c, attr)){
				kids.push(c);
			}else if(c.nodeType === 1 && FWDUtils.hasAttribute(c, attr)){
				kids.push(c);
			}
		}
		return kids.length == 0 ? undefined : kids;
	};
	
	FWDUtils.getChildFromNodeListFromAttribute = function(e, attr, allNodesTypes){
		for(var c = e.firstChild; c != null; c = c.nextSibling){
			if(allNodesTypes && FWDUtils.hasAttribute(c, attr)){
				return c;
			}else if(c.nodeType === 1 && FWDUtils.hasAttribute(c, attr)){
				return c;
			}
		}
		return undefined;
	};
	
	FWDUtils.getAttributeValue = function(e, attr){
		if(!FWDUtils.hasAttribute(e, attr)) return undefined;
		return e.getAttribute(attr);	
	};
	
	FWDUtils.hasAttribute = function(e, attr){
		if(e.hasAttribute){
			return e.hasAttribute(attr); 
		}else {
			var test = e.attributes[attr];
			return  test ? true : false;
		}
	};
	
	FWDUtils.insertNodeAt = function(parent, child, n){
		var children = FWDUtils.children(parent);
		if(n < 0 || n > children.length){
			throw new Error("invalid index!");
		}else {
			parent.insertBefore(child, children[n]);
		};
	};
	
	FWDUtils.hasCanvas = function(){
		return Boolean(document.createElement("canvas"));
	};
	
	//###################################//
	/* DOM geometry */
	//##################################//
	FWDUtils.hitTest = function(target, x, y){
		var hit = false;
		if(!target) throw Error("Hit test target is null!");
		var rect = target.getBoundingClientRect();
		
		if(x >= rect.left && x <= rect.left +(rect.right - rect.left) && y >= rect.top && y <= rect.top + (rect.bottom - rect.top)) return true;
		return false;
	};
	
	FWDUtils.getScrollOffsets = function(){
		//all browsers
		if(window.pageXOffset != null) return{x:window.pageXOffset, y:window.pageYOffset};
		
		//ie7/ie8
		if(document.compatMode == "CSS1Compat"){
			return({x:document.documentElement.scrollLeft, y:document.documentElement.scrollTop});
		}
	};
	
	FWDUtils.getViewportSize = function(){
		if(FWDUtils.hasPointerEvent && navigator.msMaxTouchPoints > 1){
			return {w:document.documentElement.clientWidth || window.innerWidth, h:document.documentElement.clientHeight || window.innerHeight};
		}
		
		if(FWDUtils.isMobile) return {w:window.innerWidth, h:window.innerHeight};
		return {w:document.documentElement.clientWidth || window.innerWidth, h:document.documentElement.clientHeight || window.innerHeight};
	};
	
	FWDUtils.getViewportMouseCoordinates = function(e){
		var offsets = FWDUtils.getScrollOffsets();
		if(e.touches){
			return{
				screenX:e.touches[0] == undefined ? e.touches.pageX - offsets.x :e.touches[0].pageX - offsets.x,
				screenY:e.touches[0] == undefined ? e.touches.pageY - offsets.y :e.touches[0].pageY - offsets.y
			};
		}
		
		return{
			screenX: e.clientX == undefined ? e.pageX - offsets.x : e.clientX,
			screenY: e.clientY == undefined ? e.pageY - offsets.y : e.clientY
		};
	};
	
	
	//###################################//
	/* Browsers test */
	//##################################//
	FWDUtils.hasPointerEvent = (function(){
		return Boolean(window.navigator.msPointerEnabled);
	}());
	
	FWDUtils.isMobile = (function (){
		if(FWDUtils.hasPointerEvent && navigator.msMaxTouchPoints > 1) return true;
		var agents = ['android', 'webos', 'iphone', 'ipad', 'blackberry'];
	    for(i in agents) {
	    	 if(navigator.userAgent.toLowerCase().indexOf(agents[i].toLowerCase()) != -1) {
	            return true;
	        }
	    }
	    return false;
	}());
	
	FWDUtils.isAndroid = (function(){
		 return (navigator.userAgent.toLowerCase().indexOf("android".toLowerCase()) != -1);
	}());
	
	FWDUtils.isChrome = (function(){
		return navigator.userAgent.toLowerCase().indexOf('chrome') != -1;
	}());
	
	FWDUtils.isSafari = (function(){
		return navigator.userAgent.toLowerCase().indexOf('safari') != -1 && navigator.userAgent.toLowerCase().indexOf('chrome') == -1;
	}());
	
	FWDUtils.isOpera = (function(){
		return navigator.userAgent.toLowerCase().indexOf('opera') != -1 && navigator.userAgent.toLowerCase().indexOf('chrome') == -1;
	}());
	
	FWDUtils.isFirefox = (function(){
		return navigator.userAgent.toLowerCase().indexOf('firefox') != -1;
	}());
	
	FWDUtils.isIE = (function(){
		return navigator.userAgent.toLowerCase().indexOf('msie') != -1;;
	}());
	
	FWDUtils.isIEAndLessThen9 = (function(){
		return navigator.userAgent.toLowerCase().indexOf("msie 7") != -1 || navigator.userAgent.toLowerCase().indexOf("msie 8") != -1;
	}());
	
	FWDUtils.isApple = (function(){
		return navigator.appVersion.toLowerCase().indexOf('mac') != -1;;
	}());
	
	FWDUtils.hasFullScreen = (function(){
		return FWDUtils.dumy.requestFullScreen || FWDUtils.dumy.mozRequestFullScreen || FWDUtils.dumy.webkitRequestFullScreen || FWDUtils.dumy.msieRequestFullScreen;
	}());
	
	function get3d(){
	    var properties = ['transform', 'msTransform', 'WebkitTransform', 'MozTransform', 'OTransform', 'KhtmlTransform'];
	    var p;
	    var position;
	    while (p = properties.shift()) {
	       if (typeof FWDUtils.dumy.style[p] !== 'undefined') {
	    	   FWDUtils.dumy.style.position = "absolute";
	    	   position = FWDUtils.dumy.getBoundingClientRect().left;
	    	   FWDUtils.dumy.style[p] = 'translate3d(500px, 0px, 0px)';
	    	   position = Math.abs(FWDUtils.dumy.getBoundingClientRect().left - position);
	    	   
	           if(position > 100 && position < 900){
	        	   try{document.documentElement.removeChild(FWDUtils.dumy);}catch(e){}
	        	   return true;
	           }
	       }
	    }
	    try{document.documentElement.removeChild(FWDUtils.dumy);}catch(e){}
	    return false;
	};
	
	function get2d(){
	    var properties = ['transform', 'msTransform', 'WebkitTransform', 'MozTransform', 'OTransform', 'KhtmlTransform'];
	    var p;
	    while (p = properties.shift()) {
	       if (typeof FWDUtils.dumy.style[p] !== 'undefined') {
	    	   return true;
	       }
	    }
	    try{document.documentElement.removeChild(FWDUtils.dumy);}catch(e){}
	    return false;
	};
	
	FWDUtils.checkIfHasTransofrms = function(){
		document.documentElement.appendChild(FWDUtils.dumy);
		FWDUtils.hasTransform3d = get3d();
		FWDUtils.hasTransform2d = get2d();
		FWDUtils.isReadyMethodCalled_bl = true;
	};
	
	//###############################################//
	/* various utils */
	//###############################################//
	FWDUtils.onReady =  function(callbalk){
		if (document.addEventListener) {
			document.addEventListener( "DOMContentLoaded", function(){
				document.documentElement.appendChild(FWDUtils.dumy);
				FWDUtils.hasTransform3d = get3d();
				FWDUtils.hasTransform2d = get2d();
				callbalk();
			});
		}else{
			document.onreadystatechange = function () {
				document.documentElement.appendChild(FWDUtils.dumy);
				FWDUtils.hasTransform3d = get3d();
				FWDUtils.hasTransform2d = get2d();
				if (document.readyState == "complete") callbalk();
			};
		 }
	};
	
	FWDUtils.disableElementSelection = function(e){
		try{e.style.userSelect = "none";}catch(e){};
		try{e.style.MozUserSelect = "none";}catch(e){};
		try{e.style.webkitUserSelect = "none";}catch(e){};
		try{e.style.khtmlUserSelect = "none";}catch(e){};
		try{e.style.oUserSelect = "none";}catch(e){};
		try{e.style.msUserSelect = "none";}catch(e){};
		try{e.msUserSelect = "none";}catch(e){};
		e.onselectstart = function(){return false;};
	};
	
	FWDUtils.getUrlArgs = function urlArgs(string){
		var args = {};
		var query = string.substr(string.indexOf("?") + 1) || location.search.substring(1);
		var pairs = query.split("&");
		for(var i=0; i< pairs.length; i++){
			var pos = pairs[i].indexOf("=");
			var name = pairs[i].substring(0,pos);
			var value = pairs[i].substring(pos + 1);
			value = decodeURIComponent(value);
			args[name] = value;
		}
		return args;
	};
	
	FWDUtils.validateEmail = function(mail){  
		if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)){  
			return true;  
		}  
		return false;  
    }; 
    
	//################################//
	/* resize utils */
	//################################//
	FWDUtils.resizeDoWithLimit = function(
			displayObject,
			containerWidth,
			containerHeight,
			doWidth,
			doHeight,
			removeWidthOffset,
			removeHeightOffset,
			offsetX,
			offsetY,
			animate,
			pDuration,
			pDelay,
			pEase
		) {
		var containerWidth = containerWidth - removeWidthOffset;
		var containerHeight = containerHeight - removeHeightOffset;
			
		var scaleX = containerWidth/doWidth;
		var scaleY = containerHeight/doHeight;
		var totalScale = 0;
				
		if(scaleX <= scaleY){
			totalScale = scaleX;
		}else if(scaleX >= scaleY){
			totalScale = scaleY;
		}
			
		var finalWidth = Math.round((doWidth * totalScale));
		var finalHeight = Math.round((doHeight * totalScale));
		var x = Math.floor((containerWidth -  (doWidth * totalScale))/2  + offsetX);
		var y = Math.floor((containerHeight -  (doHeight * totalScale))/2 + offsetY);
			
		if(animate){
			TweenMax.to(displayObject, pDuration, {x:x, y:y, w:finalWidth, h:finalHeight, delay:pDelay, ease:pEase});
		}else{
			displayObject.x = x;
			displayObject.y = y;
			displayObject.w = finalWidth;
			displayObject.h = finalHeight;
		}
	};
	
	FWDUtils.isReadyMethodCalled_bl = false;
	
	window.FWDUtils = FWDUtils;
}(window));/* Gallery */
(function (window){
	
	var FWDViewer = function(props){
		
		var self = this;
	
		/* init gallery */
		self.init = function(){
		
			TweenLite.ticker.useRAF(false);
			self.props_obj = props;
			
			self.isFullScreen_bl = false;
			self.mustHaveHolderDiv_bl = false;
		
			self.displayType = props.displayType.toLowerCase();
			
			if(!self.displayType) self.displayType = FWDViewer.FULL_SCREEN;

			if(self.displayType == FWDViewer.RESPONSIVE) self.mustHaveHolderDiv_bl = true;
			
			self.body = document.getElementsByTagName("body")[0];
	
			if(!self.props_obj){
				alert("FWDViewer constructor properties object is not defined!");
				return;
			}
			
			if(!self.props_obj.divHolderId){		
				if(self.mustHaveHolderDiv_bl){
					alert("Property divHolderId is not defined in the FWDViewer constructor, self property represents the div id into which the grid is added as a child!");
					return;
				}
			}
			
			if(self.mustHaveHolderDiv_bl && !FWDUtils.getChildById(self.props_obj.divHolderId)){
				alert("FWDViewer holder div is not found, please make sure that the div exsists and the id is correct! " + self.props_obj.divHolderId);
				return;
			}
		
			if(self.displayType == FWDViewer.FULL_SCREEN || self.displayType == FWDViewer.LIGHTBOX){
				if(FWDUtils.isIEAndLessThen9){
					self.stageContainer = self.body;
				}else{
					self.stageContainer = document.documentElement;
				}
			}else{
				self.stageContainer =  FWDUtils.getChildById(self.props_obj.divHolderId);
			}
			
			this.customContextMenu = null;
			this.info_do = null;
			this.main_do = null;
			this.preloader_do = null;
			this.navigator_do = null;
			this.controller_do = null;
			this.imageManager_do = null;
			this.descriptionWindow_do = null;
			this.hider = null;
			this.lightBox_do = null;
			this.rotateDumy_sdo = null;
			this.markersDumy_sdo = null;
			this.panDumy_sdo = null;
			
			this.backgroundColor_str = self.props_obj.backgroundColor || "transparent";
			this.lightBoxBackgroundColor_str = self.props_obj.lightBoxBackgroundColor || "transparent";
			
			this.viewportWidth = 0;
			this.viewportHeight = 0;
			this.stageWidth = 0;
			this.stageHeight = 0;
			this.pageXOffset = window.pageXOffset;
			this.pageYOffset = window.pageYOffset;
			this.lastScrollY;
			this.lastScrollX;
			this.lightBoxBackgroundOpacity = self.props_obj.lightBoxBackgroundOpacity || 1;
			this.lightBoxWidth = self.props_obj.lightBoxWidth || 500;
			this.lightBoxHeight =  self.props_obj.lightBoxHeight || 400;
			this.finalLightBoxWidth;
			this.finalLightBoxHeight;
			
			this.resizeHandlerId_to;
			this.resizeHandler2Id_to;
			this.lighboxAnimDoneId_to;
			this.startHiderWithDelayId_to;
			this.initPluginId_to;
			this.activateWithDelayImagemanagerId_to;
			
			this.isMobile_bl = FWDUtils.isMobile;
			this.hibernate_bl = false;
			this.safeToControll_bl = false;
			
			if(!FWDUtils.isReadyMethodCalled_bl) FWDUtils.checkIfHasTransofrms();
			
			if(self.displayType == FWDViewer.LIGHTBOX){
				this.initPluginId_to = setTimeout(function(){self.setupLightBox();}, 50);
			}else{
				this.initPluginId_to = setTimeout(function(){self.setupViewer();}, 50);
			}
		};
		
		//#############################################//
		/* setup grid main instances */
		//#############################################//
		self.setupViewer = function(){
			
			self.setupMainDo();
			self.startResizeHandler();
			self.setupInfo();
			self.setupData();
			if(FWDUtils.hasPointerEvent && FWDUtils.isMobile) window.addEventListener("contextmenu", self.preventContextMenu);
		};
	
		//#############################################//
		/* setup main do */
		//#############################################//
		self.setupMainDo = function(){
			
			self.main_do = new FWDDisplayObject("div", "relative");
			self.main_do.getStyle().msTouchAction = "none";
			self.main_do.getStyle().webkitTapHighlightColor =  "rgba(0, 0, 0, 0)";  
			self.main_do.setBackfaceVisibility();
			self.main_do.setBkColor(self.backgroundColor_str);
			
			if(!FWDUtils.isMobile || (FWDUtils.isMobile && FWDUtils.hasPointerEvent)) self.main_do.setSelectable(false);
		
			//start full screen
			if(self.displayType == FWDViewer.FULL_SCREEN){	
				self.stageContainer.style.overflow = "hidden";
				self.main_do.getStyle().position = "absolute";
				document.documentElement.style.overflow = "hidden";
				self.stageContainer.appendChild(self.main_do.screen);
			}else if(self.displayType == FWDViewer.LIGHTBOX){
				self.main_do.getStyle().position = "absolute";
				self.stageContainer.appendChild(self.main_do.screen);
			}else{
				self.stageContainer.appendChild(self.main_do.screen);
			}	
		};
		
		//#############################################//
		/* prevent context menu on windows8 mobile */
		//############################################//
		self.preventContextMenu = function(e){
			e.preventDefault();
		};
		
		//#############################################//
		/* setup info_do */
		//#############################################//
		self.setupInfo = function(){
			FWDInfo.setPrototype();
			self.info_do = new FWDInfo();
		};	
		
		//#############################################//
		/* resize handler */
		//#############################################//
		self.startResizeHandler = function(){
			if(window.addEventListener){
				window.addEventListener("resize", self.onResizeHandler);
				window.addEventListener("scroll", self.onScrollHandler);
			}else if(window.attachEvent){
				window.attachEvent("onresize", self.onResizeHandler);
				window.attachEvent("onscroll", self.onScrollHandler);
			}
			self.onResizeHandler(true);
			self.resizeHandlerId_to = setTimeout(function(){self.resizeHandler(true);}, 500);
		};
		
		self.stopResizeHandler = function(){
			if(window.removeEventListener){
				window.removeEventListener("resize", self.onResizeHandler);
				window.removeEventListener("scroll", self.onScrollHandler);
			}else if(window.detachEvent){
				window.detachEvent("onresize", self.onResizeHandler);
				window.detachEvent("onscroll", self.onScrollHandler);
			}	
			clearTimeout(self.resizeHandlerId_to);
		};
		
		self.onResizeHandler = function(e){
			self.resizeHandler();
		};
		
		self.onScrollHandler = function(e){
			if(self.hibernate_bl) return;
			if(self.isFullScreen_bl 
			   || self.displayType == FWDViewer.FULL_SCREEN 
			   || self.displayType == FWDViewer.LIGHTBOX){
				self.scrollHandler();
			}
		};
		
		//##########################################//
		/* resize and scroll handler */
		//##########################################//
		self.scrollHandler = function(){
			var scrollOffsets = FWDUtils.getScrollOffsets();
			self.pageXOffset = scrollOffsets.x;
			self.pageYOffset = scrollOffsets.y;
			if(self.displayType == FWDViewer.LIGHTBOX){
				self.lightBox_do.setX(scrollOffsets.x);
				self.lightBox_do.setY(scrollOffsets.y);
			}else if(self.isFullScreen_bl || self.displayType == FWDViewer.FULL_SCREEN){	
				self.main_do.setX(scrollOffsets.x);
				self.main_do.setY(scrollOffsets.y);
			}
		};
		
		self.resizeHandler = function(overwrite){
			if(self.hibernate_bl) return;
			var scrollOffsets = FWDUtils.getScrollOffsets();
			var viewportSize = FWDUtils.getViewportSize();
			
			if(self.viewportWidth == viewportSize.w && self.viewportHeight == viewportSize.h 
				&& self.pageXOffset == scrollOffsets.x && self.pageYOffset == scrollOffsets.y
				&& !overwrite) return;
			
			self.viewportWidth = viewportSize.w;
			self.viewportHeight = viewportSize.h;
			self.pageXOffset = scrollOffsets.x;
			self.pageYOffset = scrollOffsets.y;
		
			if(self.displayType == FWDViewer.LIGHTBOX && !self.isFullScreen_bl){
				if(self.lightBoxWidth > viewportSize.w){
					self.finalLightBoxWidth = viewportSize.w;
					self.finalLightBoxHeight = parseInt(self.lightBoxHeight * (viewportSize.w/self.lightBoxWidth));
				}else{
					self.finalLightBoxWidth = self.lightBoxWidth;
					self.finalLightBoxHeight = self.lightBoxHeight;
				}
				self.lightBox_do.setWidth(viewportSize.w);
				self.lightBox_do.setHeight(viewportSize.h);
				self.lightBox_do.setX(scrollOffsets.x);
				self.lightBox_do.setY(scrollOffsets.y);
				self.lightBox_do.mainLightBox_do.setX(parseInt((viewportSize.w - self.finalLightBoxWidth)/2));
				self.lightBox_do.mainLightBox_do.setY(parseInt((viewportSize.h - self.finalLightBoxHeight)/2));
				if(self.lightBox_do.closeButton_do && !self.lightBox_do.closeButtonIsTweening_bl){ 
					var closeButtonFinalX = parseInt((viewportSize.w + self.finalLightBoxWidth)/2 - self.lightBox_do.closeButton_do.totalWidth/2);
					var closeButtonFinalY = parseInt((viewportSize.h - self.finalLightBoxHeight)/2 - self.lightBox_do.closeButton_do.totalHeight/2);
		
					if(closeButtonFinalX + self.lightBox_do.closeButton_do.totalWidth > self.viewportWidth){
						closeButtonFinalX = self.viewportWidth - self.lightBox_do.closeButton_do.totalWidth;
					}
					
					if(closeButtonFinalY < 0){
						closeButtonFinalY = 0;
					}
				
					self.lightBox_do.closeButton_do.setX(closeButtonFinalX);
					self.lightBox_do.closeButton_do.setY(closeButtonFinalY);	
				}
				self.main_do.setX(0);
				self.main_do.setY(0);
				self.lightBox_do.mainLightBox_do.setWidth(self.finalLightBoxWidth);
				self.lightBox_do.mainLightBox_do.setHeight(self.finalLightBoxHeight);	
				self.stageWidth = self.finalLightBoxWidth;
				self.stageHeight = self.finalLightBoxHeight;
			}else if(self.isFullScreen_bl || self.displayType == FWDViewer.FULL_SCREEN){	
				self.main_do.setX(scrollOffsets.x);
				self.main_do.setY(scrollOffsets.y);
				self.stageWidth = viewportSize.w;
				self.stageHeight = viewportSize.h;
			}else{
				self.main_do.setX(0);
				self.main_do.setY(0);
				self.stageWidth = self.stageContainer.offsetWidth;
				self.stageHeight = self.stageContainer.offsetHeight;
			}
			
			self.main_do.setWidth(self.stageWidth);
			self.main_do.setHeight(self.stageHeight);
			
			if(self.preloader_do) self.preloader_do.positionAndResize();
			if(self.controller_do) self.controller_do.resizeAndPosition();
			if(self.imageManager_do) self.imageManager_do.resizeAndPosition(false);
			if(self.navigator_do) self.navigator_do.resizeAndPosition();
			if(self.descriptionWindow_do && self.descriptionWindow_do.isShowed_bl)  self.descriptionWindow_do.resizeAndPosition();
		};
		
		//#############################################//
		/* setup  lighbox...*/
		//#############################################//
		self.setupLightBox = function(){
			FWDLightBox.setPrototype();
			self.lightBox_do =  new FWDLightBox(self, 
					self.lightBoxBackgroundColor_str, 
					self.backgroundColor_str, 
					self.lightBoxBackgroundOpacity, 
					self.lightBoxWidth, 
					self.lightBoxHeight);
			self.lightBox_do.addListener(FWDLightBox.CLOSE, self.lightBoxCloseHandler);
			self.lightBox_do.addListener(FWDLightBox.HIDE_COMPLETE, self.lightBoxHideCompleteHandler);
			self.lighboxAnimDoneId_to = setTimeout(self.setupViewer, 1200);
		};
		
		self.lightBoxCloseHandler = function(){
			self.stopResizeHandler();
			if(self.data) self.data.stopToLoad();
		};
		
		self.lightBoxHideCompleteHandler = function(){
			if(self.dispatchEvent) self.dispatchEvent(FWDViewer.CLOSE_LIGHTBOX);
			self.destroy();
		};
		
		//#############################################//
		/* setup context menu */
		//#############################################//
		self.setupContextMenu = function(){
			FWDContextMenu.setPrototype();
			self.customContextMenu = new FWDContextMenu(self, self.data);
			self.customContextMenu.addListener(FWDController.ROTATE, self.contextMenuRotateHandler);
			self.customContextMenu.addListener(FWDController.PAN, self.contextMenuPanHandler);
			self.customContextMenu.addListener(FWDController.GOTO_NEXT_IMAGE, self.contextMenuGoToNextImageHandler);
			self.customContextMenu.addListener(FWDController.GOTO_PREV_IMAGE, self.contextMenuGoToPrevImageHandler);
			self.customContextMenu.addListener(FWDController.ZOOM_IN, self.contextMenuZoomInHandler);
			self.customContextMenu.addListener(FWDController.ZOOM_OUT, self.contextMenuZoomOutHandler);
			self.customContextMenu.addListener(FWDController.START_SLIDE_SHOW, self.contextMenuStartSlideShowHandler);
			self.customContextMenu.addListener(FWDController.STOP_SLIDE_SHOW, self.contextMenuStopSlideShowHandler);
			self.customContextMenu.addListener(FWDController.SHOW_INFO, self.contextMenuShowInfoWindow);
			self.customContextMenu.addListener(FWDController.GO_FULL_SCREEN, self.controllerGoFullScreen);
			self.customContextMenu.addListener(FWDController.GO_NORMAL_SCREEN, self.controllerGoNormalSreen);
		};
		
		self.contextMenuRotateHandler = function(e){
			self.controller_do.rotateButtonOnMouseDownHandler(e);
		};
		
		self.contextMenuPanHandler = function(e){
			self.controller_do.panButtonOnMouseDownHandler(e.e);
		};
		
		self.contextMenuGoToNextImageHandler = function(e){
			self.controller_do.nextButtonStartHandler(e);
		};
		
		self.contextMenuGoToPrevImageHandler = function(e){
			self.controller_do.prevButtonStartHandler(e);
		};
		
		self.contextMenuZoomInHandler = function(e){
			self.controller_do.zoomInStartHandler(e);
		};
		
		self.contextMenuZoomOutHandler = function(e){
			self.controller_do.zoomOutStartHandler(e);
		};
		
		self.contextMenuStartSlideShowHandler = function(e){
			self.controller_do.startSlideshow(e);
		};
		
		self.contextMenuShowInfoWindow = function(e){
			self.main_do.addChild(self.descriptionWindow_do);
			self.descriptionWindow_do.hide(false, true);
			self.descriptionWindow_do.show(self.data.infoText_str);
		};
		
		self.contextMenuStopSlideShowHandler = function(e){
			self.controller_do.stopSlideShow(e);
		};
		
		//#############################################//
		/* setup data */
		//#############################################//
		self.setupData = function(){
			FWDData.setPrototype();
			self.data = new FWDData(self.props_obj);
			self.data.addListener(FWDData.LIGHBOX_CLOSE_BUTTON_LOADED, self.onLightboxCloseButtonLoadComplete);
			self.data.addListener(FWDData.PRELOADER_LOAD_DONE, self.onPreloaderLoadDone);
			self.data.addListener(FWDData.FIRST_IMAGE_LOAD_COMPLETE, self.firstImageLoadComplete);
			self.data.addListener(FWDData.LOAD_ERROR, self.dataLoadError);
			self.data.addListener(FWDData.SKIN_PROGRESS, self.dataSkinProgressHandler);
			self.data.addListener(FWDData.IMAGES_PROGRESS, self.dataImagesProgressHandler);
			self.data.addListener(FWDData.LOAD_DONE, self.dataLoadComplete);
			self.data.addListener(FWDData.IMAGE_LOADED, self.onImageLoad);
			self.data.addListener(FWDData.IMAGES_LOAD_COMPLETE, self.dataImagesLoadComplete);
		};
		
		self.onLightboxCloseButtonLoadComplete = function(){
			if(self.displayType == FWDViewer.LIGHTBOX) self.lightBox_do.setupCloseButton(self.data.mainLightboxCloseButtonN_img, self.data.mainLightboxCloseButtonS_img);
		};
		
		self.firstImageLoadComplete = function(){
			if(self.data.showNavigator_bl) self.setupNavigator();
			self.imageManager_do.setAlpha(0);
			TweenMax.to(self.imageManager_do, .6, {alpha:1});
			self.main_do.addChild(self.preloader_do);
		};
		
		self.onPreloaderLoadDone = function(){
			self.setupPreloader();
		};
		
		self.onImageLoad = function(e){
			self.imageManager_do.showLoadedImage(e.id);
		};
		
		self.dataLoadError = function(e, text){
			self.main_do.addChild(self.info_do);
			self.info_do.showText(e.text);
		};
		
		self.dataSkinProgressHandler = function(e){
			self.preloader_do.update(e.percent, "Loading skin:" + (Math.round(e.percent * 100)) + "%");
		};
		
		self.dataImagesProgressHandler = function(e){
			self.preloader_do.update(e.percent, self.data.preloaderText_str + (Math.round(e.percent * 100)) + "%");
		};
		
		self.dataLoadComplete = function(e){
			self.setupImageManager();
			self.setupDisableMarkersDumy();
			self.setupController();
			self.main_do.addChild(self.preloader_do);
			if(!self.isMobile_bl) self.setupContextMenu();
		};
		
		self.dataImagesLoadComplete = function(){
			self.preloader_do.hide(true);
			self.activateWithDelayImagemanagerId_to = setTimeout(function(){self.imageManager_do.activate();}, 41);
			if(self.data.hideController_bl){
				self.setupHider();
				self.controller_do.setupHider(self.hider);
				self.imageManager_do.setupHider(self.hider);
				if(self.navigator_do) self.navigator_do.setupHider(self.hider);
				self.startHiderWithDelayId_to = setTimeout(function(){
					self.hider.start();
				}, self.data.hideControllerDelay);
			}
			if(self.customContextMenu) self.customContextMenu.isActive_bl = true;
			if(self.navigator_do) self.navigator_do.activate();
			self.setupDescriptionWindow();
			self.setupRotationDumy();
			self.setupPanDumy();
			if(self.data.slideShowAutoPlay_bl) self.controller_do.startSlideshow(); 
			self.safeToControll_bl = true;
		};
		
		//#############################################//
		/* setup preloader */
		//#############################################//
		self.setupPreloader = function(){
			FWDPreloader.setPrototype();
			self.preloader_do = new FWDPreloader(
					self, 
					self.data.mainPreloader_img, 
					40, 43, 60,
					self.data.preloaderFontColor_str,
					self.data.preloaderBackgroundColor_str);
			
			self.preloader_do.addListener(FWDPreloader.HIDE_COMPLETE, self.onPreloaderHideCompleteHandler);
			self.preloader_do.positionAndResize();
			self.preloader_do.hide(false);
			self.preloader_do.show(true);
			self.main_do.addChild(self.preloader_do);
		};
		
		self.onPreloaderHideCompleteHandler = function(){
			self.main_do.removeChild(self.preloader_do);
			self.preloader_do.destroy();
			self.preloader_do = null;
		};
		
		//###########################################//
		/* setup hider */
		//###########################################//
		self.setupHider = function(){
			FWDHider.setPrototype();
			self.hider = new FWDHider(self.data.isMobile_bl, self.main_do, self.data.hideControllerDelay);
		};
		
		//###########################################//
		/* setup controller */
		//###########################################//
		self.setupController = function(){
			FWDController.setPrototype();
			self.controller_do = new FWDController(self.data, self);
			self.controller_do.addListener(FWDController.MOUSE_DOWN, self.controllerOnMouseDownHandler);
			self.controller_do.addListener(FWDController.CHANGE_NAVIGATION_STYLE, self.setImageViewerNavigationStyleHandler);
			self.controller_do.addListener(FWDController.GOTO_NEXT_OR_PREV_IMAGE, self.gotoNextImageHandler);
			self.controller_do.addListener(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE, self.gotoNextImageCompleteHandler);
			self.controller_do.addListener(FWDController.DISABLE_PAN_OR_MOVE, self.disablePanOrMoveHandler);
			self.controller_do.addListener(FWDController.ENABLE_PAN_OR_MOVE, self.enablePanOrMoveHandler);
			self.controller_do.addListener(FWDController.SCROLL_BAR_UPDATE, self.controllerScrollBarUpdateHandler);
			self.controller_do.addListener(FWDController.ZOOM_WITH_BUTTONS, self.controllerZoomHandler);
			self.controller_do.addListener(FWDController.START_SLIDE_SHOW, self.controllerStartSlideshowHandler);
			self.controller_do.addListener(FWDController.STOP_SLIDE_SHOW, self.controllerStopSlideshowHandler);
			self.controller_do.addListener(FWDController.SHOW_INFO, self.controllerShowInfoHandler);
			self.controller_do.addListener(FWDController.GO_FULL_SCREEN, self.controllerGoFullScreen);
			self.controller_do.addListener(FWDController.GO_NORMAL_SCREEN, self.controllerGoNormalSreen);
	
			if(self.controller_do) self.controller_do.resizeAndPosition();
			self.main_do.addChild(self.controller_do);
		};
		
		self.controllerOnMouseDownHandler = function(){
			self.imageManager_do.hideToolTipWindow();
		};
	
		self.setImageViewerNavigationStyleHandler = function(e){
			self.imageManager_do.setDraggingMode(e.draggingMode);
			
			if(self.customContextMenu){
				if(e.draggingMode ==  FWDController.ROTATE){
					self.customContextMenu.enablePanButton();
				}else if(e.draggingMode ==  FWDController.PAN){
					self.customContextMenu.enableRotateButton();
				}
			}
		};
		
		self.gotoNextImageHandler = function(e){
			if(!self.data.areAllImagesLoaded_bl) return;
			self.imageManager_do.curId += e.dir;
			self.imageManager_do.gotoImage();
		};
		
		self.gotoNextImageCompleteHandler = function(e){
			if(!self.data.areAllImagesLoaded_bl) return;
			self.imageManager_do.addLargeImage();
		};
		
		self.disablePanOrMoveHandler = function(){
			self.imageManager_do.disableOrEnablePanOrTouch(true);
			self.showMarkersDumy();
		};
		
		self.enablePanOrMoveHandler = function(){
			self.imageManager_do.disableOrEnablePanOrTouch(false);
			self.hideMarkersDumy();
		};
		
		self.controllerScrollBarUpdateHandler = function(e){
			self.imageManager_do.zoomInOrOutWithScrollBar(e.percent);
		};
		
		self.controllerZoomHandler = function(e){
			self.imageManager_do.zoomInOrOutWithButtons(e.dir, e.withPause);
		};
		
		self.controllerStartSlideshowHandler = function(e){
			if(self.customContextMenu) self.customContextMenu.updateSlideShowButton(1);
		};
		
		self.controllerStopSlideshowHandler = function(e){
			if(self.customContextMenu) self.customContextMenu.updateSlideShowButton(0);
		};
		
		self.controllerShowInfoHandler = function(){
			if(self.main_do.contains(self.descriptionWindow_do)) return;
			self.main_do.addChild(self.descriptionWindow_do);
			self.descriptionWindow_do.hide(false, true);
			self.descriptionWindow_do.show(self.data.infoText_str);
		};
		
		self.controllerGoFullScreen = function(){
			if(self.isFullScreen_bl) return;
			self.goFullScreen();
			self.imageManager_do.centerImage();
			self.controller_do.setFullScreenButtonState(0);
			if(self.customContextMenu) self.customContextMenu.updateFullScreenButton(1);
			if(document.addEventListener){
				document.addEventListener("fullscreenchange", self.onFullScreenChange);
				document.addEventListener("mozfullscreenchange", self.onFullScreenChange);
				document.addEventListener("webkitfullscreenchange", self.onFullScreenChange);
			}
		};
		
		self.controllerGoNormalSreen = function(){
			if(!self.isFullScreen_bl) return;
			self.goNormalScreen();
			self.imageManager_do.centerImage();
			self.controller_do.setFullScreenButtonState(1);
			if(self.customContextMenu) self.customContextMenu.updateFullScreenButton(0);
			
			if(document.removeEventListener){
				document.removeEventListener("fullscreenchange", self.onFullScreenChange);
				document.removeEventListener("mozfullscreenchange", self.onFullScreenChange);
				document.removeEventListener("webkitfullscreenchange", self.onFullScreenChange);
			}
		};
		
		this.onFullScreenChange = function(e){
			if(!(document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msieFullScreen)){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.controller_do.setFullScreenButtonState(1);
				if(self.customContextMenu) self.customContextMenu.updateFullScreenButton(0);
			
				self.isFullScreen_bl = false;
			}
		};
		
		
		this.onFullScreenChange = function(e){
			
			if(!(document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msieFullScreen)){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.controller_do.setFullScreenButtonState(1);
				if(self.customContextMenu) self.customContextMenu.updateFullScreenButton(0);
				self.controllerGoNormalSreen();
				if(document.removeEventListener){
					document.removeEventListener("fullscreenchange", self.onFullScreenChange);
					document.removeEventListener("mozfullscreenchange", self.onFullScreenChange);
					document.removeEventListener("webkitfullscreenchange", self.onFullScreenChange);
				}
				self.isFullScreen_bl = false;
			}
		};
		
		
		//###########################################//
		/* setup image manager */
		//###########################################//
		self.setupImageManager = function(id){	
			FWDImageManager.setPrototype();
			self.imageManager_do = new FWDImageManager(self.data, self);
			self.imageManager_do.addListener(FWDImageManager.LARGE_IMAGE_LOAD_ERROR, self.imageManagerLoadError);
			self.imageManager_do.addListener(FWDImageManager.SCROLL_BAR_UPDATE, self.imageManagerScrollBarUpdate);
			self.imageManager_do.addListener(FWDImageManager.PAN_START, self.imageManagerPanStartHandler);
			self.imageManager_do.addListener(FWDImageManager.ROTATE_START, self.imageManagerRotateStartHandler);
			self.imageManager_do.addListener(FWDImageManager.ROTATE_UPDATE, self.imageManagerRotateUpdateHandler);
			self.imageManager_do.addListener(FWDImageManager.SHOW_NAVIGATOR, self.imageManagerShowNavigatorHandler);
			self.imageManager_do.addListener(FWDImageManager.HIDE_NAVIGATOR, self.imageManagerHideNavigatorHandler);
			self.imageManager_do.addListener(FWDImageManager.UPDATE_NAVIGATOR, self.imageManagerUpdateNavigatorHandler);
			self.imageManager_do.addListener(FWDImageManager.SHOW_INFO, self.imageManagerShowInfoHandler);
			self.main_do.addChild(self.imageManager_do);
		};
		
		self.imageManagerLoadError = function(e){
			self.main_do.addChild(self.info_do);
			self.info_do.showText(e.error);
		};
		
		self.imageManagerScrollBarUpdate = function(e){
			self.controller_do.updateScrollBar(e.percent, e.animate);
		};
		
		self.imageManagerPanStartHandler = function(e){
			self.controller_do.stopSlideShow();
		};
		
		self.imageManagerRotateStartHandler = function(e){
			self.controller_do.stopSlideShow();
		};
		
		self.imageManagerRotateUpdateHandler = function(e){
			if(self.navigator_do) self.navigator_do.updateImage(e.id);
			if(self.main_do.contains(self.info_do))self.main_do.removeChild(self.info_do);
		};
		
		self.imageManagerShowNavigatorHandler = function(){
			self.navigator_do.show(true);
		};
		
		self.imageManagerHideNavigatorHandler = function(){
			self.navigator_do.hide(true);
		};
		
		self.imageManagerUpdateNavigatorHandler = function(e){
			self.navigator_do.update(e.percentX, e.percentY, e.percentWidth, e.percentHeight, e.animate);
		};
		
		self.imageManagerShowInfoHandler = function(e){
			self.main_do.addChild(self.descriptionWindow_do);
			self.descriptionWindow_do.hide(false, true);
			self.descriptionWindow_do.show(e.text);
		};
		
		//#############################################//
		/* Setup navigator */
		//#############################################//
		self.setupNavigator = function(){
			FWDNavigator.setPrototype();
			self.navigator_do = new FWDNavigator(self, self.data);
			self.navigator_do.addListener(FWDNavigator.MOUSE_DOWN, self.navigatorOnMouseDownHandler);
			self.navigator_do.addListener(FWDNavigator.PAN_START, self.navigatorPanStartHandler);
			self.navigator_do.addListener(FWDNavigator.PAN, self.navigatorPanHandler);
			self.main_do.addChild(self.navigator_do);
		};
		
		self.navigatorOnMouseDownHandler = function(){
			self.imageManager_do.hideToolTipWindow();
		};
		
		self.navigatorPanStartHandler = function(e){
			self.controller_do.stopSlideShow();
		};
		
		self.navigatorPanHandler = function(e){
			self.imageManager_do.updateOnNavigatorPan(e.percentX, e.percentY);
		};
		
		//#############################################//
		/* Setup description window */
		//#############################################//
		self.setupDescriptionWindow = function(){
			FWDDescriptionWindow.setPrototype();
			self.descriptionWindow_do = new FWDDescriptionWindow(self, self.data);
			self.descriptionWindow_do.addListener(FWDDescriptionWindow.SHOW_START, self.descWindowShowStartHandler);
			self.descriptionWindow_do.addListener(FWDDescriptionWindow.HIDE_COMPLETE, self.descWindowHideComplteHandler);
		};
		
		self.descWindowShowStartHandler = function(){
			if(self.customContextMenu) self.customContextMenu.disable();
		};
		
		self.descWindowHideComplteHandler = function(){
			if(self.customContextMenu) self.customContextMenu.enable();
			self.main_do.removeChild(self.descriptionWindow_do);
		};
		
		//##########################################//
		/* setup rotation dummy */
		//##########################################//
		this.setupRotationDumy = function(){
			self.rotateDumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE) self.rotateDumy_sdo.getStyle().background = "url('dumy')";
			self.rotateDumy_sdo.getStyle().cursor = 'url(' + self.data.handGrabRotatePath_str + '), default';
			self.main_do.addChild(self.rotateDumy_sdo);
		};
		
		this.showRotateDumy = function(){
			self.rotateDumy_sdo.setWidth(self.stageWidth);
			self.rotateDumy_sdo.setHeight(self.stageHeight);
		};
		
		this.hideRotateDumy = function(){
			self.rotateDumy_sdo.setWidth(0);
			self.rotateDumy_sdo.setHeight(0);
		};
		
		//##########################################//
		/* setup move dummy */
		//##########################################//
		this.setupPanDumy = function(){
			self.panDumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE) self.panDumy_sdo.getStyle().background = "url('dumy')";
			self.panDumy_sdo.getStyle().cursor = 'url(' + self.data.handGrabPath_str + '), default';
			self.main_do.addChild(self.panDumy_sdo);
		};
		
		this.showPanDumy = function(){
			self.panDumy_sdo.setWidth(self.stageWidth);
			self.panDumy_sdo.setHeight(self.stageHeight);
		};
		
		this.hidePanDumy = function(){
			self.panDumy_sdo.setWidth(0);
			self.panDumy_sdo.setHeight(0);
		};
		
		//##########################################//
		/* setup markers dummy */
		//##########################################//
		this.setupDisableMarkersDumy = function(){
			self.markersDumy_sdo = new FWDSimpleDisplayObject("div");
			if(FWDUtils.isIE) self.markersDumy_sdo.getStyle().background = "url('dumy')";
			self.main_do.addChild(self.markersDumy_sdo);
		};
		
		this.showMarkersDumy = function(){
			self.markersDumy_sdo.setWidth(self.stageWidth);
			self.markersDumy_sdo.setHeight(self.stageHeight);
		};
		
		this.hideMarkersDumy = function(){
			self.markersDumy_sdo.setWidth(0);
			self.markersDumy_sdo.setHeight(0);
		};
		
		//#############################################//
		/* go fullscreen / normal screen */
		//#############################################//
		self.goFullScreen = function(){
			
			var scrollOffsets = FWDUtils.getScrollOffsets();
			
			self.lastScrollX = scrollOffsets.x;
			self.lastScrollY = scrollOffsets.y;
			
			if (document.documentElement.requestFullScreen) {  
				document.documentElement.requestFullScreen();  
			}else if(document.documentElement.mozRequestFullScreen) {  
				document.documentElement.mozRequestFullScreen();  
			}else if(document.documentElement.webkitRequestFullScreen) {  
				document.documentElement.webkitRequestFullScreen();  
			}else if(document.documentElement.msieRequestFullScreen) {  
				document.documentElement.msieRequestFullScreen();  
			}
			
			self.main_do.getStyle().position = "absolute";
			self.body.style.overflow = "hidden";
			document.documentElement.style.overflow = "hidden";
			
			if(FWDUtils.isIEAndLessThen9){
				self.body.appendChild(self.main_do.screen);
			}else{
				//self.body.style.visiblity = "hidden";
				document.documentElement.appendChild(self.main_do.screen);
			}
			
			self.main_do.getStyle().zIndex = 100000001;
			
			self.isFullScreen_bl = true;
			self.resizeHandler(true);
		};
		
		self.goNormalScreen = function(){			
			if (document.cancelFullScreen) {  
				document.cancelFullScreen();  
			}else if (document.mozCancelFullScreen) {  
				document.mozCancelFullScreen();  
			}else if (document.webkitCancelFullScreen) {  
				document.webkitCancelFullScreen();  
			}else if (document.msieCancelFullScreen) {  
				document.msieCancelFullScreen();  
			}
			
			self.addMainDoToTheOriginalParent();
			
			self.isFullScreen_bl = false;
			self.resizeHandler(true);
		};
		
		self.addMainDoToTheOriginalParent = function(){
			
			if(self.displayType != FWDViewer.FULL_SCREEN){
				if(FWDUtils.isIEAndLessThen9){
					document.documentElement.style.overflow = "auto";
					this.body.style.overflow = "auto";
					this.body.style.visibility = "visible";
				}else{
					document.documentElement.style.overflow = "visible";
					self.body.style.overflow = "visible";
					self.body.style.display = "inline";
				}
			}
			
			if(self.displayType == FWDViewer.FULL_SCREEN){
				if(FWDUtils.isIEAndLessThen9){
					self.body.appendChild(self.main_do.screen);
				}else{
					document.documentElement.appendChild(self.main_do.screen);
				}
			}else if(self.displayType == FWDViewer.LIGHTBOX){
				self.stageContainer.appendChild(self.main_do.screen);
				//self.stageContainer.appendChild(self.closeButton_do.screen);
			}else{
				self.main_do.getStyle().position = "relative";
				self.stageContainer.appendChild(self.main_do.screen);
			}
			
			self.main_do.getStyle().zIndex = 0;
			window.scrollTo(self.lastScrollX, self.lastScrollY);
		};
		
		//#############################################//
		/* API */
		//#############################################//
		this.pan = function(){
			if(self.safeToControll_bl) self.controller_do.pan();
		};
		
		this.rotate = function(){
			if(self.safeToControll_bl) self.controller_do.rotate();
		};
		
		this.rotateLeft = function(){
			if(self.safeToControll_bl) self.controller_do.prevButtonStartHandler();
		};
		
		this.rotateRight = function(){
			if(self.safeToControll_bl) self.controller_do.nextButtonStartHandler();
		};
		
		this.zoomOut = function(){
			if(self.safeToControll_bl) self.controller_do.zoomOutStartHandler();
		};
		
		this.zoomIn = function(){
			if(self.safeToControll_bl) self.controller_do.zoomInStartHandler();
		};
		
		this.play = function(){
			if(self.safeToControll_bl) self.controller_do.startSlideshow();
		};
		
		this.pause = function(){
			if(self.safeToControll_bl) self.controller_do.stopSlideShow();
		};
		
		this.info = function(){
			if(self.safeToControll_bl) self.controller_do.infoButtonStartHandler();
		};
		
		this.fullScreen = function(){
			if(self.safeToControll_bl) self.controllerGoFullScreen();
		};
		
		this.normalScreen = function(){
			if(self.safeToControll_bl) self.controllerGoNormalSreen();
		};
		
		
		
		//#############################################//
		/* clean main events */
		//#############################################//
		self.cleanMainEvents = function(){
			
			if(window.removeEventListener){
				window.removeEventListener("resize", self.onResizeHandler);
				window.removeEventListener("scroll", self.onScrollHandler);
				document.removeEventListener("fullscreenchange", self.onFullScreenChange);
				document.removeEventListener("mozfullscreenchange", self.onFullScreenChange);
				document.removeEventListener("webkitfullscreenchange", self.onFullScreenChange);
			}else if(window.detachEvent){
				window.detachEvent("onresize", self.onResizeHandler);
				window.detachEvent("onscroll", self.onScrollHandler);
			}
			
			if(self.isMobile_bl){
				window.removeEventListener("contextmenu", self.preventContextMenu);	
			}
			
			clearTimeout(self.resizeHandlerId_to);
			clearTimeout(self.resizeHandler2Id_to);
			clearTimeout(self.lighboxAnimDoneId_to);
			clearTimeout(self.startHiderWithDelayId_to);
			clearTimeout(self.initPluginId_to);
			clearTimeout(self.activateWithDelayImagemanagerId_to);
			
		};
		
		/* destroy */
		self.destroy = function(){
			
			self.cleanMainEvents();
			
			if(self.data) self.data.destroy();
			if(self.lightBox_do)self.lightBox_do.destroy();
			if(self.preloader_do) self.preloader_do.destroy();
			if(self.customContextMenu) self.customContextMenu.destroy();
			if(self.info_do) self.info_do.destroy();
			
			
			if(self.imageManager_do){
				TweenMax.killTweensOf(self.imageManager_do);
				self.imageManager_do.destroy();
			}
			
			if(self.controller_do) self.controller_do.destroy();
			if(self.navigator_do) self.navigator_do.destroy();
			
			if(self.hider) self.hider.destroy();
			if(self.descriptionWindow_do) self.descriptionWindow_do.destroy();
			
			if(self.rotateDumy_sdo) self.rotateDumy_sdo.destroy();
			if(self.markersDumy_sdo) self.markersDumy_sdo.destroy();
			if(self.panDumy_sdo) self.panDumy_sdo.destroy();
			
			try{
				self.main_do.screen.parentNode.removeChild(self.main_do.screen);
			}catch(e){}
			if(self.main_do){
				self.main_do.setInnerHTML("");
				self.main_do.destroy();
			}
			
			self.data = null;
			self.lightBox_do = null;
			self.customContextMenu = null;
			self.preloader_do = null;
			self.hider = null;
			self.info_do = null;
			self.main_do = null;
			self.imageManager_do = null;
			self.navigator_do = null;
			self.rotateDumy_sdo = null;
			self.markersDumy_sdo = null;
			self.panDumy_sdo = null;
			
			self = null;
		};
		
		self.init();
		
	};
	
	/* set prototype */
	FWDViewer.setPrototype =  function(){
		FWDViewer.prototype = new FWDEventDispatcher();
	};
	
	FWDViewer.CLOSE_LIGHTBOX = "closeLightBox";
	FWDViewer.FULL_SCREEN = "fullscreen";
	FWDViewer.LIGHTBOX = "lightbox";
	FWDViewer.RESPONSIVE = "responsive";
	
	window.FWDViewer = FWDViewer;
	
}(window));