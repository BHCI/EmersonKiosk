/* FWDController */
(function(){
var FWDController = function(
			data,
			parent
		){
		
		var self = this;
		var prototype = FWDController.prototype;
		
		this.buttonsTest_ar = data.buttons_ar;
		this.buttonsLabels_ar = data.buttonsLabels_ar;
		this.buttons_ar = [];
	
		this.backgroundLeft_img = data.controllerBackgroundLeft_img;
		this.backgroundRight_img = data.controllerBackgroundRight_img;
		this.panN_img = data.controllerPanN_img;
		this.panS_img = data.controllerPanS_img;
		this.rotateN_img = data.controllerRotateN_img;
		this.rotateS_img = data.controllerRotateS_img;
		this.nextN_img = data.controllerNextN_img;
		this.nextS_img = data.controllerNextS_img;
		this.prevN_img = data.controllerPrevN_img;
		this.prevS_img = data.controllerPrevS_img;
		this.playN_img = data.controllerPlayN_img;
		this.playS_img = data.controllerPlayS_img;
		this.pauseN_img = data.controllerPauseN_img;
		this.pauseS_img = data.controllerPauseS_img;
		this.infoN_img = data.controllerInfoN_img;
		this.infoS_img = data.controllerInfoS_img;
		this.linkN_img = data.controllerLinkN_img;
		this.linkS_img = data.controllerLinkS_img;
		this.fullScreenNormalN_img = data.controllerFullScreenNormalN_img;
		this.fullScreenNormalS_img = data.controllerFullScreenNormalS_img;
		this.fullScreenFullN_img = data.controllerFullScreenFullN_img;
		this.fullScreenFullS_img = data.controllerFullScreenFullS_img;
		this.zoomInN_img = data.zoomInN_img;
		this.zoomInS_img = data.zoomInS_img;
		this.zoomOutN_img = data.zoomOutN_img;
		this.zoomOutS_img = data.zoomOutS_img;
		this.scrollBarHandlerN_img = data.scrollBarHandlerN_img;
		this.scrollBarHandlerS_img =  data.scrollBarHandlerS_img;
		this.scrollBarLeft_img = data.scrollBarLeft_img;
		this.scrollBarRight_img =  data.scrollBarRight_img;
		this.toolTipLeft_img = data.toolTipLeft_img;
		this.toolTipPointer_img = data.toolTipPointer_img;

		this.hider = null;
		this.mainHolder_do = null;
		this.backgroundLeft_sdo = null;
		this.backgroundMiddle_sdo = null;
		this.backgroundRight_sdo = null;
		this.panButton_do = null;
		this.rotateButton_do = null;
		this.nextButton_do = null;
		this.prevButton_do = null;
		this.slideShowButton_do = null;
		this.infoButton_do = null;
		this.linkButton_do = null;
		this.fullScreenButton_do = null;
		this.zoomIn_do = null;
		this.zoomOut_do = null;
		this.scrollBar_do = null;
		this.scrollBarLeft_sdo = null;
		this.scrollBarRight_sdo = null;
		this.scrollBarMiddle_sdo = null;
		this.scrollBarHandler_do = null;
		this.scrollBarHandlerN_sdo = null;
		this.scrollBarHandlerS_sdo = null;
		this.panButtonTooTipLabel_do = null;
		this.scrollBarHandlerToolTip_do = null;
		this.rotateButtonToolTip_do = null;
		this.nextButtonToolTip_do = null;
		this.prevButtonToolTip_do = null;
		this.slideShowToolTip_do = null;
		this.infoToolTip_do = null;
		this.linkToolTip_do = null;
		this.fullscreenToolTip_do = null;
		
		this.backgroundMiddlePath_str = data.controllerBackgroundMiddlePath_str;
		this.scrollBarMiddlePath_str = data.scrollBarMiddlePath_str;
		this.draggingMode_str = data.startDraggingMode_str;
		this.controllerPosition_str  = data.controllerPosition_str; 
		this.buttonToolTipLeft_str = data.buttonToolTipLeft_str;
		this.buttonToolTipMiddle_str = data.buttonToolTipMiddle_str;
		this.buttonToolTipRight_str = data.buttonToolTipRight_str;
		this.link_str = data.link_str;;
		this.buttonToolTipFontColor_str = data.buttonToolTipFontColor_str;
		this.buttonToolTipBottomPointer_str = data.buttonToolTipBottomPointer_str;
		this.buttonToolTipTopPointer_str = data.buttonToolTipTopPointer_str;
		
		this.scrollBarPosition = FWDUtils.indexOfArray(self.buttonsTest_ar, "scrollbar");
		this.controllerBackgroundOpacity = data.controllerBackgroundOpacity;
		this.rotationSpeed = data.buttonsRotationSpeed;
		
		this.slideShowDelay = data.slideShowDelay;
		this.stageWidth;
		this.setHeight;
		this.controllerOffsetY = data.controllerOffsetY;
		this.scrollBarOffsetX = data.scrollBarOffsetX;
		this.scrollBarRightPartWidth = self.scrollBarRight_img.width;
		this.startSpaceBetweenButtons = data.startSpaceBetweenButtons;
		this.scrollBarHeight = self.scrollBarLeft_img.height;
		this.scrollBarHandlerWidth = self.scrollBarHandlerN_img.width;
		this.scrollBarHandlerHeight = self.scrollBarHandlerN_img.height;
		this.spaceBetweenButtons = data.spaceBetweenButtons;
		this.curHeight = self.backgroundLeft_img.height;
		this.zoomButtonWidth = self.zoomOutN_img.width;
		this.zoomButtonHeight = self.zoomOutN_img.height;
		this.finalHandlerX;
		this.startSpaceForScrollBarButtons = data.startSpaceForScrollBarButtons;
		this.smallSpaceForScrollBar = data.startSpaceForScrollBar;
		this.totalLargeButtons;
		this.curWidth;
		this.maxWidth = data.controllerMaxWidth;
		this.minWidth;
		this.buttonWidth = self.panN_img.width;
		this.buttonHeight = self.panN_img.height;
		this.scrollBarTotalWidth;
		this.scrollBarHandlerXPositionOnPress;
		this.lastPresedX;
		this.scrollBarHandlerToolTipOffsetY = data.scrollBarHandlerToolTipOffsetY;
		this.zoomInAndOutToolTipOffsetY = data.zoomInAndOutToolTipOffsetY;
		this.buttonsToolTipOffsetY = data.buttonsToolTipOffsetY;
		
		this.gotoImageId_int;
		this.zoomWithButtonsId_int;
		this.slideShowId_int;
		this.gotoImageId_to;
		this.zoomWithButtonsId_to;
		
		this.showScrollBar_bl = false;
		if(FWDUtils.indexOfArray(self.buttonsTest_ar, "scrollbar") != -1) self.showScrollBar_bl = true;
		
		this.isMobile_bl = data.isMobile_bl;
		this.inverseNextAndPrevRotation_bl = data.inverseNextAndPrevRotation_bl;
		this.isScrollBarActive_bl = false;
		this.isZoomInOrOutPressed_bl = false;
		this.isKeyPressed_bl = false;
		this.addKeyboardSupport_bl = data.addKeyboardSupport_bl;
		this.showButtonsLabels_bl = Boolean(self.buttonsLabels_ar);
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;

		//##########################################//
		/* initialize this */
		//##########################################//
		self.init = function(){
			self.setOverflow("visible");
			self.setSelectable(false);
			self.setupMainHolder();
			self.setupBackground();
			if(self.addKeyboardSupport_bl) self.addKeyboardSupport();
			self.setupButtons();
			self.totalLargeButtons = self.buttons_ar.lenght;
			if(self.showScrollBar_bl) self.setupScrollBar();
			if(self.buttonsTest_ar.length == 0 && !self.showScrollBar_bl) self.setVisible(false);
			self.hide();
			self.show();
			
			self.screen.onmousedown = function(){
				self.dispatchEvent(FWDController.MOUSE_DOWN);
			};
		};
		
		//###########################################//
		// Resize and position self...
		//###########################################//
		self.resizeAndPosition = function(){
			if(parent.stageWidth == self.stageWidth && parent.stageHeight == self.stageHeight) return;
					
			self.stageWidth = parent.stageWidth;
			self.stageHeight = parent.stageHeight;
			
			self.setWidth(self.stageWidth);
			self.setHeight(self.stageHeight);
			self.positionButtons();
		};
		
		//##########################################//
		//Setup main container.
		//##########################################//
		self.setupMainHolder = function(){
			self.mainHolder_do = new FWDDisplayObject("div");
			self.mainHolder_do.setOverflow("visible");
			self.addChild(self.mainHolder_do);
		};
		
		//##########################################//
		//Setup hider.
		//##########################################//
		self.setupHider = function(hider){
			self.hider = hider;
			self.hider.addListener(FWDHider.SHOW, self.onHiderShow);
			self.hider.addListener(FWDHider.HIDE, self.onHiderHide);
		};
		
		self.onHiderShow = function(){
			self.show();
		};
		
		self.onHiderHide = function(){
			if(FWDUtils.hitTest(self.mainHolder_do.screen, self.hider.globalX, self.hider.globalY)){
				self.hider.reset();
				return;
			}else{
				self.hide(true);
			}
		};
		
		//#####################################//
		/* add keyboard support */
		//####################################//
		this.addKeyboardSupport = function(){
			if(document.addEventListener){
				window.addEventListener("keydown",  self.onKeyDownHandler);	
				window.addEventListener("keyup",  self.onKeyUpHandler);
			}else if(document.attachEvent){
				document.attachEvent("onkeydown",  self.onKeyDownHandler);	
				document.attachEvent("onkeyup",  self.onKeyUpHandler);
			}
		};
		
		this.onKeyDownHandler = function(e){
			if(parent.hibernate_bl) return;
			if(self.isKeyPressed_bl) return;
			if(e.keyCode == 39){
				self.isKeyPressed_bl = true;
				if(self.slideShowButton_do) self.stopSlideShow();
				self.gotoNextImage();
				clearInterval(self.gotoImageId_int);
				clearTimeout(self.gotoImageId_to);
				self.gotoImageId_to = setTimeout(self.goToNextImageInWithDelay, 400);
				self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
				
				if(e.preventDefault){
					e.preventDefault();
				}else{
					return false;
				}
			}else if(e.keyCode == 37){
				self.isKeyPressed_bl = true;
				if(self.slideShowButton_do) self.stopSlideShow();
				self.gotoPrevImage();
				clearInterval(self.gotoImageId_int);
				clearTimeout(self.gotoImageId_to);
				self.gotoImageId_to = setTimeout(self.goToPrevImageInWithDelay, 400);
				self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
				
				if(e.preventDefault){
					e.preventDefault();
				}else{
					return false;
				}
			}
		};
		
		this.onKeyUpHandler = function(e){
			self.isKeyPressed_bl = false;
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			if(window.addEventListener){
				window.addEventListener("keydown",  self.onKeyDownHandler);	
			}else if(document.attachEvent){
				document.attachEvent("onkeydown",  self.onKeyDownHandler);	
			}
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		
		//##########################################//
		/* Setup buttons. */
		//##########################################//
		self.setupButtons = function(){
			var len = self.buttonsTest_ar.length;
			var res;
			var label1_str = "";
			var label2_str = "";
			for(var i=0; i<len; i++){
				res = self.buttonsTest_ar[i];		
				if(res == "pan"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupPanButton(label1_str);
					self.buttons_ar.push(self.panButton_do);
				}else if(res == "rotate"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupRotateButton(label1_str);
					self.buttons_ar.push(self.rotateButton_do);	
				}else if(res == "rotateright"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupNextButton(label1_str);
					self.buttons_ar.push(self.nextButton_do);
				}else if(res == "roteteleft"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupPrevButton(label1_str);
					self.buttons_ar.push(self.prevButton_do);
				}else if(res == "play"){
					if(self.showButtonsLabels_bl){
						var str =  self.buttonsLabels_ar[i];
						if(str){
							if(str.indexOf("/") == -1){
								label1_str = "tooltip is not defined!";
								label2_str = "tooltip is not defined!";
							}else{
								label1_str = str.substr(0, str.indexOf("/"));
								label2_str = str.substr(str.indexOf("/") + 1);
							}
						}else{
							label1_str = "tooltip is not defined!";
							label2_str = "tooltip is not defined!";
						}
					}
					self.setupSlideshowButton(label1_str, label2_str);
					self.buttons_ar.push(self.slideShowButton_do);
				}else if(res == "info"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupInfoButton(label1_str);
					self.buttons_ar.push(self.infoButton_do);
				}else if(res == "link"){
					if(self.showButtonsLabels_bl) label1_str = self.buttonsLabels_ar[i] || "tooltip is not defined!";
					self.setupLinkButton(label1_str);
					self.buttons_ar.push(self.linkButton_do);
				}else if(res == "fullscreen"){
					if(!(parent.displayType == FWDViewer.FULL_SCREEN && !FWDUtils.hasFullScreen)){
						if(self.showButtonsLabels_bl){
							var str =  self.buttonsLabels_ar[i];
							if(str){
								if(str.indexOf("/") == -1){
									label1_str = "tooltip is not defined!";
									label2_str = "tooltip is not defined!";
								}else{
									label1_str = str.substr(0, str.indexOf("/"));
									label2_str = str.substr(str.indexOf("/") + 1);
								}
							}else{
								label1_str = "tooltip is not defined!";
								label2_str = "tooltip is not defined!";
							}
						}
						self.setupFullScreenButton(label1_str, label2_str);
						self.buttons_ar.push(self.fullScreenButton_do);
					}
				}
			}
		};

		//##############################//
		/* setup background */
		//##############################//
		self.positionButtons = function(){
			
			var len = self.buttons_ar.length;
			var tempSpacerBetweenButtons = self.spaceBetweenButtons;
			var lastLeftButton_do;
			var totalButtonsWidth;
			var scrollBarLength;
			var startZoomX;
			var finalX;
			var finalY;
			var button;
			var indexToAddZoomButtons;
			
			if(self.showScrollBar_bl){
				self.isScrollBarActive_bl = true;
				self.curWidth = self.stageWidth;
				
				indexToAddZoomButtons = FWDUtils.indexOfArray(self.buttons_ar, self.zoomIn_do);
				if(indexToAddZoomButtons != -1){
					self.buttons_ar.splice(indexToAddZoomButtons, 1);
					len--;
				}
				
				indexToAddZoomButtons = FWDUtils.indexOfArray(self.buttons_ar, self.zoomOut_do);
				if(indexToAddZoomButtons != -1){
					self.buttons_ar.splice(indexToAddZoomButtons, 1);
					len--;
				}
				
				if(self.scrollBarPosition > len) self.scrollBarPosition = len;
				if(self.scrollBarPosition < 0) self.scrollBarPosition = 0;
				if(self.curWidth > self.maxWidth) self.curWidth = self.maxWidth;
				
				if(len == 0){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else if(len > 1 && self.scrollBarPosition != 0 && self.scrollBarPosition != len){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (len * self.buttonWidth) + (self.spaceBetweenButtons * (len - 2)) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else if(len > 1 && (self.scrollBarPosition == 0 || self.scrollBarPosition == len)){
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 3) + (len * self.buttonWidth) + (self.spaceBetweenButtons * (len - 1)) + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}else{
					self.scrollBarTotalWidth = (self.startSpaceBetweenButtons * 2) + (len * self.buttonWidth)  + (self.startSpaceForScrollBarButtons * 2) + (self.smallSpaceForScrollBar * 2) + (self.zoomButtonWidth * 2);
				}
				
				self.scrollBarTotalWidth = self.curWidth - self.scrollBarTotalWidth;
				if(self.scrollBarTotalWidth < 100) self.isScrollBarActive_bl = false;
			}
			
			if(self.isScrollBarActive_bl){
				
				self.scrollBar_do.setVisible(true);
				
				for(var i=0; i<self.scrollBarPosition; i++){
					button = self.buttons_ar[i];
					if(button){
						button = self.buttons_ar[i];
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						button.setX(finalX);
						button.setY(finalY);
					}
				}
				
				for(var i = len + 1; i>=self.scrollBarPosition; i--){
					button = self.buttons_ar[i];
					if(button){
						button = self.buttons_ar[i];
						finalX = self.curWidth  - self.startSpaceBetweenButtons - self.buttonWidth  - (Math.abs(i - len + 1) * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						button.setX(finalX);
						button.setY(finalY);
					}
				}
				
				if(len == 0){
					startZoomX = self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}else if(len > 1 && self.scrollBarPosition != 0 && self.scrollBarPosition != len){
					startZoomX = self.buttons_ar[self.scrollBarPosition - 1].getX() + self.buttonWidth + self.startSpaceForScrollBarButtons;
				}else if(len > 1 && self.scrollBarPosition == 0){
					startZoomX = self.startSpaceBetweenButtons + self.startSpaceForScrollBarButtons;
				}else if(len > 1 && self.scrollBarPosition == len){
					startZoomX = self.buttons_ar[self.scrollBarPosition - 1].getX() + self.buttonWidth + self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}else if(len == 1 && self.scrollBarPosition > 0){
					startZoomX = self.startSpaceBetweenButtons + self.buttonWidth + self.startSpaceForScrollBarButtons;
				}else if(len == 1 && self.scrollBarPosition == 0){
					startZoomX = self.startSpaceForScrollBarButtons + self.startSpaceBetweenButtons;
				}
				
				startZoomX += self.scrollBarOffsetX;
				
				self.zoomOut_do.setX(startZoomX );
				self.zoomOut_do.setY(parseInt((self.curHeight - self.zoomButtonHeight)/2));
				
				self.zoomIn_do.setX(self.zoomOut_do.getX() + self.zoomButtonWidth + (self.smallSpaceForScrollBar * 2) + self.scrollBarTotalWidth);
				self.zoomIn_do.setY(parseInt((self.curHeight - self.zoomButtonHeight)/2));
				
				self.scrollBar_do.setX(self.zoomOut_do.getX() + self.smallSpaceForScrollBar + self.zoomButtonWidth);
				
				self.scrollBar_do.setY(parseInt((self.curHeight - self.scrollBarHeight)/2) + 1);
				self.scrollBar_do.setWidth(self.scrollBarTotalWidth);
				
				self.scrollBarMiddle_do.setX(self.scrollBarRightPartWidth - 1);
				self.scrollBarMiddle_do.setWidth(self.scrollBarTotalWidth - (self.scrollBarRightPartWidth * 2) + 2);
				self.scrollBarRight_do.setX(self.scrollBarTotalWidth - self.scrollBarRightPartWidth);
			}else{
				if(self.showScrollBar_bl){
					self.scrollBar_do.setVisible(false);
					if(FWDUtils.indexOfArray(self.buttons_ar, self.zoomIn_do) == -1){
						indexToAddZoomButtons = self.scrollBarPosition;
						self.buttons_ar.splice(indexToAddZoomButtons, 0, self.zoomIn_do);
						self.buttons_ar.splice(indexToAddZoomButtons, 0, self.zoomOut_do);
					}
					len = self.buttons_ar.length;
					//self.scrollBar_do.setWidth(self.scrollBarTotalWidth);
				}
				
				self.minWidth = (len * self.buttonWidth) + (self.startSpaceBetweenButtons * 2) + (self.spaceBetweenButtons * len) - self.spaceBetweenButtons;
				
				if(self.minWidth > self.stageWidth){
					self.minWidth = self.stageWidth;
					if(self.minWidth < 320) self.minWidth = 320;
					totalButtonsWidth = self.buttonWidth * len;
					tempSpacerBetweenButtons = ((self.minWidth - (self.startSpaceBetweenButtons * 2)) - totalButtonsWidth)/(len - 1);
				}
				
				self.curWidth = self.minWidth;
				for(var i=0; i<len + 2; i++){
					button = self.buttons_ar[i];
					if(button){
						finalX = self.startSpaceBetweenButtons + (i * (tempSpacerBetweenButtons + self.buttonWidth));
						finalY = parseInt((self.curHeight - self.buttonHeight)/2);
						
						if(button == self.zoomIn_do){
							finalX = finalX + parseInt((self.buttonWidth - self.zoomButtonWidth)/2) - 2;
							finalY = parseInt((self.curHeight - self.zoomButtonHeight)/2);
						}else if(button ==  self.zoomOut_do){
							finalX = finalX + parseInt((self.buttonWidth - self.zoomButtonWidth)/2) + 2;
							finalY = parseInt((self.curHeight - self.zoomButtonHeight)/2);
						}
						
						button.setX(finalX);
						button.setY(finalY);
					}
				}
			}
		
			self.backgroundRight_sdo.setX(self.curWidth -  self.backgroundRight_sdo.getWidth());
			self.backgroundMiddle_sdo.setX(self.backgroundLeft_sdo.getWidth());
			self.backgroundMiddle_sdo.setWidth(self.curWidth - (self.backgroundLeft_sdo.getWidth() * 2));
			self.backgroundMiddle_sdo.setHeight(self.curHeight);
			
			self.mainHolder_do.setWidth(self.curWidth);
			self.mainHolder_do.setHeight(self.curHeight);
			self.setWidth(self.curWidth);
			self.setHeight(self.curHeight);
			
			if(self.controllerPosition_str == FWDController.POSITION_TOP){
				self.mainHolder_do.setX(Math.round((self.stageWidth - self.curWidth)/2));
				self.setY(self.controllerOffsetY);
			}else{
				self.mainHolder_do.setX(Math.round((self.stageWidth - self.curWidth)/2));
				self.setY(self.stageHeight - self.curHeight - self.controllerOffsetY);
			}
		};
		
		//##############################//
		/* setup background */
		//##############################//
		self.setupBackground = function(){
		
			self.backgroundLeft_sdo = new FWDSimpleDisplayObject("img");
			self.backgroundLeft_sdo.setScreen(self.backgroundLeft_img);
			if(self.controllerBackgroundOpacity != 1) self.backgroundLeft_sdo.setAlpha(self.controllerBackgroundOpacity);
			
			self.backgroundMiddle_sdo = new FWDSimpleDisplayObject("div");
			self.backgroundMiddle_sdo.getStyle().background = "url('" + self.backgroundMiddlePath_str + "')";
			self.backgroundMiddle_sdo.getStyle().backgroundRepeat = "repeat-x";
			if(self.controllerBackgroundOpacity != 1) self.backgroundMiddle_sdo.setAlpha(self.controllerBackgroundOpacity);
		
			self.backgroundRight_sdo = new FWDSimpleDisplayObject("img");
			self.backgroundRight_sdo.setScreen(self.backgroundRight_img);
			if(self.controllerBackgroundOpacity != 1) self.backgroundRight_sdo.setAlpha(self.controllerBackgroundOpacity);
			
			self.mainHolder_do.addChild(self.backgroundLeft_sdo);
			self.mainHolder_do.addChild(self.backgroundRight_sdo);
			self.mainHolder_do.addChild(self.backgroundMiddle_sdo);
		};
		
		//##############################//
		/* setup pan button */
		//##############################//
		self.setupPanButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.panButton_do = new FWDSimpleButton(self.panN_img, self.panS_img, self.isMobile_bl);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.panButtonOnMouseOverHandler);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.panButtonOnMouseOutHandler);
			self.panButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.panButtonOnMouseDownHandler);
			self.mainHolder_do.addChild(self.panButton_do);
			if(self.draggingMode_str == FWDController.PAN)  self.disablePanButton();
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.panButtonTooTipLabel_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str
						);
				self.mainHolder_do.addChild(self.panButtonTooTipLabel_do);
			}
			
		};
		
		self.panButtonOnMouseOverHandler = function(e){
			if(self.panButton_do.isSelectedFinal_bl) return;
			self.showToolTipButton(self.panButton_do, self.panButtonTooTipLabel_do, self.buttonsToolTipOffsetY);
		};
		
		self.panButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.panButtonTooTipLabel_do.hide();
		};
		
		self.panButtonOnMouseDownHandler = function(e){
			self.pan();
		};
		
		self.disablePanButton = function(){
			self.panButton_do.setSelctedFinal();
			if(self.rotateButton_do) self.rotateButton_do.setUnselctedFinal();
		};
		
		this.pan = function(){
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			if(self.panButton_do){
				if(self.showButtonsLabels_bl) self.panButtonTooTipLabel_do.hide();
				self.disablePanButton();
			}
			self.dispatchEvent(FWDController.CHANGE_NAVIGATION_STYLE, {draggingMode:FWDController.PAN});
		};
		
		//##############################//
		/* setup rotate button */
		//##############################//
		self.setupRotateButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.rotateButton_do = new FWDSimpleButton(self.rotateN_img, self.rotateS_img, self.isMobile_bl);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.rotateButtonOnMouseOverHandler);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.rotateButtonOnMouseOutHandler);
			self.rotateButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.rotateButtonOnMouseDownHandler);
			self.mainHolder_do.addChild(self.rotateButton_do);
			if(self.draggingMode_str == FWDController.ROTATE) self.disableRotateButton();
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.rotateButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.rotateButtonToolTip_do);
			}
			
		};			
		
		self.rotateButtonOnMouseOverHandler = function(e){
			if(self.rotateButton_do.isSelectedFinal_bl) return;
			self.showToolTipButton(self.rotateButton_do, self.rotateButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.rotateButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.rotateButtonToolTip_do.hide();
		};
		
		self.rotateButtonOnMouseDownHandler = function(e){
			self.rotate();
		};
		
		self.disableRotateButton = function(){	
			self.rotateButton_do.setSelctedFinal();
			if(self.panButton_do) self.panButton_do.setUnselctedFinal();
		};
		
		this.rotate = function(){
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			if(self.rotateButton_do){
				if(self.showButtonsLabels_bl) self.rotateButtonToolTip_do.hide();
				self.disableRotateButton();
			}
			self.dispatchEvent(FWDController.CHANGE_NAVIGATION_STYLE, {draggingMode:FWDController.ROTATE});
		}
		
		//##############################//
		/* setup next  button */
		//##############################//
		self.setupNextButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.nextButton_do = new FWDSimpleButton(self.nextN_img, self.nextS_img, self.isMobile_bl);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_OVER, self.nextButtonOnMouseOverHandler);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_OUT, self.nextButtonOnMouseOutHandler);
			self.nextButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.nextButtonStartHandler);
			self.mainHolder_do.addChild(self.nextButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.nextButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.nextButtonToolTip_do);
			}
		};
		
		self.nextButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.nextButton_do, self.nextButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.nextButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.nextButtonToolTip_do.hide();
		};
		
		self.nextButtonStartHandler = function(e){
			if(e){
				var e = e.e;
				if(e.touches){
					if(self.scrollBarHandler_do){
						self.zoomInWithButtonsEndHandler(e);
						self.zoomOutWithButtonsEndHandler(e);
						self.handlerDragEndHandler(e);
					}
				}
			}
			
			self.gotoNextImage();
			if(self.slideShowButton_do) self.stopSlideShow();
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.gotoImageId_to = setTimeout(self.goToNextImageInWithDelay, 400);
			
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.addEventListener("touchend", self.gotoImageEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
		};
		
		self.goToNextImageInWithDelay = function(){
			self.gotoImageId_int = setInterval(self.gotoNextImage, self.rotationSpeed);
		};
		
		self.gotoImageEndHandler = function(e){
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.removeEventListener("touchend", self.gotoImageEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		self.gotoNextImage = function(){
			var dir = 1;
			if(self.inverseNextAndPrevRotation_bl) dir = -1; 
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:dir});
		};
		
		//##############################//
		/* setup prev button */
		//##############################//
		self.setupPrevButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.prevButton_do = new FWDSimpleButton(self.prevN_img, self.prevS_img, self.isMobile_bl);
			self.prevButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.prevButtonOnMouseOverHandler);
			self.prevButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.prevShowButtonOnMouseOutHandler);
			self.prevButton_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.prevButtonStartHandler);
			self.mainHolder_do.addChild(self.prevButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.prevButtonToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.prevButtonToolTip_do);
			}
		};
		
		self.prevButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.prevButton_do, self.prevButtonToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.prevShowButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.prevButtonToolTip_do.hide();
		};
		
		self.prevButtonStartHandler = function(e){
			if(e){
				var e = e.e;
				if(e.touches){
					if(self.scrollBarHandler_do){
						self.zoomInWithButtonsEndHandler(e);
						self.zoomOutWithButtonsEndHandler(e);
						self.handlerDragEndHandler(e);
					}
				}
			}
			if(self.slideShowButton_do) self.stopSlideShow();
			self.gotoPrevImage();
			clearInterval(self.gotoImageId_int);
			clearTimeout(self.gotoImageId_to);
			self.gotoImageId_to = setTimeout(self.goToPrevImageInWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.gotoImageEndHandler);
				}else{
					window.addEventListener("touchend", self.gotoImageEndHandler);
				}
				window.addEventListener("mouseup", self.gotoImageEndHandler);
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.gotoImageEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.gotoImageEndHandler);
				}
			}
		};
		
		self.goToPrevImageInWithDelay = function(){
			self.gotoImageId_int = setInterval(self.gotoPrevImage, self.rotationSpeed);
		};
		
		self.gotoPrevImage = function(){
			var dir = -1;
			if(self.inverseNextAndPrevRotation_bl) dir = 1; 
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:dir});
		};
		
		//##############################//
		/* setup slideshow button */
		//##############################//
		self.setupSlideshowButton = function(toolTipLabel1, toolTipLabel2){
			FWDComplexButton.setPrototype();
			self.slideShowButton_do = new FWDComplexButton(self.playN_img, self.playS_img, self.pauseN_img, self.pauseS_img, true);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.slideSwhoButtonOnMouseOverHandler);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.slideShowButtonOnMouseOutHandler);
			self.slideShowButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.slideShowButtonStartHandler);
			self.mainHolder_do.addChild(self.slideShowButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.slideShowToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel1,
						toolTipLabel2,
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.slideShowToolTip_do);
			}
		};
		
		self.slideSwhoButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.slideShowButton_do, self.slideShowToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.slideShowButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.slideShowToolTip_do.hide();
		};
		
		self.slideShowButtonStartHandler = function(e){
			if(self.showButtonsLabels_bl) self.slideShowToolTip_do.hide();
			if(self.slideShowButton_do.currentState == 1){
				self.startSlideshow();
				self.slideShowButton_do.setButtonState(0);
				if(self.showButtonsLabels_bl) self.slideShowToolTip_do.setLabel(self.slideShowToolTip_do.toolTipLabel2_str);
			}else{
				self.stopSlideShow();
				self.slideShowButton_do.setButtonState(1);
				if(self.showButtonsLabels_bl) self.slideShowToolTip_do.setLabel(self.slideShowToolTip_do.toolTipLabel_str);
			}
		};
		
		self.startSlideshow = function(){
			if(self.slideShowButton_do) self.slideShowButton_do.setButtonState(0);
			clearInterval(self.slideShowId_int);
			self.slideShowId_int = setInterval(self.slideShowComplete, self.slideShowDelay);
			self.dispatchEvent(FWDController.START_SLIDE_SHOW);
		};
		
		self.stopSlideShow = function(){
			if(self.slideShowButton_do) self.slideShowButton_do.setButtonState(1);
			clearInterval(self.slideShowId_int);
			self.dispatchEvent(FWDController.STOP_SLIDE_SHOW);
		};
		
		self.slideShowComplete = function(){
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE, {dir:1});
			self.dispatchEvent(FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE);
		};
		
		//##############################//
		/* setup info button */
		//##############################//
		self.setupInfoButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.infoButton_do = new FWDSimpleButton(self.infoN_img, self.infoS_img, self.isMobile_bl);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.infoButtonOnMouseOverHandler);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.infoButtonOnMouseOutHandler);
			self.infoButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.infoButtonStartHandler);
			self.mainHolder_do.addChild(self.infoButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.infoToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.infoToolTip_do);
			}
		};
		
		self.infoButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.infoButton_do, self.infoToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.infoButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.infoToolTip_do.hide();
		};
		
		self.infoButtonStartHandler = function(e){
			self.dispatchEvent(FWDController.SHOW_INFO);
		};
		
		
		//##############################//
		/* setup link button */
		//##############################//
		self.setupLinkButton = function(toolTipLabel){
			FWDSimpleButton.setPrototype();
			self.linkButton_do = new FWDSimpleButton(self.linkN_img, self.linkS_img, self.isMobile_bl);
			self.linkButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.linkButtonOnMouseOverHandler);
			self.linkButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.linkButtonOnMouseOutHandler);
			self.linkButton_do.addListener(FWDComplexButton.CLICK, self.linkButtonOnMouseClickHandler);
			self.mainHolder_do.addChild(self.linkButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.linkToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel,
						"",
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.linkToolTip_do);
			}
		};
		
		self.linkButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.linkButton_do, self.linkToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.linkButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.linkToolTip_do.hide();
		};
		
		self.linkButtonOnMouseClickHandler = function(e){
			window.open(self.link_str, "_blank");
		};
		
		//##############################//
		/* setup link button */
		//##############################//
		self.setupFullScreenButton = function(toolTipLabel1, toolTipLabel2){
			FWDComplexButton.setPrototype();
			self.fullScreenButton_do = new FWDComplexButton(self.fullScreenFullN_img, self.fullScreenFullS_img, self.fullScreenNormalN_img, self.fullScreenNormalS_img, true);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_OVER, self.fullscreenButtonOnMouseOverHandler);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_OUT, self.fullscreenButtonOnMouseOutHandler);
			self.fullScreenButton_do.addListener(FWDComplexButton.MOUSE_DOWN, self.fullScreenButtonStartHandler);
			self.mainHolder_do.addChild(self.fullScreenButton_do);
			
			if(self.showButtonsLabels_bl){
				FWDButtonToolTip.setPrototype();
				self.fullscreenToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						toolTipLabel1,
						toolTipLabel2,
						self.buttonToolTipLeft_str, 
						self.buttonToolTipMiddle_str, 
						self.buttonToolTipRight_str, 
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				self.mainHolder_do.addChild(self.fullscreenToolTip_do);
			}
		};
		
		self.fullscreenButtonOnMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl) self.showToolTipButton(self.fullScreenButton_do, self.fullscreenToolTip_do, self.buttonsToolTipOffsetY);
		};
		
		self.fullscreenButtonOnMouseOutHandler = function(e){
			if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.hide();
		};
		
		self.fullScreenButtonStartHandler = function(e){
			if(self.fullScreenButton_do.currentState == 1){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.fullScreenButton_do.setButtonState(0);
				self.dispatchEvent(FWDController.GO_FULL_SCREEN);
			}else if(self.fullScreenButton_do.currentState == 0){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
				self.fullScreenButton_do.setButtonState(1);
				self.dispatchEvent(FWDController.GO_NORMAL_SCREEN);
			}
			setTimeout(function(){
				if(self == null) return;
				self.fullScreenButton_do.onMouseOut(e);
				}, 50);
		};
		
		self.setFullScreenButtonState = function(state){
			if(state == 0){
				self.fullScreenButton_do.setButtonState(0);
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
			}else if(state == 1){
				self.fullScreenButton_do.setButtonState(1);
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
			}
		};
		
		this.onFullScreenChange = function(e){
			if(parent.hibernate_bl) return;
			if(document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msieFullScreen){
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel2_str);
				self.fullScreenButton_do.setButtonState(0);
				self.dispatchEvent(FWDController.GO_FULL_SCREEN);
			}else{
				if(self.showButtonsLabels_bl) self.fullscreenToolTip_do.setLabel(self.fullscreenToolTip_do.toolTipLabel_str);
				self.fullScreenButton_do.setButtonState(1);	
				self.dispatchEvent(FWDController.GO_NORMAL_SCREEN);
			}
		};
		
		//##############################//
		/* setup scrollbar */
		//##############################//
		self.setupScrollBar = function(){
			var label_str1;
			
			FWDSimpleButton.setPrototype();
			self.zoomIn_do = new FWDSimpleButton(self.zoomInN_img, self.zoomInS_img);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_OVER, self.zoomInMouseOverHandler);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_OUT, self.zoomInOrOutMouseOutHandler);
			self.zoomIn_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.zoomInStartHandler);
			self.mainHolder_do.addChild(self.zoomIn_do);
			
			FWDSimpleButton.setPrototype();
			self.zoomOut_do = new FWDSimpleButton(self.zoomOutN_img, self.zoomOutS_img);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_OVER, self.zoomOutMouseOverHandler);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_OUT, self.zoomInOrOutMouseOutHandler);
			self.zoomOut_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.zoomOutStartHandler);
			self.mainHolder_do.addChild(self.zoomOut_do);
			
			self.scrollBar_do = new FWDDisplayObject("div");
			self.scrollBar_do.setOverflow("visible");
			self.scrollBar_do.setHeight(self.scrollBarHeight);
			self.mainHolder_do.addChild(self.scrollBar_do);
			
			self.scrollBarLeft_do = new FWDSimpleDisplayObject("img");
			self.scrollBarLeft_do.setScreen(data.scrollBarLeft_img);
			self.scrollBar_do.addChild(self.scrollBarLeft_do);
			
			self.scrollBarMiddle_do = new FWDSimpleDisplayObject("div");
			self.scrollBarMiddle_do.setHeight(self.scrollBarHeight);
			self.scrollBarMiddle_do.getStyle().background = "url('" + self.scrollBarMiddlePath_str + "')";
			self.scrollBarMiddle_do.getStyle().backgroundRepeat = "repeat-x";
			
			self.scrollBar_do.addChild(self.scrollBarMiddle_do);
			
			self.scrollBarRight_do = new FWDSimpleDisplayObject("img");
			self.scrollBarRight_do.setScreen(self.scrollBarRight_img);
			self.scrollBar_do.addChild(self.scrollBarRight_do);
			
			FWDSimpleButton.setPrototype();
			self.scrollBarHandler_do = new FWDSimpleButton(self.scrollBarHandlerN_img, self.scrollBarHandlerS_img, self.isMobile_bl);
			self.scrollBarHandler_do.setY(parseInt((self.scrollBarHeight - self.scrollBarHandlerHeight)/2) - 1);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_OVER, self.handlerOnMouseOver);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_OUT, self.handlerOnMouseOut);
			self.scrollBarHandler_do.addListener(FWDSimpleButton.MOUSE_DOWN, self.handlerDragStartHandler);
			self.scrollBar_do.addChild(self.scrollBarHandler_do);
			
			if(self.showButtonsLabels_bl){
				label_str1 = self.buttonsLabels_ar[self.scrollBarPosition] || "tooltip is not defined!";
				FWDButtonToolTip.setPrototype();
				self.scrollBarHandlerToolTip_do = new FWDButtonToolTip(
						self.toolTipLeft_img,
						self.toolTipPointer_img,
						label_str1,
						"",
						self.buttonToolTipLeft_str,
						self.buttonToolTipMiddle_str,
						self.buttonToolTipRight_str,
						self.buttonToolTipFontColor_str,
						self.controllerPosition_str, 
						self.buttonToolTipTopPointer_str,
						self.buttonToolTipBottomPointer_str);
				
				self.mainHolder_do.addChild(self.scrollBarHandlerToolTip_do);
			}
		};
		
			
		//##########################################//
		// zoom in / out handler...
		//##########################################//
		self.zoomInMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl){
				self.scrollBarHandlerToolTip_do.show();
				if(self.isScrollBarActive_bl){
					self.positionAndSetLabelScrollBarHandler();
				}else{
					if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
						setTimeout(function(){
							if(self == null) return;
							var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
							self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
							self.showZoomInOrOutToolTipButton(self.zoomIn_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
						}, 50);
					}
				}
			}
		};
		
		self.zoomInOrOutMouseOutHandler  = function(e){
			if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
		};
			
		self.zoomInStartHandler = function(e){
			if(e){
				e = e.e;
				if(e.touches){
					self.handlerDragEndHandler(e);
				}
			}
			
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.zoomWithButtonsId_to = setTimeout(self.startZoomInWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			self.zoomInWithButtonsDispatchEvent(true);
			if(self.slideShowButton_do) self.stopSlideShow();
			if(self.zoomIn_do) self.zoomIn_do.isSelectedFinal_bl = true;
			self.isZoomInOrOutPressed_bl = true;
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				}else{
					window.addEventListener("touchend", self.zoomInWithButtonsEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.zoomInWithButtonsEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
				}
			}
		};
		
		self.startZoomInWithDelay = function(){
			self.zoomWithButtonsId_int = setInterval(self.zoomInWithButtonsDispatchEvent, 16);
		};
	
		self.zoomInWithButtonsDispatchEvent = function(withPause){	
			if(withPause){
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:1, withPause:true});
			}else{
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:1, withPause:false});
			}
			if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
				setTimeout(function(){
					if(self == null) return;
					var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
					if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
					if(self.showZoomInOrOutToolTipButton) self.showZoomInOrOutToolTipButton(self.zoomIn_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
				}, 50);
			}
		};
		
		self.zoomInWithButtonsEndHandler = function(e){
			var viewportMouseCoordinates;
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.isZoomInOrOutPressed_bl = false;
			
			if(self.zoomIn_do){
				self.zoomIn_do.isSelectedFinal_bl = false;
				viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
				if(!FWDUtils.hitTest(self.zoomIn_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
					self.zoomIn_do.onMouseOut(e);
				}
			}
		
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				}else{
					window.removeEventListener("touchend", self.zoomInWithButtonsEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.zoomInWithButtonsEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
				}
			}
		};
		
		//////////////////////////////////////////////////////
		/////////////////////////////////////////////////////
		self.zoomOutMouseOverHandler = function(e){
			if(self.showButtonsLabels_bl){
				self.scrollBarHandlerToolTip_do.show();
				if(self.isScrollBarActive_bl){
					self.positionAndSetLabelScrollBarHandler();
				}else{
					if(!self.isScrollBarActive_bl && self.showButtonsLabels_bl){
						setTimeout(function(){
							if(self == null) return;
							var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
							self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
							self.showZoomInOrOutToolTipButton(self.zoomOut_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
						}, 50);
					}
				}
			}
		};
	
		self.zoomOutStartHandler = function(e){
			if(e){
				e = e.e;
				if(e.touches){
					self.handlerDragEndHandler(e);
				}
			}
			
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.zoomWithButtonsId_to = setTimeout(self.startZoomOutWithDelay, 400);
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			self.zoomOutWithButtonsDispatchEvent(true);
			if(self.slideShowButton_do) self.stopSlideShow();
			if(self.zoomOut_do) self.zoomOut_do.isSelectedFinal_bl = true;
			self.isZoomInOrOutPressed_bl = true;
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				}else{
					window.addEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				}
			}else{
				if(window.addEventListener){
					window.addEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
				}else if(document.attachEvent){
					document.attachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
				}
			}
		};
		
		self.startZoomOutWithDelay = function(){
			self.zoomWithButtonsId_int = setInterval(self.zoomOutWithButtonsDispatchEvent, 16);
		};
		
		self.zoomOutWithButtonsDispatchEvent = function(withPause){	
			if(!self.isScrollBarActive_bl  && self.showButtonsLabels_bl){
				setTimeout(function(){
					if(self == null) return;
					var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
					if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
					if(self.showZoomInOrOutToolTipButton) self.showZoomInOrOutToolTipButton(self.zoomOut_do, self.scrollBarHandlerToolTip_do, self.zoomInAndOutToolTipOffsetY);
				}, 50);
			};
			
			if(withPause){
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:-1, withPause:true});
			}else{
				self.dispatchEvent(FWDController.ZOOM_WITH_BUTTONS, {dir:-1, withPause:false});
			}
		};

		self.zoomOutWithButtonsEndHandler = function(e){
			var viewportMouseCoordinates;
			clearInterval(self.zoomWithButtonsId_int);
			clearTimeout(self.zoomWithButtonsId_to);
			self.isZoomInOrOutPressed_bl = false;
			
			if(self.zoomOut_do){
				self.zoomOut_do.isSelectedFinal_bl = false;
				viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
				if(!FWDUtils.hitTest(self.zoomOut_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
					self.zoomOut_do.onMouseOut(e);
				}
			}
			
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				}else{
					window.removeEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				}
			}else{
				
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
				}
			}
		};
		
		//##########################################//
		// Scrollbar handler...
		//##########################################//
		self.handlerOnMouseOver = function(e){
			if(self.showButtonsLabels_bl){
				self.positionAndSetLabelScrollBarHandler();
				self.scrollBarHandlerToolTip_do.show();
			}
		};
		
		self.handlerOnMouseOut = function(e){
			if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
		};
		
		self.handlerDragStartHandler = function(e){
			e = e.e;
			if(self.isMobile_bl){
				self.handlerDragEndHandler(e);
				if(self.prevButton_do || self.prevButton_do) self.gotoImageEndHandler(e);
			}
			if(self.slideShowButton_do) self.stopSlideShow();
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.lastPresedX = viewportMouseCoordinates.screenX;
			self.scrollBarHandlerXPositionOnPress = self.scrollBarHandler_do.getX();
			self.scrollBarHandler_do.isSelectedFinal_bl = true;
			self.dispatchEvent(FWDController.DISABLE_PAN_OR_MOVE);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.addEventListener("MSPointerMove", self.handlerDragMoveHandler);
					window.addEventListener("MSPointerUp", self.handlerDragEndHandler);
				}else{
					window.addEventListener("touchmove", self.handlerDragMoveHandler);
					window.addEventListener("touchend", self.handlerDragEndHandler);
				}
			}else{
				self.scrollBarHandler_do.isSelectedFinal_bl = true;
				if(window.addEventListener){
					window.addEventListener("mousemove", self.handlerDragMoveHandler);
					window.addEventListener("mouseup", self.handlerDragEndHandler);	
				}else if(document.attachEvent){
					document.attachEvent("onmousemove", self.handlerDragMoveHandler);
					document.attachEvent("onmouseup", self.handlerDragEndHandler);
				}
			}
		};
		
		self.handlerDragMoveHandler = function(e){
			if(e.preventDefault) e.preventDefault();
			
			var viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			self.finalHandlerX = Math.round(self.scrollBarHandlerXPositionOnPress + viewportMouseCoordinates.screenX - self.lastPresedX);
			
			if(self.finalHandlerX <= 0){
				self.finalHandlerX = 0;
			}else if(self.finalHandlerX >= self.scrollBarTotalWidth - self.scrollBarHandlerWidth){
				self.finalHandlerX = self.scrollBarTotalWidth - self.scrollBarHandlerWidth;
			}
			
			var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
			self.dispatchEvent(FWDController.SCROLL_BAR_UPDATE, {percent:percent});
			
			self.scrollBarHandler_do.setX(self.finalHandlerX);
			self.positionAndSetLabelScrollBarHandler();
		};
		
		self.handlerDragEndHandler = function(e){
			var viewportMouseCoordinates;
			self.dispatchEvent(FWDController.ENABLE_PAN_OR_MOVE);
			viewportMouseCoordinates = FWDUtils.getViewportMouseCoordinates(e);	
			if(!FWDUtils.hitTest(self.scrollBarHandler_do.screen, viewportMouseCoordinates.screenX, viewportMouseCoordinates.screenY)){
				self.scrollBarHandler_do.onMouseOut(e);
				if(self.showButtonsLabels_bl) self.scrollBarHandlerToolTip_do.hide();
				self.scrollBarHandler_do.setUnselctedFinal();
			}
			
			self.scrollBarHandler_do.isSelectedFinal_bl = false;
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					window.removeEventListener("MSPointerMove", self.handlerDragMoveHandler);
					window.removeEventListener("MSPointerUp", self.handlerDragEndHandler);
				}else{
					window.removeEventListener("touchmove", self.handlerDragMoveHandler);
					window.removeEventListener("touchend", self.handlerDragEndHandler);
				}
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mousemove", self.handlerDragMoveHandler);
					window.removeEventListener("mouseup", self.handlerDragEndHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmousemove", self.handlerDragMoveHandler);
					document.detachEvent("onmouseup", self.handlerDragEndHandler);
				}
			}
		};
		
		self.updateScrollBar = function(percent, animate){
			if(!self.scrollBarHandler_do) return;
			self.finalHandlerX = Math.round(percent * (self.scrollBarTotalWidth - self.scrollBarHandlerWidth));
			
			if(!self.isScrollBarActive_bl) return
			if(self.finalHandlerX <= 0){
				self.finalHandlerX = 0;
			}else if(self.finalHandlerX >= self.scrollBarTotalWidth - self.scrollBarHandlerWidth){
				self.finalHandlerX = self.scrollBarTotalWidth - self.scrollBarHandlerWidth;
			}
			
			if(animate){
				TweenMax.to(self.scrollBarHandler_do, .2, {x:self.finalHandlerX, 
					onUpdate:self.positionAndSetLabelScrollBarHandler,
					onComplete:self.positionAndSetLabelScrollBarHandler});
			}else{
				TweenMax.killTweensOf(self.scrollBarHandler_do);
				self.scrollBarHandler_do.setX(self.finalHandlerX);
			}
		};
		
		//###############################//
		//Position scrollbar handler.
		//###############################//
		self.positionAndSetLabelScrollBarHandler = function(){
			
			if(!self.showButtonsLabels_bl || !self.isScrollBarActive_bl) return;
			var finalX = 0;
			var finalY = 0;
			var percent = self.finalHandlerX/(self.scrollBarTotalWidth - self.scrollBarHandlerWidth);
			var globalX = self.getGlobalX();
		
			self.scrollBarHandlerToolTip_do.setLabel(self.scrollBarHandlerToolTip_do.toolTipLabel_str + (Math.round(percent * 100)) + "%");
			
			setTimeout(function(){
				if(self == null || !self.scrollBarHandlerToolTip_do.isShowed_bl) return
				finalX = parseInt(self.scrollBarHandler_do.getX() + self.scrollBar_do.getX() + (self.scrollBarHandlerWidth - self.scrollBarHandlerToolTip_do.totalWidth)/2);
				if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
					finalY = - self.scrollBarHandlerToolTip_do.totalHeight - self.scrollBarHandlerToolTipOffsetY;
				}else{
					finalY =  self.curHeight + self.scrollBarHandlerToolTipOffsetY;
				}
				if(globalX + finalX < 0) finalX = 0;
				self.scrollBarHandlerToolTip_do.setX(finalX);
				self.scrollBarHandlerToolTip_do.setY(finalY);
			}, 51);
		};
		
		//###############################//
		//Hide / show.
		//###############################//
		self.hide = function(animate){
			if(self.controllerPosition_str == FWDController.POSITION_BOTTOM){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:self.curHeight + self.controllerOffsetY, ease:Expo.easeInOut});
				}else{
					self.mainHolder_do.setY(self.curHeight + self.controllerOffsetY);
				}
			}else if(self.controllerPosition_str == FWDController.POSITION_TOP){
				if(animate){
					TweenMax.to(self.mainHolder_do, 1, {y:-self.curHeight - self.controllerOffsetY, ease:Expo.easeInOut});
				}else{
					self.mainHolder_do.setY(-self.curHeight - self.controllerOffsetY);
				}
				
			}
		};
		
		self.show = function(){
			TweenMax.to(self.mainHolder_do, 1, {y:0, ease:Expo.easeInOut});
		};
		
		//######################################################//
		/* show tool tip */
		//######################################################//
		self.showToolTipButton = function(button, toolTip, offsetY){
			if(self.showButtonsLabels_bl){
			
				var finalX;
				var finalY;
				var globalX = self.mainHolder_do.getX();
				var pointerOffsetX = 0;
				
				if(self.showButtonsLabels_bl) toolTip.show();
				
				setTimeout(function(){
					if(self == null || !toolTip.isShowed_bl) return
					finalX = parseInt(button.getX() + (self.buttonWidth - toolTip.totalWidth)/2);
					
					if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
						finalY = - toolTip.totalHeight - offsetY;
					}else{
						finalY =  self.curHeight + offsetY;
					}
					
					if(globalX + finalX < 0){
						pointerOffsetX = globalX + finalX;
						finalX = finalX + Math.abs((globalX + finalX));
					}else if(globalX + self.curWidth - finalX - toolTip.totalWidth < 0){
						pointerOffsetX = -(globalX + self.curWidth - finalX - toolTip.totalWidth);
						finalX = finalX + globalX + self.curWidth - finalX - toolTip.totalWidth;
					}
					
					toolTip.setX(finalX);
					toolTip.setY(finalY);	
					toolTip.positionPointer(pointerOffsetX);
				}, 51);
			}
		};
		
		self.showZoomInOrOutToolTipButton = function(button, toolTip, offsetY){
			if(self.showButtonsLabels_bl && toolTip){
				var finalX;
				var finalY;
				var globalX = self.mainHolder_do.getX();
				var pointerOffsetX = 0;
				
				setTimeout(function(){
					if(self == null || !toolTip.isShowed_bl) return
					finalX = parseInt(button.getX() + (self.zoomButtonHeight - toolTip.totalWidth)/2);
					if(self.controllerPosition_str ==  FWDController.POSITION_BOTTOM){
						finalY = - toolTip.totalHeight - offsetY;
					}else{
						finalY =  self.curHeight + offsetY;
					}
					
					if(globalX + finalX < 0){
						pointerOffsetX = globalX + finalX;
						finalX = finalX + Math.abs((globalX + finalX));
					}else if(globalX + self.curWidth - finalX - toolTip.totalWidth < 0){
						pointerOffsetX = -(globalX + self.curWidth - finalX - toolTip.totalWidth);
						finalX = finalX + globalX + self.curWidth - finalX - toolTip.totalWidth;
					}
					
					toolTip.setX(finalX);
					toolTip.setY(finalY);	
					toolTip.positionPointer(pointerOffsetX);
				}, 51);
			}
		};
		
		//###############################//
		//Clean main events.
		//###############################//
		self.cleanMainEvents = function(){
		
			clearInterval(self.gotoImageId_int);
			clearInterval(self.zoomWithButtonsId_int);
			clearInterval(self.slideShowId_int);
			clearTimeout(self.gotoImageId_to);
			clearTimeout(self.zoomWithButtonsId_to);	
			
			if(self.hider){
				self.hider.removeListener(FWDHider.SHOW, self.onHiderShow);
				self.hider.removeListener(FWDHider.HIDE, self.onHiderHide);
			}
			
			self.screen.onmousedown = null;
			
			if(self.isMobile_bl){
				window.removeEventListener("touchend", self.gotoImageEndHandler);
				window.removeEventListener("MSPointerUp", self.gotoImageEndHandler);
				window.removeEventListener("touchend", self.zoomInWithButtonsEndHandler);
				window.removeEventListener("MSPointerUp", self.zoomInWithButtonsEndHandler);
				window.removeEventListener("touchend", self.zoomOutWithButtonsEndHandler);
				window.removeEventListener("MSPointerUp", self.zoomOutWithButtonsEndHandler);
				window.removeEventListener("touchmove", self.handlerDragMoveHandler);
				window.removeEventListener("touchend", self.handlerDragEndHandler);
				window.removeEventListener("MSPointerMove", self.handlerDragMoveHandler);
				window.removeEventListener("MSPointerUp", self.handlerDragEndHandler);
			}else{
				if(window.removeEventListener){
					window.removeEventListener("mouseup", self.gotoImageEndHandler);
					window.removeEventListener("mouseup", self.zoomInWithButtonsEndHandler);
					window.removeEventListener("mouseup", self.zoomOutWithButtonsEndHandler);
					window.removeEventListener("mousemove", self.handlerDragMoveHandler);
					window.removeEventListener("mouseup", self.handlerDragEndHandler);
					window.removeEventListener("keydown",  self.onKeyDownHandler);	
					window.removeEventListener("keyup",  self.onKeyUpHandler);
				}else if(document.detachEvent){
					document.detachEvent("onmouseup", self.gotoImageEndHandler);
					document.detachEvent("onmouseup", self.zoomInWithButtonsEndHandler);
					document.detachEvent("onmouseup", self.zoomOutWithButtonsEndHandler);
					document.detachEvent("onmousemove", self.handlerDragMoveHandler);
					document.detachEvent("onmouseup", self.handlerDragEndHandler);
					document.detachEvent("onkeydown",  self.onKeyDownHandler);	
					document.detachEvent("onkeyup",  self.onKeyUpHandler);
				}
			}
		};
	
		//##############################//
		/* destroy */
		//##############################//
		this.destroy = function(){
			
			self.cleanMainEvents();
			
			TweenMax.killTweensOf(self.mainHolder_do);
			self.mainHolder_do.destroy();
			
			self.backgroundLeft_sdo.destroy();
			self.backgroundMiddle_sdo.destroy();
			self.backgroundRight_sdo.destroy();
			
			if(self.panButton_do) self.panButton_do.destroy();
			if(self.rotateButton_do) self.rotateButton_do.destroy();
			if(self.nextButton_do) self.nextButton_do.destroy();
			if(self.prevButton_do) self.prevButton_do.destroy();
			if(self.slideShowButton_do) self.slideShowButton_do.destroy();
			if(self.infoButton_do) self.infoButton_do.destroy();
			if(self.linkButton_do) self.linkButton_do.destroy();
			if(self.fullScreenButton_do) self.fullScreenButton_do.destroy();
			if(self.zoomIn_do) self.zoomIn_do.destroy();
			if(self.zoomOut_do) self.zoomOut_do.destroy();
			if(self.scrollBar_do) self.scrollBar_do.destroy();
			if(self.scrollBarLeft_sdo) self.scrollBarLeft_sdo.destroy();
			if(self.scrollBarRight_sdo) self.scrollBarRight_sdo.destroy();
			if(self.scrollBarMiddle_sdo) self.scrollBarMiddle_sdo.destroy();
			if(self.scrollBarHandler_do){
				TweenMax.killTweensOf(self.mainHolder_do);
				self.scrollBarHandler_do.destroy();
			}
			if(self.scrollBarHandlerN_sdo) self.scrollBarHandlerN_sdo.destroy();
			if(self.scrollBarHandlerS_sdo) self.scrollBarHandlerS_sdo.destroy();
			
			if(self.panButtonTooTipLabel_do) self.panButtonTooTipLabel_do.destroy();
			if(self.scrollBarHandlerToolTip_do) self.scrollBarHandlerToolTip_do.destroy();
			if(self.rotateButtonToolTip_do) self.rotateButtonToolTip_do.destroy();
			if(self.nextButtonToolTip_do) self.nextButtonToolTip_do.destroy();
			if(self.prevButtonToolTip_do) self.prevButtonToolTip_do.destroy();
			if(self.slideShowToolTip_do) self.slideShowToolTip_do.destroy();
			if(self.infoToolTip_do) self.infoToolTip_do.destroy();
			if(self.linkToolTip_do) self.linkToolTip_do.destroy();
			if(self.fullscreenToolTip_do) self.fullscreenToolTip_do.destroy();
		
			self.buttonsTest_ar = null;
			self.buttons_ar = null;
			
			self.hider = null;
			self.mainHolder_do = null;
			self.backgroundLeft_sdo = null;
			self.backgroundMiddle_sdo = null;
			self.backgroundRight_sdo = null;
			self.panButton_do = null;
			self.rotateButton_do = null;
			self.nextButton_do = null;
			self.prevButton_do = null;
			self.slideShowButton_do = null;
			self.infoButton_do = null;
			self.linkButton_do = null;
			self.fullScreenButton_do = null;
			self.zoomIn_do = null;
			self.zoomOut_do = null;
			self.scrollBar_do = null;
			self.scrollBarLeft_sdo = null;
			self.scrollBarRight_sdo = null;
			self.scrollBarMiddle_sdo = null;
			self.scrollBarHandler_do = null;
			self.scrollBarHandlerN_sdo = null;
			self.scrollBarHandlerS_sdo = null;
			self.panButtonTooTipLabel_do = null;
			self.scrollBarHandlerToolTip_do = null;
			self.rotateButtonToolTip_do = null;
			self.nextButtonToolTip_do = null;
			self.prevButtonToolTip_do = null;
			self.slideShowToolTip_do = null;
			self.infoToolTip_do = null;
			self.linkToolTip_do = null;
			self.fullscreenToolTip_do = null;
		
			self.backgroundLeft_img = null;
			self.backgroundRight_img = null;
			self.panN_img = null;
			self.panS_img = null;
			self.rotateN_img = null;
			self.rotateS_img = null;
			self.nextN_img = null;
			self.nextS_img = null;
			self.prevN_img = null;
			self.prevS_img = null;
			self.playN_img = null;
			self.playS_img = null;
			self.pauseN_img = null;
			self.pauseS_img = null;
			self.infoN_img = null;
			self.infoS_img = null;
			self.linkN_img = null;
			self.linkS_img = null;
			self.fullScreenNormalN_img = null;
			self.fullScreenNormalS_img = null;
			self.fullScreenFullN_img = null;
			self.fullScreenFullS_img = null;
			self.zoomInN_img = null;
			self.zoomInS_img = null;
			self.zoomOutN_img = null;
			self.zoomOutS_img = null;
			self.scrollBarHandlerN_img = null;
			self.scrollBarHandlerS_img = null;
			self.scrollBarLeft_img = null;
			self.scrollBarRight_img = null;
			self.toolTipLeft_img = null;
			self.toolTipPointer_img = null;

			self.backgroundMiddlePath_str = null;
			self.scrollBarMiddlePath_str = null;
			self.draggingMode_str = null;
			self.controllerPosition_str = null;
			self.buttonToolTipLeft_str = null;
			self.buttonToolTipMiddle_str =  null;
			self.buttonToolTipRight_str = null;
			self.link_str = null;
			
			data = null;
			parent = null;
		
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDController.prototype = null;
		};
	
		this.init();
	};
	
	/* set prototype */
	FWDController.setPrototype = function(){
		FWDController.prototype = new FWDDisplayObject("div");
	};
	
	FWDController.SHOW_INFO = "showInfo";
	FWDController.POSITION_TOP = "top";
	FWDController.POSITION_BOTTOM = "bottom";
	FWDController.CHANGE_NAVIGATION_STYLE = "changeNavigationStyle";
	FWDController.GOTO_NEXT_IMAGE = "gotoNextImage";
	FWDController.GOTO_PREV_IMAGE = "gotoPrevImage";
	FWDController.GOTO_NEXT_OR_PREV_IMAGE = "gotoNextOrPrevImage";
	FWDController.GOTO_NEXT_OR_PREV_IMAGE_COMPLETE = "gotoNextOrPrevImageComplete";
	FWDController.DISABLE_PAN_OR_MOVE = "disablePanOrMove";
	FWDController.ENABLE_PAN_OR_MOVE = "enablePanOrMove";
	FWDController.SCROLL_BAR_UPDATE = "scrollBarUpdate";
	FWDController.ZOOM_WITH_BUTTONS = "zoomWithButtons";
	FWDController.ZOOM_IN = "zoomIn";
	FWDController.ZOOM_OUT = "zoomOut";
	FWDController.PAN = "pan";
	FWDController.ROTATE = "rotate";
	FWDController.START_SLIDE_SHOW = "startSlideShow";
	FWDController.STOP_SLIDE_SHOW = "stopSlideShow";
	FWDController.GO_FULL_SCREEN = "goFullScreen";
	FWDController.GO_NORMAL_SCREEN = "goNormalScreen";
	FWDController.MOUSE_DOWN = "controllerOnMouseDown";
	
	FWDController.prototype = null;
	window.FWDController = FWDController;
	
}());