/* FWDSimpleButton */
(function (window){
var FWDSimpleButton = function(nImg, sImg){
		
		var self = this;
		var prototype = FWDSimpleButton.prototype;
		
		self.nImg = nImg;
		self.sImg = sImg;
		
		this.n_do;
		this.s_do;
		
		this.toolTipLabel_str;
		
		this.totalWidth = this.nImg.width;
		this.totalHeight = this.nImg.height;
	
		this.isDisabled_bl = false;
		this.isSelectedFinal_bl = false;
		this.isActive_bl = false;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
	
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setupMainContainers();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			self.n_do = new FWDSimpleDisplayObject("img");	
			self.n_do.setScreen(self.nImg);
			self.s_do = new FWDSimpleDisplayObject("img");
			self.s_do.setScreen(self.sImg);
			self.s_do.setAlpha(0);
			self.addChild(self.n_do);
			self.addChild(self.s_do);
			
			self.setWidth(self.nImg.width);
			self.setHeight(self.nImg.height);
			self.setButtonMode(true);
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.addEventListener("MSPointerDown", self.onMouseDown);
					self.screen.addEventListener("MSPointerUp", self.onClick);
					self.screen.addEventListener("MSPointerOver", self.onMouseOver);
					self.screen.addEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.addEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){	
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mousedown", self.onMouseDown);
				self.screen.addEventListener("click", self.onClick);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmousedown", self.onMouseDown);
				self.screen.attachEvent("onclick", self.onClick);
			}
		};
		
		self.onMouseOver = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDSimpleButton.MOUSE_OVER, {e:e});
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
			}
		};
			
		self.onMouseOut = function(e){
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE){
				self.dispatchEvent(FWDSimpleButton.MOUSE_OUT, {e:e});
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				TweenMax.killTweensOf(self.s_do);
				TweenMax.to(self.s_do, .5, {alpha:0, ease:Expo.easeOut});	
			}
		};
			
		self.onClick = function(e){
			if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
			self.dispatchEvent(FWDSimpleButton.CLICK, {e:e});
		};
		
		self.onMouseDown = function(e){
			if(e.preventDefault) e.preventDefault();
			if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
			self.dispatchEvent(FWDSimpleButton.MOUSE_DOWN, {e:e});
		};
		
		//##############################//
		// set select / deselect final.
		//##############################//
		self.setSelctedFinal = function(){
			self.isSelectedFinal_bl = true;
			TweenMax.killTweensOf(self.s_do);
			TweenMax.to(self.s_do, .8, {alpha:1, ease:Expo.easeOut});
			self.setButtonMode(false);
		};
		
		self.setUnselctedFinal = function(){
			self.isSelectedFinal_bl = false;
			TweenMax.to(self.s_do, .8, {alpha:0, delay:.1, ease:Expo.easeOut});
			self.setButtonMode(true);
		};
		
		//##############################//
		/* destroy */
		//##############################//
		self.destroy = function(){
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.removeEventListener("MSPointerDown", self.onMouseDown);
					self.screen.removeEventListener("MSPointerUp", self.onClick);
					self.screen.removeEventListener("MSPointerOver", self.onMouseOver);
					self.screen.removeEventListener("MSPointerOut", self.onMouseOut);
				}else{
					self.screen.removeEventListener("touchstart", self.onMouseDown);
				}
			}else if(self.screen.addEventListener){
				self.screen.removeEventListener("mouseover", self.onMouseOver);
				self.screen.removeEventListener("mouseout", self.onMouseOut);
				self.screen.removeEventListener("mousedown", self.onMouseDown);
				self.screen.removeEventListener("click", self.onClick);
			}else if(self.screen.detachEvent){
				self.screen.detachEvent("onmouseover", self.onMouseOver);
				self.screen.detachEvent("onmouseout", self.onMouseOut);
				self.screen.detachEvent("onmousedown", self.onMouseDown);
				self.screen.detachEvent("onclick", self.onClick);
			}
		
			TweenMax.killTweensOf(self.s_do);
			self.n_do.destroy();
			self.s_do.destroy();
			
			self.nImg = null;
			self.sImg = null;
			self.n_do = null;
			self.s_do = null;
			
			nImg = null;
			sImg = null;
			
			self.toolTipLabel_str = null;
			
			self.init = null;
			self.setupMainContainers = null;
			self.onMouseOver = null;
			self.onMouseOut = null;
			self.onClick = null;
			self.onMouseDown = null;  
			self.setSelctedFinal = null;
			self.setUnselctedFinal = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDSimpleButton.prototype = null;
		};
	
		self.init();
	};
	
	/* set prototype */
	FWDSimpleButton.setPrototype = function(){
		FWDSimpleButton.prototype = null;
		FWDSimpleButton.prototype = new FWDDisplayObject("div");
	};
	
	FWDSimpleButton.CLICK = "onClick";
	FWDSimpleButton.MOUSE_OVER = "onMouseOver";
	FWDSimpleButton.MOUSE_OUT = "onMouseOut";
	FWDSimpleButton.MOUSE_DOWN = "onMouseDown";
	
	FWDSimpleButton.prototype = null;
	window.FWDSimpleButton = FWDSimpleButton;
}(window));