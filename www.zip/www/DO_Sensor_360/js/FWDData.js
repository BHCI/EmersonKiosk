/* Data */
(function(window){
	
	var FWDData = function(props){
		
		var self = this;
		var prototype = FWDData.prototype;
		
		this.navigatorImage_img;
		this.mainPreloader_img = null;
		this.mainLightboxCloseButtonN_img = null;
		this.mainLightboxCloseButtonS_img = null;
		this.controllerBackgroundLeft_img = null;
		this.controllerBackgroundRight_img = null;
		this.controllerPanN_img = null;
		this.controllerPanS_img = null;
		this.controllerRotateN_img = null;
		this.controllerRotateS_img = null;
		this.controllerNextN_img = null;
		this.controllerNextS_img = null;
		this.controllerPrevN_img = null;
		this.controllerPrevS_img = null;
		this.controllerPlayN_img = null;
		this.controllerPlayS_img = null;
		this.controllerPauseN_img = null;
		this.controllerPauseS_img = null;
		this.controllerInfoN_img = null;
		this.controllerInfoS_img = null;
		this.controllerLinkN_img = null;
		this.controllerLinkS_img = null;
		this.controllerFullScreenNormalN_img = null;
		this.controllerFullScreenNormalS_img = null;
		this.controllerFullScreenFullN_img = null;
		this.controllerFullScreenFullS_img = null;
		this.zoomInN_img = null;
		this.zoomInS_img = null;
		this.zoomOutN_img = null;
		this.zoomOutS_img = null;
		this.scrollBarHandlerN_img = null;
		this.scrollBarHandlerS_img = null;
		this.scrollBarLeft_img = null;
		this.scrollBarRight_img = null;
		this.toolTipLeft_img = null;
		this.toolTipPointer_img = null;
		this.infoWindowCloseNormal_img = null;
		this.infoWindowCloseSelected_img = null;
		
		this.props_obj = props;
		this.rootElement_el = null;
		this.skinPaths_ar = [];
		this.playListData_ar = [];
		this.imagesPaths_ar = [];
		this.largeImagesPaths_ar = [];
		this.navigatorImagesPaths_ar =[];
		this.images_ar = [];
		this.navigatorImages_ar = [];
		this.markersList_ar = [];
		this.markersPosition_ar = [];
		this.buttons_ar = null;
		this.buttonsLabels_ar = null;
		this.contextMenuLabels_ar = null;
	
		this.backgroundColor_str = null;
		this.handMovePath_str = null;
		this.handGrabRotatePath_str = null;
		this.handGrabPath_str = null;
		this.handGrabRotatePath_str = null;
		this.controllerBackgroundMiddlePath_str = null;
		this.scrollBarMiddlePath_str = null;
		this.startDraggingMode_str = null;
		this.controllerPosition_str = null;
		this.preloaderFontColor_str = null;
		this.preloaderBackgroundColor_str = null;
		this.preloaderText_str = null;
		this.buttonToolTipLeft_str = null;
		this.buttonToolTipMiddle_str = null;
		this.buttonToolTipRight_str = null;
		this.buttonToolTipBottomPointer_str = null;
		this.buttonToolTipTopPointer_str = null;
		this.buttonToolTipFontColor_str = null;
		this.link_str = null;
		this.contextMenuBackgroundColor_str = null;
		this.contextMenuBorderColor_str = null;
		this.contextMenuSpacerColor_str = null;
		this.contextMenuItemNormalColor_str = null;
		this.contextMenuItemSelectedColor_str = null;
		this.contextMenuItemSelectedColor_str = null;
		this.contextMenuItemDisabledColor_str = null;
		this.navigatorPosition_str = null;
		this.navigatorHandlerColor_str = null;
		this.navigatorBorderColor_str = null;
		this.infoText_str = null;
		this.infoWindowBackgroundColor_str = null;
		this.infoWindowScrollBarColor_str = null;
		
		this.dragAndSpinSpeed;
		this.dragRotationSpeed;
		this.buttonsRotationSpeed;
		this.controllerHeight;
		this.startAtImage;
		this.imageWidth;
		this.imageHeight;
		this.spaceBetweenButtons;
		this.startSpaceBetweenButtons;
		this.scrollBarOffsetX;
		this.zoomFactor;
		this.controllerOffsetY;
		this.hideControllerDelay;
		this.controllerBackgroundOpacity;
		this.controllerMaxWidth;
		this.countLoadedSkinImages = 0;
		this.countLoadedImages = 0;
		this.scrollBarHandlerToolTipOffsetY;
		this.zoomInAndOutToolTipOffsetY;
		this.buttonsToolTipOffsetY;
		this.scrollBarPosition;
		this.startSpaceForScrollBarButtons;
		this.totalGraphics;
		this.slideShowDelay;
		this.totalImages;
		this.navigatorWidth;
		this.navigatorHeight;
		this.navigatorOffsetX;
		this.navigatorOffsetY;
		this.infoWindowBackgroundOpacity;
		this.markerToolTipOffsetY;
		this.toolTipWindowMaxWidth;
		this.lightBoxBackgroundOpacity;
		
		this.parseDelayId_to;
		this.loadImageId_to;
		
		this.showContextMenu_bl;
		this.showLargeImageVersionOnZoom_bl;
		this.showNavigator_bl;
		this.addCorrectionForWebKit_bl;
		this.inverseNextAndPrevRotation_bl;
		this.useEntireScreenFor3dObject_bl;
		this.hideController_bl;
		this.showScriptDeveloper_bl;
		this.showMarkers_bl;
		this.hasNavigatorError_bl = false;
		this.showMarkersInfo_bl = false;
		this.addKeyboardSupport_bl = false;
		this.addDragAndSpinSupport_bl = false;
		this.stopRotationAtEnds_bl = false;
		this.slideShowAutoPlay_bl = false;
		this.isMobile_bl = FWDUtils.isMobile;
		this.hasPointerEvent_bl = FWDUtils.hasPointerEvent;
		this.areAllImagesLoaded_bl = false;
	
		//###################################//
		/*init*/
		//###################################//
		self.init = function(){
			self.parseDelayId_to = setTimeout(self.parseProperties, 100);
		};
		
		//#############################################//
		// parse properties.
		//#############################################//
		self.parseProperties = function(){
			
			var skinElement_el;
			var markersElement_el;
			var playListElement_el;
			
			var childKids_ar;
			var playListChildren_ar;
			var markersChildren_ar;
			var errorMessage_str;
			var mediaKid;
			var test;
			var obj;
			var obj2;
			var child;
			var hasError_bl;
			var attributeMissing;
			var positionError;
			var hasElementWithAttribute;
			var hasMarker_bl;
			
			//check for the playlist id  property.
			if(!self.props_obj.playListAndSkinId){
				errorMessage_str = "<font color='#FFFFFF'>playListAndSkinId</font> property which represents the grid playlist id is not defined in FWDGrid constructor function!";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			};
			
			//set the root element of the grid list.
			self.rootElement_el = FWDUtils.getChildById(self.props_obj.playListAndSkinId);
			if(!self.rootElement_el){
				errorMessage_str = "Make sure that the a div with the id - <font color='#FFFFFF'>" + self.props_obj.playListAndSkinId + "</font> exists, self represents the data playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			self.rootElement_el.style.display = "none";
			skinElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-skin");
			markersElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-markers");
			playListElement_el = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-paylist");
			
			
			if(!skinElement_el){
				errorMessage_str = "Make sure that the an ul tag with the data type attribute - <font color='#FFFFFF'>data-skin</font> is defined, this tag is used for creating the playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			if(!playListElement_el){
				errorMessage_str = "Make sure that the an ul tag with the data type attribute - <font color='#FFFFFF'>data-paylist</font> is defined, this tag is used for creating the playlist.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			//markers.
			if(markersElement_el) self.showMarkers_bl = true; 
			
			if(self.showMarkers_bl){
				markersChildren_ar = FWDUtils.getChildren(markersElement_el);
				for(var i=0; i<markersChildren_ar.length; i++){
					obj = {};
					child = markersChildren_ar[i];
					hasError_bl = false;
					attributeMissing = "";
					
					//check for markers attributes.
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-type", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-type", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-id", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-id", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-normal-state-path", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-normal-state-path", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-selected-state-path", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-selected-state-path", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-width", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-width", i);
						return;
					}
					
					hasElementWithAttribute = FWDUtils.hasAttribute(child, "data-marker-height", i);
					if(!hasElementWithAttribute){
						self.showMarkerError("data-marker-height", i);
						return;
					}
					
					obj.type = FWDUtils.getAttributeValue(child, "data-marker-type");
					test = obj.type == "link" || obj.type == "tooltip" || obj.type == "infowindow";
					if(!test){
						self.showMarkerTypeError(obj.type, i);
						return;
					}
					
					obj.markerId = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-id"));
					obj.normalStatePath_str = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-normal-state-path"));
					obj.selectedStatePath_str = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-marker-selected-state-path"));
					obj.toolTipLabel = FWDUtils.getAttributeValue(child, "data-tool-tip-label") || undefined;
					obj.markerWidth = parseInt(FWDUtils.getAttributeValue(child, "data-marker-width"));
					if(isNaN(obj.markerWidth)) obj.markerWidth = 5;
					obj.markerHeight = parseInt(FWDUtils.getAttributeValue(child, "data-marker-height"));
					if(isNaN(obj.markerHeight)) obj.markerHeight = 5;
					
					if(obj.type == "link"){
						obj.link = FWDUtils.getAttributeValue(child, "data-marker-url") || "http://www.link-is-not-defined.com";
						obj.target = FWDUtils.getAttributeValue(child, "data-marker-target") || "_blank";
					}else{
						obj.innerHTML = child.innerHTML;
					}
					
					test = FWDUtils.getAttributeValue(child, "data-reg-point");
					test = test === "center" || test === "centertop" || test === "centerbottom";
					if(!test){
						test = "center";
					}else{
						test = FWDUtils.trim(FWDUtils.getAttributeValue(child, "data-reg-point")).toLowerCase();
					}
					obj.regPoint = test;
					obj.maxWidth = parseInt(FWDUtils.getAttributeValue(child, "data-marker-window-width"));
					if(isNaN(obj.maxWidth)) obj.maxWidth = 200;
					
					self.markersList_ar.push(obj);
				}
			}
			
			//parse playlist
			if(!FWDUtils.getChildAt(playListElement_el, 0)){
				errorMessage_str = "The playlist dose not have any chidren <ul> element.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				return;
			}
			
			self.showLargeImageVersionOnZoom_bl = self.props_obj.showLargeImageVersionOnZoom; 
			self.showLargeImageVersionOnZoom_bl = self.showLargeImageVersionOnZoom_bl == "yes" ? true : false;
			self.showNavigator_bl = self.props_obj.showNavigator;
			self.showNavigator_bl = self.showNavigator_bl == "yes" ? true : false;
			self.showMarkersInfo_bl =  self.props_obj.showMarkersInfo == "yes" ? true : false;
			self.addKeyboardSupport_bl = self.props_obj.addKeyboardSupport == "no" ? false : true;
			self.stopRotationAtEnds_bl = self.props_obj.stopRotationAtEnds == "yes" ? true : false;
			self.addDragAndSpinSupport_bl = self.props_obj.addDragAndSpinSupport == "yes" ? true : false;
			if(self.stopRotationAtEnds_bl) self.addDragAndSpinSupport_bl = false;
			self.slideShowAutoPlay_bl = self.props_obj.slideShowAutoPlay == "yes" ? true : false;
			if(self.isMobile_bl) self.showMarkersInfo_bl = false;
		
			var playListChildren_ar = FWDUtils.getChildren(playListElement_el);
			self.totalImages = playListChildren_ar.length;
			var markersIn_ar = undefined;
			for(var i=0; i<playListChildren_ar.length; i++){
				
				obj = {};
				child = playListChildren_ar[i];
				childKids_ar = FWDUtils.getChildren(child);
				
				hasError_bl;
				attributeMissing = "";
				positionError = i;
				
				//check for data-small-image-path attribute.
				hasElementWithAttribute = self.checkForAttribute(child, "data-small-image-path", i);
				if(!hasElementWithAttribute) return;
				
				if(self.showLargeImageVersionOnZoom_bl){
					hasElementWithAttribute = self.checkForAttribute(child, "data-large-image-path", i);
					if(!hasElementWithAttribute) return;
				}
				
				if(self.showNavigator_bl){
					hasElementWithAttribute = self.checkForAttribute(child, "data-navigator-image-path", i);
					if(!hasElementWithAttribute) return;
				}
				
				//check for data-info attribute.
				hasMarker_bl = false;
				markersIn_ar = undefined;
				obj2 = undefined;
				for(var j=0; j<childKids_ar.length; j++){
					
					if(FWDUtils.hasAttribute(childKids_ar[j], "data-small-image-path")){
						obj.smallImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-small-image-path"));
					}
					
					if(FWDUtils.hasAttribute(childKids_ar[j], "data-large-image-path")){
						obj.largeImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-large-image-path"));
					}
					
					if(self.showNavigator_bl){
						if(FWDUtils.hasAttribute(childKids_ar[j], "data-navigator-image-path")){
							obj.navigatorImagePath = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-navigator-image-path"));
						}
					}
					
					if(FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-id")){
						hasMarker_bl = true;
						if(!markersIn_ar) markersIn_ar = [];
						obj2 = {};
						obj2.markerId = FWDUtils.trim(FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-id"));
						obj2.x = FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-x") || 0;
						obj2.y = FWDUtils.getAttributeValue(childKids_ar[j], "data-marker-y") || 0;
						
						markersIn_ar.push(obj2);
					};
					
					if(j == childKids_ar.length - 1){
						if(hasMarker_bl){
							self.markersPosition_ar.push(markersIn_ar);
						}else{
							self.markersPosition_ar.push(undefined);
						}
						markersIn_ar = undefined;
						obj2 = undefined;
					}
				}
				
				self.playListData_ar[i] = obj;
			};
			
			//set main properties.
			test = self.props_obj.startAtImage || 0;
			if(isNaN(test)) test = 0;
			test = test - 1;
			if(test < 0){
				test = 0;
			}else if(test > self.totalImages - 1){
				test = self.totalImages - 1;
			}
			
			
			self.startAtImage = test;
			
			self.backgroundColor_str = self.props_obj.backgroundColor || "transparent";
			self.preloaderFontColor_str = self.props_obj.preloaderFontColor || "#000000";
			self.preloaderBackgroundColor_str =	self.props_obj.preloaderBackgroundColor || "transparent";
			self.preloaderText_str = self.props_obj.preloaderText || "Loading:"; 
			
			self.startDraggingMode_str = self.props_obj.startDraggingMode || "rotate";
			if(self.startDraggingMode_str != "rotate" && self.startDraggingMode_str != "pan") self.startDraggingMode_str = "rotate";
			
			self.controllerPosition_str = self.props_obj.controllerPosition || "bottom";
			if(self.controllerPosition_str != "top" && self.controllerPosition_str != "bottom") self.startDraggingMode_str = "top";
		
			if(!self.props_obj.buttons){
				errorMessage_str = "The <font color='#FFFFFF'>buttons</font> is not defined in the contructor, this is necessary to setup the main buttons.";
				self.dispatchEvent(FWDData.LOAD_ERROR, {text:errorMessage_str});
				console.log(errorMessage_str);
				return;
			} 
			
			self.buttons_ar = FWDUtils.splitAndTrim(self.props_obj.buttons,  true);
			
			if(self.isMobile_bl && !self.hasPointerEvent_bl){
				self.buttonsLabels_ar = null;
				self.contextMenuLabels_ar = null;
			}else{
				if(self.props_obj.buttonsToolTips) self.buttonsLabels_ar =  FWDUtils.splitAndTrim(self.props_obj.buttonsToolTips, false);
				if(self.props_obj.contextMenuLabels) self.contextMenuLabels_ar =  FWDUtils.splitAndTrim(self.props_obj.contextMenuLabels, false);
			}
			
			self.showScriptDeveloper_bl = self.props_obj.showScriptDeveloper;
			self.showScriptDeveloper_bl = self.showScriptDeveloper_bl == "no" ? false : true;
			
			self.dragRotationSpeed = self.props_obj.dragRotationSpeed || .5;
			if(isNaN(self.dragRotationSpeed)) self.dragRotationSpeed = .5;
			if(self.dragRotationSpeed < 0){
				self.dragRotationSpeed = 0;
			}else if(self.dragRotationSpeed > 1){
				self.dragRotationSpeed = 1;
			}
			
			self.dragAndSpinSpeed = self.props_obj.dragAndSpinSpeed || .4;
			if(isNaN(self.dragAndSpinSpeed)) self.dragAndSpinSpeed = .4;
			if(self.dragRotationSpeed < .1){
				self.dragRotationSpeed = .1;
			}else if(self.dragRotationSpeed > 1){
				self.dragRotationSpeed = 1;
			}
			
			self.buttonsRotationSpeed = self.props_obj.buttonsRotationSpeed || 500;
			if(isNaN(self.buttonsRotationSpeed)) self.buttonsRotationSpeed = 500;
			if(self.buttonsRotationSpeed < 200){
				self.buttonsRotationSpeed = 200;
			}else if(self.buttonsRotationSpeed > 2000){
				self.buttonsRotationSpeed = 2000;
			}
			
			self.imageWidth = self.props_obj.imageWidth;
			if(!self.imageWidth){
				self.showPropertyError("imageWidth");
				return
			}
			
			self.imageHeight = self.props_obj.imageHeight;
			if(!self.imageHeight){
				self.showPropertyError("imageHeight");
				return;
			}
			
			self.zoomFactor = self.props_obj.zoomFactor;
			if(!self.zoomFactor){
				self.showPropertyError("zoomFactor");
				return;
			}
			if(self.zoomFactor < 1){
				 self.zoomFactor = 1;
			}else if(self.zoomFactor > 4){
				 self.zoomFactor = 4;
			}
		
			self.navigatorOffsetX =  self.props_obj.navigatorOffsetX || 0;
			if(isNaN(self.navigatorOffsetX)) self.navigatorOffsetX = 0;
			self.navigatorOffsetY =  self.props_obj.navigatorOffsetY || 0;
			if(isNaN(self.navigatorOffsetY)) self.navigatorOffsetY = 0;
			
			self.controllerBackgroundOpacity = self.props_obj.controllerBackgroundOpacity;
			if(!self.controllerBackgroundOpacity)  self.controllerBackgroundOpacity = 1;
			if(isNaN(self.controllerBackgroundOpacity)) self.controllerBackgroundOpacity = 1;
			if(self.controllerBackgroundOpacity < 0){
				self.controllerBackgroundOpacity = 0;
			}else if(self.controllerBackgroundOpacity > 1){
				self.controllerBackgroundOpacity = 1;
			}
			
			self.controllerMaxWidth = self.props_obj.controllerMaxWidth;
			if(!self.controllerMaxWidth)  self.controllerMaxWidth = 900;
			if(isNaN(self.controllerMaxWidth)) self.controllerMaxWidth = 900;
			if(self.controllerMaxWidth < 200) self.controllerMaxWidth = 200;
		
			self.hideControllerDelay = self.props_obj.hideControllerDelay;
			if(self.hideControllerDelay){
				self.hideController_bl = true;
				if(isNaN(self.hideControllerDelay)){
					self.hideControllerDelay = 4000;
				}else if(self.hideControllerDelay < 0){
					self.hideControllerDelay = 4000;
				}else{
					self.hideControllerDelay *= 1000;
				}
			}
		
			self.spaceBetweenButtons = self.props_obj.spaceBetweenButtons || 0;
			self.scrollBarPosition = self.props_obj.scrollBarPosition || 0;
			self.startSpaceForScrollBarButtons = self.props_obj.startSpaceForScrollBarButtons || 0;
			self.startSpaceBetweenButtons = self.props_obj.startSpaceBetweenButtons || 0;
			self.startSpaceForScrollBar = self.props_obj.startSpaceForScrollBar || 0;
			self.scrollBarOffsetX = self.props_obj.scrollBarOffsetX || 0;
			self.controllerOffsetY = self.props_obj.controllerOffsetY || 0; 
			self.scrollBarHandlerToolTipOffsetY = self.props_obj.scrollBarHandlerToolTipOffsetY || 0;
			self.zoomInAndOutToolTipOffsetY = self.props_obj.zoomInAndOutToolTipOffsetY || 0;
			self.buttonsToolTipOffsetY = self.props_obj.buttonsToolTipOffsetY || 0;
			self.infoWindowBackgroundOpacity = self.props_obj.infoWindowBackgroundOpacity || 1;
			self.markerToolTipOffsetY = self.props_obj.markerToolTipOffsetY || 1;
			self.toolTipWindowMaxWidth = self.props_obj.toolTipWindowMaxWidth || 300;
			self.buttonToolTipFontColor_str = self.props_obj.buttonToolTipFontColor || "#000000";
			self.link_str = self.props_obj.link || "http://www.link-is-not-defined.com!";
			self.contextMenuBackgroundColor_str = self.props_obj.contextMenuBackgroundColor || "#000000";
			self.contextMenuBorderColor_str = self.props_obj.contextMenuBorderColor || "#FF0000";
			self.contextMenuSpacerColor_str = self.props_obj.contextMenuSpacerColor || "#FF0000";
			self.contextMenuItemNormalColor_str = self.props_obj.contextMenuItemNormalColor || "#FF0000";
			self.contextMenuItemSelectedColor_str = self.props_obj.contextMenuItemSelectedColor || "#FF0000";
			self.contextMenuItemDisabledColor_str = self.props_obj.contextMenuItemDisabledColor || "#FF0000";
			
			self.infoWindowBackgroundColor_str = self.props_obj.infoWindowBackgroundColor || "#FF0000";
			self.infoWindowScrollBarColor_str = self.props_obj.infoWindowScrollBarColor || "#FF0000";
			
			self.navigatorPosition_str = self.props_obj.navigatorPosition || "topleft";
			self.navigatorPosition_str = String(self.navigatorPosition_str).toLowerCase();
			test = self.navigatorPosition_str == "topleft" 
					   || self.navigatorPosition_str == "topright"
					   || self.navigatorPosition_str == "bottomleft"
					   || self.navigatorPosition_str == "bottomright";
						   
			if(!test) self.navigatorPosition_str = "topleft";
			
			self.navigatorHandlerColor_str = self.props_obj.navigatorHandlerColor || "#FF0000";
			self.navigatorBorderColor_str = self.props_obj.navigatorBorderColor || "#FF0000";
			
			self.slideShowDelay =  self.props_obj.slideShowDelay || 100;
			if(self.slideShowDelay < 100) self.slideShowDelay = 100;
		
			self.showContextMenu_bl = self.props_obj.showContextMenu; 
			self.showContextMenu_bl = self.showContextMenu_bl == "no" ? false : true;
			
			self.inverseNextAndPrevRotation_bl = self.props_obj.inverseNextAndPrevRotation;
			self.inverseNextAndPrevRotation_bl = self.inverseNextAndPrevRotation_bl == "yes" ? true : false;
			
			self.addCorrectionForWebKit_bl = self.props_obj.addCorrectionForWebKit; 
			self.addCorrectionForWebKit_bl = self.addCorrectionForWebKit_bl == "yes" ? true : false;
			if(!FWDUtils.isChrome || self.hasTouch_bl) self.addCorrectionForWebKit_bl = false;
			
			self.useEntireScreenFor3dObject_bl = self.props_obj.useEntireScreenFor3dObject; 
			self.useEntireScreenFor3dObject_bl = self.useEntireScreenFor3dObject_bl == "yes" ? true : false;
			
			self.infoText_str = FWDUtils.getChildFromNodeListFromAttribute(self.rootElement_el, "data-info");
			if(self.infoText_str){
				self.infoText_str = self.infoText_str.innerHTML;
			}else{
				self.infoText_str = "not defined make sure that an ul element with the attribute data-info is defined!";
			}
			
			//setup skin paths
			self.handMovePath_str = self.checkForAttribute(skinElement_el, "data-hand-move-path");
			if(!self.handMovePath_str) return;
			
			self.handGrabRotatePath_str = self.checkForAttribute(skinElement_el, "data-hand-rotate-path");
			if(!self.handGrabRotatePath_str) return;
			
			self.handGrabPath_str = self.checkForAttribute(skinElement_el, "data-hand-grab-path");
			if(!self.handGrabPath_str) return;
			
			var preloaderPath_str = self.checkForAttribute(skinElement_el, "data-preloader-path");
			if(!preloaderPath_str) return;
				
			var mainLightBoxCloseButtonNPath_str = self.checkForAttribute(skinElement_el, "data-main-lightbox-close-button-normal-path");
			if(!mainLightBoxCloseButtonNPath_str) return;
			
			var mainLightBoxCloseButtonSPath_str = self.checkForAttribute(skinElement_el, "data-main-lightbox-close-button-selected-path");
			if(!mainLightBoxCloseButtonNPath_str) return;
			
			var controllerBackgroundLeftPath_str = self.checkForAttribute(skinElement_el, "data-controller-background-left-path");
			if(!controllerBackgroundLeftPath_str) return;
			
			var controllerBackgroundRight_str = self.checkForAttribute(skinElement_el, "data-controller-background-right-path");
			if(!controllerBackgroundRight_str) return;
			
			var controllerPanN_str = self.checkForAttribute(skinElement_el, "data-controller-pan-button-normal-state-path");
			if(!controllerPanN_str) return;
			
			var controllerPanS_str = self.checkForAttribute(skinElement_el, "data-controller-pan-button-selected-state-path");
			if(!controllerPanS_str) return;
			
			var controllerRotateN_str = self.checkForAttribute(skinElement_el, "data-controller-rotate-button-normal-state-path");
			if(!controllerRotateN_str) return;
			
			var controllerRotateS_str = self.checkForAttribute(skinElement_el, "data-controller-rotate-button-selected-state-path");
			if(!controllerRotateS_str) return;
			
			var controllerNextN_str = self.checkForAttribute(skinElement_el, "data-controller-next-button-normal-state-path");
			if(!controllerNextN_str) return;
			
			var controllerNextS_str = self.checkForAttribute(skinElement_el, "data-controller-next-button-selected-state-path");
			if(!controllerNextS_str) return;
			
			var controllerPrevN_str = self.checkForAttribute(skinElement_el, "data-controller-prev-button-normal-state-path");
			if(!controllerPrevN_str) return;
			
			var controllerPrevS_str = self.checkForAttribute(skinElement_el, "data-controller-prev-button-selected-state-path");
			if(!controllerPrevS_str) return;
			
			var controllerPlayN_str = self.checkForAttribute(skinElement_el, "data-controller-play-button-normal-state-path");
			if(!controllerPlayN_str) return;
			
			var controllerPlayS_str = self.checkForAttribute(skinElement_el, "data-controller-play-button-selected-state-path");
			if(!controllerPlayS_str) return;
			
			var controllerPauseN_str = self.checkForAttribute(skinElement_el, "data-controller-pause-button-normal-state-path");
			if(!controllerPauseN_str) return;
			
			var controllerPauseS_str = self.checkForAttribute(skinElement_el, "data-controller-pause-button-selected-state-path");
			if(!controllerPauseS_str) return;
			
			var controllerInfoN_str = self.checkForAttribute(skinElement_el, "data-controller-info-button-normal-state-path");
			if(!controllerInfoN_str) return;
			
			var controllerInfoS_str = self.checkForAttribute(skinElement_el, "data-controller-info-button-selected-state-path");
			if(!controllerInfoS_str) return;
			
			var controllerLinkN_str = self.checkForAttribute(skinElement_el, "data-controller-link-button-normal-state-path");
			if(!controllerLinkN_str) return;
			
			var controllerLinkS_str = self.checkForAttribute(skinElement_el, "data-controller-link-button-selected-state-path");
			if(!controllerLinkS_str) return;
			
			var controllerFullScreemNormalN_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-normal-button-normal-state-path");
			if(!controllerFullScreemNormalN_str) return;
			
			var controllerFullScreenNormalS_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-normal-button-selected-state-path");
			if(!controllerFullScreenNormalS_str) return;
			
			var controllerFullScreemFullN_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-full-button-normal-state-path");
			if(!controllerFullScreemFullN_str) return;
			
			var controllerFullScreenFullS_str = self.checkForAttribute(skinElement_el, "data-controller-fullscreen-full-button-selected-state-path");
			if(!controllerFullScreenFullS_str) return;
			
			var zoomInN_str = self.checkForAttribute(skinElement_el, "data-controller-zoomin-button-normal-state-path");
			if(!zoomInN_str) return;
			
			var zoomInS_str = self.checkForAttribute(skinElement_el, "data-controller-zoomin-button-slected-state-path");
			if(!zoomInS_str) return;
			
			var zoomOutN_str = self.checkForAttribute(skinElement_el, "data-controller-zoomout-button-normal-state-path");
			if(!zoomOutN_str) return;
			
			var zoomOutS_str = self.checkForAttribute(skinElement_el, "data-controller-zoomout-button-slected-state-path");
			if(!zoomOutS_str) return;
			
			var scrollBarHandlerN_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-handler-normal-state-path");
			if(!scrollBarHandlerN_str) return;
			
			var scrollBarHandlerS_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-handler-selected-state-path");
			if(!scrollBarHandlerS_str) return;
			
			var scrollBarLeft_str = self.checkForAttribute(skinElement_el, "data-controller-scrollba-background-left-path");
			if(!scrollBarLeft_str) return;
			
			var scrollBarRight_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-background-right-path");
			if(!scrollBarRight_str) return;
		
			self.scrollBarMiddlePath_str = self.checkForAttribute(skinElement_el, "data-controller-scrollbar-background-middle-path");
			if(!self.scrollBarMiddlePath_str) return;
			
			self.controllerBackgroundMiddlePath_str = self.checkForAttribute(skinElement_el, "data-controller-background-center-path");
			if(!self.controllerBackgroundMiddlePath_str) return;
			
			self.buttonToolTipLeft_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-left-path");
			if(!self.buttonToolTipLeft_str) return;
			
			self.buttonToolTipMiddle_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-middle-path");
			if(!self.buttonToolTipMiddle_str) return;
			
			self.buttonToolTipRight_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-right-path");
			if(!self.buttonToolTipRight_str) return;
			
			self.buttonToolTipBottomPointer_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-bottom-pointer-path");
			if(!self.buttonToolTipBottomPointer_str) return;
			
			self.buttonToolTipTopPointer_str = self.checkForAttribute(skinElement_el, "data-button-tooltip-top-pointer-path");
			if(!self.buttonToolTipTopPointer_str) return;
			
			var infoWindowCloseNormal_str = self.checkForAttribute(skinElement_el, "data-info-window-close-button-normal-state-path");
			if(!infoWindowCloseNormal_str) return;
			
			var infoWindowCloseSelected_str = self.checkForAttribute(skinElement_el, "data-info-window-close-button-selected-state-path");
			if(!infoWindowCloseSelected_str) return;
			
			
			//set skin graphics paths.
			self.skinPaths_ar.push(preloaderPath_str);
			self.skinPaths_ar.push(mainLightBoxCloseButtonNPath_str);
			self.skinPaths_ar.push(mainLightBoxCloseButtonSPath_str);
			self.skinPaths_ar.push(controllerBackgroundLeftPath_str);
			self.skinPaths_ar.push(controllerBackgroundRight_str);
			self.skinPaths_ar.push(controllerPanN_str);
			self.skinPaths_ar.push(controllerPanS_str);
			self.skinPaths_ar.push(controllerRotateN_str);
			self.skinPaths_ar.push(controllerRotateS_str);
			self.skinPaths_ar.push(controllerNextN_str);
			self.skinPaths_ar.push(controllerNextS_str);
			self.skinPaths_ar.push(controllerPrevN_str);
			self.skinPaths_ar.push(controllerPrevS_str);
			self.skinPaths_ar.push(controllerPlayN_str);
			self.skinPaths_ar.push(controllerPlayS_str);
			self.skinPaths_ar.push(controllerPauseN_str);
			self.skinPaths_ar.push(controllerPauseS_str);
			self.skinPaths_ar.push(controllerInfoN_str);
			self.skinPaths_ar.push(controllerInfoS_str);
			self.skinPaths_ar.push(controllerLinkN_str);
			self.skinPaths_ar.push(controllerLinkS_str);
			self.skinPaths_ar.push(controllerFullScreemNormalN_str);
			self.skinPaths_ar.push(controllerFullScreenNormalS_str);
			self.skinPaths_ar.push(controllerFullScreemFullN_str);
			self.skinPaths_ar.push(controllerFullScreenFullS_str);	
			self.skinPaths_ar.push(zoomInN_str);
			self.skinPaths_ar.push(zoomInS_str);
			self.skinPaths_ar.push(zoomOutN_str);
			self.skinPaths_ar.push(zoomOutS_str);
			self.skinPaths_ar.push(scrollBarHandlerN_str);
			self.skinPaths_ar.push(scrollBarHandlerS_str);
			self.skinPaths_ar.push(scrollBarLeft_str);
			self.skinPaths_ar.push(scrollBarRight_str);
			self.skinPaths_ar.push(self.buttonToolTipTopPointer_str);
			self.skinPaths_ar.push(self.buttonToolTipLeft_str);
			self.skinPaths_ar.push(infoWindowCloseNormal_str);
			self.skinPaths_ar.push(infoWindowCloseSelected_str);
			
			
			self.skinPaths_ar.push(self.buttonToolTipMiddle_str);
			self.skinPaths_ar.push(self.buttonToolTipRight_str);
			self.skinPaths_ar.push(self.controllerBackgroundMiddlePath_str);
			
			self.totalGraphics = self.skinPaths_ar.length;
			
			self.loadSkin();
			
			//set images paths.
			for(var i=0; i<self.totalImages; i++){
				self.imagesPaths_ar[i] = self.playListData_ar[i].smallImagePath;
				if(self.showLargeImageVersionOnZoom_bl) self.largeImagesPaths_ar[i] = self.playListData_ar[i].largeImagePath;
				if(self.showNavigator_bl) self.navigatorImagesPaths_ar[i] = self.playListData_ar[i].navigatorImagePath;
			}
		};
		
		//####################################//
		/* load buttons graphics */
		//###################################//
		self.loadSkin = function(){
		
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.skinPaths_ar[self.countLoadedSkinImages];
			
			self.image_img = new Image();
			self.image_img.onload = self.onSkinLoadHandler;
			self.image_img.onerror = self.onKinLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onSkinLoadHandler = function(e){
		
			if(self.countLoadedSkinImages == 0){
				self.mainPreloader_img = self.image_img;
				self.dispatchEvent(FWDData.PRELOADER_LOAD_DONE);
			}else if(self.countLoadedSkinImages == 1){
				self.mainLightboxCloseButtonN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 2){
				self.mainLightboxCloseButtonS_img = self.image_img;
				self.dispatchEvent(FWDData.LIGHBOX_CLOSE_BUTTON_LOADED);
			}else if(self.countLoadedSkinImages == 3){
				self.controllerBackgroundLeft_img = self.image_img;
				self.controllerHeight = self.controllerBackgroundLeft_img.height;
			}else if(self.countLoadedSkinImages == 4){
				self.controllerBackgroundRight_img = self.image_img;
			}else if(self.countLoadedSkinImages == 5){
				self.controllerPanN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 6){
				self.controllerPanS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 7){
				self.controllerRotateN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 8){
				self.controllerRotateS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 9){
				self.controllerNextN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 10){
				self.controllerNextS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 11){
				self.controllerPrevN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 12){
				self.controllerPrevS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 13){
				self.controllerPlayN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 14){
				self.controllerPlayS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 15){
				self.controllerPauseN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 16){
				self.controllerPauseS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 17){
				self.controllerInfoN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 18){
				self.controllerInfoS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 19){
				self.controllerLinkN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 20){
				self.controllerLinkS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 21){
				self.controllerFullScreenNormalN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 22){
				self.controllerFullScreenNormalS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 23){
				self.controllerFullScreenFullN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 24){
				self.controllerFullScreenFullS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 25){
				self.zoomInN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 26){
				self.zoomInS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 27){
				self.zoomOutN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 28){
				self.zoomOutS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 29){
				self.scrollBarHandlerN_img = self.image_img;
			}else if(self.countLoadedSkinImages == 30){
				self.scrollBarHandlerS_img = self.image_img;
			}else if(self.countLoadedSkinImages == 31){
				self.scrollBarLeft_img = self.image_img;
			}else if(self.countLoadedSkinImages == 32){
				self.scrollBarRight_img = self.image_img;
			}else if(self.countLoadedSkinImages == 33){
				self.toolTipPointer_img = self.image_img;
			}else if(self.countLoadedSkinImages == 34){
				self.toolTipLeft_img = self.image_img;
			}else if(self.countLoadedSkinImages == 35){
				self.infoWindowCloseNormal_img = self.image_img;
			}else if(self.countLoadedSkinImages == 36){
				self.infoWindowCloseSelected_img = self.image_img;
			}
			
			self.dispatchEvent(FWDData.SKIN_PROGRESS, {percent:self.countLoadedSkinImages/self.totalGraphics});
			
			self.countLoadedSkinImages++;
			if(self.countLoadedSkinImages < self.totalGraphics){
				self.loadImageId_to = setTimeout(self.loadSkin, 16);
			}else{
				self.dispatchEvent(FWDData.SKIN_PROGRESS, {percent:self.countLoadedSkinImages/self.totalGraphics});
				self.dispatchEvent(FWDData.LOAD_DONE);
				if(self.showNavigator_bl){
					self.loadNavigatorFirstImage();
				}else{
					self.loadImages();
				}
			}
		};
		
		self.onKinLoadErrorHandler = function(e){
			var message = "The skin graphics with the label <font color='#FFFFFF'>" + self.skinPaths_ar[self.countLoadedSkinImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			console.log(e);
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
		};
		
		self.stopToLoad = function(){
			clearTimeout(self.loadImageId_to);
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			if(self.navigatorImage_img){
				self.navigatorImage_img.onload = null;
				self.navigatorImage_img.onerror = null;
			}
		};
		
		//####################################//
		/* load navigator images */
		//###################################//
		self.loadNavigatorFirstImage = function(){
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.navigatorImagesPaths_ar[0];
			self.image_img = new Image();
			self.image_img.onload = self.onFirstNavigatorImageLoadHandler;
			self.image_img.onerror = self.onImageLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onFirstNavigatorImageLoadHandler = function(){
			self.navigatorImages_ar.push(self.image_img);
			self.navigatorWidth = self.image_img.width;
			self.navigatorHeight = self.image_img.height;
			self.loadImages();
		};
		
		//####################################//
		/* load small images */
		//###################################//
		self.loadImages = function(){
			if(self.hasNavigatorError_bl) return;
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
			}
			
			var imagePath = self.imagesPaths_ar[self.countLoadedImages];
			self.image_img = new Image();
			self.image_img.onload = self.onImageLoadHandler;
			self.image_img.onerror = self.onImageLoadErrorHandler;
			self.image_img.src = imagePath;
		};
		
		self.onImageLoadHandler = function(e){
			
			if(self.countLoadedImages == 0) self.dispatchEvent(FWDData.FIRST_IMAGE_LOAD_COMPLETE);
				
			self.images_ar.push(self.image_img);
			
			self.dispatchEvent(FWDData.IMAGE_LOADED, {id:self.countLoadedImages});
			self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
			
			if(self.showNavigator_bl && self.countLoadedImages !=0){
				self.navigatorImage_img = new Image();
				self.navigatorImages_ar.push(self.navigatorImage_img);
				if(self.countLoadedImages == self.totalImages - 1) self.navigatorImage_img.onload = self.onLastNavigatorImageLoadHandler;
				self.navigatorImage_img.onerror = self.onNavigatorImageLoadErrorHandler;
				self.navigatorImage_img.src = self.navigatorImagesPaths_ar[self.countLoadedImages];
			}
			
			self.countLoadedImages++;
			if(self.countLoadedImages < self.totalImages){
				self.loadImageId_to = setTimeout(self.loadImages, 40);
			}else{
				if(!self.showNavigator_bl){
					self.areAllImagesLoaded_bl = true;
					self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
					self.dispatchEvent(FWDData.IMAGES_LOAD_COMPLETE);
				}
			}
		};
		
		self.onLastNavigatorImageLoadHandler = function(e){
			if(self == null) return;
			self.areAllImagesLoaded_bl = true;
			self.dispatchEvent(FWDData.IMAGES_PROGRESS, {percent:self.countLoadedImages/self.totalImages});
			self.dispatchEvent(FWDData.IMAGES_LOAD_COMPLETE);
		};
		
		self.onNavigatorImageLoadErrorHandler = function(e){
			var message = "The navigator image with the label <font color='#FFFFFF'>" + self.navigatorImagesPaths_ar[self.countLoadedImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			self.hasNavigatorError_bl = true;
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
			console.log(e);
		};
		
		
		self.onImageLoadErrorHandler = function(e){
			var message = "The image with the label <font color='#FFFFFF'>" + self.imagesPaths_ar[self.countLoadedImages] + "</font> can't be loaded, make sure that the image exists and the path is correct!";
			console.log(e);
			var err = {text:message};
			self.dispatchEvent(FWDData.LOAD_ERROR, err);
		};
		
		//####################################//
		/* check if element with and attribute exists or throw error */
		//####################################//
		self.checkForAttribute = function(e, attr, position){
			var test = FWDUtils.getChildFromNodeListFromAttribute(e, attr);
			test = test ? FWDUtils.trim(FWDUtils.getAttributeValue(test, attr)) : undefined;
	
			if(!test){
				if(position != undefined){
					self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Element with attribute <font color='#FFFFFF'>" + attr + "</font> is not defined at positon <font color='#FFFFFF'>" + (position + 1) + "</font>"});
				}else{
					self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Element with attribute <font color='#FFFFFF'>" + attr + "</font> is not defined."});
				}
				return;
			}
			return test;
		};
		
		//####################################//
		/* show error if a required property is not defined */
		//####################################//
		self.showPropertyError = function(error){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"The property called <font color='#FFFFFF'>" + error + "</font> is not defined."});
		};
		
		self.showMarkerError = function(error, position){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"The marker at position <font color='#FFFFFF'>" + position + "</font> dose not have defined an attribute <font color='#FFFFFF'>" + error + "</font>."});
		};
		
		self.showMarkerTypeError = function(error, position){
			self.dispatchEvent(FWDData.LOAD_ERROR, {text:"Marker type is incorrect <font color='#FFFFFF'>" + error + "</font> at position <font color='#FFFFFF'>" + position + "</font>. Accepted types are <font color='#FFFFFF'>link, tooltip, infowindow</font>."});
		};
			
		//####################################//
		/*destroy */
		//####################################//
		self.destroy = function(){
			var totalImages;
			var img_img;
		
			clearTimeout(self.parseDelayId_to);
			clearTimeout(self.loadImageId_to);
			
			if(self.image_img){
				self.image_img.onload = null;
				self.image_img.onerror = null;
				self.image_img.src = null;
			}
			
			if(self.navigatorImage_img){
				self.navigatorImage_img.onload = null;
				self.navigatorImage_img.onerror = null;
				self.navigatorImage_img.src = null;
			}
			
			totalImages = self.images_ar.length;
			for(var i=0; i<totalImages; i++){
				img_img = self.images_ar[i];
				img_img.onerror = null;
				img_img.onload = null;
				img_img.src = null;
				img_img = null;
			}
			
			totalImages = self.navigatorImages_ar.length;
			for(var i=0; i<totalImages; i++){
				img_img = self.navigatorImages_ar[i];
				img_img.onerror = null;
				img_img.onload = null;
				img_img.src = null;
				img_img = null;
			}
			
			if(self.mainPreloader_img) self.mainPreloader_img.src = null;
			if(self.mainLightboxCloseButtonN_img) self.mainLightboxCloseButtonN_img.src = null;
			if(self.mainLightboxCloseButtonS_img) self.mainLightboxCloseButtonS_img.src = null;
			if(self.controllerBackgroundLeft_img) self.controllerBackgroundLeft_img.src = null; 
			if(self.controllerBackgroundRight_img) self.controllerBackgroundRight_img.src = null; 
			if(self.controllerPanN_img) self.controllerPanN_img.src = null; 
			if(self.controllerPanS_img) self.controllerPanS_img.src = null;
			
			if(self.controllerRotateN_img) self.controllerRotateN_img.src = null;
			if(self.controllerRotateS_img) self.controllerRotateS_img.src = null;
			if(self.controllerNextN_img) self.controllerNextN_img.src = null;
			if(self.controllerNextS_img) self.controllerNextS_img.src = null;
			if(self.controllerPrevN_img) self.controllerPrevN_img.src = null;
			if(self.controllerPrevS_img) self.controllerPrevS_img.src = null;
			if(self.controllerPlayN_img) self.controllerPlayN_img.src = null;
			if(self.controllerPlayS_img) self.controllerPlayS_img.src = null;
			if(self.controllerPauseN_img) self.controllerPauseN_img.src = null;
			if(self.controllerPauseS_img) self.controllerPauseS_img.src = null;
			if(self.controllerInfoN_img) self.controllerInfoN_img.src = null;
			if(self.controllerLinkN_img) self.controllerLinkN_img.src = null;
			if(self.controllerLinkS_img) self.controllerLinkS_img.src = null;
			if(self.controllerFullScreenNormalN_img) self.controllerFullScreenNormalN_img.src = null;
			if(self.controllerFullScreenNormalS_img) self.controllerFullScreenNormalS_img.src = null;
			if(self.controllerFullScreenFullN_img) self.controllerFullScreenFullN_img.src = null;
			if(self.controllerFullScreenFullS_img) self.controllerFullScreenFullS_img.src = null;
			if(self.zoomInN_img) self.zoomInN_img.src = null;
			if(self.zoomInS_img) self.zoomInS_img.src = null;
			if(self.zoomOutN_img) self.zoomOutN_img.src = null;
			if(self.zoomOutS_img) self.zoomOutS_img.src = null;
			if(self.scrollBarHandlerN_img) self.scrollBarHandlerN_img.src = null;
			if(self.scrollBarHandlerN_img) self.scrollBarHandlerN_img.src = null;
			if(self.scrollBarHandlerS_img) self.scrollBarHandlerS_img.src = null;
			if(self.scrollBarLeft_img) self.scrollBarLeft_img.src = null;
			if(self.scrollBarLeft_img) self.scrollBarLeft_img.src = null;
			if(self.scrollBarRight_img) self.scrollBarRight_img.src = null;
			if(self.toolTipLeft_img) self.toolTipLeft_img.src = null;
			if(self.toolTipPointer_img) self.toolTipPointer_img.src = null;
			if(self.infoWindowCloseNormal_img) self.infoWindowCloseNormal_img.src = null;
			if(self.infoWindowCloseSelected_img) self.infoWindowCloseSelected_img.src = null;
	
			
			self.mainPreloader_img = null;
			self.mainLightboxCloseButtonN_img = null;
			self.mainLightboxCloseButtonS_img = null;
			self.controllerBackgroundLeft_img = null;
			self.controllerBackgroundRight_img = null;
			self.controllerPanN_img = null;
			self.controllerPanS_img = null;
			self.controllerRotateN_img = null;
			self.controllerRotateS_img = null;
			self.controllerNextN_img = null;
			self.controllerNextS_img = null;
			self.controllerPrevN_img = null;
			self.controllerPrevS_img = null;
			self.controllerPlayN_img = null;
			self.controllerPlayS_img = null;
			self.controllerPauseN_img = null;
			self.controllerPauseS_img = null;
			self.controllerInfoN_img = null;
			self.controllerInfoS_img = null;
			self.controllerLinkN_img = null;
			self.controllerLinkS_img = null;
			self.controllerFullScreenNormalN_img = null;
			self.controllerFullScreenNormalS_img = null;
			self.controllerFullScreenFullN_img = null;
			self.controllerFullScreenFullS_img = null;
			self.zoomInN_img = null;
			self.zoomInS_img = null;
			self.zoomOutN_img = null;
			self.zoomOutS_img = null;
			self.scrollBarHandlerN_img = null;
			self.scrollBarHandlerS_img = null;
			self.scrollBarLeft_img = null;
			self.scrollBarRight_img = null;
			self.toolTipLeft_img = null;
			self.toolTipPointer_img = null;
			self.infoWindowCloseNormal_img = null;
			self.infoWindowCloseSelected_img = null;
			
			this.props_obj = null;
			this.rootElement_el = null;
			this.skinPaths_ar = null;
			this.playListData_ar = null;
			this.imagesPaths_ar = null;
			this.largeImagesPaths_ar = null;
			this.navigatorImagesPaths_ar = null ;
			this.images_ar = null;
			this.navigatorImages_ar = null;
			this.markersList_ar = null;
			this.markersPosition_ar = null;
			this.buttons_ar = null;
			this.buttonsLabels_ar = null;
			this.contextMenuLabels_ar = null;
			
			this.backgroundColor_str = null;
			this.handMovePath_str = null;
			this.handGrabRotatePath_str = null;
			this.controllerBackgroundMiddlePath_str = null;
			this.scrollBarMiddlePath_str = null;
			this.startDraggingMode_str = null;
			this.controllerPosition_str = null;
			this.preloaderFontColor_str = null;
			this.preloaderBackgroundColor_str = null;
			this.preloaderText_str = null;
			this.buttonToolTipLeft_str = null;
			this.buttonToolTipMiddle_str = null;
			this.buttonToolTipRight_str = null;
			this.buttonToolTipBottomPointer_str = null;
			this.buttonToolTipTopPointer_str = null;
			this.buttonToolTipFontColor_str = null;
			this.link_str = null;
			this.contextMenuBackgroundColor_str = null;
			this.contextMenuBorderColor_str = null;
			this.contextMenuSpacerColor_str = null;
			this.contextMenuItemNormalColor_str = null;
			this.contextMenuItemSelectedColor_str = null;
			this.contextMenuItemSelectedColor_str = null;
			this.contextMenuItemDisabledColor_str = null;
			this.navigatorPosition_str = null;
			this.navigatorHandlerColor_str = null;
			this.navigatorBorderColor_str = null;
			this.infoText_str = null;
			this.infoWindowBackgroundColor_str = null;
			this.infoWindowScrollBarColor_str = null;
			
			prototype.destroy();
			self = null;
			prototype = null;
			FWDData.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
	FWDData.setPrototype = function(){
		FWDData.prototype = new FWDEventDispatcher();
	};
	
	FWDData.prototype = null;
	FWDData.PRELOADER_LOAD_DONE = "onPreloaderLoadDone";
	FWDData.LOAD_DONE = "onLoadDone";
	FWDData.LOAD_ERROR = "onLoadError";
	FWDData.LIGHBOX_CLOSE_BUTTON_LOADED = "onLightBoxCloseButtonLoadDone";
	FWDData.IMAGE_LOADED = "onImageLoaded";
	FWDData.FIRST_IMAGE_LOAD_COMPLETE = "onFirstImageLoadComplete";
	FWDData.IMAGES_LOAD_COMPLETE = "onImagesLoadComplete";
	FWDData.SKIN_PROGRESS = "onSkinProgress";
	FWDData.IMAGES_PROGRESS = "onImagesPogress";
	FWDData.hasTouch_bl = false;
	
	window.FWDData = FWDData;
}(window));